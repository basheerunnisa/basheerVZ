/**
 * 
 */
package com.vz.uiam.inventory.equipment;

import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.Filter;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.vz.uiam.common.usermanagement.rest.model.DirDomainsDTO;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EquipmentSpec;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Site;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentSpecRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.SiteRepository;
import com.vz.uiam.inventory.equipment.model.EquipmentDTO;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.model.SlotDTO;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateTestCommon;
import com.vz.uiam.inventory.instance.rest.api.client.InventoryAttributesControllerClientInstance;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;

/**
 * @author Karthik Amarnath
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = EquipTpltCreateApplication.class)
@WebAppConfiguration
public class EquipmentControllerTest extends InstanceEquipmentCreateTestCommon {

	private static final Logger LOGGER = LoggerFactory.getLogger(EquipmentControllerTest.class);
	private static final String TEST_IP_ADDRESS = "10.11.12.14";
	private static final String RACK_ADD_PATH = "/equipment/rack/v1";
	private static final String SHELF_ADD_PATH = "/inventory/equipments/shelf/create/v1";
	private static final String SHELF_ADD_PATH_V2 = "/inventory/equipments/shelf/create/v2";
	private static final String EQUIPMENT = "EQUIPMENT";
	private static final String NAME = "USER_ID";
	private static final String VALUE = "VZ456764";

	@Autowired
	private WebApplicationContext wac;
	@Autowired
	private Filter springSecurityFilterChain;
	@Autowired
	private EquipmentSpecRepository equipmentSpecRepository;
	@Autowired
	private EquipmentRepository equipmentRepository;
	@Autowired
    private SiteRepository siteRepository;
	@Autowired
	private String svcUserName;
	@Autowired
	private String svcPassword;
	
	@Mock
	private InventoryAttributesControllerClientInstance specificationAttributesClient;
	
	private MockRestServiceServer mockServer;
	private MockMvc mockMvc;	
	
	@Bean
	RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).defaultRequest(post("/")
									  .with(httpBasic(svcUserName, svcPassword)))
									  .addFilters(springSecurityFilterChain).build();
		
		mockServer = MockRestServiceServer.createServer(restTemplate());
	}
	
	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testCreateShelf() {

		EquipmentDTOV1 equipment = new EquipmentDTOV1();
		setDataCreateShelf(equipment);
		
		Equipment rack = equipmentRepository.findByEqpName("EQP_CREATE_E").stream().findAny().orElse(null);
		equipment.setparentEqReference(rack != null ? rack.getEqpReferenceId() : 1L);
		equipment.setName("EQP_CREATE_E1");
		
		try {	
			this.mockMvc.perform(post(SHELF_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isOk());

		} catch (Exception e) {
			LOGGER.error("Exception in testCreateShelf | {}", e);
		}
		mockServer.verify();
	}
	
	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeCsrEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterCsrEquipSpecTest.sql") })
	public void testCreateShelfCSR() {

		EquipmentDTOV1 equipment = new EquipmentDTOV1();
		setDataCreateCSRShelf(equipment);
		
		Equipment rack = equipmentRepository.findByEqpName("EQP_CREATE_E").stream().findAny().orElse(null);
		equipment.setparentEqReference(rack != null ? rack.getEqpReferenceId() : 1L);
		equipment.setName("EQP_CREATE_E1");
		
		try {	
			this.mockMvc.perform(post(SHELF_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isOk());

		} catch (Exception e) {
			LOGGER.error("Exception in testCreateShelfCSR | {}", e);
		}
		mockServer.verify();
	}

	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testCreateShelfWithSlots() {

		EquipmentDTOV1 equipment = new EquipmentDTOV1();
		setDataCreateShelfWithSlots(equipment);
		
		Equipment rack = equipmentRepository.findByEqpName("EQP_CREATE_E").stream().findAny().orElse(null);
		equipment.setparentEqReference(rack != null ? rack.getEqpReferenceId() : 1L);
		equipment.setName("EQP_CREATE_E1");
		
		try {
			this.mockMvc.perform(post(SHELF_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isOk());

		} catch (Exception e) {
			LOGGER.error("Exception in testCreateShelfWithSlots | {}", e);
		}
		mockServer.verify();
	}

	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testCreateShelfWithDomainNames() {

		EquipmentDTOV1 equipment = new EquipmentDTOV1();
		setDataCreateShelf(equipment);

		Equipment rack = equipmentRepository.findByEqpName("EQP_CREATE_E").stream().findAny().orElse(null);
		equipment.setparentEqReference(rack != null ? rack.getEqpReferenceId() : 1L);
		equipment.setName("EQP_CREATE_E1");
		equipment.setDomianNames(makeDomains("ONET"));
		
		try {
			this.mockMvc.perform(post(SHELF_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isOk());

		} catch (Exception e) {
			LOGGER.error("Exception in testCreateShelfWithDomainNames", e);
		}
		mockServer.verify();
	}

	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testCreateShelfNegative() {

		EquipmentDTOV1 equipment = new EquipmentDTOV1();
		setDataCreateShelf(equipment);
		
		equipment.setName("EQP_CREATE_E");
		equipment.setcontainer(null);
		try {
			this.mockMvc.perform(post(SHELF_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isBadRequest());

		} catch (Exception e) {
			LOGGER.error("Exception in testCreateShelfNegative", e);
		}
		mockServer.verify();
	}

	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testCreateShelfNoRack() {

		EquipmentDTOV1 equipment = new EquipmentDTOV1();
		setDataCreateShelf(equipment);
		
		Equipment rack = equipmentRepository.findByEqpName("EQP_CREATE_E").stream().findAny().orElse(null);
		equipment.setparentEqReference(rack != null ? rack.getEqpReferenceId() : 1L);
		equipment.setName("EQP_CREATE_E1");
		equipment.setDomianNames(makeDomains("ONET"));
		
		try {
			this.mockMvc.perform(post(SHELF_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isOk());

		} catch (Exception e) {
			LOGGER.error("Exception in testCreateShelfNoRack", e);
		}
		mockServer.verify();
	}

	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testaddRackWithDomainNames() {
		
		EquipmentDTO equipment = new EquipmentDTO();
		setDataAddRack(equipment);
		
		EquipmentSpec equipmentSpec = equipmentSpecRepository.findByName("EQP_CREATE_ES");
		equipment.setTemplateReference(equipmentSpec != null ? equipmentSpec.getEquipmentSpecRefId().intValue() : null);
		equipment.setDomianNames(makeDomains("ONET"));
		equipment.setName("EQP_CREATE_E1");
		
		try {
			this.mockMvc.perform(post(RACK_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isOk());
			
		} catch (Exception e) {
			LOGGER.error("Exception in testaddRackWithDomainNames", e);
		}
		mockServer.verify();
	}

	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testaddRack() {
		
		EquipmentDTO equipment = new EquipmentDTO();
		setDataAddRack(equipment);
		
		EquipmentSpec equipmentSpec = equipmentSpecRepository.findByName("EQP_CREATE_ES");
		equipment.setTemplateReference(equipmentSpec != null ? equipmentSpec.getEquipmentSpecRefId().intValue() : null);
		equipment.setName("EQP_CREATE_E9");
		
		try {
			this.mockMvc.perform(post(RACK_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isOk());
			
		} catch (Exception e) {
			LOGGER.error("Exception in testaddRack", e);
		}
		mockServer.verify();
	}
	
	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testaddRackWithAttributes() {
		EquipmentDTO equipment = new EquipmentDTO();
		setDataAddRack(equipment);
		
		EquipmentSpec equipmentSpec = equipmentSpecRepository.findByName("EQP_CREATE_ES");
		equipment.setTemplateReference(equipmentSpec.getEquipmentSpecRefId().intValue());
		equipment.setName("EQP_CREATE_E1");
		
		List<AttributesDTO> attributes = makeAttributes("EqpDes", "", "");
		equipment.setAttributeList(attributes);
		
		try {
			when(specificationAttributesClient.insertInventoryAttributes(eq(EQUIPMENT), (Long) anyObject(), eq(attributes))).thenReturn(attributes);
			this.mockMvc.perform(post(RACK_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isOk());
		} catch (Exception e) {
			LOGGER.error("Exception in testaddRackWithAttributes", e);
		}
		mockServer.verify();
	}
	
	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testaddRackWithAttributes1() {
		
		EquipmentDTO equipment = new EquipmentDTO();
		setDataAddRack(equipment);
		
		EquipmentSpec equipmentSpec = equipmentSpecRepository.findByName("EQP_CREATE_ES");
		equipment.setTemplateReference(equipmentSpec != null ? equipmentSpec.getEquipmentSpecRefId().intValue() : null);
		equipment.setName("EQP_CREATE_E1");
		
		List<AttributesDTO> attributes = makeAttributes(null, "Frame", "POTN");
		equipment.setAttributeList(attributes);
		
		try {
			when(specificationAttributesClient.insertInventoryAttributes(eq(EQUIPMENT), (Long) anyObject(), eq(attributes))).thenReturn(attributes);
			this.mockMvc.perform(post(RACK_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isOk());
			
		} catch (Exception e) {
			LOGGER.error("Exception in testaddRackWithAttributes1", e);
		}
		mockServer.verify();
	}

	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testaddRack400error() {
		
		EquipmentDTO equipment = new EquipmentDTO();
		setDataAddRack(equipment);

		equipment.setName("TESTINGADDRACK");
		
		try {
			this.mockMvc.perform(post(RACK_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isBadRequest());
			
		} catch (Exception e) {
			LOGGER.error("Exception in testaddRack400error", e);
		}
	}

	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testaddRack400error1() {
		
		EquipmentDTO equipment = new EquipmentDTO();
		setDataAddRack(equipment);
		equipment.setTemplateReference(15433);
		equipment.setFrame("");
		
		try {
			this.mockMvc.perform(post(RACK_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isBadRequest());
			
		} catch (Exception e) {
			LOGGER.error("Exception in testaddRack400error1", e);
		}
		mockServer.verify();
	}

	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecNoParentCardTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testCreateEquipmentNoEquipSpec() {

		EquipmentDTO equipment = new EquipmentDTO();
		setDataAddRack(equipment);
		equipment.setTemplateReference(0);
		
		try {
			this.mockMvc.perform(post(RACK_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isBadRequest());
			
		} catch (Exception e) {
			LOGGER.error("Exception in testCreateEquipmentNoEquipSpec", e);
		}
		mockServer.verify();
	}
		
	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testCreateShelfwithClliInput() {

		EquipmentDTOV1 equipment = new EquipmentDTOV1();
		setDataCreateShelf(equipment);
			
		Equipment rack = equipmentRepository.findByEqpName("EQP_CREATE_E").stream().findAny().orElse(null);
		equipment.setparentEqReference(rack != null ? rack.getEqpReferenceId() : 1L);
		equipment.setName("EQP_CREATE_E1");
		equipment.setClli("TESTCLLI");
		equipment.setsiteReference(null);
		
		try {
			this.mockMvc.perform(post(SHELF_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isOk());

		} catch (Exception e) {
			LOGGER.error("Exception in testCreateShelfwithClliInput", e);
		}
		mockServer.verify();
	}	
	
	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testCreateShelfwithClliAndSiteRefernceIdInput() {

		EquipmentDTOV1 equipment = new EquipmentDTOV1();
		setDataCreateShelf(equipment);			
		
		Equipment rack = equipmentRepository.findByEqpName("EQP_CREATE_E").stream().findAny().orElse(null);
		equipment.setparentEqReference(rack != null ? rack.getEqpReferenceId() : 1L);
		equipment.setName("EQP_CREATE_E1");
		equipment.setClli("TESTCLLI");
		
		try {
			this.mockMvc.perform(post(SHELF_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isOk());

		} catch (Exception e) {
			LOGGER.error("Exception in testCreateShelfwithClliAndSiteRefernceIdInput", e);
		}
		mockServer.verify();
	}	
		
	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testCreateShelfwithClliNullAndSiteRefernceIdNull() {

		EquipmentDTOV1 equipment = new EquipmentDTOV1();
		setDataCreateShelf(equipment);
		
		Equipment rack = equipmentRepository.findByEqpName("EQP_CREATE_E").stream().findAny().orElse(null);
		equipment.setparentEqReference(rack != null ? rack.getEqpReferenceId() : 1L);
		equipment.setName("EQP_CREATE_E1");			
		equipment.setsiteReference(null);
		equipment.setClli(null);
		
		try {
			this.mockMvc.perform(post(SHELF_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isBadRequest());

		} catch (Exception e) {
			LOGGER.error("Exception in testCreateShelf", e);
		}
		mockServer.verify();
	}
	
	@Test
	public void testCreateShelfsWithInvalidInput() {

		List<EquipmentDTOV1> eqpList = Arrays.asList(new EquipmentDTOV1[]{
				new EquipmentDTOV1()
		});
		
		try {
			this.mockMvc.perform(post(SHELF_ADD_PATH_V2).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(eqpList))).andExpect(status().isBadRequest());

		} catch (Exception e) {
			LOGGER.error("Exception in testCreateShelfsWithInvalidInput", e);
		}
		mockServer.verify();
	}
	
	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testCreateShelfswithValidInput() {

		EquipmentDTOV1 equipment = new EquipmentDTOV1();
		setDataCreateShelf(equipment);
		
		Equipment rack = equipmentRepository.findByEqpName("EQP_CREATE_E").stream().findAny().orElse(null);
		equipment.setparentEqReference(rack != null ? rack.getEqpReferenceId() : 1L);
		equipment.setName("EQP_CREATE_E1");	
		equipment.setsiteReference(null);
		equipment.setClli(null);
		
		List<EquipmentDTOV1> eqpList = Arrays.asList(new EquipmentDTOV1[]{
				equipment
		});
		
		try {
			this.mockMvc.perform(post(SHELF_ADD_PATH_V2).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(eqpList))).andExpect(status().isBadRequest());

		} catch (Exception e) {
			LOGGER.error("Exception in testCreateShelfswithValidInput", e);
		}
		mockServer.verify();
	}
	
	// Helper Methods
	
	private List<AttributesDTO> makeAttributes(String descptName, String entityType, String functionalType){
		
        AttributesDTO attributesDTO = new AttributesDTO();
        attributesDTO.setAttrGroupName("EqpGroup");
        attributesDTO.setAttrInvDescptName(descptName);
        attributesDTO.setAttrName("EATTR");
        attributesDTO.setAttrValue("TARA");
        attributesDTO.setEntityName("");
        attributesDTO.setEntityType(entityType);
        attributesDTO.setFunctionalType(functionalType);
        attributesDTO.setReferenceId(0L);
         
        return new ArrayList<>(Arrays.asList(new AttributesDTO[]{attributesDTO}));
	}
	
	private List<DirDomainsDTO> makeDomains(String... names){
		
		List<DirDomainsDTO> domains = new ArrayList<>();
		
		for(String s : names){	
			DirDomainsDTO d = new DirDomainsDTO();
			d.setDomainName(s);
			domains.add(d);
		}
		return domains;
	}
	
	private void setDataCreateCSRShelf(EquipmentDTOV1 equipment) {
		
		Site site = siteRepository.findBySiteName("TEST_SITE1");
		EquipmentSpec equipmentSpec = equipmentSpecRepository.findByName("EQP_CREATE_ES");
		
		equipment.setcontainer("SHELF");
		equipment.setsiteReference(site.getSiteReferenceId());
		equipment.setTemplateReference(equipmentSpec.getEquipmentSpecRefId());
		equipment.setVendor("ALCATEL-LUCENT");
		equipment.setType("CSR");
		equipment.setPhysicalShelf("1");
	}
	
	
	private void setDataCreateShelf(EquipmentDTOV1 equipment) {
		
		EquipmentSpec equipmentSpec = equipmentSpecRepository.findByName("EQP_CREATE_ES");
		Site site = siteRepository.findBySiteName("TEST_SITE1");
		
		equipment.setShelfName("Shelf/15");
		equipment.setcontainer("SHELF");
		equipment.setTemplateReference(equipmentSpec.getEquipmentSpecRefId());
		equipment.setType("CIENA_T6500");
		equipment.setsiteReference(site.getSiteReferenceId());
		equipment.setparentEqReference(1L);
		equipment.setTargetId("Test91");
		equipment.setAid("01/02");
		equipment.setIpAddress(TEST_IP_ADDRESS);
		equipment.setPhysicalShelf("1");
	}
	
	private void setDataCreateShelfWithSlots(EquipmentDTOV1 equipment) {
		
		EquipmentSpec equipmentSpec = equipmentSpecRepository.findByName("EQP_CREATE_ES");
		Site site = siteRepository.findBySiteName("TEST_SITE1");
		
		equipment.setShelfName("Shelf/15");
		equipment.setcontainer("SHELF");
		equipment.setTemplateReference(equipmentSpec.getEquipmentSpecRefId());
		equipment.setType("CIENA_T6500");
		equipment.setsiteReference(site.getSiteReferenceId());
		equipment.setparentEqReference(1L);
		equipment.setTargetId("Test91");
		equipment.setAid("01/02");
		equipment.setIpAddress(TEST_IP_ADDRESS);
		equipment.setPhysicalShelf("1");
		
		List<SlotDTO> slotDTOList = new ArrayList<>();
		SlotDTO slotDTO = new SlotDTO();
		
		slotDTO.setAid("slot_aid");
		slotDTO.setDescription("");
		slotDTO.setDimDepth(new BigDecimal(1));
		slotDTO.setDimDistToBase(new BigDecimal(1));
		slotDTO.setDimDistToFront(new BigDecimal(1));
		slotDTO.setDimDistToLeft(new BigDecimal(1));
		slotDTO.setDimHeight(new BigDecimal(1));
		slotDTO.setDimWidth(new BigDecimal(1));
		slotDTO.setRelOrder("1");
		slotDTO.setSlotName("TEST_SLOT");
		slotDTOList.add(slotDTO);
		equipment.setSlotDTOList(slotDTOList);
	}

	private void setDataAddRack(EquipmentDTO equipmentDTO) {
		Site site = siteRepository.findBySiteName("TEST_SITE1");
		Long siteId = site.getSiteReferenceId();
		
		equipmentDTO.setContainer("RACK");
		equipmentDTO.setType("Frame");
		equipmentDTO.setStatus("AVAILABLE");
		equipmentDTO.setSiteReference(siteId.intValue());
		equipmentDTO.setParentEqReference(1);
		equipmentDTO.setParentShelfReference(1);
		equipmentDTO.setCustomerReference(1);
		equipmentDTO.setClli("TESTCLLI");
		equipmentDTO.setFrame("TEST_FRAME");
	}
}
