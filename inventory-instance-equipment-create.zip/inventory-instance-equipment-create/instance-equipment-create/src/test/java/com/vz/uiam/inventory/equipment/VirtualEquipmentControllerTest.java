/**
 * 
 */
package com.vz.uiam.inventory.equipment;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.MethodInvocationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV2;
import com.vz.uiam.inventory.equipment.model.VirtualEquipmentRequest;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateTestCommon;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = EquipTpltCreateApplication.class)
@WebAppConfiguration
public class VirtualEquipmentControllerTest extends InstanceEquipmentCreateTestCommon {

	private static final Logger LOGGER = LoggerFactory.getLogger(VirtualEquipmentControllerTest.class);
	private static final String SHELF_ADD_PATH = "/inventory/equipments/virtual/create";
	
	private MockMvc mockMvc;

	private MockRestServiceServer mockServer;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private Filter springSecurityFilterChain;

	@Autowired
	EquipmentRepository equipmentRepository;
	
	private String name;
	private String value;
	

	@Bean
	RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(post("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
		mockServer = MockRestServiceServer.createServer(restTemplate());
		name = "USER_ID";
		value = "AUDUTPR";
	}

	public static byte[] convertObjectToJsonBytes(Object object) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}
	
	
	@Test
	@SqlGroup({ @Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeVirtualEquipTest.sql"),
			@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterVirtualEquipTest.sql") })
	public void testCreateVirtualShelf() {

		try {
			
			List<Equipment> testEqpList = equipmentRepository.findByEqpName("EQP_CREATE_VE");
			Equipment testEquip = null;
			if(!testEqpList.isEmpty())
				testEquip = testEqpList.get(0);

			VirtualEquipmentRequest equipReq = setRequestDataCreateShelf(testEquip);
			
			this.mockMvc.perform(post(SHELF_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(name, value)
					.content(convertObjectToJsonBytes(equipReq))).andExpect(status().isOk());
			URI url = new URI("/inventory/equipments/virtual/"+testEquip.getEqpReferenceId());
			ResultActions result = this.mockMvc.perform(get(url).with(httpBasic("IVAPP", "ivapp")).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
			String response = result.andReturn().getResponse().getContentAsString();
			ObjectMapper objectMapper = new ObjectMapper();
			LOGGER.info("response : "+response);
			objectMapper.readValue(response,List.class);

		} catch (IOException e) {
			LOGGER.error("IOException in testCreateVirtualShelf", e);
		} catch (MethodInvocationException e) {
			LOGGER.error("IOException in testCreateShelf", e);
			assertTrue(false);
		} catch (Exception e) {
			LOGGER.error("Exception in testCreateVirtualShelf", e);
		}
		mockServer.verify();
	}
	
	@Test
	public void testGetVirtualEquipments() {

		try {
			
			Long phyEqpRefID = 100100L;
			
			Equipment objEquipment = new Equipment();
			objEquipment.setEqpReferenceId(1001L);
			
			Equipment objEquipment2 = new Equipment();
			objEquipment2.setEqpReferenceId(1001L);
			
			List<Equipment> virtualEquips = new ArrayList<Equipment>();
			virtualEquips.add(objEquipment);
			virtualEquips.add(objEquipment2);
			
		    when(equipmentRepository.findByPhysicalEquipmentReferenceId(phyEqpRefID)).thenReturn(virtualEquips);
			
			this.mockMvc.perform(get("/inventory/equipments/virtual/" + phyEqpRefID)
					.contentType(MediaType.APPLICATION_JSON)).andExpect(status().is(500));
			

		}catch (MethodInvocationException e) {
			LOGGER.error("IOException in testCreateShelf", e);
			assertTrue(false);
		}  catch (IOException e) {
			LOGGER.error("IOException in testCreateShelf", e);
			assertTrue(false);
		} catch (Exception e) {
			LOGGER.error("Exception in testCreateShelf", e);
		}
	}
	
	
	private VirtualEquipmentRequest setRequestDataCreateShelf(Equipment testEquip) {
		VirtualEquipmentRequest equipReq  = new VirtualEquipmentRequest();
		equipReq.setPhysicalEquipmentSpecId(testEquip.getEqpReferenceId());
		equipReq.setVirtualEquipmentTid("testVirtualEqpTID");
		equipReq.setMgmtIpAddress("10.100.10.100");
		return equipReq;
	}
	
	

	@Test
	@SqlGroup({ @Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:AfterVirtualEquipTest.sql"),
		     @Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeVirtualEquipTest.sql"),
			@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterVirtualEquipTest.sql") })
	public void testGetVirtualEquipmentsByTidPhysical() {

		try {
				List<Equipment> testEqpList = equipmentRepository.findByEqpName("EQP_CREATE_VE");
				Equipment testEquip = null;
				if(!testEqpList.isEmpty()) {
					testEquip = testEqpList.get(0);
					
					URI url = new URI("/inventory/equipments/virtual/tidPhysical/"+testEquip.getTidPhysical());
					ResultActions result = this.mockMvc.perform(get(url).with(httpBasic("IVAPP", "ivapp")).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
					String response = result.andReturn().getResponse().getContentAsString();
					ObjectMapper objectMapper = new ObjectMapper();
					LOGGER.info("response : "+response);
					
					List<EquipmentDTOV2> objEquipmentDTOV2 = objectMapper.readValue(response,new TypeReference<List<EquipmentDTOV2>>(){});
					
					assertEquals(objEquipmentDTOV2.get(0).getTargetId(), "PHYT5656");
			}
		} catch (IOException e) {
			LOGGER.error("IOException in testGetVirtualEquipmentsByTidPhysical", e);
		} catch (Exception e) {
			LOGGER.error("Exception in testGetVirtualEquipmentsByTidPhysical", e);
		}
		mockServer.verify();
	}
	
	
	@Test
	@SqlGroup({ @Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:AfterVirtualEquipTest.sql"),
		     @Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeVirtualEquipTest.sql"),
			@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterVirtualEquipTest.sql") })
	public void testGetVirtualEquipmentsByTidLogical() {

		try {
				List<Equipment> testEqpList = equipmentRepository.findByEqpName("EQP_CREATE_VE");
				Equipment testEquip = null;
				if(!testEqpList.isEmpty()) {
					testEquip = testEqpList.get(0);
					
					URI url = new URI("/inventory/equipments/virtual/tidLogical/"+testEquip.getTidLogical());
					ResultActions result = this.mockMvc.perform(get(url).with(httpBasic("IVAPP", "ivapp")).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
					String response = result.andReturn().getResponse().getContentAsString();
					ObjectMapper objectMapper = new ObjectMapper();
					LOGGER.info("response : "+response);
					EquipmentDTOV2 objEquipmentDTOV2 = objectMapper.readValue(response,EquipmentDTOV2.class);
					assertEquals(objEquipmentDTOV2.getTid_l(), "LOGIC");
			}
		} catch (IOException e) {
			LOGGER.error("IOException in testGetVirtualEquipmentsByTidLogical", e);
		} catch (Exception e) {
			LOGGER.error("Exception in testGetVirtualEquipmentsByTidLogical", e);
		}
		mockServer.verify();
	}
	
	
	}
