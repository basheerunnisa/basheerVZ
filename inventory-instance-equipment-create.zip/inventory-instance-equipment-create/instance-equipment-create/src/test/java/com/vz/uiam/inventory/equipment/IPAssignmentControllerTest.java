package com.vz.uiam.inventory.equipment;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;

import javax.servlet.Filter;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.inventory.instance.rest.api.model.IPAssignmentDTO;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateTestCommon;
import com.vz.uiam.inventory.instance.rest.api.client.InventoryAttributesControllerClientInstance;

/**
 * <p>
 * Service Test Class for {@link IPAssignmentController}
 * </p>
 * 
 * @date 19-Jan-2018
 * @author Patel, Chintan
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = EquipTpltCreateApplication.class)
@WebAppConfiguration
public class IPAssignmentControllerTest extends InstanceEquipmentCreateTestCommon{

	private static final Logger LOGGER = Logger.getLogger(IPAssignmentControllerTest.class);
	private static final String ASSIGN_LOOP_BACK_IP_PATH = "/inventory/equipments/assignIP";
	
	private MockMvc mockMvc;
	
	private MockRestServiceServer mockServer;
	
	@Autowired
	private WebApplicationContext wac;
	
	@Autowired
	private Filter springSecurityFilterChain;
	
	@Mock
	private InventoryAttributesControllerClientInstance specificationAttributesClient;
	
	private String name;
	private String value;

	@Bean
	RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(post("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
		mockServer = MockRestServiceServer.createServer(restTemplate());
		name = "USER_ID";
		value = "VZ456764";
	}
	
	public static byte[] convertObjectToJsonBytes(Object object) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}
	
	 /**
     * <p>
     * This scenario is used to test the Invalid equipment_ref_id
     * </p>
     */
    @Test
    public void testIPAssignment_Invalid_Equipment_Ref_Id() {
	LOGGER.info("Entering to testIPAssignment_Fail_InvalidData");
	try {
		IPAssignmentDTO ipAssignmentDTO =new IPAssignmentDTO();
		ipAssignmentDTO.setEquimentRefId("0");
	    this.mockMvc.perform(post(ASSIGN_LOOP_BACK_IP_PATH).contentType(MediaType.parseMediaType("application/json;charset=UTF-8"))
		    .content(convertObjectToJsonBytes(ipAssignmentDTO))).andExpect(status().isBadRequest());

	} catch (IOException e) {
	    LOGGER.error(JSON_PARSING_EXCEPTION, e);
	} catch (Exception e) {
	    LOGGER.error(EXCEPTION_MESSAGE, e);
	}
	mockServer.verify();
    }

    /**
     * <p>
     * This scenario is used to test the Invalid equipment_ref_id
     * </p>
     */
    @Test
    public void testIPAssignment_Invalid_Tid_Logical() {
	LOGGER.info("Entering to testIPAssignment_Fail_InvalidData");
	try {
		IPAssignmentDTO ipAssignmentDTO = new IPAssignmentDTO();
		ipAssignmentDTO.settIDLogical("TID12-LOG");
	    this.mockMvc.perform(post(ASSIGN_LOOP_BACK_IP_PATH).contentType(MediaType.parseMediaType("application/json;charset=UTF-8"))
		    .content(convertObjectToJsonBytes(ipAssignmentDTO))).andExpect(status().isBadRequest());

	} catch (IOException e) {
	    LOGGER.error(JSON_PARSING_EXCEPTION, e);
	} catch (Exception e) {
	    LOGGER.error(EXCEPTION_MESSAGE, e);
	}
	mockServer.verify();
    }
	
}
