package com.vz.uiam.inventory.equipment;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.common.usermanagement.rest.model.DirDomainsDTO;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.model.SlotDTO;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateTestCommon;
import com.vz.uiam.inventory.instance.rest.api.client.InventoryAttributesControllerClientInstance;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = EquipTpltCreateApplication.class)
@WebAppConfiguration
public class EquipmentControllerNoTemplSpecTest {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EquipmentControllerNoTemplSpecTest.class); 
	private static final String RACK_SHELF_ADD_PATH = "/inventory/equipments/shelf/createWOT/v1";
	private static final String NAME = "USER_ID";
	private static final String VALUE = "V534279";
	
	@Autowired
	private WebApplicationContext wac;
	@Autowired
	private Filter springSecurityFilterChain;
	@Autowired
	private String svcUserName;
	@Autowired
	private String svcPassword;
	@Mock
	private InventoryAttributesControllerClientInstance specificationAttributesClient; 

	private MockMvc mockMvc;
	private MockRestServiceServer mockServer;

	@Bean
	RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(wac)
				.defaultRequest(post("/").with(httpBasic(svcUserName, svcPassword)))
				.addFilters(springSecurityFilterChain).build();
		mockServer = MockRestServiceServer.createServer(restTemplate());
	}

	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql")})
	public void testCreateRack() {
		ObjectMapper mapper = new ObjectMapper();
		try {

			EquipmentDTOV1 equipment = populateRack();
			equipment.setsiteReference(InstanceEquipmentCreateTestCommon.DEFAULT_SITE_ID);
			equipment.setDomianNames(null); 
			LOGGER.info("Create RACK Request:  \n{}\n\n", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(equipment));

			this.mockMvc.perform(post(RACK_SHELF_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isOk());

		} catch (IOException e) {
			LOGGER.error("IOException in testCreateRack", e);
		} catch (Exception e) {
			LOGGER.error("Exception in testCreateRack", e);
		}
		mockServer.verify();
	}
	
	@Test
	@SqlGroup({ @Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeShelfCreate.sql"), 
	@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testCreateShelf() {
		ObjectMapper mapper = new ObjectMapper();
		try {

			EquipmentDTOV1 equipment = populateShelf();
			equipment.setName(null);
			LOGGER.info("Create SHELF Request:  \n{}\n\n", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(equipment));

			this.mockMvc.perform(post(RACK_SHELF_ADD_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(equipment))).andExpect(status().isBadRequest());
			
		} catch (IOException e) {
			LOGGER.error("IOException in testCreateShelf", e);
		} catch (Exception e) {
			LOGGER.error("Exception in testCreateShelf", e);
		}
		mockServer.verify();
	}

	public EquipmentDTOV1 populateRack() {
		EquipmentDTOV1 equipment = new EquipmentDTOV1();
		equipment.setName("EQP_CREATE_E3"); 
		equipment.setcontainer("RACK"); 
		equipment.setsiteReference(1L); 
		equipment.setEqClass("TRANSMISSION"); 
		equipment.setClli("PHLAPALOHPA1"); 
		equipment.setIpAddress("153.39.123.87"); 
		equipment.setLineUp("213"); 
		equipment.setAlternateName("PTX-LR5.VZBI.COM"); 
		equipment.setType("RACK"); 
		equipment.setShelfType("TL");
		equipment.setTid_l("153.39.123.87"); 
		equipment.setAssetOwner("One Network In Franchise*"); 
		equipment.setVendor("Saunders"); 
		equipment.setModel("10811000014"); 
		equipment.setFloor("N-A"); 
		equipment.setFrame("18");
		equipment.setStatus("PRE_INVENTORY");
		equipment.setModifiedUser("DISCOVERY"); 
		equipment.setheight(new BigDecimal(1)); 
		equipment.setwidth(new BigDecimal(1)); 
		equipment.setdepth(new BigDecimal(1)); 
		equipment.setDistToFront(new BigDecimal(1)); 
		equipment.setDistToLeft(new BigDecimal(1)); 
		equipment.setDistToBase(new BigDecimal(1)); 
		
		List<DirDomainsDTO> domianNames = new ArrayList<DirDomainsDTO>(); 
		DirDomainsDTO domianName = new DirDomainsDTO(); 
		domianName.setDomainName("ONENETWORK");
		domianName.setDescription("Desc ONENETWORK");
		domianNames.add(domianName); 
		equipment.setDomianNames(domianNames);
		
		return equipment;
	}

	public EquipmentDTOV1 populateShelf() {
		EquipmentDTOV1 equipment = new EquipmentDTOV1();
		equipment.setName("EQP_CREATE_E3");
		equipment.setcontainer("SHELF"); 
		equipment.setEqClass("SHELF"); 
		equipment.setClli("PHLAPALOHPA1"); 
		equipment.setIpAddress("153.39.123.87"); 
		equipment.setLineUp("213"); 
		equipment.setAlternateName("PTX-LR5.VZBI.COM"); 
		equipment.setType("TL"); 
		equipment.setShelfType("TL"); 
		equipment.setTid_l("153.39.123.87"); 
		equipment.setAssetOwner("One Network In Franchise*"); 
		equipment.setVendor("Juniper"); 
		equipment.setPhysicalShelf("1"); 
		equipment.setFunctionalEquipType(235L);
		equipment.setModel("PTX5000"); 
		equipment.setShelfType("ROUTER");
		equipment.setFloor("N-A"); 
		equipment.setFrame("18");
		equipment.setsiteReference(1L); 
		equipment.setStatus("PRE_INVENTORY");
		equipment.setModifiedUser("DISCOVERY"); 
		equipment.setheight(new BigDecimal(1)); 
		equipment.setwidth(new BigDecimal(1)); 
		equipment.setdepth(new BigDecimal(1)); 
		equipment.setDistToFront(new BigDecimal(1)); 
		equipment.setDistToLeft(new BigDecimal(1)); 
		equipment.setDistToBase(new BigDecimal(1)); 

		List<SlotDTO> slotDTOList = new ArrayList<SlotDTO>();
		SlotDTO slotDTO = new SlotDTO();
		slotDTO.setAid("slot_aid_1");
		slotDTO.setDescription("SLOT#1 of PTX-LR5");
		slotDTO.setDimDepth(new BigDecimal(1));
		slotDTO.setDimDistToBase(new BigDecimal(1));
		slotDTO.setDimDistToFront(new BigDecimal(1));
		slotDTO.setDimDistToLeft(new BigDecimal(1));
		slotDTO.setDimHeight(new BigDecimal(1));
		slotDTO.setDimWidth(new BigDecimal(1));
		slotDTO.setRelOrder("1");
		slotDTO.setSlotName("SLOT#1");
		slotDTO.setSlot("1");
		slotDTOList.add(slotDTO);
		
		slotDTO = new SlotDTO();
		slotDTO.setAid("slot_aid_2");
		slotDTO.setDescription("SLOT#2 of PTX-LR5");
		slotDTO.setDimDepth(new BigDecimal(1));
		slotDTO.setDimDistToBase(new BigDecimal(1));
		slotDTO.setDimDistToFront(new BigDecimal(1));
		slotDTO.setDimDistToLeft(new BigDecimal(1));
		slotDTO.setDimHeight(new BigDecimal(1));
		slotDTO.setDimWidth(new BigDecimal(1));
		slotDTO.setRelOrder("2");
		slotDTO.setSlotName("SLOT#2");
		slotDTO.setSlot("2");
		slotDTOList.add(slotDTO);
		
		equipment.setSlotDTOList(slotDTOList);
		
		List<DirDomainsDTO> domianNames = new ArrayList<DirDomainsDTO>(); 
		DirDomainsDTO domianName = new DirDomainsDTO(); 
		domianName.setDomainName("ONENETWORK");
		domianName.setDescription("Desc ONENETWORK");
		domianNames.add(domianName); 
		equipment.setDomianNames(domianNames);
		
		return equipment;
	}

	private static byte[] convertObjectToJsonBytes(Object object) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}	
}
