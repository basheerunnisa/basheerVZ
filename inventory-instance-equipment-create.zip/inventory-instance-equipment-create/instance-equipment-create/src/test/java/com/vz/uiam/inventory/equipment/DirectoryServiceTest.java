package com.vz.uiam.inventory.equipment;

import static org.junit.Assert.fail;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.vz.uiam.inventory.equipment.service.DirectoryService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = EquipTpltCreateApplication.class)
@WebAppConfiguration
public class DirectoryServiceTest {

	private static final Logger LOGGER = LoggerFactory.getLogger(DirectoryServiceTest.class);
	
	@Autowired
	private DirectoryService directoryService;

	
	@Test
	public void testFindContainer(){
		try {
			directoryService.findContainer("SHELF");
			
		} catch(Exception e){
			LOGGER.error("ERROR: Exception in testFindContainer -- {}", e);
			fail("Exception Thrown! | " + e.getMessage());
		}
	}

}
