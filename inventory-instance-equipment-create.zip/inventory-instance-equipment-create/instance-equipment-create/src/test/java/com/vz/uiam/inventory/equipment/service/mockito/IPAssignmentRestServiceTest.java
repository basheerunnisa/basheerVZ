package com.vz.uiam.inventory.equipment.service.mockito;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.inventory.equipment.model.NetworkIpv4;
import com.vz.uiam.inventory.equipment.service.IPAssignmentRestService;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateTestCommon;
import com.vz.uiam.inventory.instance.rest.api.model.AssignNextAvailNonPreassignDTO;

/**
 * <p>
 * Service Test Class for {@link IPAssignmentRestService}
 * </p>
 * 
 * @date 05-Feb-2018
 * @author Mounika
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class IPAssignmentRestServiceTest extends InstanceEquipmentCreateTestCommon {

	private static final Logger LOGGER = LoggerFactory.getLogger(IPAssignmentRestServiceTest.class);

	@InjectMocks
	private IPAssignmentRestService iPAssignmentRestService;

	@Mock
	private RestTemplate restTemplate;

	@Mock
	private ObjectMapper mapper;
	
	private AssignNextAvailNonPreassignDTO assignNextAvailNonPreassignDTO = new AssignNextAvailNonPreassignDTO();
	private NetworkIpv4 ipv4AssignmentResponse = new NetworkIpv4();

	/**
	 * <p>
	 * This method is used to set up all the related mocks data
	 * </p>
	 */
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		try {
			ipv4AssignmentResponse = fromJsonFileToJava(NETWORK_IPV4_JSON, NetworkIpv4.class);
			assignNextAvailNonPreassignDTO = fromJsonFileToJava(ASSIGN_DTO, AssignNextAvailNonPreassignDTO.class);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
	}

	/**
	 * Test method for
	 * {@link com.vz.uiam.inventory.equipment.service.IPAssignmentRestService#assignNextAvailableIp(assignNextAvailNonPreassignDTO)}
	 * 
	 */
	@Test
	public void testAssignNextAvailableIp() {
		LOGGER.info("Entering test method -> testAssignNextAvailableIp");
		try {
			// execution
			ResponseEntity<NetworkIpv4> responseEntity = new ResponseEntity<NetworkIpv4>(ipv4AssignmentResponse,
					HttpStatus.ACCEPTED);
			when(restTemplate.exchange(Matchers.anyString(), Matchers.any(HttpMethod.class),
					Matchers.<HttpEntity<?>>any(), Matchers.<Class<NetworkIpv4>>any())).thenReturn(responseEntity);
			ipv4AssignmentResponse = iPAssignmentRestService.assignNextAvailableIp(assignNextAvailNonPreassignDTO);
			// assertion
			assertNotNull(ipv4AssignmentResponse);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testAssignNextAvailableIp");

	}

	/**
	 * Test method for
	 * {@link com.vz.uiam.inventory.equipment.service.IPAssignmentRestService#assignNextAvailableIp(assignNextAvailNonPreassignDTO)}
	 * 
	 */
	@Test
	public void testAssignNextAvailableIpFailsWithHttpError() {
		LOGGER.info("Entering test method -> testAssignNextAvailableIpFailsWithHttpError");
		try {
			// execution
			when(restTemplate.exchange(Matchers.anyString(), Matchers.any(HttpMethod.class),
					Matchers.<HttpEntity<?>>any(), Matchers.<Class<NetworkIpv4>>any()))
							.thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST));
			ipv4AssignmentResponse = iPAssignmentRestService.assignNextAvailableIp(assignNextAvailNonPreassignDTO);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testAssignNextAvailableIpFailsWithHttpError");

	}

	/**
	 * Test method for
	 * {@link com.vz.uiam.inventory.equipment.service.IPAssignmentRestService#assignNextAvailableIp(assignNextAvailNonPreassignDTO)}
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testAssignNextAvailableIpFailsWithIoException() {
		LOGGER.info("Entering test method -> testAssignNextAvailableIpFailsWithIoException");
		try {
			// execution
			when(restTemplate.exchange(Matchers.anyString(), Matchers.any(HttpMethod.class),
					Matchers.<HttpEntity<?>>any(), Matchers.<Class<NetworkIpv4>>any())).thenThrow(IOException.class);
			ipv4AssignmentResponse = iPAssignmentRestService.assignNextAvailableIp(assignNextAvailNonPreassignDTO);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testAssignNextAvailableIpFailsWithIoException");

	}

	/**
	 * Test method for
	 * {@link com.vz.uiam.inventory.equipment.service.IPAssignmentRestService#assignNextAvailableIp(assignNextAvailNonPreassignDTO)}
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testAssignNextAvailableIpFailsWithException() {
		LOGGER.info("Entering test method -> testAssignNextAvailableIpFailsWithException");
		try {
			// execution
			when(restTemplate.exchange(Matchers.anyString(), Matchers.any(HttpMethod.class),
					Matchers.<HttpEntity<?>>any(), Matchers.<Class<NetworkIpv4>>any())).thenThrow(Exception.class);
			ipv4AssignmentResponse = iPAssignmentRestService.assignNextAvailableIp(assignNextAvailNonPreassignDTO);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testAssignNextAvailableIpFailsWithException");

	}
}
