package com.vz.uiam.inventory.equipment.service.mockito;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInventoryConfig;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInventoryConfigRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.instance.rest.api.model.IPAssignmentDTO;
import com.vz.uiam.inventory.equipment.model.NetworkIpv4;
import com.vz.uiam.inventory.equipment.service.AttributeSpecifiactionService;
import com.vz.uiam.inventory.equipment.service.FabricInterConnectIPAssignmentService;
import com.vz.uiam.inventory.equipment.service.IPAssignmentService;
import com.vz.uiam.inventory.equipment.service.LoopBackIPAssignmentService;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateConstant;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateTestCommon;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;
import com.vz.uiam.inventory.instance.rest.api.model.IPAssignmentResponseDTO;

/**
 * <p>
 * Service Test Class for {@link IPAssignmentService}
 * </p>
 * 
 * @date 05-Feb-2018
 * @author Mounika
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class IPAssignmentServiceTest extends InstanceEquipmentCreateTestCommon {

	private static final Logger LOGGER = LoggerFactory.getLogger(IPAssignmentRestServiceTest.class);

	@InjectMocks
	private IPAssignmentService iPAssignmentService;

	@Mock
	private AttributeSpecifiactionService attributeSpecificationService;

	@Mock
	private DirInventoryConfigRepository dirInventoryConfigRepository;

	@Mock
	private EquipmentRepository equipmentRepository;

	@Mock
	private LoopBackIPAssignmentService loopBackIPAssignmentService;

	@Mock
	private FabricInterConnectIPAssignmentService fabricInterConnectIPAssignmentService;

	private IPAssignmentDTO ipAssignmentDTO = new IPAssignmentDTO();
	private Equipment equipment = new Equipment();
	private List<List<AttributesDTO>> allRIAttributeslist = new ArrayList<>();
	private List<AttributesDTO> suRIAttrList = new ArrayList<>();
	private List<AttributesDTO> currentRIAttrList = new ArrayList<>();
	private AttributesDTO attributesDTO;
	private IPAssignmentResponseDTO iPAssignmentResponseDTO;
	private DirInventoryConfig dirInventoryConfig;
	private Map<String, String> ipAddressMap = new HashMap<>();
	private NetworkIpv4 ipv4AssignmentResponse = new NetworkIpv4();

	/**
	 * <p>
	 * This method is used to set up all the related mocks data
	 * </p>
	 */
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		try {
			ipAssignmentDTO = fromJsonFileToJava(IP_ASSIGNMENT_REQ, IPAssignmentDTO.class);
			equipment = fromJsonFileToJava(EQUIPMENT, Equipment.class);
			dirInventoryConfig = fromJsonFileToJava(DIR_INV_CONFIG_JSON, DirInventoryConfig.class);
			suRIAttrList = fromFileToJavaList(ALL_ATTR_LIST);
			currentRIAttrList = fromFileToJavaList(ALL_ATTR_LIST);
			allRIAttributeslist.add(suRIAttrList);
			allRIAttributeslist.add(currentRIAttrList);
			when(fabricInterConnectIPAssignmentService.assignP2PIPForFabricInterConnectRI(any(Equipment.class),
					any(Equipment.class))).thenReturn(allRIAttributeslist);
			when(dirInventoryConfigRepository.findByGroupNameAndConfigName(anyString(), anyString()))
					.thenReturn(dirInventoryConfig);
			ipv4AssignmentResponse = fromJsonFileToJava(NETWORK_IPV4_JSON, NetworkIpv4.class);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
	}

	/**
	 * This test method is used to assign IP for RI basis
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testAssignNextAvailableIp() {
		LOGGER.info("Entering test method -> testAssignNextAvailableIp");
		try {
			// execution
			List<Equipment> mockEqups = Mockito.mock(List.class);
			Equipment mockEqp = Mockito.mock(Equipment.class);
			when(mockEqups.get(0)).thenReturn(mockEqp);
			when(mockEqp.getEqpReferenceId()).thenReturn(equipment.getEqpReferenceId());
			when(mockEqp.getTidLogical()).thenReturn(equipment.getTidLogical());
			when(mockEqp.getEqpName()).thenReturn(equipment.getEqpName());
			when(mockEqp.getDirEqpType()).thenReturn("RACK");
			when(mockEqp.getFunctionalType()).thenReturn(equipment.getFunctionalType());
			when(equipmentRepository.findByTidLogical(anyString())).thenReturn(mockEqups);

			iPAssignmentResponseDTO = iPAssignmentService.assignIPForEquipment(ipAssignmentDTO);
			// assertion
			assertNotNull(iPAssignmentResponseDTO);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testAssignNextAvailableIp");

	}

	/**
	 * This test method is to get Equipment based on eqpRefId
	 * 
	 */
	@Test
	public void testGetEquipmentByEqpRefId() {
		LOGGER.info("Entering test method -> testGetEquipmentByEqpRefId");
		try {
			// execution
			when(equipmentRepository.findOne(anyLong())).thenReturn(equipment);
			ipAssignmentDTO.setEquimentRefId("1001");
			equipment = iPAssignmentService.getEquipment(ipAssignmentDTO);
			// assertion
			assertNotNull(equipment);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testGetEquipmentByEqpRefId");
	}

	/**
	 * This test method is used to fetch the AttrGrpName from config table based
	 * on RI instance
	 * 
	 */
	@Test
	public void testGetAttributeGroupName() {
		LOGGER.info("Entering test method -> testGetAttributeGroupName");
		String attrGrpName = null;
		try {
			// execution
			iPAssignmentService.getAttributeGroupName(InstanceEquipmentCreateConstant.LOOP_BACK, null);
			iPAssignmentService.getAttributeGroupName(InstanceEquipmentCreateConstant.SU_RI, equipment.getFunctionalType());
			attrGrpName = iPAssignmentService.getAttributeGroupName(InstanceEquipmentCreateConstant.OTHER_RI, equipment.getFunctionalType());
			// assertion
			assertNotNull(attrGrpName);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testGetAttributeGroupName");
	}

	/**
	 * This test method is used to populate attributes
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testBuildEqpAttributes() {
		LOGGER.info("Entering test method -> testBuildEqpAttributes");
		try {
			// execution
			List<Equipment> mockEqups = Mockito.mock(List.class);
			Equipment mockEqp = Mockito.mock(Equipment.class);
			when(mockEqups.get(0)).thenReturn(mockEqp);
			when(mockEqp.getEqpReferenceId()).thenReturn(equipment.getEqpReferenceId());
			when(mockEqp.getTidLogical()).thenReturn(equipment.getTidLogical());
			when(mockEqp.getEqpName()).thenReturn(equipment.getEqpName());
			when(mockEqp.getDirEqpType()).thenReturn("RACK");
			when(mockEqp.getFunctionalType()).thenReturn(equipment.getFunctionalType());
			ipAddressMap.put(InstanceEquipmentCreateConstant.SU_RI_FABRIC_INTERCONNECT_IP_ADDRESS, "137.1.1.10");
			suRIAttrList = iPAssignmentService.buildEqpAttributes(InstanceEquipmentCreateConstant.LOOP_BACK, mockEqp,
					ipAddressMap,mockEqp.getFunctionalType());
			// assertion
			assertNotNull(suRIAttrList);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testBuildEqpAttributes");
	}

	/**
	 * This test method is used to populate IP addresses for attributes
	 * 
	 */
	@Test
	public void testBuildAttributesMap() {
		LOGGER.info("Entering test method -> testBuildAttributesMap");
		try {
			iPAssignmentService.buildAttributesMap(InstanceEquipmentCreateConstant.OTHER_RI,
					ipv4AssignmentResponse.getCidrList(), ipAssignmentDTO.gettIDLogical());
			ipAddressMap = iPAssignmentService.buildAttributesMap(InstanceEquipmentCreateConstant.SU_RI,
					ipv4AssignmentResponse.getCidrList(), ipAssignmentDTO.getSuTIDLogical());
			// assertion
			assertNotNull(ipAddressMap);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testBuildAttributesMap");
	}

	/**
	 * This test method is used to get the loop back attributes
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testGetLoopBackAttributes() {
		LOGGER.info("Entering test method -> testGetLoopBackAttributes");
		try {
			// execution
			List<Equipment> mockEqups = Mockito.mock(List.class);
			Equipment mockEqp = Mockito.mock(Equipment.class);
			when(mockEqups.get(0)).thenReturn(mockEqp);
			when(mockEqp.getEqpReferenceId()).thenReturn(equipment.getEqpReferenceId());
			when(mockEqp.getTidLogical()).thenReturn(equipment.getTidLogical());
			when(mockEqp.getEqpName()).thenReturn(equipment.getEqpName());
			when(mockEqp.getDirEqpType()).thenReturn("RACK");
			when(mockEqp.getFunctionalType()).thenReturn(equipment.getFunctionalType());
			when(equipmentRepository.findByTidLogical(anyString())).thenReturn(mockEqups);

			attributesDTO = iPAssignmentService.getLoopBackIPAttributes("SU-RI-HostName",
					ipv4AssignmentResponse.getCidrList().get(0), mockEqp);
			// assertion
			assertNotNull(attributesDTO);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testGetLoopBackAttributes");

	}
	
	@Test
	public void testGetEquipment() {
		LOGGER.info("Entering test method -> testGetEquipment");
		try {
			// execution
			List<Equipment> mockEqups = Mockito.mock(List.class);
			Equipment mockEqp = Mockito.mock(Equipment.class);
			when(mockEqups.get(0)).thenReturn(mockEqp);
			when(mockEqp.getEqpReferenceId()).thenReturn(equipment.getEqpReferenceId());
			when(mockEqp.getTidLogical()).thenReturn(equipment.getTidLogical());
			when(mockEqp.getEqpName()).thenReturn(equipment.getEqpName());
			when(mockEqp.getDirEqpType()).thenReturn("RACK");
			when(mockEqp.getFunctionalType()).thenReturn(equipment.getFunctionalType());
			when(equipmentRepository.findByHostName(anyString())).thenReturn(mockEqups);
			ipAssignmentDTO.setHostName("NGPON2_HOST_NAME");
			iPAssignmentService.getEquipment(ipAssignmentDTO);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testGetEquipment");

	}
	
	@Test
	public void testGetEquipmentByTidLogical() {
		LOGGER.info("Entering test method -> testGetEquipmentByTidLogical");
		try {
			// execution
			List<Equipment> mockEqups = Mockito.mock(List.class);
			Equipment mockEqp = Mockito.mock(Equipment.class);
			when(mockEqups.get(0)).thenReturn(mockEqp);
			when(mockEqp.getEqpReferenceId()).thenReturn(equipment.getEqpReferenceId());
			when(mockEqp.getTidLogical()).thenReturn(equipment.getTidLogical());
			when(mockEqp.getEqpName()).thenReturn(equipment.getEqpName());
			when(mockEqp.getDirEqpType()).thenReturn("RACK");
			when(mockEqp.getFunctionalType()).thenReturn(equipment.getFunctionalType());
			when(equipmentRepository.findByTidLogical(anyString())).thenReturn(mockEqups);
			iPAssignmentService.getEquipment(ipAssignmentDTO);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testGetEquipmentByTidLogical");

	}
	
	@Test
	public void testGetEquipmentByEqpRef() {
		LOGGER.info("Entering test method -> testGetLoopBackAttributes");
		try {
			// execution
			List<Equipment> mockEqups = Mockito.mock(List.class);
			Equipment mockEqp = Mockito.mock(Equipment.class);
			when(mockEqups.get(0)).thenReturn(mockEqp);
			when(mockEqp.getEqpReferenceId()).thenReturn(equipment.getEqpReferenceId());
			when(mockEqp.getTidLogical()).thenReturn(equipment.getTidLogical());
			when(mockEqp.getEqpName()).thenReturn(equipment.getEqpName());
			when(mockEqp.getDirEqpType()).thenReturn("RACK");
			when(mockEqp.getFunctionalType()).thenReturn(equipment.getFunctionalType());
			when(equipmentRepository.findByEqpReferenceId(anyLong())).thenReturn(mockEqp);
			ipAssignmentDTO.setHostName(InstanceEquipmentCreateConstant.EMPTY);
			ipAssignmentDTO.settIDLogical(InstanceEquipmentCreateConstant.EMPTY);
			iPAssignmentService.getEquipment(ipAssignmentDTO);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testGetLoopBackAttributes");

	}
}
