package com.vz.uiam.inventory.equipment;


import static org.junit.Assert.fail;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.Filter;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.inventory.equipment.model.AuxiliaryDTO;
import com.vz.uiam.inventory.equipment.model.EnodebBandDTO;
import com.vz.uiam.inventory.equipment.model.EnodebDetailsDTO;
import com.vz.uiam.inventory.equipment.model.EnodebSectorDTO;
import com.vz.uiam.inventory.equipment.service.SupportEquipmentCreateService;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = EquipTpltCreateApplication.class)
@WebAppConfiguration
public class SupportEquipmentCreateTest {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SupportEquipmentCreateTest.class);
	private static final String AUX_URL = "/equipment/auxiliary";
	
	@Autowired
	private WebApplicationContext wac;
	@Autowired
	private Filter springSecurityFilterChain;
	@Autowired
	private SupportEquipmentCreateService enodebService;
	@Autowired
	private String svcUserName;
	@Autowired
	private String svcPassword;
	
	private MockMvc mockMvc;
	
	@Before
	public void setup(){
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).defaultRequest(post("/")
								 .with(httpBasic(svcUserName, svcPassword))).addFilters(springSecurityFilterChain)
								 .build();
	}
	
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeTestRunEnodebCreate.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterTestRunEnodebCreate.sql") })
	public void createEnodebSuccess() {
	
		List<EnodebDetailsDTO> requestBody = buildEnodebDetailsList();	
		try {
			enodebService.createEnodebs(requestBody);

		} catch (Exception e) {
			LOGGER.error("Exception in createEnodebSuccess", e);
			fail("Exception Thrown! " + e);
		}
	}
	
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AuxiliaryRemove.sql") })
	public void createAuxiliary() {
		List<AuxiliaryDTO> requestBody = Arrays.asList(new AuxiliaryDTO[]{
			new AuxiliaryDTO("UNQ_HOST", "jUnit-Type", "jUnit-Status", 1000L)
		});
		try {
			this.mockMvc.perform(post(AUX_URL).content(convertObjectToJsonBytes(requestBody))
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
						.andExpect(status().isOk());

		} catch (Exception e) {
			LOGGER.error("Exception in createAuxiliary", e);
			fail("Exception Thrown! " + e.getMessage());
		}
	}
	
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:AuxiliaryAdd.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AuxiliaryRemove.sql")})
	public void createAuxiliaryInvalid() {
		List<AuxiliaryDTO> requestBody = Arrays.asList(new AuxiliaryDTO[]{
			new AuxiliaryDTO("UNQ_HOST", "jUnit-Type", "jUnit-Status", -1L)
		});
		try {
			this.mockMvc.perform(post(AUX_URL).content(convertObjectToJsonBytes(requestBody))
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
						.andExpect(status().isBadRequest());

		} catch (Exception e) {
			LOGGER.error("Exception in createAuxiliary", e);
			fail("Exception Thrown! " + e.getMessage());
		}
	}
	
	private List<EnodebDetailsDTO> buildEnodebDetailsList() {
		
		List<EnodebDetailsDTO> details = new ArrayList<>();
	
		EnodebDetailsDTO enodebDetailsDTO = new EnodebDetailsDTO();	
		enodebDetailsDTO.setCellType("CEL_TYPE");
		enodebDetailsDTO.setEnodebId("999999");
		enodebDetailsDTO.setEnodebName("DOWNINGTOWN_VZW_MR9999");
		enodebDetailsDTO.setLatitude(23.45);
		enodebDetailsDTO.setLongitude(-45.99);
		
		EnodebSectorDTO sectorDetails = new EnodebSectorDTO();
		sectorDetails.setAntenaDegree(234l);
		sectorDetails.setAntenaEnvironment("Indoor");
		sectorDetails.setAzimuth(35l);
		sectorDetails.setCellId(45l);
		sectorDetails.setCenterlineFt(1L);
		sectorDetails.setCoverageArea("FULL");
		sectorDetails.setMaxGainAzimuth(54l);
		sectorDetails.setPci("pci");
		
		EnodebBandDTO band = new EnodebBandDTO();
		band.setBandClass(4L);
		sectorDetails.setBand(band);
		
		enodebDetailsDTO.setSectors(Arrays.asList(new EnodebSectorDTO[]{sectorDetails}));
		details.add(enodebDetailsDTO);
		
		return details;	
	}
	
	private static byte[] convertObjectToJsonBytes(Object object) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}	
}