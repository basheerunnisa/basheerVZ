package com.vz.uiam.inventory.equipment.service.mockito;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyMapOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvType;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvTypePk;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInventoryConfig;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInventoryConfigRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.equipment.model.NetworkIpv4;
import com.vz.uiam.inventory.equipment.model.validator.EntityValidator;
import com.vz.uiam.inventory.equipment.service.AttributeSpecifiactionService;
import com.vz.uiam.inventory.equipment.service.IPAssignmentRestService;
import com.vz.uiam.inventory.equipment.service.IPAssignmentService;
import com.vz.uiam.inventory.equipment.service.LoopBackIPAssignmentService;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateTestCommon;
import com.vz.uiam.inventory.instance.rest.api.model.AssignNextAvailNonPreassignDTO;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;
import com.vz.uiam.inventory.instance.rest.api.model.IPAssignmentDTO;

/**
 * <p>
 * Service Test Class for {@link LoopBackIPAssignmentService}
 * </p>
 * 
 * @date 19-Jan-2018
 * @author Gowtham, Rangana
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class LoopBackIPAssignmentServiceTest extends InstanceEquipmentCreateTestCommon {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoopBackIPAssignmentServiceTest.class);

	@InjectMocks
	private LoopBackIPAssignmentService loopBackIPAssignmentService;

	@Mock
	private IPAssignmentRestService ipAssignmentRestService;

	@Mock
	private AttributeSpecifiactionService attributeSpecificationService;

	@Mock
	private DirInventoryConfigRepository dirInventoryConfigRepository;

	@Mock
	private EquipmentRepository equipmentRepository;

	@Mock
	private EntityValidator entityValidator;
	
	@Mock
	private IPAssignmentService ipAssignmentService;

	private IPAssignmentDTO ipAssignmentDTO1 = new IPAssignmentDTO();
	private Equipment equipment = new Equipment();
	private NetworkIpv4 ipv4AssignmentResponse = new NetworkIpv4();
	private DirInventoryConfig dirInventoryConfig = new DirInventoryConfig();
	private AttributesDTO attributesDTO = new AttributesDTO();
	private AttributesDTO attributesDTO1 = new AttributesDTO();
	private List<AttributesDTO> attributes = new ArrayList<AttributesDTO>();
	private List<DirInvType> dirTypes = new ArrayList<DirInvType>();
	private DirInvType type = new DirInvType();
	private DirInvTypePk typePk = new DirInvTypePk();
	private List<Equipment> equipments = new ArrayList<>();
	private Equipment equipment1 = new Equipment();

	/**
	 * <p>
	 * This method is used to set up all the related mocks data
	 * </p>
	 */
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		try {
			attributesDTO.setAttrName("S_ATTR");
			attributesDTO1.setAttrName("SND_ATTR");
			attributes.add(attributesDTO);
			attributes.add(attributesDTO1);
			when(ipAssignmentService.buildEqpAttributes(anyString(),any(Equipment.class),anyMapOf(String.class,String.class),anyString())).thenReturn(attributes);
			when(attributeSpecificationService.addIpToAttributeSpecification(anyListOf(AttributesDTO.class), anyLong()))
					.thenReturn(attributes);

		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
	}

	/**
	 * Test method for
	 * {@link com.vz.uiam.inventory.equipment.service.LoopBackIPAssignmentService#assignLoopBackIPForRI(com.vz.uiam.inventory.equipment.model.IPAssignmentDTO)}
	 * 
	 */

	@Test
	public void testAssignLoopBackIPForRI() {
		LOGGER.info("Entering test method -> testAssignLoopBackIPForRI");
		try {
			// setup
			equipment.setEqpReferenceId(2L);
			equipment.setTidLogical("STR");
			equipment.setDirEqpType("S_TYPE");
			ipv4AssignmentResponse.setCidr("SID");
			dirInventoryConfig.setConfigValue("SVALUE");
			when(equipmentRepository.findByEqpReferenceId(anyLong())).thenReturn(equipment);
			when(ipAssignmentRestService.assignNextAvailableIp(any(AssignNextAvailNonPreassignDTO.class)))
					.thenReturn(ipv4AssignmentResponse);
			when(dirInventoryConfigRepository.findByGroupNameAndConfigName(anyString(), anyString()))
					.thenReturn(dirInventoryConfig);
			typePk.setType("S_TYPE");
			type.setPk(typePk);
			dirTypes.add(type);
			// execution
			loopBackIPAssignmentService.assignLoopBackIPForEqp(equipment);

		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testAssignLoopBackIPForRI");

	}

	/**
	 * Test method for
	 * {@link com.vz.uiam.inventory.equipment.service.LoopBackIPAssignmentService#assignLoopBackIPForRI(com.vz.uiam.inventory.equipment.model.IPAssignmentDTO)}
	 * 
	 */

	@Test
	public void testAssignLoopBackIPForRI_MethodFailureException() {
		LOGGER.info("Entering test method -> testAssignLoopBackIPForRI");
		try {
			// setup
			ipAssignmentDTO1.settIDLogical("ID");
			equipments.add(equipment1);
			when(equipmentRepository.findByTidLogical(anyString())).thenReturn(equipments);
			when(ipAssignmentRestService.assignNextAvailableIp(any(AssignNextAvailNonPreassignDTO.class)))
					.thenReturn(ipv4AssignmentResponse);
			when(dirInventoryConfigRepository.findByGroupNameAndConfigName(anyString(), anyString())).thenReturn(null);
			// execution
			loopBackIPAssignmentService.assignLoopBackIPForEqp(equipment1);

		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testAssignLoopBackIPForRI");

	}

	/**
	 * Test method for
	 * {@link com.vz.uiam.inventory.equipment.service.LoopBackIPAssignmentService#assignLoopBackIPForRI(com.vz.uiam.inventory.equipment.model.IPAssignmentDTO)}
	 * 
	 */

	@Test
	public void testAssignLoopBackIPForRI_Null() {
		LOGGER.info("Entering test method -> testAssignLoopBackIPForRI");
		try {
			// setup
			equipment.setEqpReferenceId(2L);
			ipv4AssignmentResponse.setCidr("SID");
			dirInventoryConfig.setConfigValue("SVALUE");
			when(equipmentRepository.findByEqpReferenceId(anyLong())).thenReturn(equipment);
			when(ipAssignmentRestService.assignNextAvailableIp(any(AssignNextAvailNonPreassignDTO.class)))
					.thenReturn(ipv4AssignmentResponse);
			when(dirInventoryConfigRepository.findByGroupNameAndConfigName(anyString(), anyString())).thenReturn(null);
			typePk.setType("S_TYPE");
			type.setPk(typePk);
			dirTypes.add(type);
			// execution
			loopBackIPAssignmentService.assignLoopBackIPForEqp(equipment);
			
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testAssignLoopBackIPForRI");

	}
	
	@Test
	public void testAssignLoopBackIPForNGPON2() {
		LOGGER.info("Entering test method -> testAssignLoopBackIPForNGPON2");
		try {
			// setup
			Equipment ngponEqp = fromJsonFileToJava(NGPON2_EQUIPMENT_JSON, Equipment.class);
			NetworkIpv4 networkIpv4 = fromJsonFileToJava(NETWORK_IPV4_JSON, NetworkIpv4.class);
			dirInventoryConfig = fromJsonFileToJava(DIR_INV_CONFIG_JSON, DirInventoryConfig.class);
			when(equipmentRepository.findByEqpReferenceId(anyLong())).thenReturn(ngponEqp);
			when(ipAssignmentRestService.assignNextAvailableIp(any(AssignNextAvailNonPreassignDTO.class)))
					.thenReturn(networkIpv4);
			when(dirInventoryConfigRepository.findByGroupNameAndConfigName(anyString(), anyString()))
					.thenReturn(dirInventoryConfig);
			// execution
			loopBackIPAssignmentService.assignLoopBackIPForEqp(ngponEqp);

		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testAssignLoopBackIPForNGPON2");

	}
	
	@Test
	public void testAssignLoopBackIPForMSERI() {
		LOGGER.info("Entering test method -> testAssignLoopBackIPForMSERI");
		try {
			// setup
			Equipment mseriEqp=fromJsonFileToJava(MSERI_EQUIPMENT_JSON, Equipment.class);
			NetworkIpv4 networkIpv4=fromJsonFileToJava(NETWORK_IPV4_JSON, NetworkIpv4.class);
			dirInventoryConfig=fromJsonFileToJava(DIR_INV_CONFIG_JSON, DirInventoryConfig.class);
	
			when(equipmentRepository.findByEqpReferenceId(anyLong())).thenReturn(mseriEqp);
			when(ipAssignmentRestService.assignNextAvailableIp(any(AssignNextAvailNonPreassignDTO.class)))
					.thenReturn(networkIpv4);
			when(dirInventoryConfigRepository.findByGroupNameAndConfigName(anyString(), anyString()))
					.thenReturn(dirInventoryConfig);
			
			// execution
			loopBackIPAssignmentService.assignLoopBackIPForEqp(mseriEqp);

		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testAssignLoopBackIPForMSERI");

	}
	
	@Test
	public void testAssignLoopBackIPForMSERIFail() {
		LOGGER.info("Entering test method -> testAssignLoopBackIPForMSERI");
		try {
			// setup
			Equipment mseriEqp=fromJsonFileToJava(MSERI_EQUIPMENT_JSON, Equipment.class);
			DirInventoryConfig dirInventoryConfig=fromJsonFileToJava(DIR_INV_CONFIG_JSON, DirInventoryConfig.class);
			when(equipmentRepository.findByEqpReferenceId(anyLong())).thenReturn(mseriEqp);
			when(dirInventoryConfigRepository.findByGroupNameAndConfigName(anyString(), anyString()))
					.thenReturn(dirInventoryConfig);
			
			// execution
			loopBackIPAssignmentService.assignLoopBackIPForEqp(mseriEqp);

		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testAssignLoopBackIPForMSERI");

	}
	
	@Test
	public void testAssignLoopBackIPForNGPON2HostName() {
		LOGGER.info("Entering test method -> testAssignLoopBackIPForNGPON2");
		try {
			// setup
			Equipment ngponEqp = fromJsonFileToJava(NGPON2_EQUIPMENT_HOSTNAME_JSON, Equipment.class);
			List<Equipment> eqpList=new ArrayList<Equipment>();
			eqpList.add(ngponEqp);
			NetworkIpv4 networkIpv4 = fromJsonFileToJava(NETWORK_IPV4_JSON, NetworkIpv4.class);
			DirInventoryConfig dirInventoryConfig = fromJsonFileToJava(DIR_INV_CONFIG_JSON, DirInventoryConfig.class);
			when(equipmentRepository.findByHostName(anyString())).thenReturn(eqpList);
			when(ipAssignmentRestService.assignNextAvailableIp(any(AssignNextAvailNonPreassignDTO.class)))
					.thenReturn(networkIpv4);
			when(dirInventoryConfigRepository.findByGroupNameAndConfigName(anyString(), anyString()))
					.thenReturn(dirInventoryConfig);
			// execution
			loopBackIPAssignmentService.assignLoopBackIPForEqp(ngponEqp);

		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testAssignLoopBackIPForNGPON2");

	}

}
