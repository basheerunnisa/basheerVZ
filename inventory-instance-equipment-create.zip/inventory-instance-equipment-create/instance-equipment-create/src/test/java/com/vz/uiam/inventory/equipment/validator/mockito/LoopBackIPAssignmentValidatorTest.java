package com.vz.uiam.inventory.equipment.validator.mockito;

import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInventoryConfig;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EquipmentAttributes;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInventoryConfigRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentAttributesRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.instance.rest.api.model.IPAssignmentDTO;
import com.vz.uiam.inventory.equipment.model.validator.LoopBackIPAssignmentValidator;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateConstant;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateTestCommon;

/**
 * 
 * File Name    : LoopBackIPAssignmentValidatorTest.java
 * Project Name : trail
 * @date Apr 18, 2018
 * @author Anju Rajput
 * 	
 * <P>
 * This class LoopBackIPAssignmentValidatorTest validates LoopBackIPAssignmentValidator class
 * </P>
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class LoopBackIPAssignmentValidatorTest extends InstanceEquipmentCreateTestCommon{

	private static final Logger LOGGER = LoggerFactory.getLogger(LoopBackIPAssignmentValidatorTest.class);

	@InjectMocks
	private LoopBackIPAssignmentValidator loopBackIPAssignmentValidator;
	
	@Mock
	private EquipmentRepository equipmentRepository;
	
	@Mock
	private EquipmentAttributesRepository equipmentAttributesRepository;
	
	@Mock
	private DirInventoryConfigRepository dirInventoryConfigRepository;
	
	private Equipment equipment;
	
	private List<Equipment> equipmentList = new ArrayList<>();
	
	private IPAssignmentDTO ipAssignmentDTO;
	
	private Errors errors;
	
	private EquipmentAttributes equipmentAttributes = new EquipmentAttributes();
	private EquipmentAttributes equipmentAttributes1 = new EquipmentAttributes();
	
	private List<EquipmentAttributes> attrList = new ArrayList<>();
	/**
	 * <p>
	 * This method is used to set up all the related mocks data
	 * </p>
	 */
	@Before
	public void setUp() {
		try {
			equipment = fromJsonFileToJava(EQUIPMENT, Equipment.class);
			equipmentList.add(equipment);
			ipAssignmentDTO = fromJsonFileToJava(IP_ASSIGNMENT_REQ, IPAssignmentDTO.class);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
	}
	
	@Test
	public void testProcessSuRIValidation() {
		LOGGER.info("Entering test method -> testProcessSuRIValidation");
		errors = new BeanPropertyBindingResult(ipAssignmentDTO, IP_ASSIGNMENT_REQ);
		equipment.setShelfType(InstanceEquipmentCreateConstant.SHELF_TYPE_MSERI);
		List<Equipment> equipmentListT = new ArrayList<>();
		ipAssignmentDTO.settIDLogical(TID_LOGICAL);
		try {
			//mocked calls
			when(equipmentRepository.getSuEquipments(anyString(), anyString())).thenReturn(equipmentListT);
			
			// execution
			loopBackIPAssignmentValidator.processSuRIValidation(false, equipmentList, ipAssignmentDTO, errors);
			
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testProcessSuRIValidation");

	}
	
	@Test
	public void testProcessSuRIValidation_Eqp() {
		LOGGER.info("Entering test method -> testProcessSuRIValidation_Eqp");
		errors = new BeanPropertyBindingResult(ipAssignmentDTO, IP_ASSIGNMENT_REQ);
		equipment.setShelfType(InstanceEquipmentCreateConstant.SHELF_TYPE_MSERI);
		equipment.setTidLogical(NULL);
		try {
			//mocked calls
			when(equipmentRepository.getSuEquipments(anyString(), anyString())).thenReturn(equipmentList);
			
			// execution
			loopBackIPAssignmentValidator.processSuRIValidation(false, equipmentList, ipAssignmentDTO, errors);
			
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testProcessSuRIValidation_Eqp");

	}
	
	@Test
	public void testProcessSuRIValidation_Eqp_TID_null() {
		LOGGER.info("Entering test method -> testProcessSuRIValidation_Eqp_TID_null");
		errors = new BeanPropertyBindingResult(ipAssignmentDTO, IP_ASSIGNMENT_REQ);
		equipment.setShelfType(InstanceEquipmentCreateConstant.SHELF_TYPE_MSERI);
		try {
			//mocked calls
			when(equipmentRepository.getSuEquipments(anyString(), anyString())).thenReturn(equipmentList);
			
			// execution
			loopBackIPAssignmentValidator.processSuRIValidation(false, equipmentList, ipAssignmentDTO, errors);
			
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testProcessSuRIValidation_Eqp_TID_null");

	}
	
	@Test
	public void testProcessSuRIValidation_TID_null() {
		LOGGER.info("Entering test method -> testProcessSuRIValidation_TID_null");
		errors = new BeanPropertyBindingResult(ipAssignmentDTO, IP_ASSIGNMENT_REQ);
		equipment.setShelfType(InstanceEquipmentCreateConstant.SHELF_TYPE_MSERI);
		ipAssignmentDTO.setSuTIDLogical(NULL);
		try {
			//mocked calls
			when(equipmentRepository.getSuEquipments(anyString(), anyString())).thenReturn(equipmentList);
			
			// execution
			loopBackIPAssignmentValidator.processSuRIValidation(false, equipmentList, ipAssignmentDTO, errors);
			
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testProcessSuRIValidation_TID_null");

	}
	
	@Test
	public void testProcessTidLogicalAndShelfTypeValidation() {
		LOGGER.info("Entering test method -> testProcessTidLogicalAndShelfTypeValidation");
		errors = new BeanPropertyBindingResult(ipAssignmentDTO, IP_ASSIGNMENT_REQ);
		equipment.setShelfType(InstanceEquipmentCreateConstant.SHELF_TYPE_MSERI);
		equipment.setTidLogical(NULL);
		try {
			
			// execution
			loopBackIPAssignmentValidator.processTidLogicalAndShelfTypeValidation(false, equipmentList, errors);
			
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testProcessTidLogicalAndShelfTypeValidation");

	}
	
	@Test
	public void testProcessTidLogicalAndShelfTypeValidation_Eqp() {
		LOGGER.info("Entering test method -> testProcessTidLogicalAndShelfTypeValidation_Eqp");
		errors = new BeanPropertyBindingResult(ipAssignmentDTO, IP_ASSIGNMENT_REQ);
		equipment.setFunctionalType(InstanceEquipmentCreateConstant.VRI_SU);
		try {
			
			// execution
			loopBackIPAssignmentValidator.processTidLogicalAndShelfTypeValidation(false, equipmentList, errors);
			
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testProcessTidLogicalAndShelfTypeValidation_Eqp");

	}
	
	@Test
	public void testValidate_Eqp() {
		LOGGER.info("Entering test method -> testValidate_Eqp");
		errors = new BeanPropertyBindingResult(ipAssignmentDTO, IP_ASSIGNMENT_REQ);
		equipment.setFunctionalType(InstanceEquipmentCreateConstant.VRI_SU);
		try {
			
			// execution
			loopBackIPAssignmentValidator.validate(ipAssignmentDTO, errors);
			
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testValidate_Eqp");

	}
	
	@Test
	public void testValidate_Eqp_Ref_Id() {
		LOGGER.info("Entering test method -> testValidate_Eqp_Ref_Id");
		errors = new BeanPropertyBindingResult(ipAssignmentDTO, IP_ASSIGNMENT_REQ);
		ipAssignmentDTO.setSuTIDLogical(NULL);
		ipAssignmentDTO.settIDLogical(NULL);
		ipAssignmentDTO.setEquimentRefId(ID);
		try {
			
			// execution
			loopBackIPAssignmentValidator.validate(ipAssignmentDTO, errors);
			
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testValidate_Eqp_Ref_Id");

	}
	
	@Test
	public void testValidate_EqpId() {
		LOGGER.info("Entering test method -> testValidate_EqpId");
		errors = new BeanPropertyBindingResult(ipAssignmentDTO, IP_ASSIGNMENT_REQ);
		ipAssignmentDTO.setSuTIDLogical(NULL);
		ipAssignmentDTO.settIDLogical(NULL);
		ipAssignmentDTO.setEquimentRefId(ID);
		try {
			//mock
			when(equipmentRepository.findOne(anyLong())).thenReturn(equipment);
			when(equipmentRepository.findByTidLogical(anyString())).thenReturn(equipmentList);
			// execution
			loopBackIPAssignmentValidator.validate(ipAssignmentDTO, errors);
			
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testValidate_EqpId");

	}
	
	@Test
	public void testValidate_Attributes() {
		LOGGER.info("Entering test method -> testValidate_Attributes");
		errors = new BeanPropertyBindingResult(ipAssignmentDTO, IP_ASSIGNMENT_REQ);
		ipAssignmentDTO.setSuTIDLogical(NULL);
		ipAssignmentDTO.settIDLogical(NULL);
		ipAssignmentDTO.setEquimentRefId(ID);
		equipmentAttributes1.setEqpName(InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_1);
		equipmentAttributes1.setEqpValue(TID_LOGICAL);
		attrList.add(equipmentAttributes1);
		equipmentAttributes.setEqpName(InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_2);
		equipmentAttributes.setEqpValue(TID_LOGICAL);
		attrList.add(equipmentAttributes);
		try {
			//mock
			when(equipmentRepository.findOne(anyLong())).thenReturn(equipment);
			when(equipmentRepository.findByTidLogical(anyString())).thenReturn(equipmentList);
			when(equipmentAttributesRepository.findByEqpReferenceId(anyLong())).thenReturn(attrList);
			// execution
			loopBackIPAssignmentValidator.validate(ipAssignmentDTO, errors);
			
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testValidate_Attributes");
	}
	
	@Test
	public void testValidate_Attributes1() {
		LOGGER.info("Entering test method -> testValidate_Attributes1");
		errors = new BeanPropertyBindingResult(ipAssignmentDTO, IP_ASSIGNMENT_REQ);
		ipAssignmentDTO.setSuTIDLogical(NULL);
		ipAssignmentDTO.setEquimentRefId(NULL);
		equipmentAttributes1.setEqpName(InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_1);
		equipmentAttributes1.setEqpValue(TID_LOGICAL);
		attrList.add(equipmentAttributes1);
		equipmentAttributes.setEqpName(InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_2);
		equipmentAttributes.setEqpValue(TID_LOGICAL);
		attrList.add(equipmentAttributes);
		try {
			//mock
			when(equipmentRepository.findOne(anyLong())).thenReturn(equipment);
			when(equipmentRepository.findByTidLogical(anyString())).thenReturn(equipmentList);
			when(equipmentAttributesRepository.findByEqpReferenceId(anyLong())).thenReturn(attrList);
			// execution
			loopBackIPAssignmentValidator.validate(ipAssignmentDTO, errors);
			
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testValidate_Attributes1");
	}
	
	@Test
	public void testValidate_EqpRefId_Null() {
		LOGGER.info("Entering test method -> testValidate_EqpRefId_Null");
		errors = new BeanPropertyBindingResult(ipAssignmentDTO, IP_ASSIGNMENT_REQ);
		ipAssignmentDTO.setSuTIDLogical(NULL);
		ipAssignmentDTO.setEquimentRefId(NULL);
		try {
			//mock
			when(equipmentRepository.findByTidLogical(anyString())).thenReturn(null);
			// execution
			loopBackIPAssignmentValidator.validate(ipAssignmentDTO, errors);
			
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testValidate_EqpRefId_Null");
	}
	
	@Test
	public void testValidate_HostName_Null() {
		LOGGER.info("Entering test method -> testValidate_HostName_Null");
		IPAssignmentDTO ipAssignmentDTOv1=new IPAssignmentDTO();
		errors = new BeanPropertyBindingResult(ipAssignmentDTOv1, IP_ASSIGNMENT_REQ);
		
		try {
			loopBackIPAssignmentValidator.validate(ipAssignmentDTOv1, errors);
			
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testValidate_HostName_Null");
	}
	
	@Test
	public void testValidate_HostName_Empty() {
		LOGGER.info("Entering test method -> testValidate_HostName_Empty");
		IPAssignmentDTO ipAssignmentDTOv1=new IPAssignmentDTO();
		ipAssignmentDTOv1.setHostName(InstanceEquipmentCreateConstant.EMPTY);
		errors = new BeanPropertyBindingResult(ipAssignmentDTOv1, IP_ASSIGNMENT_REQ);
		
		try {
			// execution
			loopBackIPAssignmentValidator.validate(ipAssignmentDTOv1, errors);
			
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testValidate_HostName_Empty");
	}
	
	@Test
	public void testValidate_IpAssignmentDTO_Empty() {
		LOGGER.info("Entering test method -> testValidate_IpAssignmentDTO_Empty");
		IPAssignmentDTO ipAssignmentDTOv1=new IPAssignmentDTO();
		ipAssignmentDTOv1.setHostName(InstanceEquipmentCreateConstant.EMPTY);
		ipAssignmentDTOv1.settIDLogical(InstanceEquipmentCreateConstant.EMPTY);
		ipAssignmentDTOv1.setEquimentRefId(InstanceEquipmentCreateConstant.EMPTY);
		
		errors = new BeanPropertyBindingResult(ipAssignmentDTOv1, IP_ASSIGNMENT_REQ);
		
		try {
			// execution
			loopBackIPAssignmentValidator.validate(ipAssignmentDTOv1, errors);
			
		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testValidate_IpAssignmentDTO_Empty");
	}
	
	@Test
	public void testValidate_HostName_Fail() {
		LOGGER.info("Entering test method -> testValidate_HostName_Fail");
		IPAssignmentDTO ipAssignmentDTOv1 = new IPAssignmentDTO();
		ipAssignmentDTOv1.setHostName(HOST_NAME);
		errors = new BeanPropertyBindingResult(ipAssignmentDTOv1, IP_ASSIGNMENT_REQ);

		try {
			loopBackIPAssignmentValidator.validate(ipAssignmentDTOv1, errors);

		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testValidate_HostName_Fail");
	}
	
	@Test
	public void testValidate_HostName_Success() {
		LOGGER.info("Entering test method -> testValidate_HostName_Success");
		IPAssignmentDTO ipAssignmentDTOv1 = new IPAssignmentDTO();
		ipAssignmentDTOv1.setHostName(HOST_NAME);
		Equipment ngpon2 = null;
		List<Equipment> eqpList = new ArrayList<Equipment>();
		DirInventoryConfig mockDirInventoryConfig = Mockito.mock(DirInventoryConfig.class);

		try {
			ngpon2 = fromJsonFileToJava(EQUIPMENT, Equipment.class);
			ngpon2.setShelfType(InstanceEquipmentCreateConstant.SHELF_TYPE_NGPON2);
			eqpList.add(ngpon2);
			errors = new BeanPropertyBindingResult(ipAssignmentDTOv1, IP_ASSIGNMENT_REQ);

			when(equipmentRepository.findByHostName(anyString())).thenReturn(eqpList);
			when(dirInventoryConfigRepository.findByGroupNameAndConfigNameAndConfigValue(anyString(), anyString(),
					anyString())).thenReturn(mockDirInventoryConfig);
			loopBackIPAssignmentValidator.validate(ipAssignmentDTOv1, errors);

		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testValidate_HostName_Success");
	}
	
	@Test
	public void testValidate_HostName_Fail_InvalidHostName() {
		LOGGER.info("Entering test method -> testValidate_HostName_Fail_InvalidHostName");
		IPAssignmentDTO ipAssignmentDTOv1 = new IPAssignmentDTO();
		ipAssignmentDTOv1.setHostName(HOST_NAME);
		Equipment ngpon2 = null;
		List<Equipment> eqpList = new ArrayList<Equipment>();

		try {
			ngpon2 = fromJsonFileToJava(EQUIPMENT, Equipment.class);
			ngpon2.setShelfType(InstanceEquipmentCreateConstant.SHELF_TYPE_NGPON2);
			eqpList.add(ngpon2);
			eqpList.add(ngpon2);
			errors = new BeanPropertyBindingResult(ipAssignmentDTOv1, IP_ASSIGNMENT_REQ);

			when(equipmentRepository.findByHostName(anyString())).thenReturn(eqpList);
			loopBackIPAssignmentValidator.validate(ipAssignmentDTOv1, errors);

		} catch (Exception e) {
			LOGGER.error(EXCEPTION_MESSAGE, e);
		}
		LOGGER.info("Exiting test method -> testValidate_HostName_Fail_InvalidHostName");
	}
}
