package com.vz.uiam.inventory.equipment;

import static org.junit.Assert.assertTrue;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;

import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.model.validator.AddRackValidatorNoTemplSpec;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = EquipTpltCreateApplication.class)
@WebAppConfiguration
public class AddRackValidatorNoTemplSpecTest {
	
	private static final Logger LOG = LoggerFactory.getLogger(AddRackValidatorNoTemplSpecTest.class);
	private EquipmentControllerNoTemplSpecTest ecntst = new EquipmentControllerNoTemplSpecTest();
	@Autowired
	private AddRackValidatorNoTemplSpec addRackValidatorNoTemplSpec;
	private static final String ERROR_INVALID_EQUIPMENT = "INEA0010";

	@Test
	public void testValidateAll() {
		LOG.info("=> testValidateAll started  ");
		EquipmentDTOV1 equipment = new EquipmentDTOV1();

		Errors errors = new BeanPropertyBindingResult(equipment, ERROR_INVALID_EQUIPMENT);
		equipment.setName(null);
		addRackValidatorNoTemplSpec.validate(equipment, errors);
		LOG.info("  => errors.hasErrors() " + errors.hasErrors());

		for (ObjectError oe : errors.getAllErrors()) {
			LOG.info("  => " + oe.getCode() + " / " + oe.getDefaultMessage());
		}

		assertTrue(errors.hasErrors());
		LOG.info("<= testValidateAll completed   ");
	}

	@Test
	public void testValidateName1() {
		LOG.info("=> testValidateName1 started  ");
		EquipmentDTOV1 equipment = new EquipmentDTOV1();

		Errors errors = new BeanPropertyBindingResult(equipment, ERROR_INVALID_EQUIPMENT);
		equipment.setName(null);
		addRackValidatorNoTemplSpec.validateName(equipment, errors);
		LOG.info("  => errors.hasErrors() " + errors.hasErrors());

		for (ObjectError oe : errors.getAllErrors()) {
			LOG.info("  => " + oe.getCode() + " / " + oe.getDefaultMessage());
		}

		assertTrue(errors.hasErrors());
		LOG.info("<= testValidateName1 completed   ");
	}

	@Test
	public void testValidateName2() {
		LOG.info("=> testValidateName2 started  ");
		EquipmentDTOV1 equipment = new EquipmentDTOV1();

		Errors errors = new BeanPropertyBindingResult(equipment, ERROR_INVALID_EQUIPMENT);
		equipment.setName("InvalidRackName");
		addRackValidatorNoTemplSpec.validateName(equipment, errors);
		LOG.info("  => errors.hasErrors() " + errors.hasErrors());

		for (ObjectError oe : errors.getAllErrors()) {
			LOG.info("  => " + oe.getCode() + " / " + oe.getDefaultMessage());
		}

		assertTrue(true);
		LOG.info("<= testValidateName2 completed   ");
	}
	
	@Test
	public void testValidateDomianNames() {
		LOG.info("=> testValidateDomianNames started  ");
		EquipmentDTOV1 equipment = ecntst.populateRack();
		equipment.getDomianNames().get(0).setDomainName("InValidDomainName");
		equipment.setModifiedTimeStamp(new Date());
		Errors errors = new BeanPropertyBindingResult(equipment, ERROR_INVALID_EQUIPMENT);
		addRackValidatorNoTemplSpec.validate(equipment, errors);
		LOG.info("  => errors.hasErrors() " + errors.hasErrors());

		for (ObjectError oe : errors.getAllErrors()) {
			LOG.info("  => " + oe.getCode() + " / " + oe.getDefaultMessage());
		}

		assertTrue(errors.hasErrors());
		LOG.info("<= testValidateDomianNames completed   ");
	}

}
