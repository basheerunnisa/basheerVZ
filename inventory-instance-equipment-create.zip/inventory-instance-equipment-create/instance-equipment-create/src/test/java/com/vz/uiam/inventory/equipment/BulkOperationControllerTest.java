package com.vz.uiam.inventory.equipment;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.Filter;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.vz.uiam.common.usermanagement.rest.model.DirDomainsDTO;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EquipmentSpec;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Site;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentSpecRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.SiteRepository;
import com.vz.uiam.inventory.equipment.model.BulkEquipRequestDTO;
import com.vz.uiam.inventory.equipment.model.EquipDomainOperationDTO;
import com.vz.uiam.inventory.equipment.model.EquipmentDTO;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateTestCommon;
import com.vz.uiam.inventory.instance.rest.api.client.InventoryAttributesControllerClientInstance;

/**
 * @author Karthik Amarnath
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = EquipTpltCreateApplication.class)
@WebAppConfiguration
public class BulkOperationControllerTest extends InstanceEquipmentCreateTestCommon {

	private static final Logger LOGGER = LoggerFactory.getLogger(EquipmentControllerTest.class);
	private static final String TEST_IP_ADDRESS = "10.11.12.14";
	private static final String CREATE_PATH = "/equipment/bulkoperation/create";	
	private static final String NAME = "USER_ID";
	private static final String VALUE = "VZ456764";
	private static final String MEDIA_TYPE = "application/json";    
    private static final String ADD_DOMAIN_PATH = "/equipment/bulkoperation/adddomains";

	@Autowired
	private WebApplicationContext wac;
	@Autowired
	private Filter springSecurityFilterChain;
	@Autowired
	private EquipmentSpecRepository equipmentSpecRepository;
	@Autowired
	private EquipmentRepository equipmentRepository;
	@Autowired
    private SiteRepository siteRepository;
	@Autowired
	private String svcUserName;
	@Autowired
	private String svcPassword;
	
	@Mock
	private InventoryAttributesControllerClientInstance specificationAttributesClient;
	
	private MockRestServiceServer mockServer;
	private MockMvc mockMvc;	
	
	@Bean
	RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).defaultRequest(post("/")
									  .with(httpBasic(svcUserName, svcPassword)))
									  .addFilters(springSecurityFilterChain).build();
		
		mockServer = MockRestServiceServer.createServer(restTemplate());
	}
	
	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testCreateShelf() {

		EquipmentDTOV1 equipment = new EquipmentDTOV1();
		setDataCreateShelf(equipment);
		
		Equipment rack = equipmentRepository.findByEqpName("EQP_CREATE_E").stream().findAny().orElse(null);
		equipment.setparentEqReference(rack != null ? rack.getEqpReferenceId() : 1L);
		equipment.setName("EQP_CREATE_E1");
		BulkEquipRequestDTO bulkEquipRequestDTO = new BulkEquipRequestDTO();
		List<EquipmentDTOV1> equipmentList = new ArrayList<EquipmentDTOV1>();
		equipmentList.add(equipment);
		bulkEquipRequestDTO.setEquipmentDTOV1(equipmentList);
		
		try {	
			this.mockMvc.perform(post(CREATE_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(bulkEquipRequestDTO))).andExpect(status().isOk());

		} catch (Exception e) {
			LOGGER.error("Exception in testCreateShelf | {}", e);
		}
		mockServer.verify();
	}
	
	@Test
	public void testCreateShelfsWithInvalidInput() {

		List<EquipmentDTOV1> eqpList = Arrays.asList(new EquipmentDTOV1[]{
				new EquipmentDTOV1()
		});
		
		BulkEquipRequestDTO bulkEquipRequestDTO = new BulkEquipRequestDTO();
		bulkEquipRequestDTO.setEquipmentDTOV1(eqpList);
		
		try {
			this.mockMvc.perform(post(CREATE_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(bulkEquipRequestDTO))).andExpect(status().is(200));

		} catch (Exception e) {
			LOGGER.error("Exception in testCreateShelfsWithInvalidInput", e);
		}
		mockServer.verify();
	}
	
	@Test
	public void testCreateShelfsNull() {		
				
		BulkEquipRequestDTO bulkEquipRequestDTO = new BulkEquipRequestDTO();
		List<EquipmentDTOV1> equipmentList = null;
		bulkEquipRequestDTO.setEquipmentDTOV1(equipmentList);
		try {
			this.mockMvc.perform(post(CREATE_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(bulkEquipRequestDTO))).andExpect(status().is(200));

		} catch (Exception e) {
			LOGGER.error("Exception in testCreateShelfsNull", e);
		}
		mockServer.verify();
	}
	
	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testaddRack() {
		
		EquipmentDTO equipment = new EquipmentDTO();
		setDataAddRack(equipment);
		
		EquipmentSpec equipmentSpec = equipmentSpecRepository.findByName("EQP_CREATE_ES");
		equipment.setTemplateReference(equipmentSpec != null ? equipmentSpec.getEquipmentSpecRefId().intValue() : null);
		equipment.setName("EQP_CREATE_E9");
		BulkEquipRequestDTO bulkEquipRequestDTO = new BulkEquipRequestDTO();
		List<EquipmentDTO> equipmentList = new ArrayList<EquipmentDTO>();
		equipmentList.add(equipment);
		bulkEquipRequestDTO.setEquipmentDTO(equipmentList);
		
		try {
			this.mockMvc.perform(post(CREATE_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(bulkEquipRequestDTO))).andExpect(status().isOk());
			
		} catch (Exception e) {
			LOGGER.error("Exception in testaddRack", e);
		}
		mockServer.verify();
	}
	
	@Test
	@SqlGroup({ 
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testaddRackInvalid() {
		
		EquipmentDTO equipment = new EquipmentDTO();
		setDataAddRack(equipment);

		equipment.setName("TESTINGADDRACK");
		BulkEquipRequestDTO bulkEquipRequestDTO = new BulkEquipRequestDTO();
		List<EquipmentDTO> equipmentList = new ArrayList<EquipmentDTO>();
		equipmentList.add(equipment);
		bulkEquipRequestDTO.setEquipmentDTO(equipmentList);
		try {
			this.mockMvc.perform(post(CREATE_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(bulkEquipRequestDTO))).andExpect(status().is(200));
			
		} catch (Exception e) {
			LOGGER.error("Exception in testaddRackInvalid", e);
		}
	}
	
	@Test
	public void testCreateRackNull() {		
		
		BulkEquipRequestDTO bulkEquipRequestDTO = new BulkEquipRequestDTO();
		List<EquipmentDTO> equipmentList = null;
		bulkEquipRequestDTO.setEquipmentDTO(equipmentList);
		try {
			this.mockMvc.perform(post(CREATE_PATH).contentType(MediaType.APPLICATION_JSON).header(NAME, VALUE)
						.content(convertObjectToJsonBytes(bulkEquipRequestDTO))).andExpect(status().is(200));

		} catch (Exception e) {
			LOGGER.error("Exception in testCreateShelfsNull", e);
		}
		mockServer.verify();
	}
	
	@Test
	public void testAddDomains() {		
		
		List<EquipDomainOperationDTO> domainAddList = new ArrayList<>();           
        EquipDomainOperationDTO addDomain = new EquipDomainOperationDTO();
        addDomain.setEquipmentReference((long) 1001);
        List<DirDomainsDTO> domainList = new ArrayList<>();
        DirDomainsDTO domainNames = new DirDomainsDTO();
        domainNames.setDomainId(1);
        domainNames.setDescription("Test");
        domainList.add(domainNames);
        addDomain.setDomains(domainList);
        domainAddList.add(addDomain);
        
		try {
			this.mockMvc
	        .perform(post(ADD_DOMAIN_PATH).contentType(MediaType.parseMediaType(MEDIA_TYPE))
	                .header(NAME, VALUE).content(convertObjectToJsonBytes(domainAddList)))
	                .andExpect(status().isOk());

		} catch (Exception e) {
			LOGGER.error("Exception in testAddDomains", e);
		}
		mockServer.verify();
	}
	
	@Test
	public void testAddDomainsInvalid() {		
		
		List<EquipDomainOperationDTO> domainAddList = new ArrayList<>();           
        EquipDomainOperationDTO addDomain = new EquipDomainOperationDTO();
        addDomain.setEquipmentReference((long) 1001);
        List<DirDomainsDTO> domainList = new ArrayList<>();
        DirDomainsDTO domainNames = new DirDomainsDTO();
        domainList.add(domainNames);
        addDomain.setDomains(domainList);
        domainAddList.add(addDomain);
        
		try {
			this.mockMvc
	        .perform(post(ADD_DOMAIN_PATH).contentType(MediaType.parseMediaType(MEDIA_TYPE))
	                .header(NAME, VALUE).content(convertObjectToJsonBytes(domainAddList)))
	                .andExpect(status().isOk());

		} catch (Exception e) {
			LOGGER.error("Exception in testAddDomainsInvalid", e);
		}		
	}
	
	
	private void setDataCreateShelf(EquipmentDTOV1 equipment) {
		
		EquipmentSpec equipmentSpec = equipmentSpecRepository.findByName("EQP_CREATE_ES");
		Site site = siteRepository.findBySiteName("TEST_SITE1");
		
		equipment.setShelfName("Shelf/15");
		equipment.setcontainer("SHELF");
		equipment.setTemplateReference(equipmentSpec.getEquipmentSpecRefId());
		equipment.setType("CIENA_T6500");
		equipment.setsiteReference(site.getSiteReferenceId());
		equipment.setparentEqReference(1L);
		equipment.setTargetId("Test91");
		equipment.setAid("01/02");
		equipment.setIpAddress(TEST_IP_ADDRESS);
		equipment.setPhysicalShelf("1");
	}
	
	private void setDataAddRack(EquipmentDTO equipmentDTO) {
		Site site = siteRepository.findBySiteName("TEST_SITE1");
		Long siteId = site.getSiteReferenceId();
		
		equipmentDTO.setContainer("RACK");
		equipmentDTO.setType("Frame");
		equipmentDTO.setStatus("AVAILABLE");
		equipmentDTO.setSiteReference(siteId.intValue());
		equipmentDTO.setParentEqReference(1);
		equipmentDTO.setParentShelfReference(1);
		equipmentDTO.setCustomerReference(1);
		equipmentDTO.setClli("TESTCLLI");
		equipmentDTO.setFrame("TEST_FRAME");
	}
	
}