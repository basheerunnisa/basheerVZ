package com.vz.uiam.inventory.equipment;

import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.vz.uiam.inventory.equipment.exception.DataConflictException;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EquipmentSpec;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentSpecRepository;
import com.vz.uiam.inventory.equipment.model.EquipmentDTO;
import com.vz.uiam.inventory.equipment.service.EquipmentService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = EquipTpltCreateApplication.class)
@WebAppConfiguration
public class EquipmentServiceTest {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EquipmentServiceTest.class);
	private static final String TEST_EQP_NAME = "EQP_CREATE_E";
	private static final String TEST_EQP_SPEC_NAME = "EQP_CREATE_ES";
	private static final String TEST_RACK_FRAME = "TEST_FRAME";
	
	@Autowired
	private EquipmentService equipmentService;
	@Autowired
	private EquipmentRepository equipmentRepository;
	@Autowired
	private EquipmentSpecRepository equipmentSpecRepository;
	
    @Before
    public void setup() {
    	// needed to get around the error - Java.lang.IllegalStateException: No
    	// thread-bound request found
    	try {
    		MockHttpServletRequest request = new MockHttpServletRequest();
    		MockHttpSession session = new MockHttpSession();
    		request.setSession(session);
    		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
    	} catch (Exception e) {
    		LOGGER.info("Mock Build failed :" + e);
    	}
    }
	
	@Test
	@SqlGroup({ @Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeRackValidate.sql"),
	    @Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterRackValidate.sql") })
	public void testfindByEquipmentName() {
		assertTrue(equipmentRepository.findByEqpName(TEST_EQP_NAME) != null);
	}

	@Test(expected=DataConflictException.class)
	public void testThrowLongDataConflictException() {
        throw new DataConflictException("DC","ID","TEST exception\n ORA-001");
    }

    @Test
    @SqlGroup({ @Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
        @Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
    public void testaddRackOwnData() {
        EquipmentSpec equipmentSpec = equipmentSpecRepository.findByName(TEST_EQP_SPEC_NAME);
        EquipmentDTO equipmentDTO = createRack(equipmentSpec.getEquipmentSpecRefId().intValue(), "EQP_CREATE_E4",
                "AVAILABLE", TEST_RACK_FRAME);
        equipmentDTO.setPhysicalShelf("PSH4");
        equipmentDTO.setLogicalShelf("LSH4");
        equipmentDTO.setAssetLife(new BigDecimal(500));
        equipmentDTO.setPurchasePrice(new BigDecimal(1000));
        equipmentDTO.setHeight(new BigDecimal(1));
        equipmentDTO.setWidth(new BigDecimal(2));
        equipmentDTO.setDepth(new BigDecimal(3));
        equipmentDTO.setDistToFront(new BigDecimal(4));
        equipmentDTO.setDistToLeft(new BigDecimal(5));
        equipmentDTO.setDistToBase(new BigDecimal(6));
        equipmentDTO.setFrRefKeyName("ICON_RACK");
        equipmentDTO.setFrRefKeyValue("12122");
        
        EquipmentDTO expected = equipmentService.addRack(equipmentDTO, null); 
        assertTrue(expected != null);        
    }

	private EquipmentDTO createRack(Integer templateReference, String name, String status, String frame) {
        EquipmentDTO equipmentDTO = new EquipmentDTO();
        equipmentDTO.setTemplateReference(templateReference);
        equipmentDTO.setName(name);
        equipmentDTO.setContainer("RACK");
        equipmentDTO.setType("Frame");
        equipmentDTO.setStatus(status);
        equipmentDTO.setSiteReference(1000);
        equipmentDTO.setParentEqReference(1);
        equipmentDTO.setParentShelfReference(1);
        equipmentDTO.setCustomerReference(1);
        equipmentDTO.setFrame(frame);
        return equipmentDTO;
	}
}
