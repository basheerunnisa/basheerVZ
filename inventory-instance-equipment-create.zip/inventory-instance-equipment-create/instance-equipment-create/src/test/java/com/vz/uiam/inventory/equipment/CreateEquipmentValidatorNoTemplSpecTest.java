package com.vz.uiam.inventory.equipment;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;

import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.model.validator.CreateEquipmentValidator;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = EquipTpltCreateApplication.class)
@WebAppConfiguration
public class CreateEquipmentValidatorNoTemplSpecTest {
	
	private static final Logger LOG = LoggerFactory.getLogger(CreateEquipmentValidatorNoTemplSpecTest.class); 
	private EquipmentControllerNoTemplSpecTest ecntst = new EquipmentControllerNoTemplSpecTest();
	
	@Autowired
	private CreateEquipmentValidator createEquipmentValidator; 
	
	private static final String ERROR_INVALID_EQUIPMENT = "INEA0010";
	
	@Test
	public void testValidateAll1() {
		LOG.info("=> CreateEquipmentValidatorNoTemplSpecTest.testValidateAll1 started  ");
		EquipmentDTOV1 equipment = new EquipmentDTOV1();

		Errors errors = new BeanPropertyBindingResult(equipment, ERROR_INVALID_EQUIPMENT);
		
		createEquipmentValidator.validate(equipment, errors);
		LOG.info("  => errors.hasErrors() " + errors.hasErrors());

		for (ObjectError oe : errors.getAllErrors()) {
			LOG.info("  => " + oe.getCode() + " / " + oe.getDefaultMessage());
		}

		assertTrue(errors.hasErrors());
		LOG.info("<= CreateEquipmentValidatorNoTemplSpecTest.testValidateAll1 completed   ");
	}
	
	@Test
	public void testValidateAll2() {
		LOG.info("=> CreateEquipmentValidatorNoTemplSpecTest.testValidateAll2 started  ");
		EquipmentDTOV1 equipment = new EquipmentDTOV1();

		Errors errors = new BeanPropertyBindingResult(equipment, ERROR_INVALID_EQUIPMENT);
		equipment.setName("InvalidEqpName");
		equipment.setcontainer("SHELF");
		createEquipmentValidator.validate(equipment, errors);
		LOG.info("  => errors.hasErrors() " + errors.hasErrors());

		for (ObjectError oe : errors.getAllErrors()) {
			LOG.info("  => " + oe.getCode() + " / " + oe.getDefaultMessage());
		}

		assertTrue(errors.hasErrors());
		LOG.info("<= CreateEquipmentValidatorNoTemplSpecTest.testValidateAll2 completed   ");
	}	
	
	@Test
	public void testValidate3() {
		LOG.info("=> CreateEquipmentValidatorNoTemplSpecTest.testValidate3 started  ");
		EquipmentDTOV1 equipment = ecntst.populateShelf(); 

		Errors errors = new BeanPropertyBindingResult(equipment, ERROR_INVALID_EQUIPMENT);
		equipment.getDomianNames().get(0).setDomainName("InValidDomainName");
		
		createEquipmentValidator.validate(equipment, errors);
		LOG.info("  => errors.hasErrors() " + errors.hasErrors());

		for (ObjectError oe : errors.getAllErrors()) {
			LOG.info("  => " + oe.getCode() + " / " + oe.getDefaultMessage());
		}

		assertFalse(errors.hasErrors());
		LOG.info("<= CreateEquipmentValidatorNoTemplSpecTest.testValidate3 completed   ");
	}	
	
	@Test
	public void testValidate4() {
		LOG.info("=> CreateEquipmentValidatorNoTemplSpecTest.testValidate4 started  ");
		EquipmentDTOV1 equipment = ecntst.populateShelf(); 

		Errors errors = new BeanPropertyBindingResult(equipment, ERROR_INVALID_EQUIPMENT);
		equipment.getSlotDTOList().get(0).setSlotName(null); 
		equipment.getSlotDTOList().get(1).setSlotName(null); 
		
		createEquipmentValidator.validate(equipment, errors);
		LOG.info("  => errors.hasErrors() " + errors.hasErrors());

		for (ObjectError oe : errors.getAllErrors()) {
			LOG.info("  => " + oe.getCode() + " / " + oe.getDefaultMessage());
		}

		assertTrue(errors.hasErrors());
		LOG.info("<= CreateEquipmentValidatorNoTemplSpecTest.testValidate4 completed   ");
	}

	@Test
	public void testValidateAll3() {
		LOG.info("=> CreateEquipmentValidatorNoTemplSpecTest.testValidateAll3 started  ");
		EquipmentDTOV1 equipment = new EquipmentDTOV1();

		Errors errors = new BeanPropertyBindingResult(equipment, ERROR_INVALID_EQUIPMENT);
		equipment.setName("InvalidEqpName");
		equipment.setcontainer("SHELF");
		equipment.setsiteReference(1L);
		equipment.setClli("CLLI");
		equipment.setType("TL");
		equipment.setFrame("Frame");
		
		createEquipmentValidator.validate(equipment, errors);
		LOG.info("  => errors.hasErrors() " + errors.hasErrors());

		for (ObjectError oe : errors.getAllErrors()) {
			LOG.info("  => " + oe.getCode() + " / " + oe.getDefaultMessage());
		}

		assertFalse(errors.hasErrors());
		LOG.info("<= CreateEquipmentValidatorNoTemplSpecTest.testValidateAll3 completed   ");
	}

	
	@Test
	public void testValidateAll4() {
		LOG.info("=> CreateEquipmentValidatorNoTemplSpecTest.testValidateAll4 started  ");
		EquipmentDTOV1 equipment = new EquipmentDTOV1();

		Errors errors = new BeanPropertyBindingResult(equipment, ERROR_INVALID_EQUIPMENT);
		equipment.setName("InvalidEqpName");
		equipment.setcontainer("SHELF");
		equipment.setsiteReference(1L);
		equipment.setClli("CLLI");
		equipment.setType("TL");
		equipment.setFrame("Frame");
		equipment.setTargetId("InvalidTargetId");
		
		createEquipmentValidator.validate(equipment, errors);
		
		LOG.info("  => errors.hasErrors() " + errors.hasErrors());

		for (ObjectError oe : errors.getAllErrors()) {
			LOG.info("  => " + oe.getCode() + " / " + oe.getDefaultMessage());
		}

		assertTrue(true);
		LOG.info("<= CreateEquipmentValidatorNoTemplSpecTest.testValidateAll4 completed   ");
	}
}
