package com.vz.uiam.inventory.equipment;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.vz.uiam.inventory.equipment.jpa.dao.model.CardSpec;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.CardSpecRepository;
import com.vz.uiam.inventory.equipment.model.CardDTO;
import com.vz.uiam.inventory.equipment.service.CardService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = EquipTpltCreateApplication.class)
@WebAppConfiguration
public class CardServiceTest {

    private static final String INSTALL_CARD_SPEC_NAME="EC_CS1";

    @Autowired
    private CardService cardService;

    @Autowired
    private CardSpecRepository cardSpecRepository;


    @Test
    public void testInstallCardNoCardSpec(){
        CardDTO card = createCard(0L,0L,0L);
        CardDTO expected = cardService.installCard(card, false);
        assertTrue(expected.getCardId() == null);
    }

    @Test
    public void testInstallCardNoShelfInst(){
        CardDTO card = createCard(1L,0L,0L);
        CardDTO expected = cardService.installCard(card, false);
        assertTrue(expected.getCardId() == null);
    }

    @Test
    public void testInstallCardCardSpecNotFound(){
        CardDTO card = createCard(1L,1L,0L);
        CardDTO expected = cardService.installCard(card, false);
        assertTrue(expected.getCardId() == null);
    }

    @Test
    @SqlGroup({ @Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeTest.sql"),
        @Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterTest.sql") })
    public void testInstallCardNoSlotSpec(){
        CardDTO card = createCard(1L,1L,0L);
        CardSpec cardSpec = cardSpecRepository.findByName(INSTALL_CARD_SPEC_NAME);
        card.setCardSpecId(cardSpec.getCardSpecRefId());
        CardDTO expected = cardService.installCard(card, false);
        assertTrue(expected.getCardId() == null);
    }



    private CardDTO createCard(Long cardSpecId, Long shelfInstId, Long slotInstId ) {
        CardDTO card = new CardDTO();
        card.setCardSpecId(cardSpecId);
        card.setSlotInstId(slotInstId);
        card.setShelfInstId(shelfInstId);
        return card;
    }

}
