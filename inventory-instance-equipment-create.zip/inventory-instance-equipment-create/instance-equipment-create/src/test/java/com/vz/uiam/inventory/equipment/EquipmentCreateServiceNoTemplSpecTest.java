package com.vz.uiam.inventory.equipment;

import static org.junit.Assert.assertTrue;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.service.EquipmentCreateServiceNoTemplSpec;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateTestCommon;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = EquipTpltCreateApplication.class)
@WebAppConfiguration
public class EquipmentCreateServiceNoTemplSpecTest {

	private static final Logger LOGGER = LoggerFactory.getLogger(EquipmentCreateServiceNoTemplSpecTest.class); 
	private EquipmentControllerNoTemplSpecTest ecntst = new EquipmentControllerNoTemplSpecTest();
	private ObjectMapper mapper = new ObjectMapper();
	
	@Autowired
	private EquipmentCreateServiceNoTemplSpec equipCreateServiceNoTemplSpec;
	
    @Before
    public void setup() {
    	// needed to get around the error - Java.lang.IllegalStateException: No
    	// thread-bound request found
    	try {
    		MockHttpServletRequest request = new MockHttpServletRequest();
    		MockHttpSession session = new MockHttpSession();
    		request.setSession(session);
    		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
    	} catch (Exception e) {
    		LOGGER.info("Mock Build failed :" + e);
    	}
    }
	
	@Test
	@SqlGroup({ @Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeShelfCreate.sql"), 
	@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testCreateEquipment1() {

		try {
			LOGGER.info("testCreateEquipment1 started ");
			EquipmentDTOV1 equipmentDTO = ecntst.populateShelf();
			LOGGER.info("Create SHELF Request:  \n{}\n\n", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(equipmentDTO));
			
			EquipmentDTOV1 expected = equipCreateServiceNoTemplSpec.createEquipment(equipmentDTO, null);
			assertTrue(expected != null);
			
			LOGGER.info("testCreateEquipment1 completed  ");
		} catch (IOException e) {
			LOGGER.error("IOException in testCreateEquipment1", e);
		} catch (Exception e) {
			LOGGER.error("Exception in testCreateEquipment1", e);
		}

	}	
	
	@Test
	@SqlGroup({ @Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeShelfCreate.sql"), 
	@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testCreateEquipment2() {

		try {
			LOGGER.info("testCreateEquipment2 started ");
			EquipmentDTOV1 equipmentDTO = ecntst.populateShelf();
 			equipmentDTO.setsiteReference(null);			
			LOGGER.info("Create SHELF Request:  \n{}\n\n", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(equipmentDTO));
			EquipmentDTOV1 expected = equipCreateServiceNoTemplSpec.createEquipment(equipmentDTO, null);
			
			assertTrue(expected != null);
			LOGGER.info("testCreateEquipment2 completed  ");
		} catch (IOException e) {
			LOGGER.error("IOException in testCreateEquipment2", e);
		} catch (Exception e) {
			LOGGER.error("Exception in testCreateEquipment2", e);
		}

	}	
	
	@Test
	@SqlGroup({ @Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeShelfCreate.sql"), 
	@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testCreateEquipment3() {

		try {
			LOGGER.info("testCreateEquipment3 started ");
			EquipmentDTOV1 equipmentDTO = ecntst.populateShelf();
 			equipmentDTO.setsiteReference(null);
 			equipmentDTO.setDomianNames(null);
			LOGGER.info("Create SHELF Request:  \n{}\n\n", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(equipmentDTO));
			
			EquipmentDTOV1 expected = equipCreateServiceNoTemplSpec.createEquipment(equipmentDTO, null);
			assertTrue(expected != null);
			LOGGER.info("testCreateEquipment3 completed  ");
		} catch (IOException e) {
			LOGGER.error("IOException in testCreateEquipment3", e);
		} catch (Exception e) {
			LOGGER.error("Exception in testCreateEquipment3", e);
		}

	}	
	
	@Test
	@SqlGroup({ @Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeShelfCreate.sql"), 
	@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testCreateEquipment4() {

		try {
			LOGGER.info("testCreateEquipment4 started ");
			EquipmentDTOV1 equipmentDTO = ecntst.populateShelf();
 			equipmentDTO.setsiteReference(null);
 			equipmentDTO.setDomianNames(null);
 			equipmentDTO.setMatedPair("TL2.VEG2");
			LOGGER.info("Create SHELF Request:  \n{}\n\n", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(equipmentDTO));
			
			EquipmentDTOV1 expected = equipCreateServiceNoTemplSpec.createEquipment(equipmentDTO, null);
			assertTrue(expected != null);
			assertTrue("TL2.VEG2".equals(expected.getMatedPair()));
			LOGGER.info("testCreateEquipment4 completed  ");
		} catch (IOException e) {
			LOGGER.error("IOException in testCreateEquipment4", e);
		} catch (Exception e) {
			LOGGER.error("Exception in testCreateEquipment4", e);
		}

	}
	

	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql")})
	public void testAddRack1() throws JsonProcessingException {

		LOGGER.info("testAddRack1 started ");
		EquipmentDTOV1 equipmentDTO = ecntst.populateRack();
		equipmentDTO.setsiteReference(InstanceEquipmentCreateTestCommon.DEFAULT_SITE_ID);
		LOGGER.info("Create RACK Request:  \n{}\n\n", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(equipmentDTO));
		EquipmentDTOV1 expected = equipCreateServiceNoTemplSpec.addRack(equipmentDTO, null);
		
		LOGGER.info(" <= 1 created RACK# {} " + expected.getEquipmentReference());
		assertTrue(expected != null);
		
		LOGGER.info("testAddRack1 completed  ");
	}	
	
	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql")})
	public void testAddRack2() throws JsonProcessingException {

		LOGGER.info("testAddRack2 started ");
		EquipmentDTOV1 equipmentDTO = ecntst.populateRack();
		equipmentDTO.setsiteReference(InstanceEquipmentCreateTestCommon.DEFAULT_SITE_ID);
		equipmentDTO.setDomianNames(null);
		LOGGER.info("Create RACK Request:  \n{}\n\n", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(equipmentDTO));
		EquipmentDTOV1 expected = equipCreateServiceNoTemplSpec.addRack(equipmentDTO, null);
		
		LOGGER.info(" <= 1 created RACK# {} " + expected.getEquipmentReference());
		assertTrue(expected != null);
		
		LOGGER.info("testAddRack2 completed ");
	}
	
	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql")})
	public void testAddRack3() throws JsonProcessingException {

			LOGGER.info("testAddRack3 started ");
			EquipmentDTOV1 equipmentDTO = ecntst.populateRack();
			equipmentDTO.setsiteReference(InstanceEquipmentCreateTestCommon.DEFAULT_SITE_ID);
			equipmentDTO.setDomianNames(null);
			LOGGER.info("Create RACK Request:  \n{}\n\n", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(equipmentDTO));
			EquipmentDTOV1 expected = equipCreateServiceNoTemplSpec.addRack(equipmentDTO, null);
			
			LOGGER.info(" <= 1 created RACK# {} " + expected.getEquipmentReference());
			assertTrue(expected != null);
			
			LOGGER.info("testAddRack3 completed  ");
	}		
}
