package com.vz.uiam.inventory.equipment.service.mockito;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.uiam.common.audit.exception.MethodFailureException;
import com.vz.uiam.inventory.equipment.enumeration.DirInventoryConfigGroups;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInventoryConfig;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInventoryConfigRepository;
import com.vz.uiam.inventory.equipment.model.NetworkIpv4;
import com.vz.uiam.inventory.equipment.service.FabricInterConnectIPAssignmentService;
import com.vz.uiam.inventory.equipment.service.IPAssignmentRestService;
import com.vz.uiam.inventory.equipment.service.IPAssignmentService;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateConstant;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateTestCommon;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class FabricInterConnectIPAssignmentServiceTest extends InstanceEquipmentCreateTestCommon {

	private static final Logger LOGGER = LoggerFactory.getLogger(FabricInterConnectIPAssignmentServiceTest.class);

	@InjectMocks
	private FabricInterConnectIPAssignmentService service;

	@Mock
	private IPAssignmentRestService ipAssignmentRestService;

	@Mock
	private IPAssignmentService ipAssignmentService;

	@Mock
	private DirInventoryConfigRepository dirInventoryConfigRepository;

	private Equipment currentRIEquipment;

	private Equipment suRIequipment;
	private NetworkIpv4 networkIpv4;
	private DirInventoryConfig dirInvConfig;

	@Before
	public void setUp() {
		try {
			currentRIEquipment = fromJsonFileToJava(ANY_RI_EQUIPMENT_JSON, Equipment.class);
			suRIequipment = fromJsonFileToJava(SU_RI_EQUIPMENT_JSON, Equipment.class);
			networkIpv4 = fromJsonFileToJava(NETWORK_IPV4_JSON, NetworkIpv4.class);
			dirInvConfig = fromJsonFileToJava(DIR_INV_CONFIG_JSON, DirInventoryConfig.class);
		} catch (Exception e) {
			LOGGER.error("Exception occured: {}", e);
		}
	}

	@Test(expected = MethodFailureException.class)
	public void testAssignP2PIPForFabricInterConnectRIFailInvalidIPResponse() {

		NetworkIpv4 value = new NetworkIpv4();
		when(ipAssignmentRestService.assignNextAvailableIp(any())).thenReturn(value);
		service.assignP2PIPForFabricInterConnectRI(currentRIEquipment, suRIequipment);
	}

	@Test
	public void testAssignP2PIPForFabricInterConnectRISuccess() {
		when(ipAssignmentRestService.assignNextAvailableIp(any())).thenReturn(networkIpv4);

		when(dirInventoryConfigRepository.findByGroupNameAndConfigName(anyString(), anyString()))
				.thenReturn(dirInvConfig);

		dirInventoryConfigRepository.findByGroupNameAndConfigName(
				DirInventoryConfigGroups.LOOP_BACK_IP_ASSIGNMENT.value(),
				InstanceEquipmentCreateConstant.EXTERNAL_IP_POOL_NAME);
		service.assignP2PIPForFabricInterConnectRI(currentRIEquipment, suRIequipment);
	}

}
