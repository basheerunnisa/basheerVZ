package com.vz.uiam.inventory.equipment;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.model.validator.CreateEquipmentValidator;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = EquipTpltCreateApplication.class)
@WebAppConfiguration
public class CreateEquipmentValidatorTest {

	private static final String EQUIPMENT_NAME = "TEST_EQP";
	private static final String EQUIPMENT_CONTAINER = "SHELF";
	private static final String EQUIPMENT_CLLI = "TEST_CLLI";
	private static final String EQUIPMENT_MANUFACTURER_PART_NUMBER = "TEST_MANUFACTURER_PART_NUMBER";
	private static final String EQUIPMENT_FRAME = "TEST_FRAME";
	private static final String EQUIPMENT_TARGET_ID = "TEST_NB_TID1";
	private static final String ERROR_INVALID_EQUIPMENT = "invalidEquipment";

	@Autowired
	private CreateEquipmentValidator createEquipmentValidator;

	@Test
	public void testValidateNameFailed() {
		EquipmentDTOV1 equipment = new EquipmentDTOV1();
		Errors errors = new BeanPropertyBindingResult(equipment, ERROR_INVALID_EQUIPMENT);
		equipment.setName(null);
		createEquipmentValidator.validate(equipment, errors);
		assertTrue(errors.hasErrors());
	}

	@Test
	public void testValidateContainerFailed() {
		EquipmentDTOV1 equipment = createEquipment(EQUIPMENT_NAME, null, null, null, null);
		Errors errors = new BeanPropertyBindingResult(equipment, ERROR_INVALID_EQUIPMENT);
		createEquipmentValidator.validate(equipment, errors);
		assertTrue(errors.hasErrors());
	}

	@Test
	public void testValidateClliFailed() {
		EquipmentDTOV1 equipment = createEquipment(EQUIPMENT_NAME, EQUIPMENT_CONTAINER, null, null, null);
		Errors errors = new BeanPropertyBindingResult(equipment, ERROR_INVALID_EQUIPMENT);
		createEquipmentValidator.validate(equipment, errors);
		assertTrue(errors.hasErrors());
	}

	@Test
	public void testValidateTemplateFailed() {
		EquipmentDTOV1 equipment = createEquipment(EQUIPMENT_NAME, EQUIPMENT_CONTAINER, EQUIPMENT_CLLI, null, null);
		Errors errors = new BeanPropertyBindingResult(equipment, ERROR_INVALID_EQUIPMENT);
		createEquipmentValidator.validate(equipment, errors);
		assertTrue(errors.hasErrors());
	}

	@Test
	public void testValidateParentFailed() {
		EquipmentDTOV1 equipment = createEquipment(EQUIPMENT_NAME, EQUIPMENT_CONTAINER, EQUIPMENT_CLLI,
				EQUIPMENT_MANUFACTURER_PART_NUMBER, null);
		Errors errors = new BeanPropertyBindingResult(equipment, ERROR_INVALID_EQUIPMENT);
		createEquipmentValidator.validate(equipment, errors);
		assertTrue(errors.hasErrors());
	}

	@Test
	public void testValidateParentOK() {
		EquipmentDTOV1 equipment = createEquipment(EQUIPMENT_NAME, EQUIPMENT_CONTAINER, EQUIPMENT_CLLI,
				EQUIPMENT_MANUFACTURER_PART_NUMBER, EQUIPMENT_FRAME);
		Errors errors = new BeanPropertyBindingResult(equipment, ERROR_INVALID_EQUIPMENT);
		createEquipmentValidator.validate(equipment, errors);
		assertFalse(errors.hasErrors());
	}

	@Test
	public void testValidateTidOK() {
		EquipmentDTOV1 equipment = createEquipment(EQUIPMENT_NAME, EQUIPMENT_CONTAINER, EQUIPMENT_CLLI,
				EQUIPMENT_MANUFACTURER_PART_NUMBER, EQUIPMENT_FRAME);
		equipment.setTargetId(EQUIPMENT_TARGET_ID);
		Errors errors = new BeanPropertyBindingResult(equipment, ERROR_INVALID_EQUIPMENT);
		createEquipmentValidator.validate(equipment, errors);
		assertFalse(errors.hasErrors());
	}

	private EquipmentDTOV1 createEquipment(String name, String container, String clli, String mfgPartNumber,
			String frame) {
		EquipmentDTOV1 equipment = new EquipmentDTOV1();
		equipment.setName(name);
		equipment.setcontainer(container);
		equipment.setClli(clli);
		equipment.setMfgPartNumber(mfgPartNumber);
		equipment.setFrame(frame);
		return equipment;
	}
}
