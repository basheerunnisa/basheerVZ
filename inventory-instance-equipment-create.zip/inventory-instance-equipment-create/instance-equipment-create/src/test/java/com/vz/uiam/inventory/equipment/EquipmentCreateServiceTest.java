package com.vz.uiam.inventory.equipment;

import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EquipmentSpec;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentSpecRepository;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.service.EquipmentCreateService;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateTestCommon;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = EquipTpltCreateApplication.class)
@WebAppConfiguration
public class EquipmentCreateServiceTest {

	private static final Logger LOGGER = LoggerFactory.getLogger(EquipmentCreateServiceTest.class);
	
	@Autowired
	private EquipmentCreateService equipmentCreateService;
	@Autowired
	private EquipmentRepository equipmentRepository;
	@Autowired
	private EquipmentSpecRepository equipmentSpecRepository;
	
    @Before
    public void setup() {
    	// needed to get around the error - Java.lang.IllegalStateException: No
    	// thread-bound request found
    	try {
    		MockHttpServletRequest request = new MockHttpServletRequest();
    		MockHttpSession session = new MockHttpSession();
    		request.setSession(session);
    		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
    	} catch (Exception e) {
    		LOGGER.info("Mock Build failed :" + e);
    	}
    }
	
	@Test
	@SqlGroup({ @Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecTest.sql"),
			@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testcreateEquipment() {

		EquipmentDTOV1 equipmentDTO = createRack("EQP_CREATE_E1");
		equipmentDTO.setsiteReference(InstanceEquipmentCreateTestCommon.DEFAULT_SITE_ID);
		EquipmentDTOV1 expected = equipmentCreateService.createEquipment(equipmentDTO, null);
		assertTrue(expected != null);
	}

	@Test
	@SqlGroup({
			@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecNoParentCardTest.sql"),
			@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testcreateEquipmentNoParentCard() {

		EquipmentDTOV1 equipmentDTO = createRack("EQP_CREATE_E2");
		equipmentDTO.setsiteReference(InstanceEquipmentCreateTestCommon.DEFAULT_SITE_ID);
		equipmentDTO.setPhysicalShelf("1");
		equipmentDTO.setlogicalShelf("1");
		equipmentDTO.setheight(new BigDecimal("1.01"));
		equipmentDTO.setwidth(new BigDecimal("2.01"));
		equipmentDTO.setdepth(new BigDecimal("3.01"));
		equipmentDTO.setDistToFront(new BigDecimal("3.01"));
		equipmentDTO.setDistToLeft(new BigDecimal("3.01"));
		equipmentDTO.setDistToBase(new BigDecimal("3.01"));
		equipmentDTO.setAssetLife(new BigDecimal("500"));
		equipmentDTO.setPurchasePrice(new BigDecimal("1000"));

		EquipmentDTOV1 expected = equipmentCreateService.createEquipment(equipmentDTO, null);
		assertTrue(expected != null);
	}

	@Test
	@SqlGroup({
			@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeEquipSpecNoParentCardTest.sql"),
			@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterEquipSpecTest.sql") })
	public void testCreateEquipmentNoName() {

		EquipmentDTOV1 equipmentDTO = createRack("EQP_CREATE_E2");
		equipmentDTO.setsiteReference(InstanceEquipmentCreateTestCommon.DEFAULT_SITE_ID);
		equipmentDTO.setName(null);
		EquipmentDTOV1 expected = equipmentCreateService.createEquipment(equipmentDTO, null);
		assertTrue(expected != null);
	}

	@Test
	@SqlGroup({ @Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:BeforeRackValidate.sql"),
			@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:AfterRackValidate.sql") })
	public void testfindRackByRackId() {
		List<Equipment> equipment = equipmentRepository.findByEqpName("EQP_CREATE_E");
		Equipment expected = equipmentRepository.findOne(equipment.get(0).getEqpReferenceId());
		assertTrue(expected != null);
	}

	private EquipmentDTOV1 createRack(String name) {
		EquipmentDTOV1 equipmentDTO = new EquipmentDTOV1();
		equipmentDTO.setcontainer("RACK");
		equipmentDTO.setName(name);
		equipmentDTO.setType("Frame");
		EquipmentSpec equipmentSpec = equipmentSpecRepository.findByName("EQP_CREATE_ES");
		equipmentDTO.setTemplateReference((long) equipmentSpec.getEquipmentSpecRefId());
		equipmentDTO.setsiteReference(1L);
		equipmentDTO.setCustomerReference(1L);
		equipmentDTO.setparentShelfReference(1L);
		equipmentDTO.setClli("HUMLPAHM");
		return equipmentDTO;
	}
}
