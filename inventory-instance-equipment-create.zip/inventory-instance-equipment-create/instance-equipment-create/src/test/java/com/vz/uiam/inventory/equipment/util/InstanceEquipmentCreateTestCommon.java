/**
 * 
 */
package com.vz.uiam.inventory.equipment.util;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import org.springframework.util.ResourceUtils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;

/**
 * <p>
 * This utility class used for common test related functionalities
 * </p>
 * 
 * @date 14-June-2017
 * @author Asif Billa
 *
 */
public class InstanceEquipmentCreateTestCommon {
	/*
	 * Controller test JSON File paths
	 */
	protected static final String EXCEPTION_MESSAGE = "Exception Occured : {} ";
	protected static final String JSON_PARSING_EXCEPTION = "JSON Parsing Exception: {} ";
	protected static final String CREATE_EQUIPMENT_JSON = "/create-equipment-request.json";
	protected static final String ANY_RI_EQUIPMENT_JSON="/any-ri-equipment.json";
	protected static final String SU_RI_EQUIPMENT_JSON="/su-ri-equipment.json";
	protected static final String NETWORK_IPV4_JSON="/network-ipv4.json";
	protected static final String DIR_INV_CONFIG_JSON="/dir-inv-config.json";
	protected static final String ASSIGN_DTO = "/assignNextAvailNonPreassignRequest.json";
	protected static final String IP_ASSIGNMENT_REQ = "/ipAssignmentRequest.json";
	protected static final String EQUIPMENT ="/equipment.json";
	protected static final String ALL_ATTR_LIST = "/attr-list.json";
	protected static final String NGPON2_EQUIPMENT_JSON = "/ngpon-equipment-request.json";
	protected static final String NGPON2_EQUIPMENT_HOSTNAME_JSON = "/ngpon-equipment-hostname-request.json";
	protected static final String MSERI_EQUIPMENT_JSON = "/mseri-equipment-request.json";
	public static final Long DEFAULT_SITE_ID = 0L; 
	protected static final String TID_LOGICAL = "IRVLTXM2K62-SU01RI-V0";
	protected static final String NULL = null;
	protected static final String ID = "1";
	protected static final String HOST_NAME = "HOST_NAME";
	/**
	 * Convert object to JSON String
	 * 
	 * @param object
	 * @return
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public String fromJavaToJson(Serializable object) throws JsonMappingException, IOException {
		ObjectMapper jsonMapper = new ObjectMapper();
		return jsonMapper.writeValueAsString(object);
	}

	/**
	 * Convert a JSON string to an object
	 * 
	 * @param <T>
	 * @param json
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public <T> Object fromJsonToJava(String json, Class<T> clazz) throws JsonMappingException, IOException {
		ObjectMapper jsonMapper = new ObjectMapper();
		return jsonMapper.readValue(json, clazz);
	}

	/**
	 * Convert a JSON string to an object
	 * 
	 * @param <T>
	 * @param json
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public <T> Object fromJsonArrayToJava(String json) throws JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(json, new TypeReference<List<T>>() {
		});
	}

	/**
	 * <p>
	 * This method takes the String path of the resource json file, reads the
	 * value & sends the response as list of {@link DiversityTemplate}
	 * </p>
	 * 
	 * @param path
	 * @param clazz
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public <T> List<T> fromFileToJavaList(String path) throws JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		File file = ResourceUtils.getFile(this.getClass().getResource(path));

		return mapper.readValue(file, new TypeReference<List<AttributesDTO>>() {
		});
	}

	/**
	 * Convert a JSON string to an object
	 * 
	 * @param <T>
	 * 
	 * @param json
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public <T> T fromJsonFileToJava(String path, Class<T> clazz) throws JsonMappingException, IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		File file = ResourceUtils.getFile(this.getClass().getResource(path));

		return objectMapper.readValue(file, clazz);
	}

	/**
	 * <p>
	 * This method converts Java object to Json Bytes
	 * </p>
	 * 
	 * @param <T>
	 * @param object
	 * @return
	 * @throws IOException
	 */
	public static <T> byte[] convertObjectToJsonBytes(T t) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(t);
	}

}