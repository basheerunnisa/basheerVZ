package com.vz.uiam.inventory.equipment.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.common.monitor.performance.PerformanceMetrics;
import com.vz.uiam.inventory.equipment.model.BulkEquipRequestDTO;
import com.vz.uiam.inventory.equipment.model.EntityResponseDTO;
import com.vz.uiam.inventory.equipment.model.EquipDomainOperationDTO;
import com.vz.uiam.inventory.equipment.service.BulkOperationService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "Bulk Equipment Shelf Instance modification", description = "API for Equipment Shelf Instance bulk modify")
@PreAuthorize("hasAnyAuthority('ROLE:IVAPP_USER','ROLE:IVAPP_TESTER')")
public class BulkOperationController {

	@Autowired
	private BulkOperationService bulkOperationService;
	
	@RequestMapping(value = "equipment/bulkoperation/create", method = RequestMethod.POST)
	@PerformanceMetrics(sla = 1000)
	@ApiOperation(value = "Bulk equipment creation", notes = "Service for bulk equipment creation SLA:1000 ms", response = EntityResponseDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful received request", response = EntityResponseDTO.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	public EntityResponseDTO equipBulkCreateProcess(@RequestBody BulkEquipRequestDTO bulkEquipRequestDTO, HttpServletRequest request,@RequestHeader(value = "USER_ID", required = false) String userID) {		
		return bulkOperationService.createEquipment(bulkEquipRequestDTO, userID, request);
	}	
	
	@RequestMapping(value = "equipment/bulkoperation/adddomains", method = RequestMethod.POST)
	@PerformanceMetrics(sla = 1000)
	@ApiOperation(value = "Bulk equipment domain creation", notes = "Service for bulk equipment domain creation SLA:1000 ms", response = EntityResponseDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful received request", response = EntityResponseDTO.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	public EntityResponseDTO equipBulkDomainCreateProcess(@RequestBody List<EquipDomainOperationDTO> equipDomainOperationDTO, HttpServletRequest request) {
		EntityResponseDTO response = new EntityResponseDTO();
		if(equipDomainOperationDTO != null && !equipDomainOperationDTO.isEmpty()){
			response = bulkOperationService.bulkDomainCreation(equipDomainOperationDTO, request);
		}
		return response;
	}
}