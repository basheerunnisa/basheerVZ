package com.vz.uiam.inventory.equipment.enumeration;

/**
 * Enum for inventory entities
 * @author DIXITSH
 *
 */
public enum EntityType {
	
	SHELF, RACK, VIRTUAL_SHELF, SLOT;
	

}
