package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.DirContainerType;





@Transactional
public interface DirContainerTypeRepository extends JpaRepository<DirContainerType, String> {

}