package com.vz.uiam.inventory.equipment.exception.advice;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.TypeMismatchException;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.vz.uiam.inventory.equipment.exception.AssignmentServiceFailureException;
import com.vz.uiam.inventory.equipment.exception.BadRequestException;
import com.vz.uiam.inventory.equipment.exception.DataNotFoundException;
import com.vz.uiam.inventory.equipment.model.ErrorResponseDTO;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateConstant;
import com.vz.uiam.inventory.equipment.exception.HttpErrorException;
import com.vz.uiam.inventory.equipment.exception.MethodFailureException;

@ControllerAdvice
public class ServiceOrderGlobalAdvicer {

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(BindException.class)
	@ResponseBody
	public List<ErrorResponseDTO> handleMethodArgumentNotValid(HttpServletRequest req, BindException ex) {

		List<ObjectError> errors = ex.getBindingResult().getAllErrors();
		List<ErrorResponseDTO> errorList = new ArrayList<ErrorResponseDTO>();

		for (ObjectError e : errors) {
			if (e instanceof FieldError) {
				FieldError fe = (FieldError) e;
				errorList.add(new ErrorResponseDTO(HttpStatus.BAD_REQUEST, e.getCode(),
						fe.getField() + " " + e.getDefaultMessage(), req.getRequestURI(),
						InstanceEquipmentCreateConstant.ERROR));
			} else {
				errorList.add(new ErrorResponseDTO(HttpStatus.BAD_REQUEST, e.getCode(), e.getDefaultMessage(),
						req.getRequestURI(), InstanceEquipmentCreateConstant.ERROR));
			}

		}
		return errorList;
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(TypeMismatchException.class)
	@ResponseBody
	public List<ErrorResponseDTO> handleMethodArgumentNotValid(HttpServletRequest req, TypeMismatchException ex) {

		List<ErrorResponseDTO> errorList = new ArrayList<ErrorResponseDTO>();
		errorList.add(
				new ErrorResponseDTO(HttpStatus.BAD_REQUEST, "typeMismatch", ex.getMessage(), req.getRequestURI(), InstanceEquipmentCreateConstant.ERROR));
		return errorList;
	}

	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(DataNotFoundException.class)
	@ResponseBody
	public List<ErrorResponseDTO> handleMethodArgumentNotValid(HttpServletRequest req, DataNotFoundException ex) {

		List<ErrorResponseDTO> errorList = new ArrayList<ErrorResponseDTO>();
		errorList.add(new ErrorResponseDTO(HttpStatus.NOT_FOUND, "Not Found", ex.getMessage(), req.getRequestURI(), InstanceEquipmentCreateConstant.ERROR));
		return errorList;
	}

	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(HttpErrorException.class)
	@ResponseBody
	public List<ErrorResponseDTO> handleMethodFailureError(HttpServletRequest req, HttpErrorException ex) {

		return ex.getErrorResponseList();
	}

	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(AssignmentServiceFailureException.class)
	@ResponseBody
	public List<ErrorResponseDTO> handleAssignmentServiceFailureError(HttpServletRequest req,
			AssignmentServiceFailureException ex) {
		List<ErrorResponseDTO> errorList = new ArrayList<ErrorResponseDTO>();
		errorList.add(new ErrorResponseDTO(HttpStatus.INTERNAL_SERVER_ERROR, ex.getStatusCode(),
				ex.getStatusDescription(), req.getRequestURI(),ex.getStatus()));

		return errorList;
	}
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(BadRequestException.class)
	@ResponseBody
	public List<ErrorResponseDTO> handleMethodArgumentNotValid(
			HttpServletRequest req, BadRequestException ex) {

		FieldError e = ex.getError();
		List<ErrorResponseDTO> errorList = new ArrayList<ErrorResponseDTO>();
		errorList.add(new ErrorResponseDTO(HttpStatus.BAD_REQUEST, e.getField(),
				e.getDefaultMessage(), req.getRequestURI(),
				InstanceEquipmentCreateConstant.ERROR));
		
		return errorList;
	}
	
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(MethodFailureException.class)
	@ResponseBody
	public List<ErrorResponseDTO> handleMethodFailureError(HttpServletRequest req, MethodFailureException ex) {

		List<ErrorResponseDTO> errorList = new ArrayList<ErrorResponseDTO>();
		errorList.add(new ErrorResponseDTO(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Error", ex.getMessage(), req.getRequestURI()));
		return errorList;
	}

}