package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.Card;

@Transactional
public interface CardRepository extends JpaRepository<Card, Long> {

	List<Card> findByEqpReferenceId(Long eqpReferenceId);
	
}