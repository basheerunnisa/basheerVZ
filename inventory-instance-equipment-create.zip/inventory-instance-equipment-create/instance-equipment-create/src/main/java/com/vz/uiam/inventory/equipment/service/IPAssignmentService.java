package com.vz.uiam.inventory.equipment.service;

/**
 * <p>
 * This service to assign loop back to to RI
 * </p>
 *  
 * @author Chintan Patel
 * @date 06-Nov-2017
 *
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vz.uiam.common.audit.exception.MethodFailureException;
import com.vz.uiam.inventory.equipment.enumeration.DirInventoryConfigGroups;
import com.vz.uiam.inventory.equipment.enumeration.ErrorCodeEnum;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInventoryConfig;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInventoryConfigRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.instance.rest.api.model.IPAssignmentDTO;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateConstant;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;
import com.vz.uiam.inventory.instance.rest.api.model.IPAssignmentResponseDTO;
import com.vz.uiam.inventory.instance.rest.api.model.IPAttribute;

@Service
public class IPAssignmentService {

	private static final Logger LOGGER = LoggerFactory.getLogger(IPAssignmentService.class);

	@Autowired
	private AttributeSpecifiactionService attributeSpecificationService;
	
	@Autowired
	private DirInventoryConfigRepository dirInventoryConfigRepository;
	
	@Autowired
	private EquipmentRepository equipmentRepository;

	@Autowired
	private LoopBackIPAssignmentService loopBackIPAssignmentService;

	@Autowired
	private FabricInterConnectIPAssignmentService fabricInterConnectIPAssignmentService;

	/**
	 * <p>
	 * This method assigns IP for RI basis on following criteria
	 * </p>
	 * <li>Calls loopBackIPAssignmentService or
	 * fabricInterConnectIPAssignmentService based on below condition if
	 * suTIDLogical is null or not same as tidLogical in IPAssignmentDTO then
	 * call loopBackIPAssignmentService else call
	 * fabricInterConnectIPAssignmentService table</li>
	 * 
	 * @param ipAssignmentDTO
	 * @return
	 */
	public IPAssignmentResponseDTO assignIPForEquipment(IPAssignmentDTO ipAssignmentDTO) {
		LOGGER.info("Entering into assignIPForEquipment with request ipAssignmentDTO : {}",ipAssignmentDTO);
		List<List<AttributesDTO>> allRIAttributeslist = null;
		List<AttributesDTO> loopBackAttributes = null;
		List<AttributesDTO> eqpAttributes = new ArrayList<>();
		List<AttributesDTO> suRIAttributes = new ArrayList<>();
		List<AttributesDTO> updatedsuRIAttributes = null;
		Equipment equipment = null;
		Equipment suRIequipment = null;
		List<IPAttribute> ipAttributes = null;
		IPAssignmentResponseDTO ipAssignmentResponse = null;
		
		equipment = getEquipment(ipAssignmentDTO);

		if (InstanceEquipmentCreateConstant.validateNotNull(equipment)) {
			loopBackAttributes = loopBackIPAssignmentService.assignLoopBackIPForEqp(equipment);
			eqpAttributes.addAll(loopBackAttributes);

			if (ipAssignmentDTO.getSuTIDLogical() != null
					&& !ipAssignmentDTO.gettIDLogical().equalsIgnoreCase(ipAssignmentDTO.getSuTIDLogical())) {

				suRIequipment = fetchEquipmentByTidLogical(ipAssignmentDTO.getSuTIDLogical());

				// Call Fabric Interconnect service if suTIDLogical is not null
				allRIAttributeslist = fabricInterConnectIPAssignmentService
						.assignP2PIPForFabricInterConnectRI(equipment, suRIequipment);

				eqpAttributes.addAll(allRIAttributeslist.get(0));
				suRIAttributes.addAll(allRIAttributeslist.get(1));
			}

			LOGGER.info("Request received for updating RI Attributes with EqpRefId:{} and RI-Attributes:{}",
					equipment.getEqpReferenceId(), eqpAttributes);
			List<AttributesDTO> updatedRIAttributes = attributeSpecificationService
					.addIpToAttributeSpecification(eqpAttributes, equipment.getEqpReferenceId());
			LOGGER.info("Successfully Updated RI attributes :{}", updatedRIAttributes);

			if (suRIequipment != null) {
				LOGGER.info("Request received for updating suRI Attributes with EqpRefId:{} and SURI-Attributes:{}",
						suRIequipment.getEqpReferenceId(), suRIAttributes);
				updatedsuRIAttributes = attributeSpecificationService.addIpToAttributeSpecification(suRIAttributes,
						suRIequipment.getEqpReferenceId());
				LOGGER.info("Successfully Updated suRI attributes :{}", updatedsuRIAttributes);
			}

			ipAttributes = eqpAttributes.stream().map(e -> new IPAttribute(e.getAttrName(), e.getAttrValue()))
					.collect(Collectors.toList());
			if (InstanceEquipmentCreateConstant.validateNotNull(ipAttributes)) {
				ipAssignmentResponse = populateIPAssignmentResponse(equipment, ipAttributes);
			}
		}
		return ipAssignmentResponse;
	}
	/**
	 * <p>
	 * This method is to get Equipment based on equipment ref id
	 * </p>
	 * 
	 * @param equipmentRefID
	 * @return
	 */
	public Equipment fetchEquipmentByEqpRefId(String equipmentRefID) {
		Long eqpRefID = Long.parseLong(equipmentRefID);

		Equipment equipment = equipmentRepository.findOne(eqpRefID);
		LOGGER.info("Equipment : {}", equipment);

		return equipment;
	}

	/**
	 * <p>
	 * This method is to fetch Equipment based on Tid Logical
	 * </p>
	 * 
	 * @param equipmentRefID
	 * @return
	 */
	public Equipment fetchEquipmentByTidLogical(String tidLogical) {
		List<Equipment> equipments = equipmentRepository.findByTidLogical(tidLogical);
		LOGGER.info("Equipment Details: {}", equipments);
		return equipments.get(0);
	}
	
	
	/**
	 * <p>
	 * This method is to fetch Equipment based on host name
	 * </p>
	 * 
	 * @param hostName
	 * @return
	 */
	public Equipment fetchEquipmentByHostName(String hostName) {
		List<Equipment> equipments = equipmentRepository.findByHostName(hostName);
		LOGGER.info("Equipment Details: {}", equipments);
		return equipments.get(0);
	}

	/**
	 * This method is to update equipment attributes
	 * 
	 * @param attributeType
	 * @param equipment
	 * @param ipAddressMap
	 * @param sutIDLogical
	 * @return
	 */
	public List<AttributesDTO> buildEqpAttributes(String attributeType, Equipment equipment,
			Map<String, String> ipAddressMap,String functionalType) {
		List<AttributesDTO> attributes = new ArrayList<>();
		if (ipAddressMap != null && !ipAddressMap.isEmpty()) {
			ipAddressMap.forEach((k, v) -> {
				attributes.add(getAttributes(attributeType, k, v, equipment, functionalType));
			});
		}
		LOGGER.info("Attributes formed for respective Equipment in buildEqpAttributes method: {} ",attributes);
		return attributes;
	}
	
	/**
	 * 
	 * This method is used to populate attributes
	 * 
	 * @param attributeType
	 * @param riIPAddresses
	 * @param ipAssignmentDTO
	 * @return
	 */
	public Map<String, String> buildAttributesMap(String attributeType, List<String> riIPAddresses,
			String riTid) {

		Map<String, String> ipAddressMap = new HashMap<>();
		if (attributeType.equalsIgnoreCase(InstanceEquipmentCreateConstant.OTHER_RI)) {
			ipAddressMap.put(InstanceEquipmentCreateConstant.SU_RI_HOSTNAME, riTid);
			ipAddressMap.put(InstanceEquipmentCreateConstant.SU_RI_FABRIC_INTERCONNECT_IP_ADDRESS,
					riIPAddresses.get(0));
			ipAddressMap.put(InstanceEquipmentCreateConstant.CURRENT_RI_FABRIC_INTERCONNECT_IP_ADDRESS,
					riIPAddresses.get(1));
		} else if (attributeType.equalsIgnoreCase(InstanceEquipmentCreateConstant.SU_RI)) {
			ipAddressMap.put(InstanceEquipmentCreateConstant.SU_RI_FABRIC_INTERCONNECT_IP_ADDRESS,
					riIPAddresses.get(0));
			ipAddressMap.put(InstanceEquipmentCreateConstant.OTHER_RI_FABRIC_INTERCONNECT_IP_ADDRESS,
					riIPAddresses.get(1));
			ipAddressMap.put(InstanceEquipmentCreateConstant.OTHER_RI_HOSTNAME, riTid);
		}
		LOGGER.info("IP addresses assigned for equipment in buildAttributesMap method with ipAddressMap : {}",ipAddressMap);
		return ipAddressMap;
	}

	/**
	 * <p>
	 * This is the method to set IPAssignmntDTO
	 * </p>
	 * 
	 * @param equipment
	 * @param ipAttributes
	 * @return
	 */
	private IPAssignmentResponseDTO populateIPAssignmentResponse(Equipment equipment, List<IPAttribute> ipAttributes) {

		IPAssignmentResponseDTO ipAssignmentResponseDTO = new IPAssignmentResponseDTO();

		ipAssignmentResponseDTO.setEquimentRefId(equipment.getEqpReferenceId());
		ipAssignmentResponseDTO.settIDLogical(equipment.getTidLogical());
		ipAssignmentResponseDTO.setEquipmentName(equipment.getEqpName());
		ipAssignmentResponseDTO.setHostName(equipment.getHostName());
		ipAssignmentResponseDTO.setEquipmentType(equipment.getDirEqpType().trim());
		ipAssignmentResponseDTO.setFunctionalType(equipment.getFunctionalType());
		ipAssignmentResponseDTO.setIpAttributes(ipAttributes);

		return ipAssignmentResponseDTO;
	}

	/**
	 * <p>
	 * fetch attribute group name from DIR_INVENTORY_CONFIG table
	 * </p>
	 * 
	 * @param attGrpName
	 * @return
	 */
	private String fetchAttGrpName(String configGroupName, String configName) {
		DirInventoryConfig dirInventoryConfig = null;
		if (configGroupName != null) {
			dirInventoryConfig = dirInventoryConfigRepository.findByGroupNameAndConfigName(configGroupName,configName);
		}
		if (null == dirInventoryConfig) {
			LOGGER.error("could not able to get the Attribute Group Name");
			throw new MethodFailureException(ErrorCodeEnum.INVALID_ATTRIBUTE_GROUP_NAME.getCode(),
					ErrorCodeEnum.INVALID_ATTRIBUTE_GROUP_NAME.getDescription(), "assignment IP is empty");
		}
		LOGGER.info("Return dirInventoryConfig details : {} with config value :{}",dirInventoryConfig, dirInventoryConfig.getConfigValue());
		return dirInventoryConfig.getConfigValue();
	}

	/**
	 * This method is used to get the loopBackIPAttributes
	 * 
	 * @param attributeName
	 * @param IPaddress
	 * @param equipment
	 * @return
	 */
	public AttributesDTO getLoopBackIPAttributes(String attributeName, String IPAddress, Equipment equipment) {
		AttributesDTO attributeIPV4DTO = new AttributesDTO();

		String attrGrpName = fetchAttGrpName(DirInventoryConfigGroups.LOOP_BACK_IP_ASSIGNMENT.value(),
				InstanceEquipmentCreateConstant.ATTRIBUTE_GROUP_NAME);
		if (attrGrpName != null) {
			attributeIPV4DTO.setAttrGroupName(attrGrpName);
			attributeIPV4DTO.setAttrName(attributeName);
			attributeIPV4DTO.setAttrValue(IPAddress);
			attributeIPV4DTO.setFunctionalType(equipment.getFunctionalType());
			attributeIPV4DTO.setEntityType(equipment.getDirEqpType());
		} else {
			LOGGER.error("could not able to get the Attr Group Name");
			throw new MethodFailureException(ErrorCodeEnum.INVALID_ATTRIBUTE_GROUP_NAME.getCode(),
					ErrorCodeEnum.INVALID_ATTRIBUTE_GROUP_NAME.getDescription(), "assignment IP is empty");
		}
		LOGGER.info("Attribute for LoopBackIPAttributes attributeIPV4DTO : {}",attributeIPV4DTO);
		return attributeIPV4DTO;
	}
	
	/**
	 * This method is used to get the attributes associated for the RI instance
	 * 
	 * @param attributeType
	 * @param attributeName
	 * @param IPaddress
	 * @param equipment
	 * @param sutIDLogical
	 * @return
	 */
	public AttributesDTO getAttributes(String attributeType, String attributeName, String ipAddress, Equipment equipment, String functionalType) {
		
		AttributesDTO attributeIPV4DTO = new AttributesDTO();	
		String attrGrpName = getAttributeGroupName(attributeType, functionalType);
		if (attrGrpName != null) {
			attributeIPV4DTO.setAttrGroupName(attrGrpName);
			attributeIPV4DTO.setAttrName(attributeName);
			attributeIPV4DTO.setAttrValue(ipAddress);
			attributeIPV4DTO.setFunctionalType(equipment.getFunctionalType());
			attributeIPV4DTO.setEntityType(equipment.getDirEqpType());
		} else {
			LOGGER.error("could not able to get Attribute Group Name");
			throw new MethodFailureException(ErrorCodeEnum.INVALID_ATTRIBUTE_GROUP_NAME.getCode(),
					ErrorCodeEnum.INVALID_ATTRIBUTE_GROUP_NAME.getDescription(), "assignment IP is empty");
		}
		LOGGER.info("Attribute for Fabric Interconnect : {} ",attributeIPV4DTO);
		return attributeIPV4DTO;
	}
	
	/**
	 * This method is used to fetch the AttrGrpName from config table based on RI instance
	 * 
	 * @param attributeType
	 * @param equipment
	 * @return
	 */
	public String getAttributeGroupName(String attributeType, String functionalType) {
		LOGGER.info("Attempting to fecth Group Name from DB table -> with attributeType:{}, functionaltype:{}",
				attributeType, functionalType);
		String attrGrpName = null;
		if (attributeType.equalsIgnoreCase(InstanceEquipmentCreateConstant.LOOP_BACK)) {
			attrGrpName = fetchAttGrpName(DirInventoryConfigGroups.LOOP_BACK_IP_ASSIGNMENT.value(),
					InstanceEquipmentCreateConstant.ATTRIBUTE_GROUP_NAME);
		} else if (attributeType.equals(InstanceEquipmentCreateConstant.SU_RI)) {
			attrGrpName = fetchAttGrpName(DirInventoryConfigGroups.FABRIC_INTERCONNET_IP_ASSIGNMENT_GRP.value(),
					functionalType);
		} else if (attributeType.equalsIgnoreCase(InstanceEquipmentCreateConstant.OTHER_RI)) {
			attrGrpName = fetchAttGrpName(DirInventoryConfigGroups.FABRIC_INTERCONNET_IP_ASSIGNMENT_GRP.value(),
					functionalType);
		}
		LOGGER.info("Successfully received Attribute group name from DB: {}",attrGrpName);
		
		return attrGrpName;
	}
	
	
	/**
	 * This method is to get Equipment based on request DTO
	 * 
	 * @param ipAssignmentDTO
	 * @return
	 */
	public Equipment getEquipment(IPAssignmentDTO ipAssignmentDTO) {
		Equipment equipment = null;
		
		if (ipAssignmentDTO.getHostName() != null && !ipAssignmentDTO.getHostName().isEmpty()) {
			equipment =fetchEquipmentByHostName(ipAssignmentDTO.getHostName().trim());
			LOGGER.info("Equipment details based on Host_Name:{} Equipment:{}", ipAssignmentDTO.getHostName(),
					equipment);
		}else if (ipAssignmentDTO.getEquimentRefId() != null && !ipAssignmentDTO.getEquimentRefId().isEmpty()) {
			equipment =fetchEquipmentByEqpRefId(ipAssignmentDTO.getEquimentRefId().trim());
			LOGGER.info("Equipment details based on Eqp_Ref_Id:{} Equipment:{}", ipAssignmentDTO.getEquimentRefId(),
					equipment);
		} else if (ipAssignmentDTO.gettIDLogical() != null && !ipAssignmentDTO.gettIDLogical().isEmpty()) {
			equipment = fetchEquipmentByTidLogical(ipAssignmentDTO.gettIDLogical().trim());
			LOGGER.info("Equipment details based on Eqp_Tid_Logical:{} Equipment:{}", ipAssignmentDTO.gettIDLogical(),
					equipment);
		}
		return equipment;
	}
}