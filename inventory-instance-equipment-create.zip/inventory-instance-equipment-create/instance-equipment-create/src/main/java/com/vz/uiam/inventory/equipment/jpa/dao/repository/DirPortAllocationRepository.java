package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import org.javers.spring.annotation.JaversSpringDataAuditable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.DirPortAllocation;

/**
 * <p>
 * JPA repository for DB table -> DIR_PORT_ALLOCATION
 * 
 * @author Asif Billa
 * @date 13-June-2017
 *
 */
@Transactional
@JaversSpringDataAuditable
public interface DirPortAllocationRepository extends JpaRepository<DirPortAllocation, Long> {

}