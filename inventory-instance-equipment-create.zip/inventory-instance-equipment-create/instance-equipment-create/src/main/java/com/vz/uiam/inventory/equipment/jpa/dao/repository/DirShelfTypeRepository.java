package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.DirShelfType;



@Transactional
public interface DirShelfTypeRepository extends JpaRepository<DirShelfType, Long> {

	List<DirShelfType> findByShelfType(String name);
 

}