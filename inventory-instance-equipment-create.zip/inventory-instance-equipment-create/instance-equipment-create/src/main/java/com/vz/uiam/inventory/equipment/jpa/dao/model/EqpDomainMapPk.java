package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class EqpDomainMapPk  implements Serializable{

	private static final long serialVersionUID = 1L; 
	
	@Column(name="EQP_REFERENCE_ID")
	private long eqpReferenceId;
	
	@Column(name="DOMAIN_ID")
	private Integer domainId;

	public long getEqpReferenceId() {
		return eqpReferenceId;
	}

	public void setEqpReferenceId(long eqpReferenceId) {
		this.eqpReferenceId = eqpReferenceId;
	}

	public Integer getDomainId() {
		return domainId;
	}

	public void setDomainId(Integer domainId) {
		this.domainId = domainId;
	}

	@Override
	public String toString() {
		return "EqpDomainMapPk [eqpReferenceId=" + eqpReferenceId + ", domainId=" + domainId + "]";
	}
	

}
