package com.vz.uiam.inventory.equipment.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ValidationUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.common.monitor.performance.PerformanceMetrics;
import com.vz.uiam.inventory.equipment.exception.MethodFailureException;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.model.SlotDTO;
import com.vz.uiam.inventory.equipment.model.validator.AddRackValidatorNoTemplSpec;
import com.vz.uiam.inventory.equipment.model.validator.CreateEquipmentValidator;
import com.vz.uiam.inventory.equipment.model.validator.CreateEquipmentValidator.CreationType;
import com.vz.uiam.inventory.equipment.service.DirectoryService;
import com.vz.uiam.inventory.equipment.service.EquipmentCreateServiceNoTemplSpec;
import com.vz.uiam.inventory.equipment.service.EquipmentService;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("inventory/equipments")
@Api(value = "Non Template Equipment Instance Creation Task Handler", description = "Create Non Template Equipment(RACK/SHELF) ")
@PreAuthorize("hasAnyAuthority('ROLE:IVAPP_USER','ROLE:IVAPP_TESTER')")
public class EquipmentControllerNoTemplSpec {

	private static final Logger LOGGER = LoggerFactory.getLogger(EquipmentControllerNoTemplSpec.class);

	@Autowired
	private EquipmentService equipmentService;
	@Autowired
	private EquipmentCreateServiceNoTemplSpec equipCreateServiceNoTemplSpec;
	@Autowired
	private AddRackValidatorNoTemplSpec addRackValidatorNoTemplSpec;
	@Autowired
	private CreateEquipmentValidator validator;

	@RequestMapping(value = "/shelf/createWOT/v1", method = RequestMethod.POST)
	@PerformanceMetrics(sla = 60000)
	@ApiOperation(value = "Create Equipment instance without TEMPLATEs", notes = "Service to create equipment without TEMPLATEs SLA:60000 ms", response = EquipmentDTOV1.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful received request", response = EquipmentDTOV1.class), 
			@ApiResponse(code = 400, message = "Invalid input provided"), 
			@ApiResponse(code = 409, message = "Data conflict"), 
			@ApiResponse(code = 500, message = "Internal Server Error")})
	public EquipmentDTOV1 createShelfRack(
			@RequestBody EquipmentDTOV1 equipment, 
			@RequestHeader(value = "USER_ID", required = false) String userID, 
			HttpServletRequest httpRequest, BindingResult errors) throws BindException {
		
		DirectoryService.clearCache();
		equipment.setModifiedUser(EquipmentService.validateNotNull(userID) ? userID : "");
		
		if ("SHELF".equalsIgnoreCase(equipment.getcontainer())) {

			validator.setCreationType(CreationType.NON_TEMPLATE);
			ValidationUtils.invokeValidator(validator, equipment, errors);

			if (errors.hasErrors()) {
				throw new BindException(errors);
			}
			equipCreateServiceNoTemplSpec.updateEquipmentFromParent(equipment);
			EquipmentDTOV1 shelf = equipCreateServiceNoTemplSpec.createEquipment(equipment, httpRequest);
			if (shelf == null) {
				throw new MethodFailureException("Shelf Not Found");
			}
			List<AttributesDTO> equipmentAttributesDTOList = equipment.getAttributeList();
			String eqpFunctionalType = shelf.getFunctionalEquipTypeName();
			shelf.setAttributeList(equipmentService.createEquipmentAttributes(shelf.getEquipmentReference().longValue(), shelf.getType(), eqpFunctionalType, equipmentAttributesDTOList));

			String slotIDs = ", SLOT#  ";
			if (shelf.getSlotDTOList() != null && !shelf.getSlotDTOList().isEmpty())
				for (SlotDTO slotDTO : shelf.getSlotDTOList())
					slotIDs += ("  "+slotDTO.getSlotInstId());
			LOGGER.info(" <= EquipmentControllerNoTemplSpec.createShelf SHELF# {}   {} ", shelf.getEquipmentReference(), slotIDs);
			equipment.setEquipmentReference(shelf.getEquipmentReference());
			equipment.setSlotDTOList(shelf.getSlotDTOList());
			return equipment;
		}

		if ("RACK".equalsIgnoreCase(equipment.getcontainer())) {
			LOGGER.info("=> EquipmentControllerNoTemplSpec:createShelfRack:Input [" + equipment + "] ");
			ValidationUtils.invokeValidator(addRackValidatorNoTemplSpec, equipment, errors);

			if (errors.hasErrors()) {
				throw new BindException(errors);
			}
			
			EquipmentDTOV1 rack = equipCreateServiceNoTemplSpec.addRack(equipment, httpRequest);
			if (rack == null) {
				throw new MethodFailureException("Rack Not Found/Created ");
			}

			List<AttributesDTO> equipmentAttributesDTOList = equipment.getAttributeList();
			String eqpFunctionalType = rack.getFunctionalEquipTypeName();
			rack.setAttributeList(equipmentService.createEquipmentAttributes(rack.getEquipmentReference(), rack.getType(), eqpFunctionalType, equipmentAttributesDTOList));
			LOGGER.info(" <= EquipmentControllerNoTemplSpec.addRack   {}    ", rack.getEquipmentReference());
			return rack;
		}
		return null;
	}
}
