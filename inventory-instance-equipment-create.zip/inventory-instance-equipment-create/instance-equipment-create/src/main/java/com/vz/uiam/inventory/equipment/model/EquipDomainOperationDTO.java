package com.vz.uiam.inventory.equipment.model;

import java.io.Serializable;
import java.util.List;

import com.vz.uiam.common.usermanagement.rest.model.DirDomainsDTO;

public class EquipDomainOperationDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long equipmentReference;
	private List<DirDomainsDTO> domains;
	
		
	public Long getEquipmentReference() {
		return equipmentReference;
	}



	public void setEquipmentReference(Long equipmentReference) {
		this.equipmentReference = equipmentReference;
	}

	
	public List<DirDomainsDTO> getDomains() {
		return domains;
	}



	public void setDomains(List<DirDomainsDTO> domains) {
		this.domains = domains;
	}



	@Override
	public String toString() {
		return "EquipDomainOperationDTO [equipmentReference=" + equipmentReference + ",domianNames = " +domains+ "]";
	}
	
}
