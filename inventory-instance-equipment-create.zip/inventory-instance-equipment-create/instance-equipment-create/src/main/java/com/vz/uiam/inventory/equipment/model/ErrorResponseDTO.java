package com.vz.uiam.inventory.equipment.model;

import java.io.Serializable;
import java.util.Date;

import org.springframework.http.HttpStatus;

public class ErrorResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	public Date time;
	public HttpStatus httpStatus;
	public String code;
	public String message;
	public String object;
	public String status;

	public ErrorResponseDTO() {
		super();
	}

	public ErrorResponseDTO(HttpStatus httpStatus, String code, String message, String object) {
		this.httpStatus = httpStatus;
		this.code = code;
		this.message = message;
		this.object = object;
		this.time = new Date();
	}

	public ErrorResponseDTO(HttpStatus httpStatus, String code, String message, String object, String status) {
		this.httpStatus = httpStatus;
		this.code = code;
		this.message = message;
		this.object = object;
		this.time = new Date();
		this.status = status;

	    }
	public HttpStatus getHttpStatus() {
		return this.httpStatus;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getTime() {
		return this.time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public String getUri() {
		return this.object;
	}

	public void setUri(String uri) {
		this.object = uri;
	}

	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ErrorResponseDTO [time=" + time + ", httpStatus=" + httpStatus + ", code=" + code + ", message="
				+ message + ", object=" + object + "status=" + status + "]";
	}

}