package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.util.List;

import org.javers.spring.annotation.JaversSpringDataAuditable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.CardEqpFunctionalTypeMap;
import com.vz.uiam.inventory.equipment.jpa.dao.model.CardEqpFunctionalTypeMapPK;


@Transactional
@JaversSpringDataAuditable
public interface CardEqpFunctionalTypeMapRepository extends JpaRepository<CardEqpFunctionalTypeMap, CardEqpFunctionalTypeMapPK>{

	List<CardEqpFunctionalTypeMap> findByCardEqpFunctionalTypeMapPkPartNumber(String partNumber);
	
}

