package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.util.List;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvStatus;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvStatusPk;

@Transactional
public interface DirInvStatusRepository extends JpaRepository<DirInvStatus, DirInvStatusPk> {
	
	DirInvStatus findByPkStatusAndPkEntityNameIgnoreCase(String status, String name);

	DirInvStatus findByInvStatusId(Long StatusId);

	@Query(value = "SELECT * FROM DIR_INV_STATUS WHERE INV_STATUS=:status AND ENTITY_NAME = 'PORT'", nativeQuery = true)
	DirInvStatus findByInvStatusForPort(@Param(value = "status") String status);

	@Query(value = "SELECT * FROM DIR_INV_STATUS WHERE INV_STATUS=:status AND ENTITY_NAME = 'EQUIPMENT'", nativeQuery = true)
	DirInvStatus getEquipmentStatusByName(@Param(value = "status") String status);

	@Query(value = "SELECT * FROM DIR_INV_STATUS WHERE INV_STATUS=:status AND ENTITY_NAME = 'CARD'", nativeQuery = true)
	DirInvStatus findByInvStatusForCard(@Param(value = "status") String string);

	@Cacheable("dirInvStatus")
	List<DirInvStatus> findByPkEntityNameIgnoreCase(String name);

	@Cacheable("dirInvStatus")
	List<DirInvStatus> findByPkEntityNameIgnoreCaseIn(List<String> entities);
}