package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.Site;

@Transactional
public interface SiteRepository extends JpaRepository<Site,Long> {

	List<Site> findByClli(String clli);
	
	Site findOneByClliIgnoreCase(String clli);

	Site findBySiteName(String string);
	
	Site findBySiteReferenceId(long siteReferenceId);

}