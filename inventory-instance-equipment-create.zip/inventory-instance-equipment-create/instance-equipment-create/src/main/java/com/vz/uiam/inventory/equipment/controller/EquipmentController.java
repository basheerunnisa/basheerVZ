/**
 * 
 */
package com.vz.uiam.inventory.equipment.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ValidationUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.common.monitor.performance.PerformanceMetrics;
import com.vz.uiam.inventory.equipment.enumeration.EntityOperation;
import com.vz.uiam.inventory.equipment.enumeration.EntityType;
import com.vz.uiam.inventory.equipment.exception.MethodFailureException;
import com.vz.uiam.inventory.equipment.model.EntityEventData;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.model.validator.CreateEquipmentValidator;
import com.vz.uiam.inventory.equipment.model.validator.CreateEquipmentValidator.CreationType;
import com.vz.uiam.inventory.equipment.service.DirectoryService;
import com.vz.uiam.inventory.equipment.service.EquipmentCreateService;
import com.vz.uiam.inventory.equipment.service.EquipmentService;
import com.vz.uiam.inventory.equipment.service.KafkaEventPublisher;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author Karthik Amarnath
 *
 */
@RestController
@RequestMapping("inventory/equipments")
@Api(value = "Equipment Instance creation Task handler", description = "API for Equipment Instace create Task Handler")
@PreAuthorize("hasAnyAuthority('ROLE:IVAPP_USER','ROLE:IVAPP_TESTER')")
public class EquipmentController {
	
	@Autowired
	private CreateEquipmentValidator validator;
	@Autowired
	private EquipmentCreateService equipCreateService;
	@Autowired
	private EquipmentService equipmentService;
	@Autowired
	private KafkaEventPublisher kafkaEventPublisher;

	@RequestMapping(value = "/shelf/create/v1", method = RequestMethod.POST)
	@PerformanceMetrics(sla = 60000)
	@ApiOperation(value = "Create Equipment instance using Template", notes = "Service to create equipment using template SLA:60000 ms", response = EquipmentDTOV1.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful received request", response = EquipmentDTOV1.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 409, message = "Data conflict"),
			@ApiResponse(code = 500, message = "Internal Server Error") })
	public EquipmentDTOV1 createShelf(
			@RequestBody EquipmentDTOV1 equipment,
			@RequestHeader(value = "USER_ID", required = false) String userID, 
			HttpServletRequest httpRequest, BindingResult errors) throws BindException {

		EquipmentDTOV1 respObj = validator.validatePhysicalTid(equipment, errors);
		validator.validateShelfCreation(equipment, errors);
		if (errors.hasErrors()) {
			throw new BindException(errors);
		}else if(respObj!=null){
			return respObj;
		}
		
		DirectoryService.clearCache();
		validator.setCreationType(CreationType.TEMPLATE);
		ValidationUtils.invokeValidator(validator, equipment, errors);

		if (errors.hasErrors()) {
			throw new BindException(errors);
		}
		if (userID != null && !userID.trim().isEmpty()) {
			equipment.setModifiedUser(userID);
		}
		
		EquipmentDTOV1 shelf = equipCreateService.createEquipment(equipment, httpRequest);
		
		if (shelf == null) {
			throw new MethodFailureException("Create Shelf Failed!");
		}
			
		equipmentService.updateVlanAttribute(shelf,equipment);
		
		List<AttributesDTO> equipmentAttributesDTOList = equipment.getAttributeList();
		String eqpFunctionalType = shelf.getFunctionalEquipTypeName();
		shelf.setAttributeList(equipmentService.createEquipmentAttributes(shelf.getEquipmentReference().longValue(), shelf.getType(), eqpFunctionalType, equipmentAttributesDTOList));
		
		
		/*
		 * Shelf creation Notification sending to Kafka
		 */
		kafkaEventPublisher.publishData(new EntityEventData(EntityType.SHELF.toString(), shelf.getEquipmentReference(),
				EntityOperation.INSERT.toString(), equipment));
		
		return shelf;
	}
	
	@RequestMapping(value = "/shelf/create/v2", method = RequestMethod.POST)
	@PerformanceMetrics(sla = 60000)
	@ApiOperation(value = "List of Create Equipment instance using Template", notes = "Service to create equipments using template SLA:60000 ms", response = List.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful creation of shelfs", response = EquipmentDTOV1.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 409, message = "Data conflict"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	public List<EquipmentDTOV1> createShelf(
			@RequestBody List<EquipmentDTOV1> equipment,
			@RequestHeader(value = "USER_ID", required = false) String userID, 
			HttpServletRequest httpRequest, BindingResult errors) throws BindException {
	
		DirectoryService.clearCache();
		validator.setCreationType(CreationType.TEMPLATE);
 		ValidationUtils.invokeValidator(validator, equipment, errors);
 		
		if (errors.hasErrors()){
			throw new BindException(errors);
		}
			
		return equipCreateService.createEquipments(equipment, httpRequest);
	}
}
