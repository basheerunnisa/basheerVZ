package com.vz.uiam.inventory.equipment.model;

public class AuxiliaryDTO {

	private String hostname;
	private String auxType;
	private String auxStatus;
	private Long siteReferenceId;
	
	
	public AuxiliaryDTO(){
		super();
	}
	public AuxiliaryDTO(String hostname, String auxType, String auxStatus, Long siteReferenceId) {
		this();
		this.hostname = hostname;
		this.auxType = auxType;
		this.auxStatus = auxStatus;
		this.siteReferenceId = siteReferenceId;
	}
	
	
	public String getHostname() {
		return hostname;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public String getAuxType() {
		return auxType;
	}
	public void setAuxType(String auxType) {
		this.auxType = auxType;
	}
	public String getAuxStatus() {
		return auxStatus;
	}
	public void setAuxStatus(String auxStatus) {
		this.auxStatus = auxStatus;
	}
	public Long getSiteReferenceId() {
		return siteReferenceId;
	}
	public void setSiteReferenceId(Long siteReferenceId) {
		this.siteReferenceId = siteReferenceId;
	}	
}
