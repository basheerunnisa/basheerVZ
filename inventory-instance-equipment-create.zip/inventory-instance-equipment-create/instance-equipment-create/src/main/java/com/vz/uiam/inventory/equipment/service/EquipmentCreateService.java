/**
 * 
 */
package com.vz.uiam.inventory.equipment.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.FieldError;

import com.vz.uiam.inventory.equipment.enumeration.Entity;
import com.vz.uiam.inventory.equipment.enumeration.EntityOperation;
import com.vz.uiam.inventory.equipment.enumeration.EntityType;
import com.vz.uiam.inventory.equipment.exception.BadRequestException;
import com.vz.uiam.inventory.equipment.exception.MethodFailureException;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Card;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirContainerType;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvStatus;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvType;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EquipmentSpec;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Port;
import com.vz.uiam.inventory.equipment.jpa.dao.model.PortSpec;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Site;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Slot;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.CardRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInventoryConfigRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.PortRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.PortSpecRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.SlotRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.SlotSpecRepository;
import com.vz.uiam.inventory.equipment.model.EntityEventData;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.model.SlotDTO;
import com.vz.uiam.inventory.equipment.model.mapper.ResourceMapper;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateConstant;
import com.vz.uiam.inventory.instance.rest.api.client.CardCardControllerClientInstance;
import com.vz.uiam.inventory.instance.rest.api.client.EquipmentModifyClientInstance;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;
import com.vz.uiam.inventory.instance.rest.api.service.EquipmentModifyApiServiceInstance;

/**
 * @author Karthik Amarnath
 *
 */

@Service
public class EquipmentCreateService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EquipmentCreateService.class);
	private static final List<String> LGX_SHELF_TYPES = Arrays.asList(new String[] { "ILGX", "LGI", "LGX"

	});

	@Autowired
	private CardService cardService;
	@Autowired
	private DirectoryService directoryService;
	@Autowired
	private EquipmentService equipmentService;
	@Autowired
	private EquipmentRepository equipmentRepository;
	@Autowired
	private PortSpecRepository portSpecRepository;
	@Autowired
	private SlotRepository slotRepository;
	@Autowired
	private SlotSpecRepository slotSpecRepository;
	@Autowired
	private ResourceMapper resourceMapper;
	@Autowired
	private KafkaEventPublisher kafkaEventPublisher;
	@Autowired
	private DirInventoryConfigRepository dirInvCfgRepo;
	@Autowired
	private PortRepository portRepository;
	@Autowired
	private CardCardControllerClientInstance cardCardControllerClient;
	@Autowired
	private CardRepository cardRepository;
	@Autowired
	private EquipmentModifyApiServiceInstance equipmentModifyApiServiceInstance;
	@Autowired
	private EquipmentModifyClientInstance equipmentModifyClientInstance;

	@Transactional
	public EquipmentDTOV1 createEquipment(EquipmentDTOV1 equipmentDTO, HttpServletRequest httpRequest) {

		boolean isSharedEquipment = EquipmentService.validateSharedEquipment(equipmentDTO.getAttributeList());

		Site site = directoryService.findSite(equipmentDTO);
		EquipmentSpec equipSpec = directoryService.findEquipmentSpec(equipmentDTO);
		DirContainerType dirContainerType = directoryService.findContainer(equipmentDTO.getcontainer());
		DirInvStatus dirInvStatus = directoryService.findStatusByEntityWithDefault(Entity.EQUIPMENT,
				equipmentDTO.getStatus(), "PENDING_IN");
		DirInvType dirEqpType = null;

		boolean upceCreation = equipmentDTO.getFunctionalEquipTypeName() != null
				&& "UCPE".equalsIgnoreCase(equipmentDTO.getFunctionalEquipTypeName().trim());

		if (EquipmentService.validateNotNull(equipmentDTO.getType())) {
			dirEqpType = directoryService.findTypeByEntity(Entity.EQUIPMENT, equipmentDTO.getType());
		} else {
			dirEqpType = directoryService.findTypeByEntity(Entity.EQUIPMENT_SPEC, equipSpec.getDirEqpType());
		}

		String type = null;
		if (EquipmentService.validateNotNull(equipmentDTO.getShelfType())
				&& LGX_SHELF_TYPES.contains(equipmentDTO.getShelfType().trim().toUpperCase())) {
			type = "PATCH_PANEL";
		} else {
			type = dirEqpType.getType();
		}

		String networkDomain = null;
		if (EquipmentService.validateNotNull(equipmentDTO.getNetworkDomain())) {
			networkDomain = equipmentDTO.getNetworkDomain();
		} else if (equipSpec.getManufacturer() != null && equipmentDTO.getNetworkType() != null
				&& site.getRegion() != null) {
			networkDomain = directoryService.findNetworkDomain(equipSpec.getManufacturer(),
					equipmentDTO.getNetworkType(), site.getRegion());
		}

		String mgmtTeletPort = null;
		if (EquipmentService.validateNotNull(equipmentDTO.getRawTelnetPort())
				|| EquipmentService.validateNotNull(equipmentDTO.getNormalTelnetPort())) {
			mgmtTeletPort = "RAW:" + (equipmentDTO.getRawTelnetPort() + "").trim() + "," + "NORMAL:"
					+ (equipmentDTO.getNormalTelnetPort() + "").trim();
		}

		Equipment rack = null;
		Equipment rackFrRef = null;
		if (!upceCreation) {

			if (equipmentDTO.getparentEqReference() != null) {
				rack = equipmentRepository.findOne(equipmentDTO.getparentEqReference());

				if (rack == null) {
					throw new MethodFailureException("Failed to find Equipment Rack with "
							+ "Parent Equipment Reference Id: " + equipmentDTO.getparentEqReference());
				} else {
					equipmentDTO.setparentEqReference(rack.getEqpReferenceId());
					equipmentDTO.setFrame(EquipmentService.validateNotNull(equipmentDTO.getFrame())
							? equipmentDTO.getFrame() : rack.getFrame());
				}
			}

			if (equipmentDTO.getFrRefParentKeyValue() != null && !equipmentDTO.getFrRefParentKeyValue().isEmpty()) {
				if (equipmentDTO.getFloor() != null && !equipmentDTO.getFloor().isEmpty()) {
					rackFrRef = equipmentRepository
							.findByLocationClliAndFrameAndHiLocationReferenceAndDirContainerTypeContainer(
									equipmentDTO.getClli(), equipmentDTO.getFrame(), equipmentDTO.getFloor(),
									EntityType.RACK.toString())
							.stream().findFirst().orElse(null);
				} else {
					rackFrRef = equipmentRepository
							.findByLocationClliAndFrameAndDirContainerTypeContainer(equipmentDTO.getClli(),
									equipmentDTO.getFrame(), EntityType.RACK.toString())
							.stream().findFirst().orElse(null);
				}

				if (rackFrRef != null) {
					equipmentDTO.setparentEqReference(rackFrRef.getEqpReferenceId());
					equipmentDTO.setFrame(EquipmentService.validateNotNull(equipmentDTO.getFrame())
							? equipmentDTO.getFrame() : rackFrRef.getFrame());

				}
			}

			equipmentDTO.setPhysicalShelf(EquipmentService.validateNotNull(equipmentDTO.getPhysicalShelf())
					? equipmentDTO.getPhysicalShelf() : equipSpec.getDefaultPhysicalShelf());
			equipmentService.validateExists(site.getSiteReferenceId(), equipmentDTO.getFrame(),
					equipmentDTO.getPhysicalShelf(), dirContainerType.getContainer());
		}

		if (equipmentDTO.getFrRefKeyName() != null && !equipmentDTO.getFrRefKeyName().trim().isEmpty()
				&& equipmentDTO.getFrRefKeyValue() != null && !equipmentDTO.getFrRefKeyValue().trim().isEmpty()) {
			autoDecomShelf(equipmentDTO.getFrRefKeyName().trim(), equipmentDTO.getFrRefKeyValue().trim());
		}

		if (rack != null && rack.getDirInvStatus().equals(InstanceEquipmentCreateConstant.PENDING_DECOM)) {
			LOGGER.info("While Shelf Install on Rack when the status is PENDING_DECOM of Rack"
					+ equipmentDTO.getparentEqReference());
			throw new BadRequestException(new FieldError("SHELF", "Pending Decom",
					"Shelf cannot be created when the status is 'Pending Decom' of Rack"));
		}

		Equipment equipment = new Equipment();

		equipment.setAid(equipSpec.getAid());
		equipment.setAlternateName(equipmentDTO.getAlternateName());
		equipment.setAssetOwner(equipmentDTO.getAssetOwner());
		equipment.setBarCode(equipmentDTO.getBarCode());
		equipment.setBatchNumber(equipmentDTO.getBatchNumber());
		equipment.setComments(equipmentDTO.getComments());
		equipment.setCustomerName(equipmentDTO.getCustomerName());
		equipment.setDecommisionDate(equipmentDTO.getdecommisionDate());
		equipment.setDirContainerType(dirContainerType);
		equipment.setDirEqpType(type);
		equipment.setDirInvStatus(dirInvStatus.getStatus());
		equipment.setDueDate(equipmentDTO.getDueDate());
		equipment.setEms(equipmentDTO.getems());
		equipment.setEqpClei(equipmentDTO.getClei());
		equipment.setEqpManufacturer(equipSpec.getManufacturer());
		equipment.setEqpModel(equipSpec.getModel());
		equipment.setEqpName(equipmentDTO.getName());
		equipment.setEqpPurchaseDate(equipmentDTO.getPurchaseDate());
		equipment.setEquipmentSpecName(equipSpec.getName());
		equipment.setEquipmentSpecRefId(new BigDecimal(equipSpec.getEquipmentSpecRefId()));
		equipment.setFieldId(equipmentDTO.getFieldId());
		equipment.setFrRefKeyName(equipmentDTO.getFrRefKeyName());
		equipment.setFrRefKeyValue(equipmentDTO.getFrRefKeyValue());
		equipment.setFrame(equipmentDTO.getFrame());
		equipment.setFunctionalType(equipSpec.getFunctionalType());
		equipment.setHardwareRevision(equipmentDTO.gethardwareRevision());
		equipment.setIneffectDate(equipmentDTO.getinServiceDate());
		if (equipmentDTO.getInstalledDate() != null)
			equipment.setInstalledDate(equipmentDTO.getInstalledDate());
		else
			equipment.setInstalledDate(new Date());
		equipment.setIsMultiTidShelf(equipmentDTO.getIsMultiTidShelf());
		equipment.setLastModifiedTimeStamp(new Date());
		equipment.setLineUp(equipmentDTO.getLineUp());
		equipment.setLocationClli(site.getClli());
		equipment.setMaterialId(equipSpec.getMaterialId());
		equipment.setMgmtIpAddress(equipmentDTO.getIpAddress());
		equipment.setMgmtSSHPort(equipmentDTO.getMgmtSSHPort());
		equipment.setMgmtTelnetPort(mgmtTeletPort);
		equipment.setNetworkDomain(networkDomain);
		equipment.setNetworkType(equipmentDTO.getNetworkType());
		equipment.setNoOfSlots(equipSpec.getNumOfSlots());
		equipment.setOrderNumber(equipmentDTO.getOrderNumber());
		equipment.setPartNum(equipSpec.getPartNum());
		equipment.setPhysicalShelfPosition(equipmentDTO.getPhysicalShelf());
		equipment.setPointCode(equipmentDTO.getPointCode());
		equipment.setProjectReferenceId(equipmentDTO.getProjectReferenceId());
		equipment.setScheduledDate(equipmentDTO.getScheduledDate());
		equipment.setSerialNumber(equipmentDTO.getSerialNumber());
		equipment.setShelfType(equipSpec.getDirShelfType().getShelfType());
		equipment.setSiteReferenceId(new BigDecimal(site.getSiteReferenceId()));
		equipment.setSoftwareRevision(equipmentDTO.getsoftwareRevision());
		equipment.setSubLocation(equipmentDTO.getSubLocation());
		equipment.setTidLogical(equipmentDTO.getTid_l());
		equipment.setTidPhysical(equipmentDTO.getTargetId());

		equipment.setAssetLife(EquipmentService.validateNotNull(equipmentDTO.getAssetLife())
				? equipmentDTO.getAssetLife().longValue() : null);
		equipment.setCustomerReferenceId(EquipmentService.validateNotNull(equipmentDTO.getCustomerReference())
				? new BigDecimal(equipmentDTO.getCustomerReference()) : null);
		equipment.setDistFromX(EquipmentService.validateNotNull(equipmentDTO.getDistToFront())
				? equipmentDTO.getDistToFront() : equipSpec.getDistFromX());
		equipment.setDistFromY(EquipmentService.validateNotNull(equipmentDTO.getDistToLeft())
				? equipmentDTO.getDistToLeft() : equipSpec.getDistFromY());
		equipment.setDistFromZ(EquipmentService.validateNotNull(equipmentDTO.getDistToBase())
				? equipmentDTO.getDistToBase() : equipSpec.getDistFromZ());
		equipment.setEqpDepth(EquipmentService.validateNotNull(equipmentDTO.getdepth()) ? equipmentDTO.getdepth()
				: equipSpec.getEqpDepth());
		equipment.setEqpHeight(EquipmentService.validateNotNull(equipmentDTO.getheight()) ? equipmentDTO.getheight()
				: equipSpec.getEqpHeight());
		equipment.setEqpName(EquipmentService.validateNotNull(equipmentDTO.getName()) ? equipmentDTO.getName()
				: equipSpec.getName());
		equipment.setEqpPurchasePrice(EquipmentService.validateNotNull(equipmentDTO.getPurchasePrice())
				? equipmentDTO.getPurchasePrice().toString() : null);
		equipment.setEqpVendor(EquipmentService.validateNotNull(equipmentDTO.getVendor()) ? equipmentDTO.getVendor()
				: equipSpec.getEquipmentVendor());
		equipment.setEqpWidth(EquipmentService.validateNotNull(equipmentDTO.getwidth()) ? equipmentDTO.getwidth()
				: equipSpec.getEqpWidth());
		equipment.setHiLocationReference(
				EquipmentService.validateNotNull(equipmentDTO.getFloor()) ? equipmentDTO.getFloor() : null);
		equipment.setLastModifiedBy(EquipmentService.validateNotNull(equipmentDTO.getModifiedUser())
				? equipmentDTO.getModifiedUser() : "SYSTEM");
		equipment.setLogicalShelf(EquipmentService.validateNotNull(equipmentDTO.getlogicalShelf())
				? equipmentDTO.getlogicalShelf() : "1");
		equipment.setParentEqpReferenceId(EquipmentService.validateNotNull(equipmentDTO.getparentEqReference())
				? new BigDecimal(equipmentDTO.getparentEqReference()) : null);
		equipment.setParentShelfReferenceId(EquipmentService.validateNotNull(equipmentDTO.getparentShelfReference())
				? new BigDecimal(equipmentDTO.getparentShelfReference()) : null);
		equipment.setHostName(
				EquipmentService.validateNotNull(equipmentDTO.getHostName()) ? equipmentDTO.getHostName() : null);
		equipment.setUtIndicator(
				EquipmentService.validateNotNull(equipSpec.getUtIndicator()) ? equipSpec.getUtIndicator() : null);

		Equipment equipmentRef = equipmentRepository.save(equipment);
		equipmentService.createEquipmentDomains(equipmentRef.getEqpReferenceId(), equipmentDTO, httpRequest);
		LOGGER.info("Equipment Created is {}", equipmentRef.getEqpReferenceId());

		List<SlotDTO> slotDTOList = null;
		if (EquipmentService.validateNotNull(equipmentDTO.getSlotDTOList())) {
			slotDTOList = createSlotsWithoutSlotSpec(equipmentRef, equipmentDTO.getSlotDTOList());
		} else {
			DirInvStatus cardStatus = directoryService.findStatusByEntity(Entity.CARD, "PENDING_IN");
			slotSpecRepository
					.findByEquipmentSpecEquipmentSpecRefIdAndParentCardSpecIdIsNull(equipSpec.getEquipmentSpecRefId())
					.forEach(slotSpec -> equipmentService.createSlot(equipmentRef.getEqpReferenceId(), slotSpec,
							equipmentRef, equipmentDTO.getModifiedUser(), equipment.getOrderNumber(), isSharedEquipment,
							cardStatus));
		}

		List<PortSpec> portSpecList = portSpecRepository
				.findByEquipmentSpecRefIdOrderByDirectionAsc(equipSpec.getEquipmentSpecRefId());
		if (!portSpecList.isEmpty()) {
			cardService.createPhysicalAndLogicalPort(null, portSpecList, equipmentRef, isSharedEquipment);
		}

		EquipmentDTOV1 equipmentDTOV1 = resourceMapper.convertToEquipmentDTOV1(equipmentRef);
		equipmentDTOV1.setSlotDTOList(slotDTOList);

		return equipmentDTOV1;
	}

	public List<SlotDTO> createSlotsWithoutSlotSpec(Equipment equipmentRef, List<SlotDTO> slotDTOList) {
		List<Slot> slotList = resourceMapper.convertToSlotList(slotDTOList);
		for (Slot slot : slotList) {
			slot.setEquipment(equipmentRef);
			slot.setEqpReferenceId(equipmentRef.getEqpReferenceId());
		}
		List<Slot> savedSlotList = slotRepository.save(slotList);
		return resourceMapper.convertToSlotDTOList(savedSlotList, equipmentRef);
	}

	public List<EquipmentDTOV1> createEquipments(List<EquipmentDTOV1> equipments, HttpServletRequest httpRequest) {

		final String userID = httpRequest.getHeader("USER_ID");
		List<EquipmentDTOV1> shelfList = new ArrayList<>();

		equipments.stream().filter(e -> e != null).forEach(equipmentDTOV1 -> {
			equipmentDTOV1.setModifiedUser(userID != null ? userID : "");
			EquipmentDTOV1 shelf = createEquipment(equipmentDTOV1, httpRequest);

			if (shelf == null) {
				throw new MethodFailureException("Create Equipment Failed!");
			}

			List<AttributesDTO> equipmentAttributesDTOList = equipmentDTOV1.getAttributeList();
			String eqpFunctionalType = shelf.getFunctionalEquipType() != null
					? String.valueOf(shelf.getFunctionalEquipType()) : null;
			shelf.setAttributeList(equipmentService.createEquipmentAttributes(shelf.getEquipmentReference().longValue(),
					shelf.getType(), eqpFunctionalType, equipmentAttributesDTOList));

			LOGGER.info("Successfully created attributes with ReferrenceId: {}",
					shelf.getEquipmentReference().longValue());

			/*
			 * Shelf creation Notification sending to Kafka
			 */
			kafkaEventPublisher.publishData(new EntityEventData(EntityType.SHELF.toString(),
					shelf.getEquipmentReference(), EntityOperation.INSERT.toString(), equipmentDTOV1));

			shelfList.add(shelf);
		});

		return shelfList;
	}

	public void autoDecomShelf(String frRefKeyName, String frRefKeyValue) {
		LOGGER.info("calling autoDecomShelf...\n");

		String equipStatus = null;

		Equipment shelf = equipmentRepository.findFirstByFrRefKeyNameAndFrRefKeyValueAndDirContainerTypeContainer(
				frRefKeyName, frRefKeyValue, InstanceEquipmentCreateConstant.CONTAINER_SHELF);

		if (shelf != null) {

			equipStatus = shelf.getDirInvStatus();

			if (equipStatus != null && equipStatus.equals(InstanceEquipmentCreateConstant.PENDING_DECOM)) {
				autoDecomDeleteStatus(shelf.getEqpReferenceId());
			}
			LOGGER.info(
					"While Shelf Decom, Shelf or Card's  are deleted for the ReferenceID " + shelf.getEqpReferenceId());
		}
	}

	public void autoDecomShelfFromRack(String frRefKeyName, String frRefKeyValue) {
		List<Equipment> shelves = equipmentRepository.findByFrRefKeyNameAndFrRefKeyValueAndDirContainerTypeContainer(
				frRefKeyName, frRefKeyValue, InstanceEquipmentCreateConstant.CONTAINER_SHELF);

		for (Equipment shelfDecom : shelves) {
			Boolean decomShelfStatus = autoDecomDeleteStatus(shelfDecom.getEqpReferenceId());
			if (decomShelfStatus) {
				try {
					equipmentModifyClientInstance.deleteRack(shelfDecom.getEqpReferenceId());
					LOGGER.info("While Rack Decom, Rack,Shelf or Card's are deleted for the ReferenceID "
							+ shelfDecom.getEqpReferenceId());
				} catch (Exception e) {
					LOGGER.error("Unable to call Delete Rack API {}", e);
				}
			}
		}
	}

	public Boolean autoDecomDeleteStatus(Long eqpReferenceId) {

		List<Port> ports = null;
		List<String> portStatuses = new ArrayList<String>();
		Boolean isPortStatus = null;
		Boolean autoDecomDeleteStatus = false;

		portStatuses = dirInvCfgRepo.selectPortStatusCheckConstants();

		ports = portRepository.findByEqpReferenceId(eqpReferenceId);

		if (!ports.isEmpty()) {

			isPortStatus = checkPorts(portStatuses, eqpReferenceId);

			if (!isPortStatus) {
				ports = portRepository
						.findByEqpReferenceIdAndCardReferenceIdIsNullAndSlotReferenceIdIsNull(eqpReferenceId);

				if (!ports.isEmpty()) {
					callDeleteShelfAPI(eqpReferenceId);

				} else {
					callDeleteCardAPI(eqpReferenceId);
					callDeleteShelfAPI(eqpReferenceId);
				}
				autoDecomDeleteStatus = true;
			} else {
				autoDecomDeleteStatus = false;
			}
		}
		return autoDecomDeleteStatus;
	}

	public void callDeleteShelfAPI(Long eqpReferenceId) {
		try {
			equipmentModifyApiServiceInstance.deleteShelf(eqpReferenceId);
		} catch (Exception e) {
			LOGGER.error("Unable to call Delete SHELF API {}", e);
		}
	}

	public void callDeleteCardAPI(Long eqpReferenceId) {
		List<Card> cardLists = new ArrayList<>();
		cardLists = cardRepository.findByEqpReferenceId(eqpReferenceId);
		try {
			for (Card cardID : cardLists) {
				cardCardControllerClient.deleteCard(cardID.getCardReferenceId());
			}
		} catch (Exception e) {
			LOGGER.error("Unable to call Delete CARD API {} ", e);
		}
	}

	public Boolean checkPorts(List<String> portStatuses, Long shelfEqpRefID) {
		LOGGER.info("Checking port...\n");

		List<Port> portList = portRepository.findByEqpReferenceId(shelfEqpRefID);

		return portList.stream().anyMatch(port -> portStatuses.contains(port.getPortStatus()));
	}
}
