package com.vz.uiam.inventory.equipment.model.mapper;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;

import com.vz.uiam.inventory.equipment.jpa.dao.model.AuxiliaryEquipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Card;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EnodebDetails;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EnodebSector;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Slot;
import com.vz.uiam.inventory.equipment.model.AuxiliaryDTO;
import com.vz.uiam.inventory.equipment.model.CardDTO;
import com.vz.uiam.inventory.equipment.model.CardDTO1;
import com.vz.uiam.inventory.equipment.model.EnodebDetailsDTO;
import com.vz.uiam.inventory.equipment.model.EnodebSectorDTO;
import com.vz.uiam.inventory.equipment.model.EquipmentDTO;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV2;
import com.vz.uiam.inventory.equipment.model.SlotDTO;

import ma.glasnost.orika.MapperFacade;

public class ResourceMapper {

	@Autowired
	private MapperFacade mapperFacade;

	public EquipmentDTOV1 convertToEquipmentDTOV1(Equipment equipmentDAO) {
		
		if(equipmentDAO == null){
			return null;
		}
		
		EquipmentDTOV1 equipmentDTO = new EquipmentDTOV1();
		equipmentDTO = mapperFacade.map(equipmentDAO, EquipmentDTOV1.class);
		equipmentDTO.setcontainer(equipmentDAO.getDirContainerType().getContainer());
		equipmentDTO.setType(equipmentDAO.getDirEqpType());
		equipmentDTO.setStatus(equipmentDAO.getDirInvStatus());
		equipmentDTO.setCustomerReference(equipmentDAO.getCustomerReferenceId() != null ? equipmentDAO.getCustomerReferenceId().longValue() : null);
		equipmentDTO.setTemplateReference(equipmentDAO.getEquipmentSpecRefId() != null ? equipmentDAO.getEquipmentSpecRefId().longValue() : null);
		equipmentDTO.setparentEqReference(equipmentDAO.getParentEqpReferenceId() != null ? equipmentDAO.getParentEqpReferenceId().longValue() : null);
		equipmentDTO.setparentShelfReference(equipmentDAO.getParentShelfReferenceId() != null ? equipmentDAO.getParentShelfReferenceId().longValue() : null);
		equipmentDTO.setsiteReference(equipmentDAO.getSiteReferenceId() != null ? equipmentDAO.getSiteReferenceId().longValue() : null);
		equipmentDTO.setTid_l(equipmentDAO.getTidLogical());
		equipmentDTO.setAssetOwner(equipmentDAO.getAssetOwner());
		equipmentDTO.setSubLocation(equipmentDAO.getSubLocation());
		equipmentDTO.setCustomerName(equipmentDAO.getCustomerName());
		equipmentDTO.setShelfType(equipmentDAO.getShelfType());
		equipmentDTO.setFunctionalEquipTypeName(equipmentDAO.getFunctionalType());
		
		if(equipmentDAO.getMgmtTelnetPort() != null  
				&& equipmentDAO.getMgmtTelnetPort().contains("RAW:") 
				&& equipmentDAO.getMgmtTelnetPort().contains(",NORMAL:")) {	
			equipmentDTO.setRawTelnetPort(equipmentDAO.getMgmtTelnetPort().substring(equipmentDAO.getMgmtTelnetPort().indexOf("RAW:")+4,equipmentDAO.getMgmtTelnetPort().indexOf(",")));
			equipmentDTO.setNormalTelnetPort(equipmentDAO.getMgmtTelnetPort().substring(equipmentDAO.getMgmtTelnetPort().indexOf("NORMAL:")+7));
		}
		return equipmentDTO;
	}
	
	
	public EquipmentDTOV2 convertToEquipmentDTOV2(Equipment equipmentDAO) {
		EquipmentDTOV2 equipmentDTO = new EquipmentDTOV2();
		equipmentDTO = mapperFacade.map(equipmentDAO, EquipmentDTOV2.class);
		equipmentDTO.setcontainer(equipmentDAO.getDirContainerType().getContainer());
		equipmentDTO.setType(equipmentDAO.getDirEqpType());
		equipmentDTO.setStatus(equipmentDAO.getDirInvStatus());
		equipmentDTO.setCustomerReference(equipmentDAO.getCustomerReferenceId() != null ? equipmentDAO.getCustomerReferenceId().longValue() : null);
		equipmentDTO.setTemplateReference(equipmentDAO.getEquipmentSpecRefId() != null ? equipmentDAO.getEquipmentSpecRefId().longValue() : null);
		equipmentDTO.setparentEqReference(equipmentDAO.getParentEqpReferenceId() != null ? equipmentDAO.getParentEqpReferenceId().longValue() : null);
		equipmentDTO.setparentShelfReference(equipmentDAO.getParentShelfReferenceId() != null ? equipmentDAO.getParentShelfReferenceId().longValue() : null);
		equipmentDTO.setsiteReference(equipmentDAO.getSiteReferenceId() != null ? equipmentDAO.getSiteReferenceId().longValue() : null);
		equipmentDTO.setTid_l(equipmentDAO.getTidLogical());
		equipmentDTO.setAssetOwner(equipmentDAO.getAssetOwner());
		equipmentDTO.setSubLocation(equipmentDAO.getSubLocation());
		equipmentDTO.setCustomerName(equipmentDAO.getCustomerName());
		equipmentDTO.setShelfType(equipmentDAO.getShelfType());
		equipmentDTO.setEquipmentReference(equipmentDAO.getEqpReferenceId());
		
		equipmentDTO.setTargetId(equipmentDAO.getTidPhysical());
		equipmentDTO.setFunctionalEquipTypeName(equipmentDAO.getFunctionalType());
		
		if(equipmentDAO.getMgmtTelnetPort() != null  
				&& equipmentDAO.getMgmtTelnetPort().contains("RAW:") 
				&& equipmentDAO.getMgmtTelnetPort().contains(",NORMAL:")) {	
			equipmentDTO.setRawTelnetPort(equipmentDAO.getMgmtTelnetPort().substring(equipmentDAO.getMgmtTelnetPort().indexOf("RAW:")+4,equipmentDAO.getMgmtTelnetPort().indexOf(",")));
			equipmentDTO.setNormalTelnetPort(equipmentDAO.getMgmtTelnetPort().substring(equipmentDAO.getMgmtTelnetPort().indexOf("NORMAL:")+7));
		}
		return equipmentDTO;
	}

	public EquipmentDTO convertToEquipmentDTO(Equipment equipmentDAO) {
		
		EquipmentDTO equipmentDTO = mapperFacade.map(equipmentDAO, EquipmentDTO.class);
		equipmentDTO.setContainer(equipmentDAO.getDirContainerType().getContainer());
		equipmentDTO.setType(equipmentDAO.getDirEqpType());
		equipmentDTO.setStatus(equipmentDAO.getDirInvStatus());
		if (equipmentDAO.getCustomerReferenceId() != null) {
			equipmentDTO.setCustomerReference(equipmentDAO.getCustomerReferenceId().intValue());
		}
		if (equipmentDAO.getEquipmentSpecRefId() != null) {
			equipmentDTO.setTemplateReference(equipmentDAO.getEquipmentSpecRefId().intValue());
		}
		if (equipmentDAO.getParentEqpReferenceId() != null) {
			equipmentDTO.setParentEqReference(equipmentDAO.getParentEqpReferenceId().intValue());
		}
		if (equipmentDAO.getParentShelfReferenceId() != null) {
			equipmentDTO.setParentShelfReference(equipmentDAO.getParentShelfReferenceId().intValue());
		}
		if (equipmentDAO.getSiteReferenceId() != null) {
			equipmentDTO.setSiteReference(equipmentDAO.getSiteReferenceId().intValue());
		}
		if (equipmentDTO.getType().matches("AISLE")) {
			equipmentDTO.add(new Link("/equipment/rack/" + equipmentDTO.getEquipmentReference() + "/v1", "RACKS"));
		}
		if (equipmentDAO.getSlots() != null) {
			equipmentDTO.setSlotDTOList(convertToSlotDTOList(equipmentDAO.getSlots(), equipmentDAO));
		}
		if(equipmentDAO.getMgmtTelnetPort() != null 
				&& equipmentDAO.getMgmtTelnetPort().contains("RAW:") 
				&& equipmentDAO.getMgmtTelnetPort().contains(",NORMAL:")) {	
			
			equipmentDTO.setRawTelnetPort(
					equipmentDAO.getMgmtTelnetPort().substring(
					equipmentDAO.getMgmtTelnetPort().indexOf("RAW:")+4, equipmentDAO.getMgmtTelnetPort().indexOf(",")));
			
			equipmentDTO.setNormalTelnetPort(
					equipmentDAO.getMgmtTelnetPort().substring(
					equipmentDAO.getMgmtTelnetPort().indexOf("NORMAL:")+7));
		}
		
		return equipmentDTO;
	}
	
	public <T extends Collection<Equipment>> List<EquipmentDTO> convertToEquipmentDTO(T collection){
		
		List<EquipmentDTO> equipmentDTOs = new ArrayList<>();
		collection.forEach(i -> equipmentDTOs.add(convertToEquipmentDTO(i)));
		return equipmentDTOs;
	}

	public Card convertToCard(CardDTO cardDTO) {
		return mapperFacade.map(cardDTO, Card.class);
	}
	
	public CardDTO1 convertToCardDTO1(Card card) {
		
		CardDTO1 objCardDTO1 =  mapperFacade.map( card ,CardDTO1.class);
		
		objCardDTO1.setCardId(card.getCardReferenceId());
		objCardDTO1.setParentCardId(card.getParentCardRefId());
		objCardDTO1.setParentSlotName(card.getSlot().getSlotName());
		objCardDTO1.setSlotNum(card.getSlot().getSlotNumber());
		
		return objCardDTO1;
		
	}

	public List<Slot> convertToSlotList(List<SlotDTO> slotDTOList) {
		return mapperFacade.mapAsList(slotDTOList, Slot.class);
	}

	public List<SlotDTO> convertToSlotDTOList(List<Slot> slotList, Equipment equipment) {
		List<SlotDTO> slotDTOList = new ArrayList<SlotDTO>();
		for (Slot slot : slotList) {
			slotDTOList.add(convertToSlotDTO(slot, equipment));
		}
		return slotDTOList;
	}

	public SlotDTO convertToSlotDTO(Slot slot, Equipment equipment) {
		SlotDTO slotDTO = mapperFacade.map(slot, SlotDTO.class);
		slotDTO.setEquipInstId(equipment.getEqpReferenceId());
		return slotDTO;
	}

	public List<EquipmentDTOV1> convertToEquipmentDTOList(List<Equipment> equipList) {
		return mapperFacade.mapAsList(equipList, EquipmentDTOV1.class);
	}
	
	public List<EquipmentDTOV2> convertToEquipmentDTOV2List(List<Equipment> equipList) {
		
		 List<EquipmentDTOV2> lst  = new ArrayList<EquipmentDTOV2>();
		 
		 for(Equipment objEquipment : equipList) {
		
			 lst.add(convertToEquipmentDTOV2(objEquipment));
			
		}
		return lst;
		
	}

	public EnodebDetails convertToEnodebDetails(EnodebDetailsDTO enodebDetailsDTO) {
		EnodebDetails details = mapperFacade.map(enodebDetailsDTO, EnodebDetails.class);
		details.setSectors(mapperFacade.mapAsList(enodebDetailsDTO.getSectors(), EnodebSector.class));
		return details;
	}
	
	public EnodebSector convertToEnodebSector(EnodebSectorDTO enodebDetailsDTO) {
		return mapperFacade.map(enodebDetailsDTO, EnodebSector.class);
	}

	public <T extends Iterable<EnodebDetailsDTO>> List<EnodebDetails> convertToEnodebDetails(T enodebDetailsDTO) {
		List<EnodebDetails> details = new ArrayList<>();
		enodebDetailsDTO.forEach(enodeb -> details.add(convertToEnodebDetails(enodeb)));
		return details;
	}

	public EnodebDetailsDTO convertToEnodebDetailsDTO(EnodebDetails enodebDetails) {
		EnodebDetailsDTO dto = mapperFacade.map(enodebDetails, EnodebDetailsDTO.class);
		dto.setSectors(mapperFacade.mapAsList(enodebDetails.getSectors(), EnodebSectorDTO.class));
		return dto;
	}

	public <T extends Iterable<EnodebDetails>> List<EnodebDetailsDTO> convertToEnodebDetailsDTO(T enodebDetails) {
		List<EnodebDetailsDTO> dto = new ArrayList<>();
		enodebDetails.forEach(enodeb -> dto.add(convertToEnodebDetailsDTO(enodeb)));
		return dto;
	}
	
	public List<AuxiliaryEquipment> convertToAuxiliaryFromDTO(List<AuxiliaryDTO> auxiliaryDTOs){
		return mapperFacade.mapAsList(auxiliaryDTOs, AuxiliaryEquipment.class);
	}
}