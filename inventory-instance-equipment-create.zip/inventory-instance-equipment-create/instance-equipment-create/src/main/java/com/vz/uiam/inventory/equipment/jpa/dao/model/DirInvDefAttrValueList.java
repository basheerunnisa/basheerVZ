package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.javers.core.metamodel.annotation.TypeName;


/**
 * The persistent class for the DIR_INV_DEF_ATTR_VALUE_LIST database table.
 * 
 */
@Entity
@Table(name="DIR_INV_DEF_ATTR_VALUE_LIST")
@TypeName("DirInvDefAttrValueList")
@NamedQuery(name="DirInvDefAttrValueList.findAll", query="SELECT d FROM DirInvDefAttrValueList d")
public class DirInvDefAttrValueList implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ATTR_VALUE")
	private String attrValue;

	@Column(name="DISPLAY_SEQUENCE")
	private BigDecimal displaySequence;

	//bi-directional many-to-one association to DirInvDefAttribute
	@ManyToOne
	@JoinColumn(name="INV_DEF_ATTR_ID")
	private DirInvDefAttribute dirInvDefAttribute;

	public DirInvDefAttrValueList() {
	}

	public String getAttrValue() {
		return this.attrValue;
	}

	public void setAttrValue(String attrValue) {
		this.attrValue = attrValue;
	}

	public BigDecimal getDisplaySequence() {
		return this.displaySequence;
	}

	public void setDisplaySequence(BigDecimal displaySequence) {
		this.displaySequence = displaySequence;
	}

	public DirInvDefAttribute getDirInvDefAttribute() {
		return this.dirInvDefAttribute;
	}

	public void setDirInvDefAttribute(DirInvDefAttribute dirInvDefAttribute) {
		this.dirInvDefAttribute = dirInvDefAttribute;
	}

}