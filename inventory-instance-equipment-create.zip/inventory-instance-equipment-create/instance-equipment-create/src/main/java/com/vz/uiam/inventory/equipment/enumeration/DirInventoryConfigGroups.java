package com.vz.uiam.inventory.equipment.enumeration;

/**
 * @author Chintan Patel
 * @date 10-Nov-2017
 */
public enum DirInventoryConfigGroups {

	LOOP_BACK_IP_ASSIGNMENT("LOOP_BACK_IP_ASSIGNMENT"),
	FABRIC_INTERCONNET_IP_ASSIGNMENT_GRP("FABRIC_INTERCONNET_IP_ASSIGNMENT_GRP"),
	LOOPBACK_IP_ADDRESS("LOOPBACK_IP_ADDRESS");
	private String value;

	DirInventoryConfigGroups(String value) {
		this.value = value;
	}

	public String value() {
		return value;
	}
}
