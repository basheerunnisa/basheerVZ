/**
 * 
 */
package com.vz.uiam.inventory.equipment.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.exception.DataNotFoundException;
import com.vz.uiam.inventory.equipment.exception.MethodFailureException;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Card;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Slot;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.CardRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.SlotRepository;
import com.vz.uiam.inventory.equipment.model.CardDTO1;
import com.vz.uiam.inventory.equipment.model.EquipmentDTO;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV2;
import com.vz.uiam.inventory.equipment.model.VirtualEquipmentRequest;
import com.vz.uiam.inventory.equipment.model.mapper.ResourceMapper;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateConstant;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;

@Service
public class VirtualEquipmentCreateService {

	private static final Logger LOGGER = LoggerFactory.getLogger(VirtualEquipmentCreateService.class);

	@Autowired
	private EquipmentService equipmentService;
	@Autowired
	private CardRepository cardRepository;
	@Autowired
	private EquipmentRepository equipmentRepository;
	@Autowired
	private SlotRepository slotRepository;
	@Autowired
	private ResourceMapper resourceMapper;

	/**
	 * @param physicalEquipmentRefId
	 * @param physicalEquipmentTid
	 * @param virtualEquipmentReferenceName
	 * @param principalName
	 * @param requestUserName
	 * @return
	 */
	@Transactional
	public EquipmentDTOV1 createEquipment(VirtualEquipmentRequest virtualEquipmentReq, HttpServletRequest httpRequest) {
		
		final String userId = httpRequest.getHeader("USER_ID") != null ? httpRequest.getHeader("USER_ID") : "";
		
		Equipment physicalEquipment = null;
		Long physicalEquipmentRefId = virtualEquipmentReq.getPhysicalEquipmentSpecId();
		if (physicalEquipmentRefId != null && physicalEquipmentRefId > 0) {
			physicalEquipment = equipmentRepository.findOne(physicalEquipmentRefId);
		} else {
			throw new MethodFailureException("Invalid request data for physical equipment. Physical equipment could not be found.");
		}

		if (physicalEquipment == null) {
			LOGGER.info("Physical Equipment from request with id {} does not exist.", physicalEquipmentRefId);
			throw new MethodFailureException("Physical Equipment from request with id " + physicalEquipmentRefId + " does not exist.");
		} 
		
		LOGGER.info("Physical Equipment Id is {}", physicalEquipment.getEqpReferenceId());

		Equipment virtualEquipment = new Equipment();
		virtualEquipment.setLastModifiedBy(userId);
		virtualEquipment.setTidLogical(virtualEquipmentReq.getVirtualEquipmentTid());
		virtualEquipment.setAlternateName(virtualEquipmentReq.getVirtualEquipmentTid());
		virtualEquipment.setMgmtIpAddress(virtualEquipmentReq.getMgmtIpAddress());
		virtualEquipment.setFunctionalType(virtualEquipmentReq.getFunctionalType());
		
		populateVirtualEquipment(virtualEquipment, physicalEquipment);
		Equipment equipmentRef = equipmentRepository.save(virtualEquipment);
		
		LOGGER.info("Equipment Created is {}", equipmentRef.getEqpReferenceId());

		/** Create Virtual Slot Instance **/
		createVirtualSlotsForEquipment(equipmentRef, userId);

		equipmentService.createEquipmentDomains(equipmentRef.getEqpReferenceId(), new EquipmentDTO(), httpRequest);
		
		return resourceMapper.convertToEquipmentDTOV1(equipmentRef);
	}

	private void populateVirtualEquipment(Equipment virtualEquipment, Equipment physicalEquipment) {

		if (null != physicalEquipment) {
			virtualEquipment.setEqpName(physicalEquipment.getEqpName() + InstanceEquipmentCreateConstant.VIRTUAL_EQP_NAME_SUFFIX);
			virtualEquipment.setAid(physicalEquipment.getAid());
			virtualEquipment.setTidPhysical(physicalEquipment.getTidPhysical());
			virtualEquipment.setLocationClli(physicalEquipment.getLocationClli());
			virtualEquipment.setComments(physicalEquipment.getComments());
			virtualEquipment.setDirContainerType(physicalEquipment.getDirContainerType());
			virtualEquipment.setIneffectDate(physicalEquipment.getIneffectDate());
			virtualEquipment.setInstalledDate(new Date());
			virtualEquipment.setIpv4Address(physicalEquipment.getIpv4Address());
			virtualEquipment.setIpv6Address(physicalEquipment.getIpv6Address());
			virtualEquipment.setEqpModel(physicalEquipment.getEqpModel());
			virtualEquipment.setLastModifiedTimeStamp(new Date());
			virtualEquipment.setOrderDate(new Date());
			virtualEquipment.setOrderNumber(physicalEquipment.getOrderNumber());
			virtualEquipment.setHiLocationReference(physicalEquipment.getHiLocationReference());
			virtualEquipment.setParentEqpType(physicalEquipment.getParentEqpType());
			virtualEquipment.setParentEqpReferenceId(physicalEquipment.getParentEqpReferenceId());
			virtualEquipment.setPhysicalShelfPosition(physicalEquipment.getPhysicalShelfPosition()); 
			if (physicalEquipment.getShelfType() == null || physicalEquipment.getShelfType().length() == 0) {
				LOGGER.info("Shelf type for physical equipment is null or empty");
			}
			virtualEquipment.setShelfType(InstanceEquipmentCreateConstant.SHELF_TYPE_MSERI);
			virtualEquipment.setSiteReferenceId(physicalEquipment.getSiteReferenceId());
			virtualEquipment.setSoftwareRevision(physicalEquipment.getSoftwareRevision());
			virtualEquipment.setDirInvStatus(physicalEquipment.getDirInvStatus());
			virtualEquipment.setEqpVendor(physicalEquipment.getEqpVendor());
			virtualEquipment.setInstanceType(InstanceEquipmentCreateConstant.INSTANCE_TYPE_VIRTUAL);
			virtualEquipment.setPhysicalEquipmentReferenceId(physicalEquipment.getEqpReferenceId());
			virtualEquipment.setDirEqpType(physicalEquipment.getDirEqpType());
			virtualEquipment.setLogicalShelf(physicalEquipment.getLogicalShelf());
			virtualEquipment.setEqpManufacturer(physicalEquipment.getEqpManufacturer());
			virtualEquipment.setNoOfSlots(physicalEquipment.getNoOfSlots());
			virtualEquipment.setDueDate(physicalEquipment.getDueDate());
			virtualEquipment.setNetworkType(physicalEquipment.getNetworkType());
			virtualEquipment.setNetworkDomain(physicalEquipment.getNetworkDomain());
			virtualEquipment.setAssetOwner(physicalEquipment.getAssetOwner());
			virtualEquipment.setEqpClei(physicalEquipment.getEqpClei());
			virtualEquipment.setPartNum(physicalEquipment.getPartNum());
			virtualEquipment.setSerialNumber(physicalEquipment.getSerialNumber());
			virtualEquipment.setSubLocation(physicalEquipment.getSubLocation());
			virtualEquipment.setMaterialId(physicalEquipment.getMaterialId());
			virtualEquipment.setFrame(physicalEquipment.getFrame());
			virtualEquipment.setLineUp(physicalEquipment.getLineUp());
			virtualEquipment.setEquipmentSpecRefId(physicalEquipment.getEquipmentSpecRefId());
			virtualEquipment.setEquipmentSpecName(physicalEquipment.getEquipmentSpecName());
			virtualEquipment.setHostName(physicalEquipment.getHostName());
		}

	}

	private void createVirtualSlotsForEquipment(Equipment equipmentRef, String requestUserName) {
		List<Slot> slots = slotRepository
				.findEligibleParentSlotsForVirtualEquipment(equipmentRef.getPhysicalEquipmentReferenceId());
		List<Slot> virtualSlots = new ArrayList<Slot>();
		for (Slot slot : slots) {
			LOGGER.info("Creating new virtual slot from physical slot reference - " + slot.getSlotReferenceId());
			Slot virtualSlot = new Slot();
			virtualSlot.setSlotName(slot.getSlotName());
			virtualSlot.setLogicalSlotName(slot.getLogicalSlotName());
			virtualSlot.setInstanceType(InstanceEquipmentCreateConstant.INSTANCE_TYPE_VIRTUAL);
			virtualSlot.setPhysicalSlotReferenceId(slot.getSlotReferenceId());
			virtualSlot.setSlotNumber(slot.getSlotNumber());
			virtualSlot.setEquipment(slot.getEquipment());
			virtualSlot.setParentCardReferenceId(slot.getParentCardReferenceId());
			virtualSlot.setAid(slot.getAid());
			virtualSlot.setSlotPosition(slot.getSlotPosition());
			virtualSlot.setLastModifiedTimeStamp(new Date());
			virtualSlot.setLastModifiedBy(requestUserName);
			virtualSlot.setDirSlotStatus(slot.getDirSlotStatus()); 
			virtualSlot.setCardReferenceId(null);
			virtualSlot.setEqpReferenceId(equipmentRef.getEqpReferenceId());
			virtualSlot.setPlane(slot.getPlane());
			
			virtualSlots.add(virtualSlot);
		}
		slotRepository.save(virtualSlots);
	}

	/**
	 * @param equipmentId
	 * @return
	 */
	public List<EquipmentDTOV1> findByPhysicalEquipId(Long equipmentId) {
		List<Equipment> virtualEquips = equipmentRepository.findByPhysicalEquipmentReferenceId(equipmentId);

		if (!virtualEquips.isEmpty()) {
			LOGGER.info("Virtual equipments found : " + virtualEquips.size() + "  " + virtualEquips);
		} else {
			LOGGER.info("Virtual equipments NOT found");
			return null;
		}

		List<EquipmentDTOV1> equipmentDTOList = resourceMapper.convertToEquipmentDTOList(virtualEquips);

		return equipmentDTOList;

	}

	/**
	 * @param phyEquipmentID
	 * @return true if virtual equipment exists else return false
	 */
	public boolean checkForExistingVirtualEquipmentByEqpIdAndTid(long phyEquipmentID, String eqpTid) {
		boolean virEqpExists = true;
		List<Equipment> equipments = null;
		try {
			equipments = equipmentRepository.findByPhysicalEquipmentReferenceIdAndTidLogicalAndInstanceType(
					phyEquipmentID, eqpTid, InstanceEquipmentCreateConstant.INSTANCE_TYPE_VIRTUAL);
			if (null == equipments || equipments.isEmpty()) {
				virEqpExists = false;
			}
			return virEqpExists;

		} catch (Exception ex) {
			LOGGER.error("Error while checkForExistingVirtualEquipment  " + phyEquipmentID, ex);
			throw new MethodFailureException(ex.getMessage());
		}
	}

	public List<AttributesDTO> createEquipmentAttributes(EquipmentDTOV1 equipment, String eqpType,
			String eqpFunctionalType, List<AttributesDTO> equipmentAttributesDTOList) {
		List<AttributesDTO> attributes = new ArrayList<AttributesDTO>();
		try {
			if (equipmentAttributesDTOList != null && !equipmentAttributesDTOList.isEmpty()) {
				attributes = equipmentService.createEquipmentAttributes(equipment.getEquipmentReference().longValue(),
						eqpType, eqpFunctionalType, equipmentAttributesDTOList);
			}

			return attributes;
		} catch (Exception ex) {
			LOGGER.error("Error while createEquipmentAttributes for virtual eqp " + equipment.getEquipmentReference(),
					ex);
			throw new MethodFailureException("Failed to create equipment attributes : " + ex.getMessage());
		}
	}

	public List<EquipmentDTOV2> findByPhysicalTID(String targetId) {
		try {
			List<Equipment> virtualEquips = equipmentRepository.findByTidPhysicalAndInstanceType(targetId,
					InstanceEquipmentCreateConstant.INSTANCE_TYPE_VIRTUAL);
			if (!virtualEquips.isEmpty()) {
				LOGGER.info("Virtual equipments found : " + virtualEquips.size() + "  " + virtualEquips);
			} else {
				LOGGER.info("Virtual equipments NOT found");
				throw new DataNotFoundException("Virtual Equipment with tid", String.valueOf(targetId), "Not found");
			}
			List<EquipmentDTOV2> equipmentDTOList = resourceMapper.convertToEquipmentDTOV2List(virtualEquips);
			return equipmentDTOList;
		} catch (MethodFailureException me) {
			LOGGER.error("Exception : ", me.getMessage());
			throw me;
		} catch (Exception e) {
			LOGGER.error("Exception : ", e.getMessage());
			throw e;
		}
	}

	public EquipmentDTOV2 findByLogicalTID(String targetId) {
		try {
			List<Equipment> virtualEquips = equipmentRepository.findByTidLogicalAndInstanceType(targetId,
					InstanceEquipmentCreateConstant.INSTANCE_TYPE_VIRTUAL);
			if (!virtualEquips.isEmpty()) {
				LOGGER.info("Virtual equipments found : " + virtualEquips.size() + "  " + virtualEquips);
				if (virtualEquips.size() > 1) {
					LOGGER.info("More than one virtual equipments found with logical tid : ", targetId);
					throw new DataNotFoundException("More than one virtual equipment found with logical tid",
							String.valueOf(targetId), "");
				}
			} else {
				LOGGER.info("Virtual equipments NOT found");
				throw new DataNotFoundException("Virtual Equipment with logical tid", String.valueOf(targetId),
						"Not found");
			}
			Equipment virtualEquip = virtualEquips.get(0);
			EquipmentDTOV2 equipmentDTO = resourceMapper.convertToEquipmentDTOV2(virtualEquip);
			return equipmentDTO;
		} catch (MethodFailureException me) {
			LOGGER.error("Exception : ", me.getMessage());
			throw me;
		} catch (Exception e) {
			LOGGER.error("Exception : ", e.getMessage());
			throw e;
		}
	}

	public List<CardDTO1> findAllVirutalCard(Long eqpRefID) {
		try {
			List<Card> lstCard = cardRepository.findByEqpReferenceId(eqpRefID);
			List<CardDTO1> responselst = new ArrayList<CardDTO1>();

			if (!lstCard.isEmpty()) {
				LOGGER.info("Virtual Card found : " + lstCard.size() + "  " + lstCard);
				for (Card objCard : lstCard) {
					CardDTO1 objCardDTO1 = resourceMapper.convertToCardDTO1(objCard);

					if (null != objCard.getParentCardRefId()) {
						Card parentCard = cardRepository.findOne(objCard.getParentCardRefId());

						objCardDTO1.setParentSlotName(parentCard.getSlotName());
					}

					responselst.add(objCardDTO1);
				}
			}
			return responselst;
		} catch (Exception e) {
			LOGGER.error("Exception : {}", e);
			throw e;
		}
	}
}
