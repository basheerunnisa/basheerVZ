package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.SlotCardSpecMap;
import com.vz.uiam.inventory.equipment.jpa.dao.model.SlotCardSpecMapPk;



@Transactional
public interface SlotCardSpecMapRepository extends JpaRepository<SlotCardSpecMap,SlotCardSpecMapPk> {

    List<SlotCardSpecMap> findAllBySlotCardSpecMapPkSlotSpecRefId(List<Long> slotSpecIdList);
  
    List<SlotCardSpecMap> findBySlotCardSpecMapPkSlotSpecRefId(Long slotSpecId);

    List<SlotCardSpecMap> findBySlotCardSpecMapPkSlotSpecRefIdAndIsDefault(Long slotSpecRefId, String isDefault);
    
}