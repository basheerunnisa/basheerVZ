package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.javers.core.metamodel.annotation.TypeName;

@Entity
@Table(name="DIR_NETWORK_DOMAIN_MAP ")
@TypeName("DirNetworkDomainMap")
public class DirNetworkDomainMap implements Serializable {
	
	private static final long serialVersionUID = 1L; 
		
	@EmbeddedId
	private DirNetworkDomainMapPk pk;

	@Column(name = "NETWORK_DOMAIN")
	private String networkDomain;

	public DirNetworkDomainMap(){
		super();
		this.pk = new DirNetworkDomainMapPk();
	}
	public DirNetworkDomainMap(String vendor, String networkType, String region) {
		super();
		this.pk = new DirNetworkDomainMapPk(vendor, networkType, region);
	}
	public DirNetworkDomainMap(String vendor, String networkType, String region, String networkDomain) {
		this(vendor, networkType, region);
		this.networkDomain = networkDomain;
	}
	
	public DirNetworkDomainMapPk getPk() {
		return pk;
	}
	public void setPk(DirNetworkDomainMapPk pk) {
		this.pk = pk;
	}
	public String getNetworkDomain() {
		return networkDomain;
	}
	public void setNetworkDomain(String networkDomain) {
		this.networkDomain = networkDomain;
	}
	public String getVendor() {
		return pk != null ? pk.getVendor() : null;
	}
	public void setVendor(String vendor) {
		if(pk != null){
			this.pk.setVendor(vendor);
		}
	}
	public String getNetworkType() {
		return pk != null ? pk.getNetworkType() : null;
	}
	public void setNetworkType(String networkType) {
		if(pk != null){
			this.pk.setNetworkType(networkType);
		}
	}
	public String getRegion() {
		return pk != null ? pk.getRegion() : null;
	}
	public void setRegion(String region) {
		if(pk != null){
			this.pk.setRegion(region);
		}
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((networkDomain == null) ? 0 : networkDomain.hashCode());
		result = prime * result + ((pk == null) ? 0 : pk.hashCode());
		return result;
	}
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DirNetworkDomainMap other = (DirNetworkDomainMap) obj;
		if (networkDomain == null) {
			if (other.networkDomain != null)
				return false;
		} else if (!networkDomain.equals(other.networkDomain))
			return false;
		if (pk == null) {
			if (other.pk != null)
				return false;
		} else if (!pk.equals(other.pk))
			return false;
		return true;
	}
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DirNetworkDomainMap [pk=" + pk + ", networkDomain=" + networkDomain + "]";
	}
}
