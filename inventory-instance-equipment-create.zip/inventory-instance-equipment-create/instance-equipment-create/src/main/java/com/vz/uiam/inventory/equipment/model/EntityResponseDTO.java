package com.vz.uiam.inventory.equipment.model;

import java.util.List;

public class EntityResponseDTO {

	private String entityType;
	private String container;
	private List<Status> statusList;
	
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public String getContainer() {
		return container;
	}
	public void setContainer(String container) {
		this.container = container;
	}
	public List<Status> getStatusList() {
		return statusList;
	}
	public void setStatusList(List<Status> statusList) {
		this.statusList = statusList;
	}
}
