package com.vz.uiam.inventory.equipment.exception;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.vz.uiam.inventory.equipment.model.ErrorResponseDTO;


@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR, reason = "Method failed")
public class HttpErrorException extends Exception {

    private static final long serialVersionUID = -3992797190692194686L;

    private final List<ErrorResponseDTO> errorResponseList;

    public HttpErrorException(List<ErrorResponseDTO> errorResponseList) {
	super(errorResponseList.toString());
	this.errorResponseList = errorResponseList;
    }

    public List<ErrorResponseDTO> getErrorResponseList() {
	return errorResponseList;
    }


}
