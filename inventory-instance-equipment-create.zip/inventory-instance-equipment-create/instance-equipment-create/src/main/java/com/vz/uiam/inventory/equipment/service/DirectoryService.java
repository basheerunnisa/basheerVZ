/**
 * 
 */
package com.vz.uiam.inventory.equipment.service;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;

import com.vz.uiam.common.usermanagement.rest.model.DirDomainsDTO;
import com.vz.uiam.common.usermanagement.service.SecurityUserDetailsService;
import com.vz.uiam.inventory.equipment.enumeration.Entity;
import com.vz.uiam.inventory.equipment.exception.MethodFailureException;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Bandwidth;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirContainerType;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvStatus;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvType;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirNetworkDomainMap;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirNetworkDomainMapPk;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirPortAllocation;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EquipmentSpec;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Site;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.BandwidthRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirContainerTypeRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInvStatusRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInvTypeRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInventoryConfigRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirNetworkDomainMapRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirPortAllocationRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentSpecRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.SiteRepository;
import com.vz.uiam.inventory.equipment.model.EquipmentDTO;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;

/**
 * @author Karthik Amarnath
 *
 */

@Service
public class DirectoryService {

	private static final Logger LOGGER = LoggerFactory.getLogger(DirectoryService.class);
	private static final String PATCH_PANEL = "PATCH_PANEL";
	private static final List<String> PANEL_TYPES = Arrays
			.asList(new String[] { "LGX", "LCI", "ILGX", "FDB", "LGI", "PATCH_PANEL" });
	
	private static List<Bandwidth> bandwidths;
	private static List<DirPortAllocation> portAllocations;
	
	@Autowired
	private BandwidthRepository bandwidthRepository;
	@Autowired
	private DirContainerTypeRepository dirContainerRepository;
	@Autowired
	private DirInvStatusRepository dirInvStatusRepository;
	@Autowired
	private DirInvTypeRepository dirInvTypeRepository;
	@Autowired
	private DirInventoryConfigRepository dirInventoryConfigRepository;
	@Autowired
	private DirNetworkDomainMapRepository dirNetworkDomainMapRepository;
	@Autowired
	private DirPortAllocationRepository dirPortAllocationRepository;
	@Autowired
	private EquipmentSpecRepository equipmentSpecRepository;
	@Autowired
	private SiteRepository siteRepository;
	@Autowired
	private SecurityUserDetailsService securityUserDetailsService;
	
	/**
	 * Will clear the caches.
	 */
	public static void clearCache(){	
		DirectoryService.bandwidths = null;
		DirectoryService.portAllocations = null;
		LOGGER.info("Caches Cleared!");
	}
	
	/**
	 * 
	 * @return Finds all the Bandwidths in the database. *Will cache results. 
	 * Call clearBandwidths to refresh results. 
	 */
	public List<Bandwidth> findBandwidths(){
		
		if(bandwidths == null || bandwidths.isEmpty()){
			DirectoryService.bandwidths = bandwidthRepository.findAll();
			LOGGER.info("{} Bandwidths Cached!", bandwidths.size());
		}
		return bandwidths;
	}
	
	/**
	 * 
	 * @return Finds all the Port Allocations in the database. *Will cache results. 
	 * Call clearPortAllocations to refresh results. 
	 */
	public List<DirPortAllocation> findPortAllocations(){
		
		if(portAllocations == null || portAllocations.isEmpty()){
			DirectoryService.portAllocations = dirPortAllocationRepository.findAll();
			LOGGER.info("{} Port Allocations Cached!", portAllocations.size());
		}
		return portAllocations;
	}

	/**
	 * Validates the Container given against DIR_CONTAINER table.
	 * 
	 * @param container The container to validate.
	 * @return The valid container or MethodFailureException will be thrown; never null.
	 */
	public DirContainerType findContainer(String container){
		return findContainer(container, null);
	}
	
	/**
	 * Validates the Container given against DIR_CONTAINER table.
	 * 
	 * @param container The container to validate.
	 * @param errors The BindingResult errors to reject on or null to throw a MethodFailureException.
	 * @return The valid container.
	 */
	public DirContainerType findContainer(String container, Errors errors){
		
		final String errorDesc = "DIR_CONTAINER Lookup Failed for Container: " + container;
		
		DirContainerType dirContainer = EquipmentService.validateNotNull(container)
				? dirContainerRepository.findOne(container.trim()) : null;
		
		if(dirContainer == null){
			LOGGER.error("ERROR: {}", errorDesc);
			
			if(errors != null){
				errors.reject("Container Lookup", errorDesc);
			} else {
				throw new MethodFailureException(errorDesc);
			}
		}
		return dirContainer;
	}

	
	/**
	 * Validates the Status given against DIR_INV_STATUS table where ENTITY_NAME = entity;
	 * 
	 * @param entity The Entity the status belongs to.
	 * @param status The Status to validate.
	 * @param defaultValue The Default Value you want to validate if the primary status fails.
	 * @return The valid status or MethodFailureException will be thrown; never null.
	 */
	public DirInvStatus findStatusByEntityWithDefault(Entity entity, String status, String defaultValue){
		
		DirInvStatus dirStatus = status != null && !status.trim().isEmpty() 
				? dirInvStatusRepository.findByPkStatusAndPkEntityNameIgnoreCase(status.trim(), entity.name()) : null;
		
		if(dirStatus == null && defaultValue != null){
			LOGGER.info("DIR_INV_STATUS Lookup Failed for Status: {} -- Trying with Default: {}", status, defaultValue);
			dirStatus = dirInvStatusRepository.findByPkStatusAndPkEntityNameIgnoreCase(defaultValue, entity.name());
		}
		if(dirStatus == null){
			LOGGER.info("DIR_INV_STATUS Lookup Failed for Status: {}", defaultValue != null ? defaultValue : status);
			throw new MethodFailureException("DIR_INV_STATUS Lookup Failed for Status: " + defaultValue != null ? defaultValue : status);
		}
		return dirStatus;
	}
	
	/**
	 * Validates the Status given against DIR_INV_STATUS table where ENTITY_NAME = entity;
	 * 
	 * @param entity The Entity the status belongs to.
	 * @param status The Status to validate.
	 * @return The valid status or MethodFailureException will be thrown; never null.
	 */
	public DirInvStatus findStatusByEntity(Entity entity, String status){
		return findStatusByEntityWithDefault(entity, status, null);
	}
	
	/**
	 * Validates the Type given against DIR_INV_TYPE table where ENTITY_NAME = entity;
	 * 
	 * @param entity The Entity the type belongs to.
	 * @param type The Type to validate.
	 * @param defaultValue The Default Value you want to validate if the primary type fails.
	 * @return The valid type or MethodFailureException will be thrown; never null.
	 */
	public DirInvType findTypeByEntityWithDefault(Entity entity, String type, String defaultValue){
		
		DirInvType dirType = type != null && !type.trim().isEmpty() 
				? dirInvTypeRepository.findByPkTypeAndPkEntityNameIgnoreCase(type.trim(), entity.name()) : null;
		
		if(dirType == null && defaultValue != null){
			LOGGER.info("DIR_INV_TYPE Lookup Failed for Type: {} -- Trying with Default: {}", type, defaultValue);
			dirType = dirInvTypeRepository.findByPkTypeAndPkEntityNameIgnoreCase(defaultValue, entity.name());
		}
		if(dirType == null){
			LOGGER.info("DIR_INV_TYPE Lookup Failed for Type: {}", defaultValue != null ? defaultValue : type);
			throw new MethodFailureException("DIR_INV_TYPE Lookup Failed for Type: " + defaultValue != null ? defaultValue : type);
		}
		return dirType;
	}
	
	/**
	 * Validates the Type given against DIR_INV_TYPE table where ENTITY_NAME = entity;
	 * 
	 * @param entity The Entity the type belongs to.
	 * @param type The Type to validate.
	 * @return The valid type or MethodFailureException will be thrown; never null.
	 */
	public DirInvType findTypeByEntity(Entity entity, String type){
		return findTypeByEntityWithDefault(entity, type, null);
	}
	
	/**
	 * 
	 * @return The DIR_INVENTORY_CONFIG record for Group Name: CARD_SLOT_STATUS and Name: SLOT_STATUS_UPDATE. Throws MethodFailureException if null. 
	 */
	public String findSlotStatusConstant(){
		
		String slotConstant = dirInventoryConfigRepository.selectSlotStatusConstant();
		if(slotConstant == null){
			throw new MethodFailureException("Dir Inventory Config Missing Record -- CARD_SLOT_STATUS -- SLOT_STATUS_UPDATE");
		}
		return slotConstant.trim();
	}
	
	/**
	 * Finds Network Domain for given Vendor, Network Type, and Region combination.
	 * 
	 * @param equipmentVendor
	 * @param networkType
	 * @param region
	 * @return
	 */
	public String findNetworkDomain(String equipmentVendor, String networkType, String region){
		
		DirNetworkDomainMap dirNetworkDomainMap = 
				dirNetworkDomainMapRepository.findOne(new DirNetworkDomainMapPk(equipmentVendor, networkType, region));
		
		return dirNetworkDomainMap != null ? dirNetworkDomainMap.getNetworkDomain() : null;
	}
	
	/**
	 * Looks for Equipment Specification by numerous fields, if present.
	 * 
	 * @param input The EquipmentDTO to search by.
	 * @param errors The BindingResult errors to reject on, or null to throw MethodFailureException.
	 * @return the valid EquipmentSpec.
	 */
	public EquipmentSpec findEquipmentSpec(EquipmentDTOV1 input){
		return findEquipmentSpec(input, null);
	}
	
	/**
	 * Looks for Equipment Specification by numerous fields, if present.
	 * 
	 * @param input The EquipmentDTO to search by.
	 * @return the valid EquipmentSpec or MethodFailureException; never null.
	 */
	public EquipmentSpec findEquipmentSpec(EquipmentDTO input){
		return findEquipmentSpec(input, null, null);
	}
	
	/**
	 * Looks for Equipment Specification by numerous fields, if present.
	 * 
	 * @param input The EquipmentDTO to search by.
	 * @param errors The BindingResult errors to reject on, or null to throw MethodFailureException.
	 * @return the valid EquipmentSpec.
	 */
	public EquipmentSpec findEquipmentSpec(EquipmentDTOV1 input, Errors errors){
		
		EquipmentDTO tmp = new EquipmentDTO();
		tmp.setTemplateReference(input.getTemplateReference() != null ? input.getTemplateReference().intValue() : null);
		tmp.setTemplateName(input.getTemplateName());
		tmp.setMfgPartNumber(input.getMfgPartNumber());
		if( input.getShelfType()!=null && PANEL_TYPES.contains(input.getShelfType()) )
			tmp.setShelfType(PATCH_PANEL);
		
		return findEquipmentSpec(tmp, input.getUtIndicator() ,errors);
	}
	
	/**
	 * Looks for Equipment Specification by numerous fields, if present.
	 * 
	 * @param input The EquipmentDTO to search by.
	 * @param errors The BindingResult errors to reject on, or null to throw MethodFailureException.
	 * @return the valid EquipmentSpec.
	 */
	public EquipmentSpec findEquipmentSpec(EquipmentDTO input, String utIndicator, Errors errors){
		
		final String errorDesc = "Equipment Specification could not be located with "
					+ "Template Reference: " + input.getTemplateReference() + "or "
					+ "Template Name: " + input.getTemplateName() + " or " 
					+ "Part Number: " + input.getMfgPartNumber();
		
		EquipmentSpec equipSpec = null;
		
		if(input.getTemplateReference() != null && input.getTemplateReference() > 0){
			equipSpec = equipmentSpecRepository.findOne(input.getTemplateReference().longValue());
		}
		else if(input.getMfgPartNumber() != null && !input.getMfgPartNumber().trim().isEmpty()){
			LOGGER.info("Fetching EquipmentSpec based on mfgPartNumber");
			if (input.getShelfType() != null && PATCH_PANEL.equalsIgnoreCase(input.getShelfType())
					&& utIndicator != null && "Y".equalsIgnoreCase(utIndicator)){
				equipSpec = equipmentSpecRepository.findOneByPartNumIgnoreCaseAndUtIndicator(input.getMfgPartNumber().trim(), utIndicator);
			}else{
				equipSpec = equipmentSpecRepository.findOneByPartNumIgnoreCaseAndUtIndicator(input.getMfgPartNumber().trim(), null);
			}
		}
		else if(input.getTemplateName() != null && !input.getTemplateName().trim().isEmpty()){
			
			if (input.getShelfType() != null && PATCH_PANEL.equalsIgnoreCase(input.getShelfType())
					&& utIndicator != null && "Y".equalsIgnoreCase(utIndicator)){
				equipSpec = equipmentSpecRepository.findByNameAndUtIndicator(input.getTemplateName().trim(), utIndicator).stream().findFirst().orElse(null);
			}else{
				equipSpec = equipmentSpecRepository.findByNameAndUtIndicator(input.getTemplateName().trim(), null).stream().findFirst().orElse(null);
			}
			
		}
		
		if(equipSpec == null){
			LOGGER.error("ERROR: {}", errorDesc);
			
			if(errors != null){
				errors.reject("Equipment Spec Lookup", errorDesc);
			} else {
				throw new MethodFailureException(errorDesc);		
			}
		}
		return equipSpec;
	}
	
	/**
	 * Looks for Site by numerous fields, if present.
	 * 
	 * @param input The EquipmentDTO to search by.
	 * @return the valid Site or MethodFailureException will be thrown; never null.
	 */
	public Site findSite(EquipmentDTOV1 input){
		return findSite(input, null);
	}
	
	/**
	 * Looks for Site by numerous fields, if present.
	 * 
	 * @param input The EquipmentDTO to search by.
	 * @return the valid Site or MethodFailureException will be thrown; never null.
	 */
	public Site findSite(EquipmentDTO input){
		return findSite(input, null);
	}
	
	/**
	 * Looks for Site by numerous fields, if present.
	 * 
	 * @param input The EquipmentDTO to search by.
	 * @param errors The BindingResult errors to reject on, or null to throw MethodFailureException.
	 * @return the valid Site.
	 */
	public Site findSite(EquipmentDTOV1 input, Errors errors){
		
		EquipmentDTO tmp = new EquipmentDTO();
		tmp.setSiteReference(input.getsiteReference() != null ? input.getsiteReference().intValue() : null);
		tmp.setClli(input.getClli());
		
		return findSite(tmp, errors);
	}
	
	/**
	 * Looks for Site by numerous fields, if present.
	 * 
	 * @param input The EquipmentDTO to search by.
	 * @param errors The BindingResult errors to reject on, or null to throw MethodFailureException.
	 * @return the valid Site.
	 */
	public Site findSite(EquipmentDTO input, Errors errors){
		
		final String errorDesc = "Equipment Site could not be located with "
	 			   + "Site Reference: " + input.getSiteReference() + " or "
	 			   + "CLLI: " + input.getClli();
		
		Site site = null;
		
		if(input.getSiteReference() != null && input.getSiteReference() > 0){
			site = siteRepository.findOne(input.getSiteReference().longValue());
		}
		else if(input.getClli() != null && !input.getClli().trim().isEmpty()){
			site = siteRepository.findOneByClliIgnoreCase(input.getClli().trim());
		}
		
		if(site == null){
			LOGGER.error("ERROR: {}", errorDesc);
			
			if(errors != null){
				errors.reject("Site Lookup", errorDesc);
			} else {
				throw new MethodFailureException(errorDesc);		
			}	
		}
		return site;
	}
	
	public List<DirDomainsDTO> findDomainsMappedToUser(HttpServletRequest request) {
		
		Principal principal = request.getUserPrincipal();
		principal = principal == null ? SecurityContextHolder.getContext().getAuthentication() : principal;
	
		return findDomainsMappedToUser(request.getHeader("USER_ID"), principal.getName());
	}
	
	public List<DirDomainsDTO> findDomainsMappedToUser(String userId, String principal) {

		String entityName;
		String entityValue;
	
		if (userId != null && !userId.isEmpty()) {
			entityName = "USER_ID";
			entityValue = userId;

		} else {
			entityName = "APP_USER";
			entityValue = principal;
		}

		LOGGER.info("Entity-Name:{} Entity-Value:{} ", entityName, entityValue);
		List<DirDomainsDTO> dirDomainsList = securityUserDetailsService.getDomainsForEntity(entityName, entityValue);
		
		return dirDomainsList != null ? dirDomainsList : new ArrayList<>();
	}
	
	public List<DirDomainsDTO> findRequestedDomains(List<String> domainNames, HttpServletRequest request){
		
		List<DirDomainsDTO> domains = request != null ? findDomainsMappedToUser(request) : securityUserDetailsService.getAllDomains();
		return domainNames != null && !domainNames.isEmpty() 
				? domains.stream().filter(d -> domainNames.contains(d.getDomainName())).collect(Collectors.toList()) : domains;
	}
}
