
package com.vz.uiam.inventory.equipment.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.parboiled.common.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ValidationUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.common.monitor.performance.PerformanceMetrics;
import com.vz.uiam.inventory.equipment.enumeration.EntityOperation;
import com.vz.uiam.inventory.equipment.enumeration.EntityType;
import com.vz.uiam.inventory.equipment.exception.BadRequestException;
import com.vz.uiam.inventory.equipment.exception.DataNotFoundException;
import com.vz.uiam.inventory.equipment.exception.MethodFailureException;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentAttributesRepository;
import com.vz.uiam.inventory.equipment.model.EntityEventData;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV2;
import com.vz.uiam.inventory.equipment.model.VirtualEquipmentRequest;
import com.vz.uiam.inventory.equipment.model.validator.CreateVirtualEquipmentValidator;
import com.vz.uiam.inventory.equipment.service.DirectoryService;
import com.vz.uiam.inventory.equipment.service.KafkaEventPublisher;
import com.vz.uiam.inventory.equipment.service.VirtualEquipmentCreateService;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@RestController
@RequestMapping("inventory/equipments/virtual")
@Api(value = "Virtual Equipment Instance creation Task handler", description = "API for Virtual Equipment Instance create Task Handler")
@PreAuthorize("hasAnyAuthority('ROLE:IVAPP_USER','ROLE:IVAPP_TESTER')")
public class VirtualEquipmentController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(VirtualEquipmentController.class);

	@Autowired
	private CreateVirtualEquipmentValidator validator;
	@Autowired
	private VirtualEquipmentCreateService virtualEquipCreateService;
	@Autowired
	private EquipmentAttributesRepository equipmentAttributesRepository;
	@Autowired
	private KafkaEventPublisher kafkaEventPublisher;

	@RequestMapping(value = "/create", method = RequestMethod.POST, produces = "application/json")
	@PerformanceMetrics(sla = 60000)
	@ApiOperation(value = "Create Virtual Equipment instance using Physical Equipment", notes = "Service to create virtual equipment using physical equipment SLA:60000 ms", response = EquipmentDTOV1.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful received request", response = EquipmentDTOV1.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 409, message = "Data conflict"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	public EquipmentDTOV1 createVirtualEquipment(@RequestBody VirtualEquipmentRequest equipReq, BindingResult errors, 
			@RequestHeader(value = "USER_ID", required = false) String userID, HttpServletRequest httpRequest)
			throws BindException {

		DirectoryService.clearCache();
		
		LOGGER.info("Start : createVirtualEquipment : request obj : "+equipReq);
		
		ValidationUtils.invokeValidator(validator, equipReq, errors);

		if (errors.hasErrors()) {
			throw new BindException(errors);
		}
		
		EquipmentDTOV1 equipment = virtualEquipCreateService.createEquipment(equipReq, httpRequest);
		
		/*
		 * After creating the Virtual Equipment, the attributes need to be stored in DB
		 */
		if (equipment == null) {
			throw new MethodFailureException("Shelf Not Found");
		}
		
		LOGGER.info("Attempting create Attributes");
		List<AttributesDTO> equipmentAttributesDTOList = equipReq.getAttributeList();
		String eqpFunctionalType = equipment.getFunctionalEquipTypeName();
		equipment.setAttributeList(virtualEquipCreateService.createEquipmentAttributes(equipment, equipment.getType(), eqpFunctionalType, equipmentAttributesDTOList));
		LOGGER.info("Successfully created attributes with ReferrenceId: {}", equipment.getEquipmentReference().longValue() );
		/*
		 * Shelf creation Notification sending to Kafka
		 */
		kafkaEventPublisher.publishData(new EntityEventData(EntityType.VIRTUAL_SHELF.toString(), equipment.getEquipmentReference(),
				EntityOperation.INSERT.toString(), equipment));
		
		LOGGER.info("End : createVirtualEquipment");
		
		return equipment;
	}
	
	/********* get Virtuals Equipments based on the physical equip id *********/

	@RequestMapping(value = "/{equipmentId}", method = RequestMethod.GET, produces = "application/json")
	@PerformanceMetrics(sla = 1000)
	@ApiOperation(value = "Returns Virtual Equip details by physical equipment id", notes = "Returns a complete Virtual EquipSpec details. SLA:500", response = EquipmentDTOV1.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful retrieval of Virtual Equipment details", response = EquipmentDTOV1.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Equipment with given id does not exist"), })
	public List<EquipmentDTOV1> getVirtualEquipments(@PathVariable Long equipmentId, HttpServletRequest request)
			 {
		
		DirectoryService.clearCache();
		
		LOGGER.info("Entering Virtual Equip Details Service to get details with physical equipment id: [" + equipmentId
				+ "] and URL [" + request.getRequestURL() + "]");

		if (equipmentId == null) {
			throw new BadRequestException(
					new FieldError("Equipment", "equipmentId", "input provided is not valid"));
		}
		try 
		{

			List<EquipmentDTOV1> res = virtualEquipCreateService.findByPhysicalEquipId(equipmentId);
			if (res == null) {
				throw new DataNotFoundException("Equipment", String.valueOf(equipmentId), "Not found");
			}
			
			return res;
		}
		catch (Exception e)
		{
			LOGGER.info("Exception Occured", e);
			throw new MethodFailureException(e.getMessage());
		}
		
	}
	
	/********* get Virtual Equipments based on the physical TID *********/

	@RequestMapping(value = "/tidPhysical/{targetId}", method = RequestMethod.GET, produces = "application/json")
	@PerformanceMetrics(sla = 1000)
	@ApiOperation(value = "Returns Virtual Equip details by physical TID", notes = "Returns a complete Virtual EquipSpec details. SLA:500", response = EquipmentDTOV2.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful retrieval of Virtual Equipment details", response = EquipmentDTOV2.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Equipment with given tid does not exist"), })
	public List<EquipmentDTOV2> getVirtualEquipmentsByTidPhysical(@PathVariable String targetId, HttpServletRequest request)
	{
		DirectoryService.clearCache();
		
		LOGGER.info("Entering Virtual Equip Details Service to get details with physical TID: [" + targetId
				+ "] and URL [" + request.getRequestURL() + "]");
		if (StringUtils.isEmpty(targetId)) {
			throw new BadRequestException(
					new FieldError("Equipment", "targetId", "input provided is not valid"));
		}
		try {
			List<EquipmentDTOV2> res = virtualEquipCreateService.findByPhysicalTID(targetId);
			if(res != null) {	
				res.forEach(e -> {
					e.setEqpAttributeList(equipmentAttributesRepository.findByEqpReferenceId(e.getEquipmentReference()));
					e.setLstCardDTO1(virtualEquipCreateService.findAllVirutalCard(e.getEquipmentReference()));
				});
			} 
			else {
				throw new DataNotFoundException("Virtual Equipment with tid physical ", String.valueOf(targetId), "Not found");
			}
			return res;
		}
		catch (Exception e) {
			LOGGER.info("Exception Occured", e);
			throw new MethodFailureException(e.getMessage());
		}				
	}
	
	/********* get Virtual Equipment based on the logical TID *********/

	@RequestMapping(value = "/tidLogical/{targetId}", method = RequestMethod.GET, produces = "application/json")
	@PerformanceMetrics(sla = 1000)
	@ApiOperation(value = "Returns Virtual Equip details by logical TID", notes = "Returns a complete Virtual EquipSpec details. SLA:500", response = EquipmentDTOV2.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful retrieval of Virtual Equipment details", response = EquipmentDTOV2.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Equipment with given tid does not exist"), })
	public EquipmentDTOV2 getVirtualEquipmentByTidLogical(@PathVariable String targetId, HttpServletRequest request)
	{
		DirectoryService.clearCache();
		
		LOGGER.info("Entering Virtual Equip Details Service to get details with logical TID: [" + targetId
				+ "] and URL [" + request.getRequestURL() + "]");
		if (StringUtils.isEmpty(targetId)) {
			throw new BadRequestException(
					new FieldError("Equipment", "targetId", "input provided is not valid"));
		}
		try {
			EquipmentDTOV2 res = virtualEquipCreateService.findByLogicalTID(targetId);
			if(res != null) {
				res.setEqpAttributeList(equipmentAttributesRepository.findByEqpReferenceId(res.getEquipmentReference()));
				res.setLstCardDTO1(virtualEquipCreateService.findAllVirutalCard(res.getEquipmentReference()));
			}
			else {
				throw new DataNotFoundException("Virtual Equipment with tid logical ", String.valueOf(targetId), "Not found");
			}
			return res;
		}
		catch (Exception e) {
			LOGGER.info("Exception Occured", e);
			throw new MethodFailureException(e.getMessage());
		}			
	}
}
