package com.vz.uiam.inventory.equipment.model.validator;

import java.awt.Color;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.uiam.inventory.equipment.enumeration.Entity;
import com.vz.uiam.inventory.equipment.exception.MethodFailureException;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInvStatusRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInvTypeRepository;


public class EntityValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(EntityValidator.class);
	
	private EntityValidator() throws IllegalAccessException {
		throw new IllegalAccessException("Utility class!");
	}
	
	private static boolean isInitialized = false;
	private static DirInvStatusRepository statusRepo;
	private static DirInvTypeRepository typeRepo;
	
	/**
	 * 
	 * @param statusRepo
	 * @param typeRepo
	 */
	public static void initialize(DirInvStatusRepository statusRepo, DirInvTypeRepository typeRepo){
		

		if(isInitialized){
			LOGGER.warn("Warning: Entity Validator is already Initialized!");
			return;
		}
		if(statusRepo == null || typeRepo == null){
			throw new MethodFailureException("Could not initialize EntityValidator because repositories given are invalid.");
		}
		
		EntityValidator.statusRepo = statusRepo;
		EntityValidator.typeRepo = typeRepo;
		isInitialized = true;
		
		LOGGER.info("Entity Validator Initialized");
	}
	/**
	 * Validates that the colors within DIR_INV_STATUS are in Hexadecimal format.
	 */
	public static void validateColor(){
		
		statusRepo.findByPkEntityNameIgnoreCaseIn(Entity.getEntities())
			.stream().filter(s -> s.getColorCode() != null).forEach(s -> {
				try {
	                Color.decode(s.getColorCode());
	                
	            } catch (Exception e) {
	                LOGGER.error("ERROR: {}", e);
	                throw new MethodFailureException("DIR_INV_STATUS.COLOR_CODE is Invalid. Colors MUST be in Hexadecimal Format.");
	            }
		});
	}
	/**
	 * 
	 * @param status
	 * @param clazz
	 * @return
	 */
	public static String validateStatus(String status, final Class<?> clazz) {

		if (status != null && clazz != null) {
			Set<String> statuses = statusRepo.findByPkEntityNameIgnoreCase(Entity.getEntityForClass(clazz))
					.stream().map(s -> s.getStatus().toUpperCase().trim()).collect(Collectors.toSet());
			
			if(!statuses.contains(status.toUpperCase().trim())){
				 LOGGER.error("ERROR: Status Invalid for Input: Status: {} & Class: {}", status, clazz);
				 throw new MethodFailureException("Status Invalid for Input Status: " + status + " & Class: " + clazz);
			}
		}	
		return status;
	}
	/**
	 * 
	 * @param type
	 * @param clazz
	 * @return
	 */
	public static String validateType(String type, final Class<?> clazz) {

		if (type != null && clazz != null) {
			Set<String> types = typeRepo.findByPkEntityNameIgnoreCase(Entity.getEntityForClass(clazz))
					.stream().map(t -> t.getType().toUpperCase().trim()).collect(Collectors.toSet());
			
			if(!types.contains(type.toUpperCase().trim())){
				LOGGER.error("ERROR: Type Invalid for Input: Type: {} & Class: {}", type, clazz);
				 throw new MethodFailureException("Type Invalid for Input Type: " + type + " & Class: " + clazz);
			}
		}	
		return type;
	}
}