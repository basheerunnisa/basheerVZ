package com.vz.uiam.inventory.equipment.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.hateoas.ResourceSupport;

import com.vz.uiam.common.usermanagement.rest.model.DirDomainsDTO;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;

public class EquipmentDTOV1 extends ResourceSupport implements Serializable {

	private Long equipmentReference;
	private String type;
	private String vendor;
	private String model;
	private String name;
	private String shelfName;
	private Long siteReference;
	private Long parentEqReference;
	private String status;
	private String container;
	private String eqClass;
	private BigDecimal height;
	private BigDecimal width;
	private BigDecimal depth;
	private BigDecimal distToBase;
	private BigDecimal distToLeft;
	private BigDecimal distToFront;
	private String lineUp;
	private String frame;
	private String logicalShelf;
	private String softwareRevision;
	private String hardwareRevision;
	private String pointCode;
	private String ems;
	private String targetId;
	private String orderNumber;
	private Date orderedDate;
	private Date dueDate;
	private Date installedDate;
	private Date inServiceDate;
	private Date scheduledDate;
	private Date decommisionDate;
	private String serialNumber;
	private String batchNumber;
	private String barCode;
	private BigDecimal purchasePrice;
	private Date purchaseDate;
	private BigDecimal assetLife;
	private String comments;
	private Date modifiedTimeStamp;
	private String modifiedUser;
	private String alternateName;
	private String clli;
	private String clei;
	private Long templateReference;
	private Long customerReference;
	private String ipAddress;
	private Long parentShelfReference;
	private String isMultiTidShelf;
	private String physicalShelf;
	private Long functionalEquipType;
	private String functionalEquipTypeName;
	private String mfgPartNumber;
	private String aid;
	private String fieldId;
	private String frRefKeyName;
	private String frRefKeyValue;
	private String templateName;
	private String tid_l;
	private String workOrderNumber;
	private String assetOwner;
	private String subLocation;
	private String customerName;
	private String shelfType;
	private String floor;
	private List<DirDomainsDTO> domianNames;
	private List<AttributesDTO> attributeList;
	private List<SlotDTO> slotDTOList;
	private String networkType;
	private Integer totalPorts;
	private Integer availablePorts;
	private Integer usedPorts;
	private String networkDomain;
	private String projectReferenceId;

	// for nontemplate rack shelf 
	private String ipv4Address; 
	private String ipv6Address; 
	
	// for virtual instance
	private String instanceType;
	private Long physicalEquipmentReferenceId;


	private String rawTelnetPort;
	private String normalTelnetPort;
	private Integer mgmtSSHPort;
	private String frRefParentKeyValue;
	private String hostName;
	private String utIndicator;
	private String matedPair;
	
	private static final long serialVersionUID = 1L;

	public Long getEquipmentReference() {
		return equipmentReference;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * EQUIP_INST.EQUIP_INST_ID
	 *
	 * @param equipmentReferece
	 *            the value for EQUIP_INST.EQUIP_INST_ID
	 *
	 */
	

	public void setEquipmentReference(Long equipmentReference) {
		this.equipmentReference = equipmentReference;
	}


	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.TYPE
	 *
	 * @return the value of EQUIP_INST.TYPE
	 *
	 */
	public String getType() {
		return type;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.TYPE
	 *
	 * @param type
	 *            the value for EQUIP_INST.TYPE
	 *
	 */
	public void setType(String type) {
		this.type = type == null ? null : type.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.VENDOR
	 *
	 * @return the value of EQUIP_INST.VENDOR
	 *
	 */
	public String getVendor() {
		return vendor;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.VENDOR
	 *
	 * @param vendor
	 *            the value for EQUIP_INST.VENDOR
	 *
	 */
	public void setVendor(String vendor) {
		this.vendor = vendor == null ? null : vendor.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.MODEL
	 *
	 * @return the value of EQUIP_INST.MODEL
	 *
	 */
	public String getModel() {
		return model;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.MODEL
	 *
	 * @param model
	 *            the value for EQUIP_INST.MODEL
	 *
	 */
	public void setModel(String model) {
		this.model = model == null ? null : model.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.name
	 *
	 * @return the value of EQUIP_INST.name
	 *
	 */
	public String getName() {
		return name;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.name
	 *
	 * @param name
	 *            the value for EQUIP_INST.name
	 *
	 */
	public void setName(String name) {
		this.name = name == null ? null : name.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.Name
	 *
	 * @return the value of EQUIP_INST.Name
	 *
	 */
	public String getShelfName() {
		return shelfName;
	}

	public void setShelfName(String shelfName) {
		this.shelfName = shelfName == null ? null : shelfName.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * EQUIP_INST.SITE_INST_ID
	 *
	 * @return the value of EQUIP_INST.SITE_INST_ID
	 *
	 */
	public Long getsiteReference() {
		return siteReference;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.SITE_INST_ID
	 *
	 * @param siteReference
	 *            the value for EQUIP_INST.SITE_INST_ID
	 *
	 */
	public void setsiteReference(Long siteReference) {
		this.siteReference = siteReference;
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * EQUIP_INST.PARENT_EQ_INST_ID
	 *
	 * @return the value of EQUIP_INST.PARENT_EQ_INST_ID
	 *
	 */
	public Long getparentEqReference() {
		return parentEqReference;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * EQUIP_INST.PARENT_EQ_INST_ID
	 *
	 * @param parentEqReference
	 *            the value for EQUIP_INST.PARENT_EQ_INST_ID
	 *
	 */
	public void setparentEqReference(Long parentEqReference) {
		this.parentEqReference = parentEqReference;
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.STATUS
	 *
	 * @return the value of EQUIP_INST.STATUS
	 *
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.STATUS
	 *
	 * @param status
	 *            the value for EQUIP_INST.STATUS
	 *
	 */
	public void setStatus(String status) {
		this.status = status == null ? null : status.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.EQ_CLASS
	 *
	 * @return the value of EQUIP_INST.EQ_CLASS
	 *
	 */
	public String getcontainer() {
		return container;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.EQ_CLASS
	 *
	 * @param container
	 *            the value for EQUIP_INST.EQ_CLASS
	 *
	 */
	public void setcontainer(String container) {
		this.container = container == null ? null : container.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST._height
	 *
	 * @return the value of EQUIP_INST._height
	 *
	 */
	public BigDecimal getheight() {
		return height;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST._height
	 *
	 * @param height
	 *            the value for EQUIP_INST._height
	 *
	 */
	public void setheight(BigDecimal height) {
		this.height = height;
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST._width
	 *
	 * @return the value of EQUIP_INST._width
	 *
	 */
	public BigDecimal getwidth() {
		return width;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST._width
	 *
	 * @param width
	 *            the value for EQUIP_INST._width
	 *
	 */
	public void setwidth(BigDecimal width) {
		this.width = width;
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST._depth
	 *
	 * @return the value of EQUIP_INST._depth
	 *
	 */
	public BigDecimal getdepth() {
		return depth;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST._depth
	 *
	 * @param depth
	 *            the value for EQUIP_INST._depth
	 *
	 */
	public void setdepth(BigDecimal depth) {
		this.depth = depth;
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * EQUIP_INST._DIST_TO_BASE
	 *
	 * @return the value of EQUIP_INST._DIST_TO_BASE
	 *
	 */
	public BigDecimal getDistToBase() {
		return distToBase;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * EQUIP_INST._DIST_TO_BASE
	 *
	 * @param DistToBase
	 *            the value for EQUIP_INST._DIST_TO_BASE
	 *
	 */
	public void setDistToBase(BigDecimal distToBase) {
		this.distToBase = distToBase;
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * EQUIP_INST._DIST_TO_LEFT
	 *
	 * @return the value of EQUIP_INST._DIST_TO_LEFT
	 *
	 */
	public BigDecimal getDistToLeft() {
		return distToLeft;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * EQUIP_INST._DIST_TO_LEFT
	 *
	 * @param DistToLeft
	 *            the value for EQUIP_INST._DIST_TO_LEFT
	 *
	 */
	public void setDistToLeft(BigDecimal distToLeft) {
		this.distToLeft = distToLeft;
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * EQUIP_INST._DIST_TO_FRONT
	 *
	 * @return the value of EQUIP_INST._DIST_TO_FRONT
	 *
	 */
	public BigDecimal getDistToFront() {
		return distToFront;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * EQUIP_INST._DIST_TO_FRONT
	 *
	 * @param DistToFront
	 *            the value for EQUIP_INST._DIST_TO_FRONT
	 *
	 */
	public void setDistToFront(BigDecimal distToFront) {
		this.distToFront = distToFront;
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.LINEUP
	 *
	 * @return the value of EQUIP_INST.LINEUP
	 *
	 */
	public String getLineUp() {
		return lineUp;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.LINEUP
	 *
	 * @param lineup
	 *            the value for EQUIP_INST.LINEUP
	 *
	 */
	public void setLineUp(String lineUp) {
		this.lineUp = lineUp == null ? null : lineUp.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.FRAME
	 *
	 * @return the value of EQUIP_INST.FRAME
	 *
	 */
	public String getFrame() {
		return frame;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.FRAME
	 *
	 * @param frame
	 *            the value for EQUIP_INST.FRAME
	 *
	 */
	public void setFrame(String frame) {
		this.frame = frame == null ? null : frame.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.SHELF
	 *
	 * @return the value of EQUIP_INST.SHELF
	 *
	 */
	public String getlogicalShelf() {
		return logicalShelf;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.SHELF
	 *
	 * @param shelf
	 *            the value for EQUIP_INST.SHELF
	 *
	 */
	public void setlogicalShelf(String logicalShelf) {
		this.logicalShelf = logicalShelf == null ? null : logicalShelf.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.TARGET_ID
	 *
	 * @return the value of EQUIP_INST.TARGET_ID
	 *
	 */
	public String getTargetId() {
		return targetId;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.TARGET_ID
	 *
	 * @param targetId
	 *            the value for EQUIP_INST.TARGET_ID
	 *
	 */
	public void setTargetId(String targetId) {
		this.targetId = targetId == null ? null : targetId.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.ORDER_NUM
	 *
	 * @return the value of EQUIP_INST.ORDER_NUM
	 *
	 */
	public String getOrderNumber() {
		return orderNumber;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.ORDER_NUM
	 *
	 * @param orderNumber
	 *            the value for EQUIP_INST.ORDER_NUM
	 *
	 */
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber == null ? null : orderNumber.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * EQUIP_INST.ordered_date
	 *
	 * @return the value of EQUIP_INST.ordered_date
	 *
	 */
	public Date getOrderedDate() {
		return orderedDate;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.ordered_date
	 *
	 * @param ordered_date
	 *            the value for EQUIP_INST.ordered_date
	 *
	 */
	public void setOrderedDate(Date orderedDate) {
		this.orderedDate = orderedDate;
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.due_date
	 *
	 * @return the value of EQUIP_INST.due_date
	 *
	 */
	public Date getDueDate() {
		return dueDate;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.due_date
	 *
	 * @param due_date
	 *            the value for EQUIP_INST.due_date
	 *
	 */
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * EQUIP_INST.installed_date
	 *
	 * @return the value of EQUIP_INST.installed_date
	 *
	 */
	public Date getInstalledDate() {
		return installedDate;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * EQUIP_INST.installed_date
	 *
	 * @param installed_date
	 *            the value for EQUIP_INST.installed_date
	 *
	 */
	public void setInstalledDate(Date installedDate) {
		this.installedDate = installedDate;
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * EQUIP_INST.IN_SERVICE
	 *
	 * @return the value of EQUIP_INST.IN_SERVICE
	 *
	 */
	public Date getinServiceDate() {
		return inServiceDate;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.IN_SERVICE
	 *
	 * @param inService_date
	 *            the value for EQUIP_INST.IN_SERVICE
	 *
	 */
	public void setinServiceDate(Date inServiceDate) {
		this.inServiceDate = inServiceDate;
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * EQUIP_INST.SCHED_DATE
	 *
	 * @return the value of EQUIP_INST.SCHED_DATE
	 *
	 */
	public Date getScheduledDate() {
		return scheduledDate;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.SCHED_DATE
	 *
	 * @param scheduled_date
	 *            the value for EQUIP_INST.SCHED_DATE
	 *
	 */
	public void setScheduledDate(Date scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * EQUIP_INST.decommision_date
	 *
	 * @return the value of EQUIP_INST.decommision_date
	 *
	 */
	public Date getdecommisionDate() {
		return decommisionDate;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * EQUIP_INST.decommision_date
	 *
	 * @param decommision_date
	 *            the value for EQUIP_INST.decommision_date
	 *
	 */
	public void setDecommisionDate(Date decommisionDate) {
		this.decommisionDate = decommisionDate;
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.SERIAL_NO
	 *
	 * @return the value of EQUIP_INST.SERIAL_NO
	 *
	 */
	public String getSerialNumber() {
		return serialNumber;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.SERIAL_NO
	 *
	 * @param serial_Number
	 *            the value for EQUIP_INST.SERIAL_NO
	 *
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber == null ? null : serialNumber.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.BATCH_NO
	 *
	 * @return the value of EQUIP_INST.BATCH_NO
	 *
	 */
	public String getBatchNumber() {
		return batchNumber;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.BATCH_NO
	 *
	 * @param batch_Number
	 *            the value for EQUIP_INST.BATCH_NO
	 *
	 */
	public void setBatchNumber(String batchNumber) {
		this.batchNumber = batchNumber == null ? null : batchNumber.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.BAR_CODE
	 *
	 * @return the value of EQUIP_INST.BAR_CODE
	 *
	 */
	public String getBarCode() {
		return barCode;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.BAR_CODE
	 *
	 * @param barCode
	 *            the value for EQUIP_INST.BAR_CODE
	 *
	 */
	public void setBarCode(String barCode) {
		this.barCode = barCode == null ? null : barCode.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * EQUIP_INST.PURCHASE_PRICE
	 *
	 * @return the value of EQUIP_INST.PURCHASE_PRICE
	 *
	 */
	public BigDecimal getPurchasePrice() {
		return purchasePrice;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * EQUIP_INST.PURCHASE_PRICE
	 *
	 * @param purchasePrice
	 *            the value for EQUIP_INST.PURCHASE_PRICE
	 *
	 */
	public void setPurchasePrice(BigDecimal purchasePrice) {
		this.purchasePrice = purchasePrice;
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * EQUIP_INST.PURCHASE_DATE
	 *
	 * @return the value of EQUIP_INST.PURCHASE_DATE
	 *
	 */
	public Date getPurchaseDate() {
		return purchaseDate;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * EQUIP_INST.PURCHASE_DATE
	 *
	 * @param purchaseDate
	 *            the value for EQUIP_INST.PURCHASE_DATE
	 *
	 */
	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * EQUIP_INST.ASSET_LIFE
	 *
	 * @return the value of EQUIP_INST.ASSET_LIFE
	 *
	 */
	public BigDecimal getAssetLife() {
		return assetLife;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.ASSET_LIFE
	 *
	 * @param assetLife
	 *            the value for EQUIP_INST.ASSET_LIFE
	 *
	 */
	public void setAssetLife(BigDecimal assetLife) {
		this.assetLife = assetLife;
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.COMMENTS
	 *
	 * @return the value of EQUIP_INST.COMMENTS
	 *
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.COMMENTS
	 *
	 * @param comments
	 *            the value for EQUIP_INST.COMMENTS
	 *
	 */
	public void setComments(String comments) {
		this.comments = comments == null ? null : comments.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * EQUIP_INST.LAST_MOD_TS
	 *
	 * @return the value of EQUIP_INST.LAST_MOD_TS
	 *
	 */
	public Date getModifiedTimeStamp() {
		return modifiedTimeStamp;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.LAST_MOD_TS
	 *
	 * @param ModifiedTimeStamp
	 *            the value for EQUIP_INST.LAST_MOD_TS
	 *
	 */
	public void setModifiedTimeStamp(Date modifiedTimeStamp) {
		this.modifiedTimeStamp = modifiedTimeStamp;
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * EQUIP_INST.LAST_MOD_BY
	 *
	 * @return the value of EQUIP_INST.LAST_MOD_BY
	 *
	 */
	public String getModifiedUser() {
		return modifiedUser;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.LAST_MOD_BY
	 *
	 * @param ModifiedUser
	 *            the value for EQUIP_INST.LAST_MOD_BY
	 *
	 */
	public void setModifiedUser(String modifiedUser) {
		this.modifiedUser = modifiedUser == null ? null : modifiedUser.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.ALT_ID
	 *
	 * @return the value of EQUIP_INST.ALT_ID
	 *
	 */
	public String getAlternateName() {
		return alternateName;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.ALT_ID
	 *
	 * @param alternateName
	 *            the value for EQUIP_INST.ALT_ID
	 *
	 */
	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName == null ? null : alternateName.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.CLLI
	 *
	 * @return the value of EQUIP_INST.CLLI
	 *
	 */
	public String getClli() {
		return clli;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.CLLI
	 *
	 * @param clli
	 *            the value for EQUIP_INST.CLLI
	 *
	 */
	public void setClli(String clli) {
		this.clli = clli == null ? null : clli.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.CLEI
	 *
	 * @return the value of EQUIP_INST.CLEI
	 *
	 */
	public String getClei() {
		return clei;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.CLEI
	 *
	 * @param clei
	 *            the value for EQUIP_INST.CLEI
	 *
	 */
	public void setClei(String clei) {
		this.clei = clei == null ? null : clei.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * EQUIP_INST.EQ_TPLT_INST_ID
	 *
	 * @return the value of EQUIP_INST.EQ_TPLT_INST_ID
	 *
	 */
	public Long getTemplateReference() {
		return templateReference;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * EQUIP_INST.EQ_TPLT_INST_ID
	 *
	 * @param template_Reference
	 *            the value for EQUIP_INST.EQ_TPLT_INST_ID
	 *
	 */
	public void setTemplateReference(Long templateReference) {
		this.templateReference = templateReference;
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * EQUIP_INST.CUST_INST_ID
	 *
	 * @return the value of EQUIP_INST.CUST_INST_ID
	 *
	 */
	public Long getCustomerReference() {
		return customerReference;
	}

	/**
	 * 
	 * This method sets the value of the database column EQUIP_INST.CUST_INST_ID
	 *
	 * @param customer_Reference
	 *            the value for EQUIP_INST.CUST_INST_ID
	 *
	 */
	public void setCustomerReference(Long customerReference) {
		this.customerReference = customerReference;
	}

	/**
	 * 
	 * This method returns the value of the database column EQUIP_INST.NPA
	 *
	 * @return the value of EQUIP_INST.NPA
	 *
	 * 
	 * 
	 * 
	 * 
	 * 
	 *         /**
	 * 
	 *         This method returns the value of the database column
	 *         XNG.EQUIP_INST.IP_ADDRESS
	 *
	 * @return the value of XNG.EQUIP_INST.IP_ADDRESS
	 *
	 *         Wed Apr 01 14:29:05 EDT 2015
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * XNG.EQUIP_INST.IP_ADDRESS
	 *
	 * @param ipAddress
	 *            the value for XNG.EQUIP_INST.IP_ADDRESS
	 *
	 *            Wed Apr 01 14:29:05 EDT 2015
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress == null ? null : ipAddress.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * XNG.EQUIP_INST.PARENT_SHELF_INST_ID
	 *
	 * @return the value of XNG.EQUIP_INST.PARENT_SHELF_INST_ID
	 *
	 *         Wed Apr 01 14:29:05 EDT 2015
	 */
	public Long getparentShelfReference() {
		return parentShelfReference;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * XNG.EQUIP_INST.PARENT_SHELF_INST_ID
	 *
	 * @param parentShelfReference
	 *            the value for XNG.EQUIP_INST.PARENT_SHELF_INST_ID
	 *
	 *            Wed Apr 01 14:29:05 EDT 2015
	 */
	public void setparentShelfReference(Long parentShelfReference) {
		this.parentShelfReference = parentShelfReference;
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * XNG.EQUIP_INST.IS_MULTI_TID_SHELF
	 *
	 * @return the value of XNG.EQUIP_INST.IS_MULTI_TID_SHELF
	 *
	 *         Wed Apr 01 14:29:05 EDT 2015
	 */
	public String getIsMultiTidShelf() {
		return isMultiTidShelf;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * XNG.EQUIP_INST.IS_MULTI_TID_SHELF
	 *
	 * @param isMultiTidShelf
	 *            the value for XNG.EQUIP_INST.IS_MULTI_TID_SHELF
	 *
	 *            Wed Apr 01 14:29:05 EDT 2015
	 */
	public void setIsMultiTidShelf(String isMultiTidShelf) {
		this.isMultiTidShelf = isMultiTidShelf == null ? null : isMultiTidShelf.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * XNG.EQUIP_INST.PHYSICAL_SHELF
	 *
	 * @return the value of XNG.EQUIP_INST.PHYSICAL_SHELF
	 *
	 *         Wed Apr 01 14:29:05 EDT 2015
	 */
	public String getPhysicalShelf() {
		return physicalShelf;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * XNG.EQUIP_INST.PHYSICAL_SHELF
	 *
	 * @param physicalShelf
	 *            the value for XNG.EQUIP_INST.PHYSICAL_SHELF
	 *
	 *            Wed Apr 01 14:29:05 EDT 2015
	 */
	public void setPhysicalShelf(String physicalShelf) {
		this.physicalShelf = physicalShelf == null ? null : physicalShelf.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * XNG.EQUIP_INST.FUNCTIONAL_EQUIP_TYPE
	 *
	 * @return the value of XNG.EQUIP_INST.FUNCTIONAL_EQUIP_TYPE
	 *
	 *         Wed Apr 01 14:29:05 EDT 2015
	 */
	public Long getFunctionalEquipType() {
		return functionalEquipType;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * XNG.EQUIP_INST.FUNCTIONAL_EQUIP_TYPE
	 *
	 * @param functionalEquipType
	 *            the value for XNG.EQUIP_INST.FUNCTIONAL_EQUIP_TYPE
	 *
	 *            Wed Apr 01 14:29:05 EDT 2015
	 */
	public void setFunctionalEquipType(Long functionalEquipType) {
		this.functionalEquipType = functionalEquipType;
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * XNG.EQUIP_INST.MFG_PART_NUMBER
	 *
	 * @return the value of XNG.EQUIP_INST.MFG_PART_NUMBER
	 *
	 *         Wed Apr 01 14:29:05 EDT 2015
	 */
	public String getMfgPartNumber() {
		return mfgPartNumber;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * XNG.EQUIP_INST.MFG_PART_NUMBER
	 *
	 * @param mfgPartNumber
	 *            the value for XNG.EQUIP_INST.MFG_PART_NUMBER
	 *
	 *            Wed Apr 01 14:29:05 EDT 2015
	 */
	public void setMfgPartNumber(String mfgPartNumber) {
		this.mfgPartNumber = mfgPartNumber == null ? null : mfgPartNumber.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column XNG.EQUIP_INST.AID
	 *
	 * @return the value of XNG.EQUIP_INST.AID
	 *
	 *         Wed Apr 01 14:29:05 EDT 2015
	 */
	public String getAid() {
		return aid;
	}

	/**
	 * 
	 * This method sets the value of the database column XNG.EQUIP_INST.AID
	 *
	 * @param aid
	 *            the value for XNG.EQUIP_INST.AID
	 *
	 *            Wed Apr 01 14:29:05 EDT 2015
	 */
	public void setAid(String aid) {
		this.aid = aid == null ? null : aid.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * XNG.EQUIP_INST.FIELD_ID
	 *
	 * @return the value of XNG.EQUIP_INST.FIELD_ID
	 *
	 *         Wed Apr 01 14:29:05 EDT 2015
	 */
	public String getFieldId() {
		return fieldId;
	}

	/**
	 * 
	 * This method sets the value of the database column XNG.EQUIP_INST.FIELD_ID
	 *
	 * @param fieldId
	 *            the value for XNG.EQUIP_INST.FIELD_ID
	 *
	 *            Wed Apr 01 14:29:05 EDT 2015
	 */
	public void setFieldId(String fieldId) {
		this.fieldId = fieldId == null ? null : fieldId.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * XNG.EQUIP_INST.FR_REF_KEY_NAME
	 *
	 * @return the value of XNG.EQUIP_INST.FR_REF_KEY_NAME
	 *
	 *         Wed Apr 01 14:29:05 EDT 2015
	 */
	public String getFrRefKeyName() {
		return frRefKeyName;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * XNG.EQUIP_INST.FR_REF_KEY_NAME
	 *
	 * @param frRefKeyName
	 *            the value for XNG.EQUIP_INST.FR_REF_KEY_NAME
	 *
	 *            Wed Apr 01 14:29:05 EDT 2015
	 */
	public void setFrRefKeyName(String frRefKeyName) {
		this.frRefKeyName = frRefKeyName == null ? null : frRefKeyName.trim();
	}

	/**
	 * 
	 * This method returns the value of the database column
	 * XNG.EQUIP_INST.FR_REF_KEY_VALUE
	 *
	 * @return the value of XNG.EQUIP_INST.FR_REF_KEY_VALUE
	 *
	 *         Wed Apr 01 14:29:05 EDT 2015
	 */
	public String getFrRefKeyValue() {
		return frRefKeyValue;
	}

	/**
	 * 
	 * This method sets the value of the database column
	 * XNG.EQUIP_INST.FR_REF_KEY_VALUE
	 *
	 * @param frRefKeyValue
	 *            the value for XNG.EQUIP_INST.FR_REF_KEY_VALUE
	 *
	 *            Wed Apr 01 14:29:05 EDT 2015
	 */
	public void setFrRefKeyValue(String frRefKeyValue) {
		this.frRefKeyValue = frRefKeyValue == null ? null : frRefKeyValue.trim();
	}

	public String getPointCode() {
		return pointCode;
	}

	/**
	 * This method was generated by MyBatis Generator. This method sets the
	 * value of the database column XNG.EQUIP_INST.POINT_CODE
	 *
	 * @param pointCode
	 *            the value for XNG.EQUIP_INST.POINT_CODE
	 *
	 *            Thu Apr 02 18:10:43 EDT 2015
	 */
	public void setPointCode(String pointCode) {
		this.pointCode = pointCode == null ? null : pointCode.trim();
	}

	/**
	 * This method was generated by MyBatis Generator. This method returns the
	 * value of the database column XNG.EQUIP_INST.NMS_EMS
	 *
	 * @return the value of XNG.EQUIP_INST.NMS_EMS
	 *
	 *         Thu Apr 02 18:10:43 EDT 2015
	 */
	public String getems() {
		return ems;
	}

	/**
	 * This method was generated by MyBatis Generator. This method sets the
	 * value of the database column XNG.EQUIP_INST.NMS_EMS
	 *
	 * @param ems
	 *            the value for XNG.EQUIP_INST.NMS_EMS
	 *
	 *            Thu Apr 02 18:10:43 EDT 2015
	 */
	public void setems(String ems) {
		this.ems = ems == null ? null : ems.trim();
	}

	/**
	 * This method was generated by MyBatis Generator. This method returns the
	 * value of the database column XNG.EQUIP_INST.REV
	 *
	 * @return the value of XNG.EQUIP_INST.REV
	 *
	 *         Thu Apr 02 18:10:43 EDT 2015
	 */
	public String gethardwareRevision() {
		return hardwareRevision;
	}

	/**
	 * This method was generated by MyBatis Generator. This method sets the
	 * value of the database column XNG.EQUIP_INST.REV
	 *
	 * @param rev
	 *            the value for XNG.EQUIP_INST.REV
	 *
	 *            Thu Apr 02 18:10:43 EDT 2015
	 */
	public void sethardwareRevision(String hardwareRevision) {
		this.hardwareRevision = hardwareRevision == null ? null : hardwareRevision.trim();
	}

	/**
	 * This method was generated by MyBatis Generator. This method returns the
	 * value of the database column XNG.EQUIP_INST.SW_REV
	 *
	 * @return the value of XNG.EQUIP_INST.SW_REV
	 *
	 *         Thu Apr 02 18:10:43 EDT 2015
	 */
	public String getsoftwareRevision() {
		return softwareRevision;
	}

	/**
	 * This method was generated by MyBatis Generator. This method sets the
	 * value of the database column XNG.EQUIP_INST.SW_REV
	 * 
	 * @param softwareRevision
	 *            the value for XNG.EQUIP_INST.SW_REV Thu Apr 02 18:10:43 EDT
	 *            2015
	 */
	public void setsoftwareRevision(String softwareRevision) {
		this.softwareRevision = softwareRevision == null ? null : softwareRevision.trim();
	}

	/**
	 * This method returns the value of the database column
	 * XNG.EQUIP_INST.EQ_CLASS
	 *
	 * @param the
	 *            value of EQUIP_INST.EQ_CLASS
	 *
	 */
	public String getEqClass() {
		return eqClass;
	}

	/**
	 * This method sets the value of the database column XNG.EQUIP_INST.EQ_CLASS
	 * 
	 * @param eqClass
	 *            value for EQUIP_INST.EQ_CLASS
	 */
	public void setEqClass(String eqClass) {
		this.eqClass = eqClass == null ? null : eqClass.trim();
	}

	public String getTid_l() {
		return tid_l;
	}

	public void setTid_l(String tid_l) {
		this.tid_l = tid_l;
	}


	public String getWorkOrderNumber() {
		return workOrderNumber;
	}

	public void setWorkOrderNumber(String workOrderNumber) {
		this.workOrderNumber = workOrderNumber;
	}
	public String getAssetOwner() {
		return assetOwner;
	}

	public void setAssetOwner(String assetOwner) {
		this.assetOwner = assetOwner;
	}

	public String getSubLocation() {
		return subLocation;
	}

	public void setSubLocation(String subLocation) {
		this.subLocation = subLocation;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getShelfType() {
		return shelfType;
	}

	public void setShelfType(String shelfType) {
		this.shelfType = shelfType;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}
	public String getFunctionalEquipTypeName() {
		return functionalEquipTypeName;
	}

	public void setFunctionalEquipTypeName(String functionalEquipTypeName) {
		this.functionalEquipTypeName = functionalEquipTypeName;
	}
	
	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}
	public List<DirDomainsDTO> getDomianNames() {
		return domianNames;
	}

	public void setDomianNames(List<DirDomainsDTO> domianNames) {
		this.domianNames = domianNames;
	}
	
	public List<AttributesDTO> getAttributeList() {
		return attributeList;
	}

	public void setAttributeList(List<AttributesDTO> attributeList) {
		this.attributeList = attributeList;
	}


	public List<SlotDTO> getSlotDTOList() {
		return slotDTOList;
	}

	public void setSlotDTOList(List<SlotDTO> slotDTOList) {
		this.slotDTOList = slotDTOList;
	}
	
	public String getNetworkType() {
		return networkType;
	}

	public void setNetworkType(String networkType) {
		this.networkType = networkType;
	}
	public Integer getTotalPorts() {
		return totalPorts;
	}

	public void setTotalPorts(Integer totalPorts) {
		this.totalPorts = totalPorts;
	}

	public Integer getAvailablePorts() {
		return availablePorts;
	}

	public void setAvailablePorts(Integer availablePorts) {
		this.availablePorts = availablePorts;
	}

	public Integer getUsedPorts() {
		return usedPorts;
	}

	public void setUsedPorts(Integer usedPorts) {
		this.usedPorts = usedPorts;
	}
	public String getNetworkDomain() {
		return networkDomain;
	}

	public void setNetworkDomain(String networkDomain) {
		this.networkDomain = networkDomain;
	}

	public String getProjectReferenceId() {
		return projectReferenceId;
	}

	public void setProjectReferenceId(String projectReferenceId) {
		this.projectReferenceId = projectReferenceId;
	}

	public String getIpv4Address() {
		return ipv4Address;
	}

	public void setIpv4Address(String ipv4Address) {
		this.ipv4Address = ipv4Address;
	}

	public String getIpv6Address() {
		return ipv6Address;
	}

	public void setIpv6Address(String ipv6Address) {
		this.ipv6Address = ipv6Address;
	}


	public String getInstanceType() {
		return instanceType;
	}

	public void setInstanceType(String instanceType) {
		this.instanceType = instanceType;
	}

	public Long getPhysicalEquipmentReferenceId() {
		return physicalEquipmentReferenceId;
	}

	public void setPhysicalEquipmentReferenceId(Long physicalEquipmentReferenceId) {
		this.physicalEquipmentReferenceId = physicalEquipmentReferenceId;
	}
	
	public String getRawTelnetPort() {
		return rawTelnetPort;
	}

	public void setRawTelnetPort(String rawTelnetPort) {
		this.rawTelnetPort = rawTelnetPort;
	}
	
	public String getNormalTelnetPort() {
		return normalTelnetPort;
	}

	public void setNormalTelnetPort(String normalTelnetPort) {
		this.normalTelnetPort = normalTelnetPort;
	}

	public Integer getMgmtSSHPort() {
		return mgmtSSHPort;
	}

	public void setMgmtSSHPort(Integer mgmtSSHPort) {
		this.mgmtSSHPort = mgmtSSHPort;
	}
	
	public String getFrRefParentKeyValue() {
		return frRefParentKeyValue;
	}

	public void setFrRefParentKeyValue(String frRefParentKeyValue) {
		this.frRefParentKeyValue = frRefParentKeyValue;
	}

	public String getHostName(){
		return hostName;
	}
	public void setHostName(String hostName){
		this.hostName = hostName;
	}
	
	public String getUtIndicator() {
		return utIndicator;
	}

	public void setUtIndicator(String utIndicator) {
		this.utIndicator = utIndicator;
	}

	public String getMatedPair() {
		return matedPair;
	}

	public void setMatedPair(String matedPair) {
		this.matedPair = matedPair;
	}
	
	@Override
	public String toString() {
		return "EquipmentDTOV1 [equipmentReference=" + equipmentReference + ", type=" + type + ", vendor=" + vendor
				+ ", model=" + model + ", name=" + name + ", shelfName=" + shelfName + ", siteReference="
				+ siteReference + ", parentEqReference=" + parentEqReference + ", status=" + status + ", container="
				+ container + ", eqClass=" + eqClass + ", height=" + height + ", width=" + width + ", depth=" + depth
				+ ", distToBase=" + distToBase + ", distToLeft=" + distToLeft + ", distToFront=" + distToFront
				+ ", lineUp=" + lineUp + ", frame=" + frame + ", logicalShelf=" + logicalShelf + ", softwareRevision="
				+ softwareRevision + ", hardwareRevision=" + hardwareRevision + ", pointCode=" + pointCode + ", ems="
				+ ems + ", targetId=" + targetId + ", orderNumber=" + orderNumber + ", orderedDate=" + orderedDate
				+ ", dueDate=" + dueDate + ", installedDate=" + installedDate + ", inServiceDate=" + inServiceDate
				+ ", scheduledDate=" + scheduledDate + ", decommisionDate=" + decommisionDate + ", serialNumber="
				+ serialNumber + ", batchNumber=" + batchNumber + ", barCode=" + barCode + ", purchasePrice="
				+ purchasePrice + ", purchaseDate=" + purchaseDate + ", assetLife=" + assetLife + ", comments="
				+ comments + ", modifiedTimeStamp=" + modifiedTimeStamp + ", modifiedUser=" + modifiedUser
				+ ", alternateName=" + alternateName + ", clli=" + clli + ", clei=" + clei + ", templateReference="
				+ templateReference + ", customerReference=" + customerReference + ", ipAddress=" + ipAddress
				+ ", parentShelfReference=" + parentShelfReference + ", isMultiTidShelf=" + isMultiTidShelf
				+ ", physicalShelf=" + physicalShelf + ", functionalEquipType=" + functionalEquipType
				+ ", functionalEquipTypeName=" + functionalEquipTypeName + ", mfgPartNumber=" + mfgPartNumber + ", aid="
				+ aid + ", fieldId=" + fieldId + ", frRefKeyName=" + frRefKeyName + ", frRefKeyValue=" + frRefKeyValue
				+ ", templateName=" + templateName + ", tid_l=" + tid_l + ", workOrderNumber=" + workOrderNumber
				+ ", assetOwner=" + assetOwner + ", subLocation=" + subLocation + ", customerName=" + customerName
				+ ", shelfType=" + shelfType + ", floor=" + floor + ", domianNames=" + domianNames + ", attributeList="
				+ attributeList + ", slotDTOList=" + slotDTOList + ", networkType=" + networkType + ", totalPorts="
				+ totalPorts + ", availablePorts=" + availablePorts + ", usedPorts=" + usedPorts + ", networkDomain="
				+ networkDomain + ", projectReferenceId=" + projectReferenceId + ", ipv4Address=" + ipv4Address
				+ ", ipv6Address=" + ipv6Address + ", instanceType=" + instanceType + ", physicalEquipmentReferenceId="
				+ physicalEquipmentReferenceId + ", " + "normalTelnetPort=" + normalTelnetPort + ", mgmtSSHPort=" + mgmtSSHPort
				+ "normalTelnetPort=" + normalTelnetPort + ", " + "frRefParentKeyValue=" + frRefParentKeyValue
				+ ", hostName=" + hostName + ", utIndicator=" + utIndicator + ", matedPair=" + matedPair+" ]";
	}

}