package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.javers.core.metamodel.annotation.TypeName;

/**
 * <p>
 * This Persistent class is used for the DB table -> DIR_PORT_ALLOCATION
 * </p>
 * 
 * @author Asif Billa
 * @date 13-June-2017
 *
 */
@Entity
@Table(name = "DIR_PORT_ALLOCATION")
@TypeName("DirPortAllocation")
@NamedQuery(name = "DirPortAllocation.findAll", query = "SELECT d FROM DirPortAllocation d")
public class DirPortAllocation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PORT_ALLOCATION_ID")
	private long portAllocationId;

	@Column(name = "BLOCK_REASON_CODE")
	private String blockReasonCode;

	@Column(name = "ALLOCATION")
	private Integer allocation;

	@Column(name = "ALLOCATION_TYPE")
	private String allocationType;

	@Column(name = "PRIORITY")
	private Integer priority;

	/**
	 * @return the portAllocationId
	 */
	public long getPortAllocationId() {
		return portAllocationId;
	}

	/**
	 * @param portAllocationId the portAllocationId to set
	 */
	public void setPortAllocationId(long portAllocationId) {
		this.portAllocationId = portAllocationId;
	}

	/**
	 * @return the blockReasonCode
	 */
	public String getBlockReasonCode() {
		return blockReasonCode;
	}

	/**
	 * @param blockReasonCode the blockReasonCode to set
	 */
	public void setBlockReasonCode(String blockReasonCode) {
		this.blockReasonCode = blockReasonCode;
	}

	/**
	 * @return the allocation
	 */
	public Integer getAllocation() {
		return allocation;
	}

	/**
	 * @param allocation the allocation to set
	 */
	public void setAllocation(Integer allocation) {
		this.allocation = allocation;
	}

	/**
	 * @return the allocationType
	 */
	public String getAllocationType() {
		return allocationType;
	}

	/**
	 * @param allocationType the allocationType to set
	 */
	public void setAllocationType(String allocationType) {
		this.allocationType = allocationType;
	}

	/**
	 * @return the priority
	 */
	public Integer getPriority() {
		return priority;
	}

	/**
	 * @param priority the priority to set
	 */
	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DirPortAllocation [portAllocationId=");
		builder.append(portAllocationId);
		builder.append(", blockReasonCode=");
		builder.append(blockReasonCode);
		builder.append(", allocation=");
		builder.append(allocation);
		builder.append(", allocationType=");
		builder.append(allocationType);
		builder.append(", priority=");
		builder.append(priority);
		builder.append("]");
		return builder.toString();
	}

}