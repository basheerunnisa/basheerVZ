package com.vz.uiam.inventory.equipment.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class EnodebDetailsDTO {

	private String enodebId;
	private Long eqpReferenceId;
	private Long siteReferenceId;
	private String enodebName;
	private String cellType;
	private Double latitude;
	private Double longitude;
	private List<EnodebSectorDTO> sectors;
	
	public EnodebDetailsDTO(){
		super();
	}
	public EnodebDetailsDTO(String enodebId, EnodebSectorDTO... sectors) {
		this();
		this.enodebId = enodebId;
		this.sectors = new ArrayList<>(Arrays.asList(sectors));
	}
	
	public String getEnodebId() {
		return enodebId;
	}
	public void setEnodebId(String enodebId) {
		this.enodebId = enodebId;
	}
	public Long getEqpReferenceId() {
		return eqpReferenceId;
	}
	public void setEqpReferenceId(Long eqpReferenceId) {
		this.eqpReferenceId = eqpReferenceId;
	}
	public Long getSiteReferenceId() {
		return siteReferenceId;
	}
	public void setSiteReferenceId(Long siteReferenceId) {
		this.siteReferenceId = siteReferenceId;
	}
	public String getEnodebName() {
		return enodebName;
	}
	public void setEnodebName(String enodebName) {
		this.enodebName = enodebName;
	}
	public String getCellType() {
		return cellType;
	}
	public void setCellType(String cellType) {
		this.cellType = cellType;
	}
	public Double getLatitude() {
		return latitude;
	}
	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}
	public Double getLongitude() {
		return longitude;
	}
	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}
	public List<EnodebSectorDTO> getSectors() {
		return sectors;
	}
	public void setSectors(List<EnodebSectorDTO> sectors) {
		this.sectors = sectors;
	}
	
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "EnodebDetailsDTO [enodebId=" + enodebId + ", eqpReferenceId=" + eqpReferenceId + ", siteReferenceId="
				+ siteReferenceId + ", enodebName=" + enodebName + ", cellType=" + cellType + ", latitude=" + latitude
				+ ", longitude=" + longitude + ", sectors=" + sectors + "]";
	}
}
