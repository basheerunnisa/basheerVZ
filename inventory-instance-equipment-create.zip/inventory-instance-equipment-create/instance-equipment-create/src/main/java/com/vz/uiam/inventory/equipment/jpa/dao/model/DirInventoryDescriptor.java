package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.javers.core.metamodel.annotation.TypeName;


/**
 * The persistent class for the DIR_INVENTORY_DESCRIPTOR database table.
 * 
 */
@Entity
@Table(name="DIR_INVENTORY_DESCRIPTOR")
@TypeName("DirInventoryDescriptor")
@NamedQuery(name="DirInventoryDescriptor.findAll", query="SELECT d FROM DirInventoryDescriptor d")
public class DirInventoryDescriptor implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="INV_DESCPT_ID")
	private long invDescptId;

	@Column(name="EQUIPMENT_TYPE")
	private String equipmentType;

	@Column(name="FUNCTIONAL_TYPE")
	private String functionalType;

	@Column(name="INV_DESCPT_NAME")
	private String invDescptName;

	private String status;

	//bi-directional many-to-one association to DirInventoryDefinition
	@OneToMany(mappedBy="dirInventoryDescriptor")
	private List<DirInventoryDefinition> dirInventoryDefinitions;

	public DirInventoryDescriptor() {
	}

	public long getInvDescptId() {
		return this.invDescptId;
	}

	public void setInvDescptId(long invDescptId) {
		this.invDescptId = invDescptId;
	}

	public String getEquipmentType() {
		return this.equipmentType;
	}

	public void setEquipmentType(String equipmentType) {
		this.equipmentType = equipmentType;
	}

	public String getFunctionalType() {
		return this.functionalType;
	}

	public void setFunctionalType(String functionalType) {
		this.functionalType = functionalType;
	}

	public String getInvDescptName() {
		return this.invDescptName;
	}

	public void setInvDescptName(String invDescptName) {
		this.invDescptName = invDescptName;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<DirInventoryDefinition> getDirInventoryDefinitions() {
		return this.dirInventoryDefinitions;
	}

	public void setDirInventoryDefinitions(List<DirInventoryDefinition> dirInventoryDefinitions) {
		this.dirInventoryDefinitions = dirInventoryDefinitions;
	}

	public DirInventoryDefinition addDirInventoryDefinition(DirInventoryDefinition dirInventoryDefinition) {
		getDirInventoryDefinitions().add(dirInventoryDefinition);
		dirInventoryDefinition.setDirInventoryDescriptor(this);

		return dirInventoryDefinition;
	}

	public DirInventoryDefinition removeDirInventoryDefinition(DirInventoryDefinition dirInventoryDefinition) {
		getDirInventoryDefinitions().remove(dirInventoryDefinition);
		dirInventoryDefinition.setDirInventoryDescriptor(null);

		return dirInventoryDefinition;
	}

}