package com.vz.uiam.inventory.equipment.controller;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.inventory.equipment.config.EntityValidatorBean;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/configuration")
public class ConfigController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigController.class);
	
	@Autowired
	private EntityValidatorBean cacheBean;
	@Autowired
	private CacheManager cacheManager;
	
	@RequestMapping(value = "/cache/clear", method = RequestMethod.GET)
	@ApiOperation(value = "Clears the Config Cache", 
				  notes = "Static Types and Statuses are cached for performance and changing the DIR_INV_STATUS or DIR_INV_TYPE "
				  		+ "tables will require a refresh of the cache.", response = boolean.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = boolean.class),
			@ApiResponse(code = 500, message = "Internal Server Error")})
	public boolean cacheRefresh(HttpServletResponse httpResponse){
		
		LOGGER.info("Clearing Caches");
		
		cacheManager.getCacheNames().forEach(c -> {
			cacheManager.getCache(c).clear();
			LOGGER.info("Cache {} Cleared!", c);
		});
		
		cacheBean.init();
		return true;
	}
}