package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInventoryConfig;

public interface DirInventoryConfigRepository extends JpaRepository<DirInventoryConfig, Long> {

	DirInventoryConfig findByGroupNameAndConfigName(String groupName, String configName);

	@Query(value = "SELECT CONFIG_VALUE FROM DIR_INVENTORY_CONFIG"
			+ " WHERE GROUP_NAME = 'CARD_SLOT_STATUS' AND CONFIG_NAME = 'SLOT_STATUS_UPDATE'"
			+ " ORDER BY SEQUENCE LIMIT 1", nativeQuery = true)
	String selectSlotStatusConstant();

	DirInventoryConfig findByGroupNameAndConfigNameAndConfigValue(String groupName, String configName, String configValue);
	
	@Query(value = "SELECT CONFIG_VALUE FROM DIR_INVENTORY_CONFIG"
			+ " WHERE GROUP_NAME = 'TRAIL_VALIDATION' AND CONFIG_NAME = 'PORT_STATUS_CHECK'"
			+ " ORDER BY SEQUENCE", nativeQuery = true)
	List<String> selectPortStatusCheckConstants();
}
