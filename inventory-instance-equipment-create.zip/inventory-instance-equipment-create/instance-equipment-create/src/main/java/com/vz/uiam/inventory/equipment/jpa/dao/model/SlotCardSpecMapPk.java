package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class SlotCardSpecMapPk implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Column(name = "CARD_SPEC_REF_ID")
	private Long cardSpecRefId;

	@Column(name = "SLOT_SPEC_REF_ID")
	private Long slotSpecRefId;

	public Long getCardSpecRefId() {
		return cardSpecRefId;
	}

	public void setCardSpecRefId(Long cardSpecRefId) {
		this.cardSpecRefId = cardSpecRefId;
	}

	public Long getSlotSpecRefId() {
		return slotSpecRefId;
	}

	public void setSlotSpecRefId(Long slotSpecRefId) {
		this.slotSpecRefId = slotSpecRefId;
	}

	@Override
	public String toString() {
		return "SlotCardSpecMapPk [cardSpecRefId=" + cardSpecRefId + ", slotSpecRefId=" + slotSpecRefId + "]";
	}
	
}