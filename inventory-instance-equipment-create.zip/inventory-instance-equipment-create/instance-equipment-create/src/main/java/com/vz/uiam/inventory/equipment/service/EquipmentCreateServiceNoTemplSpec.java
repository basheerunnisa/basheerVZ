package com.vz.uiam.inventory.equipment.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.enumeration.Entity;
import com.vz.uiam.inventory.equipment.exception.MethodFailureException;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirContainerType;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvStatus;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvType;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Site;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.SiteRepository;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.model.mapper.ResourceMapper;

@Service
public class EquipmentCreateServiceNoTemplSpec {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EquipmentCreateServiceNoTemplSpec.class);
	private static final String SHELF = "SHELF";
	
	@Autowired
	private DirectoryService dirService;
	@Autowired
	private EquipmentService equipmentService;
	@Autowired
	private EquipmentRepository equipmentRepository;
	@Autowired
	private ResourceMapper resourceMapper;

	@Autowired
	private SiteRepository siteRepository;
	
	@Transactional
	public EquipmentDTOV1 createEquipment(EquipmentDTOV1 equipmentDTO, HttpServletRequest httpRequest) {
		LOGGER.info(" => createEquipment started {}", equipmentDTO);
		
		Site site = dirService.findSite(equipmentDTO);
		DirInvStatus dirInvStatus = dirService.findStatusByEntityWithDefault(Entity.EQUIPMENT, equipmentDTO.getStatus(), "PENDING_IN");
		DirContainerType dirContainerType = dirService.findContainer(equipmentDTO.getcontainer());

		// Retrieve Rack
		Equipment rack = null;
		if (SHELF.equalsIgnoreCase(dirContainerType.getContainer())) {
			rack = equipmentRepository.findOne(equipmentDTO.getparentEqReference());
			if (rack == null || rack != null && rack.getSiteReferenceId().compareTo(BigDecimal.ZERO) < 0) {
				LOGGER.info("createEquipment: Error in getting Rack details");
				throw new MethodFailureException("Equipment not created. Error in getting Rack details");
			}
			equipmentDTO.setparentEqReference(rack.getEqpReferenceId());
			equipmentDTO.setFrame(EquipmentService.validateNotNull(equipmentDTO.getFrame()) ? equipmentDTO.getFrame() : rack.getFrame());
		}

		Equipment equipment = new Equipment();
		
		equipment.setAlternateName(equipmentDTO.getAlternateName());
		equipment.setAssetOwner(equipmentDTO.getAssetOwner());
		equipment.setBarCode(equipmentDTO.getBarCode());
		equipment.setBatchNumber(equipmentDTO.getBatchNumber());
		equipment.setComments(equipmentDTO.getComments());
		equipment.setCustomerName(equipmentDTO.getCustomerName());
		equipment.setDecommisionDate(equipmentDTO.getdecommisionDate());
		equipment.setDirContainerType(dirContainerType);
		equipment.setDirEqpType(dirService.findTypeByEntity(Entity.EQUIPMENT, equipmentDTO.getType()).getType());
		equipment.setDirInvStatus(dirInvStatus.getStatus());
		equipment.setDueDate(equipmentDTO.getDueDate());
		equipment.setEms(equipmentDTO.getems());
		equipment.setEqpClei(equipmentDTO.getClei());
		equipment.setEqpManufacturer("Juniper");
		equipment.setEqpModel(equipmentDTO.getModel());
		equipment.setEqpName(equipmentDTO.getName());
		equipment.setEqpPurchaseDate(equipmentDTO.getPurchaseDate());
		equipment.setEqpVendor(equipmentDTO.getVendor());
		equipment.setFieldId(equipmentDTO.getFieldId());
		equipment.setFrRefKeyName("IPNMP_DISCOVERY");
		equipment.setFrRefKeyName(equipmentDTO.getFrRefKeyName());
		equipment.setFrRefKeyValue("snm_NE_publicIP");
		equipment.setFrRefKeyValue(equipmentDTO.getFrRefKeyValue());
		equipment.setFrame(equipmentDTO.getFrame());
		equipment.setFunctionalType("ROUTER");
		equipment.setHardwareRevision(equipmentDTO.gethardwareRevision());
		equipment.setIneffectDate(equipmentDTO.getinServiceDate());
		if(equipmentDTO.getInstalledDate()!=null)
			equipment.setInstalledDate(equipmentDTO.getInstalledDate());
		else
			equipment.setInstalledDate(new Date());
		equipment.setIpv4Address(equipmentDTO.getIpAddress());
		equipment.setIsMultiTidShelf(equipmentDTO.getIsMultiTidShelf());
		equipment.setLastModifiedTimeStamp(new Date());
		equipment.setLineUp(equipmentDTO.getLineUp());
		equipment.setLocationClli(site.getClli());
		equipment.setMgmtIpAddress(equipmentDTO.getIpAddress());
		equipment.setNetworkType(equipmentDTO.getNetworkType());
		equipment.setOrderNumber(equipmentDTO.getOrderNumber());
		equipment.setPointCode(equipmentDTO.getPointCode());
		equipment.setScheduledDate(equipmentDTO.getScheduledDate());
		equipment.setSerialNumber(equipmentDTO.getSerialNumber());
		equipment.setShelfType(equipmentDTO.getShelfType());
		equipment.setSiteReferenceId(new BigDecimal(equipmentDTO.getsiteReference()));
		equipment.setSoftwareRevision(equipmentDTO.getsoftwareRevision());
		equipment.setSubLocation(equipmentDTO.getSubLocation());
		equipment.setTidLogical(equipmentDTO.getTid_l());
		equipment.setTidPhysical(equipmentDTO.getTargetId());

		equipment.setAssetLife(EquipmentService.validateNotNull(equipmentDTO.getAssetLife()) ? equipmentDTO.getAssetLife().longValue() : null);
		equipment.setCustomerReferenceId(EquipmentService.validateNotNull(equipmentDTO.getCustomerReference()) ? new BigDecimal(equipmentDTO.getCustomerReference()) : null);
		equipment.setDistFromX(EquipmentService.validateNotNull(equipmentDTO.getDistToFront()) ? equipmentDTO.getDistToFront() : null);
		equipment.setDistFromY(EquipmentService.validateNotNull(equipmentDTO.getDistToLeft()) ? equipmentDTO.getDistToLeft() : null);
		equipment.setDistFromZ(EquipmentService.validateNotNull(equipmentDTO.getDistToBase()) ? equipmentDTO.getDistToBase() : null);
		equipment.setEqpDepth(EquipmentService.validateNotNull(equipmentDTO.getdepth()) ? equipmentDTO.getdepth() : null);
		equipment.setEqpHeight(EquipmentService.validateNotNull(equipmentDTO.getheight()) ? equipmentDTO.getheight() : null);
		equipment.setEqpPurchasePrice(EquipmentService.validateNotNull(equipmentDTO.getPurchasePrice()) ? equipmentDTO.getPurchasePrice().toString() : null);
		equipment.setEqpWidth(EquipmentService.validateNotNull(equipmentDTO.getwidth()) ? equipmentDTO.getwidth() : null);
		equipment.setHiLocationReference(EquipmentService.validateNotNull(equipmentDTO.getFloor()) ? equipmentDTO.getFloor() : null);
		equipment.setLastModifiedBy(EquipmentService.validateNotNull(equipmentDTO.getModifiedUser()) ? equipmentDTO.getModifiedUser() : "DISCOVERY");
		equipment.setLogicalShelf(EquipmentService.validateNotNull(equipmentDTO.getlogicalShelf()) ? equipmentDTO.getlogicalShelf() : "1");
		equipment.setParentEqpReferenceId(EquipmentService.validateNotNull(equipmentDTO.getparentEqReference()) ? new BigDecimal(equipmentDTO.getparentEqReference()) : null);
		equipment.setParentShelfReferenceId(EquipmentService.validateNotNull(equipmentDTO.getparentShelfReference()) ? new BigDecimal(equipmentDTO.getparentShelfReference()) : null);
		equipment.setPhysicalShelfPosition(EquipmentService.validateNotNull(equipmentDTO.getPhysicalShelf()) ? equipmentDTO.getPhysicalShelf() : null);
		equipment.setMatedPair(EquipmentService.validateNotNull(equipmentDTO.getMatedPair()) ? equipmentDTO.getMatedPair() : null);
		
		Equipment equipmentRef = equipmentRepository.save(equipment);
		equipmentService.createEquipmentDomains(equipmentRef.getEqpReferenceId(), equipmentDTO, httpRequest);
		return resourceMapper.convertToEquipmentDTOV1(equipmentRef);
	}

	public EquipmentDTOV1 addRack(EquipmentDTOV1 equipmentDTO, HttpServletRequest httpRequest) {
		
		Site site = dirService.findSite(equipmentDTO);
		DirContainerType dirContainerType = dirService.findContainer(equipmentDTO.getcontainer());
		DirInvStatus dirInvStatus = dirService.findStatusByEntityWithDefault(Entity.EQUIPMENT, equipmentDTO.getStatus(), "PENDING_IN");
		DirInvType dirEqpType = dirService.findTypeByEntity(Entity.EQUIPMENT, equipmentDTO.getType());

		Equipment equipment = new Equipment();
		
		equipment.setAid(equipmentDTO.getAid());
		equipment.setAlternateName(equipmentDTO.getAlternateName());
		equipment.setAssetOwner(equipmentDTO.getAssetOwner());
		equipment.setBarCode(equipmentDTO.getBarCode());
		equipment.setBatchNumber(equipmentDTO.getBatchNumber());
		equipment.setComments(equipmentDTO.getComments());
		equipment.setDecommisionDate(equipmentDTO.getdecommisionDate());
		equipment.setDirContainerType(dirContainerType);
		equipment.setDirEqpType(dirEqpType.getType());
		equipment.setDirInvStatus(dirInvStatus.getStatus());
		equipment.setDueDate(equipmentDTO.getDueDate());
		equipment.setEms(equipmentDTO.getems());
		equipment.setEqpClei(equipmentDTO.getClei());
		equipment.setEqpManufacturer("Juniper");
		equipment.setEqpModel(equipmentDTO.getModel());
		equipment.setEqpName(equipmentDTO.getName());
		equipment.setEqpPurchaseDate(equipmentDTO.getPurchaseDate());
		equipment.setEqpVendor(equipmentDTO.getVendor());
		equipment.setFieldId(equipmentDTO.getFieldId());
		equipment.setFrRefKeyName("IPNMP_DISCOVERY");
		equipment.setFrRefKeyName(equipmentDTO.getFrRefKeyName());
		equipment.setFrRefKeyValue("snm_NE_publicIP");
		equipment.setFrRefKeyValue(equipmentDTO.getFrRefKeyValue());
		equipment.setFrame(equipmentDTO.getFrame());
		equipment.setFunctionalType("ROUTER");
		equipment.setHardwareRevision(equipmentDTO.gethardwareRevision());
		equipment.setIneffectDate(equipmentDTO.getinServiceDate());
		if(equipmentDTO.getInstalledDate()!=null)
			equipment.setInstalledDate(equipmentDTO.getInstalledDate());
		else
			equipment.setInstalledDate(new Date());
		equipment.setIpv4Address(equipmentDTO.getIpAddress());
		equipment.setIsMultiTidShelf(equipmentDTO.getIsMultiTidShelf());
		equipment.setLastModifiedBy(equipmentDTO.getModifiedUser());
		equipment.setLastModifiedTimeStamp(new Date());
		equipment.setLineUp(equipmentDTO.getLineUp());
		equipment.setLocationClli(site.getClli());
		equipment.setMgmtIpAddress(equipmentDTO.getIpAddress());
		equipment.setNetworkType(equipmentDTO.getNetworkType());
		equipment.setOrderNumber(equipmentDTO.getOrderNumber());
		equipment.setPointCode(equipmentDTO.getPointCode());
		equipment.setScheduledDate(equipmentDTO.getScheduledDate());
		equipment.setSerialNumber(equipmentDTO.getSerialNumber());
		equipment.setShelfType(equipmentDTO.getShelfType());
		equipment.setSiteReferenceId(new BigDecimal(site.getSiteReferenceId()));
		equipment.setSoftwareRevision(equipmentDTO.getsoftwareRevision());
		equipment.setTidLogical(equipmentDTO.getTid_l());
		equipment.setTidPhysical(equipmentDTO.getTargetId());

		equipment.setAssetLife(EquipmentService.validateNotNull(equipmentDTO.getAssetLife()) ? equipmentDTO.getAssetLife().longValue() : null);
		equipment.setCustomerReferenceId(EquipmentService.validateNotNull(equipmentDTO.getCustomerReference()) ? new BigDecimal(equipmentDTO.getCustomerReference()) : null);
		equipment.setDistFromX(EquipmentService.validateNotNull(equipmentDTO.getDistToFront()) ? equipmentDTO.getDistToFront() : null);
		equipment.setDistFromY(EquipmentService.validateNotNull(equipmentDTO.getDistToLeft()) ? equipmentDTO.getDistToLeft() : null);
		equipment.setDistFromZ(EquipmentService.validateNotNull(equipmentDTO.getDistToBase()) ? equipmentDTO.getDistToBase() : null);
		equipment.setEqpDepth(EquipmentService.validateNotNull(equipmentDTO.getdepth()) ? equipmentDTO.getdepth() : null);
		equipment.setEqpHeight(EquipmentService.validateNotNull(equipmentDTO.getheight()) ? equipmentDTO.getheight() : null);
		equipment.setEqpPurchasePrice(EquipmentService.validateNotNull(equipmentDTO.getPurchasePrice()) ? equipmentDTO.getPurchasePrice().toString() : null);
		equipment.setEqpWidth(EquipmentService.validateNotNull(equipmentDTO.getwidth()) ? equipmentDTO.getwidth() : null);
		equipment.setHiLocationReference(EquipmentService.validateNotNull(equipmentDTO.getFloor()) ? equipmentDTO.getFloor() : null);
		equipment.setLogicalShelf(EquipmentService.validateNotNull(equipmentDTO.getlogicalShelf()) ? equipmentDTO.getlogicalShelf() : null);
		equipment.setParentEqpReferenceId(EquipmentService.validateNotNull(equipmentDTO.getparentEqReference()) ? new BigDecimal(equipmentDTO.getparentEqReference()) : null);
		equipment.setParentShelfReferenceId(EquipmentService.validateNotNull(equipmentDTO.getparentShelfReference()) ? new BigDecimal(equipmentDTO.getparentShelfReference()) : null);
		equipment.setPhysicalShelfPosition(EquipmentService.validateNotNull(equipmentDTO.getPhysicalShelf()) ? equipmentDTO.getPhysicalShelf() : null);

		Equipment rackRef = equipmentRepository.save(equipment);
		equipmentService.createEquipmentDomains(rackRef.getEqpReferenceId(), equipmentDTO, httpRequest);
		return resourceMapper.convertToEquipmentDTOV1(rackRef);
	}
	public void updateEquipmentFromParent(EquipmentDTOV1 equipment) 
	{
	    if ("SHELF".equals(equipment.getcontainer())) {
	        
	        if (equipment.getsiteReference() == null || equipment.getsiteReference()<=0) {
	            LOGGER.debug("Looking for CLLI: {} ...", equipment.getClli());
	            List<Site> siteList = siteRepository.findByClli(equipment.getClli().trim());
	            if (siteList.isEmpty()) {
	                LOGGER.error("Unable to find site CLLI "+equipment.getClli());
	                throw new MethodFailureException("Unable to find site CLLI "+equipment.getClli());
	            }
                if (siteList.size()>1) {
                    LOGGER.error("Found too many sites for CLLI "+equipment.getClli());
                    throw new MethodFailureException("Found too many sites for CLLI "+equipment.getClli());
                }
                equipment.setsiteReference(siteList.get(0).getSiteReferenceId());
                LOGGER.debug("equipment set siteReference:{}", equipment.getsiteReference());
	        }
	        
	        
            if (equipment.getparentEqReference() == null || equipment.getparentEqReference() <=0) {
                LOGGER.debug("Looking for rack based on locationId: {}, frame:{}...", equipment.getsiteReference(), equipment.getFrame());
                List<Equipment> eqList = equipmentRepository.findBySiteReferenceIdAndFrameAndDirContainerTypeContainer(new BigDecimal(equipment.getsiteReference()),equipment.getFrame().trim(),"RACK");
                if (eqList.isEmpty()) {
                    LOGGER.error("Unable to find equipment with locationId: {}, frame:{} ",equipment.getsiteReference(),equipment.getFrame());
                    throw new MethodFailureException("Unable to find RACK with locationId "+equipment.getsiteReference()+" and frame "+equipment.getFrame());
                }
                if (eqList.size()>1) {
                    LOGGER.error("Found multiple equipments with locationId:{}, frame:{} ",equipment.getsiteReference(),equipment.getFrame());
                    throw new MethodFailureException("Found multiple RACKs with locationId "+equipment.getsiteReference()+" and frame "+equipment.getFrame());
                }
                equipment.setparentEqReference(new Long(eqList.get(0).getEqpReferenceId()).longValue());
                LOGGER.debug("equipment set parentEqReference:{}", equipment.getparentEqReference());
            }
	    }
	        
	}
}
