package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.javers.core.metamodel.annotation.TypeName;

import com.vz.uiam.inventory.equipment.model.validator.EntityValidator;

/**
 * The persistent class for the EQUIPMENT_SPEC database table.
 * 
 */
@Entity
@Table(name = "EQUIPMENT_SPEC")
@TypeName("EquipmentSpec")
@NamedQuery(name = "EquipmentSpec.findAll", query = "SELECT e FROM EquipmentSpec e")
public class EquipmentSpec implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "EQUIPMENT_SPEC_REF_ID")
	private Long equipmentSpecRefId;

	private String aid;

	private String altitude;

	private String clei;

	private String comments;

	@Column(name = "DEFAULT_LOGICAL_SHELF")
	private String defaultLogicalShelf;

	@Column(name = "DEFAULT_PHYSICAL_SHELF")
	private String defaultPhysicalShelf;

	private String description;

	@Column(name = "DIST_FROM_X")
	private BigDecimal distFromX;

	@Column(name = "DIST_FROM_Y")
	private BigDecimal distFromY;

	@Column(name = "DIST_FROM_Z")
	private BigDecimal distFromZ;

	private String duplex;

	@Column(name = "EQP_DEPTH")
	private BigDecimal eqpDepth;

	@Column(name = "EQP_HEIGHT")
	private BigDecimal eqpHeight;

	@Column(name = "EQP_WIDTH")
	private BigDecimal eqpWidth;

	@Column(name = "EQUIPMENT_VENDOR")
	private String equipmentVendor;

	@Column(name = "FUNCTIONAL_TYPE")
	private String functionalType;

	@Column(name = "FUSE_REQUIREMENTS")
	private String fuseRequirements;

	@Column(name = "LAN_REACH")
	private String lanReach;

	@Column(name = "LAST_MODIFIED_BY")
	private String lastModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_MODIFIED_TIME_STAMP")
	private Date lastModifiedTimeStamp;

	@Column(name = "LOGICAL_SHELF_RANGE")
	private String logicalShelfRange;

	private String manufacturer;

	@Column(name = "MATERIAL_ID")
	private String materialId;

	@Column(name = "MAX_CURRENT_DRAW")
	private String maxCurrentDraw;

	@Column(name = "MAX_HEAT_DISSIPATION")
	private String maxHeatDissipation;

	@Column(name = "MAX_POWER_DRAW")
	private String maxPowerDraw;

	private String model;

	private String name;

	@Column(name = "NUM_EQP_SHELVES")
	private BigDecimal numEqpShelves;

	@Column(name = "NUM_OF_SLOTS")
	private BigDecimal numOfSlots;

	@Column(name = "OPERATING_TEMPERATURE")
	private String operatingTemperature;

	@Column(name = "ORDER_NUM")
	private String orderNum;

	@Column(name = "PARENT_SPEC_ID")
	private BigDecimal parentSpecId;

	@Column(name = "PART_NUM")
	private String partNum;

	@Column(name = "PHYSICAL_SHELF_RANGE")
	private String physicalShelfRange;

	@Column(name = "PURCHASE_PRICE")
	private BigDecimal purchasePrice;

	@Column(name = "SPEC_VERSION")
	private BigDecimal specVersion;

	@Column(name = "VOLTAGE_REQUIREMENT")
	private String voltageRequirement;

	@Column(name = "WAN_REACH")
	private String wanReach;

	private String weight;

	@ManyToOne
	@JoinColumn(name = "CONTAINER")
	private DirContainerType dirContainerType;

	@Column(name = "EQP_TYPE")
	private String dirEqpType;

	@ManyToOne
	@JoinColumn(name = "SHELF_TYPE")
	private DirShelfType dirShelfType;

	@Column(name = "SPEC_STATUS")
	private String dirSpecStatus;

	@OneToMany(mappedBy = "equipmentSpec")
	private List<SlotSpec> slotSpecs;
	
	@Column(name = "UT_INDICATOR")
	private String utIndicator;

	public EquipmentSpec() {
	}
	
	public Long getEquipmentSpecRefId() {
		return this.equipmentSpecRefId;
	}

	public void setEquipmentSpecRefId(Long equipmentSpecRefId) {
		this.equipmentSpecRefId = equipmentSpecRefId;
	}

	public String getAid() {
		return this.aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public String getAltitude() {
		return this.altitude;
	}

	public void setAltitude(String altitude) {
		this.altitude = altitude;
	}

	public String getClei() {
		return this.clei;
	}

	public void setClei(String clei) {
		this.clei = clei;
	}

	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getDefaultLogicalShelf() {
		return this.defaultLogicalShelf;
	}

	public void setDefaultLogicalShelf(String defaultLogicalShelf) {
		this.defaultLogicalShelf = defaultLogicalShelf;
	}

	public String getDefaultPhysicalShelf() {
		return this.defaultPhysicalShelf;
	}

	public void setDefaultPhysicalShelf(String defaultPhysicalShelf) {
		this.defaultPhysicalShelf = defaultPhysicalShelf;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getDistFromX() {
		return this.distFromX;
	}

	public void setDistFromX(BigDecimal distFromX) {
		this.distFromX = distFromX;
	}

	public BigDecimal getDistFromY() {
		return this.distFromY;
	}

	public void setDistFromY(BigDecimal distFromY) {
		this.distFromY = distFromY;
	}

	public BigDecimal getDistFromZ() {
		return this.distFromZ;
	}

	public void setDistFromZ(BigDecimal distFromZ) {
		this.distFromZ = distFromZ;
	}

	public String getDuplex() {
		return this.duplex;
	}

	public void setDuplex(String duplex) {
		this.duplex = duplex;
	}

	public BigDecimal getEqpDepth() {
		return this.eqpDepth;
	}

	public void setEqpDepth(BigDecimal eqpDepth) {
		this.eqpDepth = eqpDepth;
	}

	public BigDecimal getEqpHeight() {
		return this.eqpHeight;
	}

	public void setEqpHeight(BigDecimal eqpHeight) {
		this.eqpHeight = eqpHeight;
	}

	public BigDecimal getEqpWidth() {
		return this.eqpWidth;
	}

	public void setEqpWidth(BigDecimal eqpWidth) {
		this.eqpWidth = eqpWidth;
	}

	public String getEquipmentVendor() {
		return this.equipmentVendor;
	}

	public void setEquipmentVendor(String equipmentVendor) {
		this.equipmentVendor = equipmentVendor;
	}

	public String getFunctionalType() {
		return this.functionalType;
	}

	public void setFunctionalType(String functionalType) {
		this.functionalType = functionalType;
	}

	public String getFuseRequirements() {
		return this.fuseRequirements;
	}

	public void setFuseRequirements(String fuseRequirements) {
		this.fuseRequirements = fuseRequirements;
	}

	public String getLanReach() {
		return this.lanReach;
	}

	public void setLanReach(String lanReach) {
		this.lanReach = lanReach;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifiedTimeStamp() {
		return this.lastModifiedTimeStamp;
	}

	public void setLastModifiedTimeStamp(Date lastModifiedTimeStamp) {
		this.lastModifiedTimeStamp = lastModifiedTimeStamp;
	}

	public String getLogicalShelfRange() {
		return this.logicalShelfRange;
	}

	public void setLogicalShelfRange(String logicalShelfRange) {
		this.logicalShelfRange = logicalShelfRange;
	}

	public String getManufacturer() {
		return this.manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getMaterialId() {
		return this.materialId;
	}

	public void setMaterialId(String materialId) {
		this.materialId = materialId;
	}

	public String getMaxCurrentDraw() {
		return this.maxCurrentDraw;
	}

	public void setMaxCurrentDraw(String maxCurrentDraw) {
		this.maxCurrentDraw = maxCurrentDraw;
	}

	public String getMaxHeatDissipation() {
		return this.maxHeatDissipation;
	}

	public void setMaxHeatDissipation(String maxHeatDissipation) {
		this.maxHeatDissipation = maxHeatDissipation;
	}

	public String getMaxPowerDraw() {
		return this.maxPowerDraw;
	}

	public void setMaxPowerDraw(String maxPowerDraw) {
		this.maxPowerDraw = maxPowerDraw;
	}

	public String getModel() {
		return this.model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigDecimal getNumEqpShelves() {
		return this.numEqpShelves;
	}

	public void setNumEqpShelves(BigDecimal numEqpShelves) {
		this.numEqpShelves = numEqpShelves;
	}

	public BigDecimal getNumOfSlots() {
		return this.numOfSlots;
	}

	public void setNumOfSlots(BigDecimal numOfSlots) {
		this.numOfSlots = numOfSlots;
	}

	public String getOperatingTemperature() {
		return this.operatingTemperature;
	}

	public void setOperatingTemperature(String operatingTemperature) {
		this.operatingTemperature = operatingTemperature;
	}

	public String getOrderNum() {
		return this.orderNum;
	}

	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}

	public BigDecimal getParentSpecId() {
		return this.parentSpecId;
	}

	public void setParentSpecId(BigDecimal parentSpecId) {
		this.parentSpecId = parentSpecId;
	}

	public String getPartNum() {
		return this.partNum;
	}

	public void setPartNum(String partNum) {
		this.partNum = partNum;
	}

	public String getPhysicalShelfRange() {
		return this.physicalShelfRange;
	}

	public void setPhysicalShelfRange(String physicalShelfRange) {
		this.physicalShelfRange = physicalShelfRange;
	}

	public BigDecimal getPurchasePrice() {
		return this.purchasePrice;
	}

	public void setPurchasePrice(BigDecimal purchasePrice) {
		this.purchasePrice = purchasePrice;
	}

	public BigDecimal getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(BigDecimal specVersion) {
		this.specVersion = specVersion;
	}

	public String getVoltageRequirement() {
		return this.voltageRequirement;
	}

	public void setVoltageRequirement(String voltageRequirement) {
		this.voltageRequirement = voltageRequirement;
	}

	public String getWanReach() {
		return this.wanReach;
	}

	public void setWanReach(String wanReach) {
		this.wanReach = wanReach;
	}

	public String getWeight() {
		return this.weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public DirContainerType getDirContainerType() {
		return this.dirContainerType;
	}

	public void setDirContainerType(DirContainerType dirContainerType) {
		this.dirContainerType = dirContainerType;
	}

	public String getDirEqpType() {
		return EntityValidator.validateType(dirEqpType, this.getClass());	
	}

	public void setDirEqpType(String dirEqpType) {
		this.dirEqpType = dirEqpType;
	}

	public DirShelfType getDirShelfType() {
		return this.dirShelfType;
	}

	public void setDirShelfType(DirShelfType dirShelfType) {
		this.dirShelfType = dirShelfType;
	}

	public String getDirSpecStatus() {
		return EntityValidator.validateStatus(dirSpecStatus, this.getClass());
	}

	public void setDirSpecStatus(String dirSpecStatus) {
		this.dirSpecStatus = dirSpecStatus;
	}

	public List<SlotSpec> getSlotSpecs() {
		return this.slotSpecs;
	}

	public void setSlotSpecs(List<SlotSpec> slotSpecs) {
		this.slotSpecs = slotSpecs;
	}

	public String getUtIndicator() {
		return utIndicator;
	}

	public void setUtIndicator(String utIndicator) {
		this.utIndicator = utIndicator;
	}

	public SlotSpec addSlotSpec(SlotSpec slotSpec) {
		getSlotSpecs().add(slotSpec);
		slotSpec.setEquipmentSpec(this);

		return slotSpec;
	}

	public SlotSpec removeSlotSpec(SlotSpec slotSpec) {
		getSlotSpecs().remove(slotSpec);
		slotSpec.setEquipmentSpec(null);

		return slotSpec;
	}

}