package com.vz.uiam.inventory.equipment.service;

import java.util.HashMap;

import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.inventory.equipment.model.EntityEventData;

/**
 * KafkaEventPublisher is designed to publish inventory entity events to the
 * relevant kafka-topics for the subscribers.
 * 
 * @author DIXITSH
 *
 */
@Component
public class KafkaEventPublisher {

	@Value("${kafka.bootstrap.servers}")
	private String bootstrapServers;

	@Value("${kafka.acks}")
	private String acksConfiguration;

	@Value("${kafka.retries}")
	private Integer retries;

	@Value("${kafka.linger.ms}")
	private Integer lingerConfiguration;

	@Value("${kafka.batch.size}")
	private Integer batchSize;

	@Value("${kafka.buffer.memory}")
	private Long bufferMemory;

	@Value("${kafka.max.in.flight.requests.per.connection}")
	private Integer maxInFlightRequests;

	@Value("${kafka.enable.auto.commit}")
	private boolean autoCommit;

	@Value("${kafka.rack.event.topic}")
	private String kafkaRackTopic;

	@Value("${kafka.shelf.event.topic}")
	private String kafkaShelfTopic;
	
	@Value("${kafka.virtual.shelf.event.topic}")
	private String kafkaVirtualShelfTopic;

	@Value("${kafka.enableNotification}")
	private boolean enableKafkaNotifications;

	private Producer<String, String> kafkaProducer;

	@Autowired
	private ObjectMapper objectMapper;

	private static final Logger LOGGER = LoggerFactory.getLogger(KafkaEventPublisher.class);

	/**
	 * initKafkaProducer method is defined to configure the apache-kafka
	 * producer using the configuration specified in the yml.
	 */
	@PostConstruct
	public void initKakfaProducer() {
		if (enableKafkaNotifications) {
			Map<String, Object> producerConfiguration = new HashMap<String, Object>();
			producerConfiguration.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
			producerConfiguration.put(ProducerConfig.RETRIES_CONFIG, retries);
			producerConfiguration.put(ProducerConfig.BATCH_SIZE_CONFIG, batchSize);
			producerConfiguration.put(ProducerConfig.LINGER_MS_CONFIG, lingerConfiguration);
			producerConfiguration.put(ProducerConfig.BUFFER_MEMORY_CONFIG, bufferMemory);
			producerConfiguration.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
			producerConfiguration.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
			producerConfiguration.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, maxInFlightRequests);
			kafkaProducer = new KafkaProducer<>(producerConfiguration);
		}
	}

	/** 
	 * PublishData function is being used to push the message to the kafka topic	 
	 * @param eventData -The message payload to be delivered
	 */
	public void publishData(EntityEventData eventData) {

		String entityTopic = "";
		switch (eventData.getEntityType()) {
		case "SHELF": 
			entityTopic = kafkaShelfTopic;
			break;
		case "RACK": 
			entityTopic = kafkaRackTopic;
			break;
		case "VIRTUAL_SHELF": 
			entityTopic = kafkaVirtualShelfTopic;
			break;
		default:
			LOGGER.info("INVALID ENTITY TYPE SPECIFIED");
			entityTopic = "";
			break;
		}
		publishData(eventData, entityTopic);

	}

	/**
	 * publishData function is being used to push the message to the kafka topic
	 * 
	 * @param eventData
	 *            - The message payload that is to be sent
	 * @param entityTopic
	 *            - The entity topic to which the message is to be delivered
	 */
	public void publishData(EntityEventData eventData, String entityTopic) {
		if (!enableKafkaNotifications)
			return;
		LOGGER.info("PUBLISHING TO KAKFA-TOPIC: {}\n DATA:{}", entityTopic, eventData);

		ProducerRecord<String, String> dataToPublish = new ProducerRecord<String, String>(entityTopic,
				objectMapper.valueToTree(eventData).toString());
		try {
			kafkaProducer.send(dataToPublish);
		} catch (Exception ex) {
			LOGGER.error("ERROR PULBLISHING EVENT DATA TO KAFKA: {}", ex);
		}

	}

}
