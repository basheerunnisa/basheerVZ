package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.javers.core.metamodel.annotation.TypeName;

/**
 * <p>
 * This Persistent class is used for the DB table -> EQUIPMENT_ATTRIBUTES
 * </p>
 * 
 * @author Asif Billa
 * @date 13-June-2017
 *
 */
@Entity
@Table(name = "EQUIPMENT_ATTRIBUTES")
@TypeName("EquipmentAttributes")
@NamedQuery(name = "EquipmentAttributes.findAll", query = "SELECT e FROM EquipmentAttributes e")
public class EquipmentAttributes implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "EQP_ATTRIBUTES_ID")
	private Long eqpAttributesId;

	@Column(name = "EQP_REFERENCE_ID")
	private Long eqpReferenceId;

	@Column(name = "EQP_DESCPT_ID")
	private Integer eqpDescptId;

	@Column(name = "EQP_GROUP_NAME")
	private String eqpGroupName;

	@Column(name = "EQP_NAME")
	private String eqpName;

	@Column(name = "EQP_VALUE")
	private String eqpValue;


	/**
	 * @return the eqpAttributesId
	 */
	public Long getEqpAttributesId() {
		return eqpAttributesId;
	}


	/**
	 * @param eqpAttributesId the eqpAttributesId to set
	 */
	public void setEqpAttributesId(Long eqpAttributesId) {
		this.eqpAttributesId = eqpAttributesId;
	}


	/**
	 * @return the eqpReferenceId
	 */
	public Long getEqpReferenceId() {
		return eqpReferenceId;
	}


	/**
	 * @param eqpReferenceId the eqpReferenceId to set
	 */
	public void setEqpReferenceId(Long eqpReferenceId) {
		this.eqpReferenceId = eqpReferenceId;
	}


	/**
	 * @return the eqpDescptId
	 */
	public Integer getEqpDescptId() {
		return eqpDescptId;
	}


	/**
	 * @param eqpDescptId the eqpDescptId to set
	 */
	public void setEqpDescptId(Integer eqpDescptId) {
		this.eqpDescptId = eqpDescptId;
	}


	/**
	 * @return the eqpGroupName
	 */
	public String getEqpGroupName() {
		return eqpGroupName;
	}


	/**
	 * @param eqpGroupName the eqpGroupName to set
	 */
	public void setEqpGroupName(String eqpGroupName) {
		this.eqpGroupName = eqpGroupName;
	}


	/**
	 * @return the eqpName
	 */
	public String getEqpName() {
		return eqpName;
	}


	/**
	 * @param eqpName the eqpName to set
	 */
	public void setEqpName(String eqpName) {
		this.eqpName = eqpName;
	}


	/**
	 * @return the eqpValue
	 */
	public String getEqpValue() {
		return eqpValue;
	}


	/**
	 * @param eqpValue the eqpValue to set
	 */
	public void setEqpValue(String eqpValue) {
		this.eqpValue = eqpValue;
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EquipmentAttributes [eqpAttributesId=");
		builder.append(eqpAttributesId);
		builder.append(", eqpReferenceId=");
		builder.append(eqpReferenceId);
		builder.append(", eqpDescptId=");
		builder.append(eqpDescptId);
		builder.append(", eqpGroupName=");
		builder.append(eqpGroupName);
		builder.append(", eqpName=");
		builder.append(eqpName);
		builder.append(", eqpValue=");
		builder.append(eqpValue);
		builder.append("]");
		return builder.toString();
	}

}