package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.javers.core.metamodel.annotation.TypeName;

/**
 * The persistent class for the EQUIPMENT database table.
 * 
 */
@Entity
@Table(name = "VLAN")
@TypeName("VLAN")
public class Vlan implements Serializable {

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "VLAN_ID")
	private Long vlanId;

	private static final long serialVersionUID = 1L;
	
	@Column(name = "STATUS")
	private String status;

	@Column(name = "FIRST_VLAN")
	private Long firstVlan;
	
	@Column(name = "SECOND_VLAN")
	private Long secondVlan;
	
	@Column(name = "VENDOR")
	private String vendor;
	
	@Column(name = "MARKET")
	private String market;
	
	
	public Long getVlanId() {
		return vlanId;
	}

	public void setVlanId(Long vlanId) {
		this.vlanId = vlanId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public Long getFirstVlan() {
		return firstVlan;
	}

	public void setFirstVlan(Long firstVlan) {
		this.firstVlan = firstVlan;
	}

	public Long getSecondVlan() {
		return secondVlan;
	}

	public void setSecondVlan(Long secondVlan) {
		this.secondVlan = secondVlan;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	
}
