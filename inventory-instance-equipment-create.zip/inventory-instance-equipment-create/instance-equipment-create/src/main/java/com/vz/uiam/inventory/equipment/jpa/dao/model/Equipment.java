package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.javers.core.metamodel.annotation.TypeName;

import com.vz.uiam.inventory.equipment.model.validator.EntityValidator;

/**
 * The persistent class for the EQUIPMENT database table.
 * 
 */
@Entity
@Table(name = "EQUIPMENT")
@TypeName("Equipment")
public class Equipment implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "EQP_REFERENCE_ID")
	private Long eqpReferenceId;

	private String aid;

	@Column(name = "ALTERNATE_NAME")
	private String alternateName;

	@Column(name = "ASSET_LIFE")
	private Long assetLife;

	@Column(name = "BAR_CODE")
	private String barCode;

	@Column(name = "BATCH_NUMBER")
	private String batchNumber;

	private String comments;

	@Column(name = "CUSTOMER_REFERENCE_ID")
	private BigDecimal customerReferenceId;

	@Temporal(TemporalType.DATE)
	@Column(name = "DECOMMISION_DATE")
	private Date decommisionDate;

	@Column(name = "DIST_FROM_X")
	private BigDecimal distFromX;

	@Column(name = "DIST_FROM_Y")
	private BigDecimal distFromY;

	@Column(name = "DIST_FROM_Z")
	private BigDecimal distFromZ;

	@Temporal(TemporalType.DATE)
	@Column(name = "DUE_DATE")
	private Date dueDate;

	private String ems;

	@Column(name = "EQP_CLEI")
	private String eqpClei;

	@Column(name = "EQP_DEPTH")
	private BigDecimal eqpDepth;

	@Column(name = "EQP_HEIGHT")
	private BigDecimal eqpHeight;

	@Column(name = "EQP_MANUFACTURER")
	private String eqpManufacturer;

	@Column(name = "EQP_MODEL")
	private String eqpModel;

	@Column(name = "EQP_NAME")
	private String eqpName;

	@Temporal(TemporalType.DATE)
	@Column(name = "EQP_PURCHASE_DATE")
	private Date eqpPurchaseDate;

	@Column(name = "EQP_PURCHASE_PRICE")
	private String eqpPurchasePrice;

	@Column(name = "EQP_SOURCE")
	private String eqpSource;

	@Column(name = "EQP_VENDOR")
	private String eqpVendor;

	@Column(name = "EQP_WIDTH")
	private BigDecimal eqpWidth;

	@Column(name = "EQUIPMENT_SPEC_NAME")
	private String equipmentSpecName;

	@Column(name = "EQUIPMENT_SPEC_REF_ID")
	private BigDecimal equipmentSpecRefId;

	@Column(name = "FIELD_ID")
	private String fieldId;

	@Column(name = "FR_REF_KEY_NAME")
	private String frRefKeyName;

	@Column(name = "FR_REF_KEY_VALUE")
	private String frRefKeyValue;

	private String frame;

	@Column(name = "FUNCTIONAL_TYPE")
	private String functionalType;

	@Column(name = "HARDWARE_REVISION")
	private String hardwareRevision;

	@Column(name = "HI_LOCATION_REFERENCE")
	private String hiLocationReference;

	@Column(name = "HI_LOCATION_TYPE")
	private BigDecimal hiLocationType;

	@Temporal(TemporalType.DATE)
	@Column(name = "INEFFECT_DATE")
	private Date ineffectDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "INSTALLED_DATE")
	private Date installedDate;

	@Column(name = "IPV4_ADDRESS")
	private String ipv4Address;

	@Column(name = "IPV6_ADDRESS")
	private String ipv6Address;

	@Column(name = "IS_MULTI_TID_SHELF")
	private String isMultiTidShelf;

	@Column(name = "LAST_MODIFIED_BY")
	private String lastModifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_MODIFIED_TIME_STAMP")
	private Date lastModifiedTimeStamp;

	@Column(name = "LINE_UP")
	private String lineUp;

	@Column(name = "LOCATION_CLLI")
	private String locationClli;

	@Column(name = "LOGICAL_SHELF")
	private String logicalShelf;

	@Column(name = "LOW_LOCATION_REFERENCE")
	private String lowLocationReference;

	@Column(name = "LOW_LOCATION_TYPE")
	private BigDecimal lowLocationType;

	@Column(name = "MATERIAL_ID")
	private String materialId;

	@Column(name = "MGMT_IP_ADDRESS")
	private String mgmtIpAddress;

	@Column(name = "NO_OF_SLOTS")
	private BigDecimal noOfSlots;

	@Temporal(TemporalType.DATE)
	@Column(name = "ORDER_DATE")
	private Date orderDate;

	@Column(name = "ORDER_NUMBER")
	private String orderNumber;

	@Column(name = "PARENT_EQP_REFERENCE_ID")
	private BigDecimal parentEqpReferenceId;

	@Column(name = "PARENT_EQP_TYPE")
	private String parentEqpType;

	@Column(name = "PARENT_SHELF_REFERENCE_ID")
	private BigDecimal parentShelfReferenceId;

	@Column(name = "PART_NUM")
	private String partNum;

	@Column(name = "PHYSICAL_SHELF_POSITION")
	private String physicalShelfPosition;

	@Column(name = "POINT_CODE")
	private String pointCode;

	@Temporal(TemporalType.DATE)
	@Column(name = "SCHEDULED_DATE")
	private Date scheduledDate;

	@Column(name = "SERIAL_NUMBER")
	private String serialNumber;

	@Column(name = "SHELF_TYPE")
	private String shelfType;

	@Column(name = "SITE_REFERENCE_ID")
	private BigDecimal siteReferenceId;

	@Column(name = "SOFTWARE_REVISION")
	private String softwareRevision;

	@Column(name = "TID_LOGICAL")
	private String tidLogical;

	@Column(name = "TID_PHYSICAL")
	private String tidPhysical;

	@Column(name = "WIRE_CENTER")
	private String wireCenter;

	@ManyToOne
	@JoinColumn(name = "CONTAINER")
	private DirContainerType dirContainerType;

	@Column(name = "EQP_TYPE")
	private String dirEqpType;

	@Column(name = "INV_STATUS")
	private String dirInvStatus;

	@OneToMany(mappedBy = "equipment", fetch = FetchType.EAGER)
	private List<Slot> slots;

	@Column(name = "ASSET_OWNER")
	private String assetOwner;

	@Column(name = "SUB_LOCATION")
	private String subLocation;

	@Column(name = "CUSTOMER_NAME")
	private String customerName;

	@Column(name = "NETWORK_TYPE")
	private String networkType;

	@Column(name = "NETWORK_DOMAIN")
	private String networkDomain;

	@Column(name = "PROJECT_REFERENCE_ID")
	private String projectReferenceId;

	@Column(name = "INSTANCE_TYPE")
	private String instanceType;

	@Column(name = "PHYSICAL_EQUIPMENT_REFERENCE_ID")
	private Long physicalEquipmentReferenceId;

	@Column(name = "MGMT_TELNET_PORT")
	private String mgmtTelnetPort;

	@Column(name = "MGMT_SSH_PORT")
	private Integer mgmtSSHPort;

	@Column(name = "HOST_NAME")
	private String hostName;
	
	@Column(name = "UT_INDICATOR")
	private String utIndicator;
	
	@Column(name = "MATED_PAIR")
	private String matedPair;
	
	public String getMatedPair() {
		return matedPair;
	}

	public void setMatedPair(String matedPair) {
		this.matedPair = matedPair;
	}

	public Equipment() {
	}

	public String getNetworkType() {
		return networkType;
	}

	public void setNetworkType(String networkType) {
		this.networkType = networkType;
	}

	public Long getEqpReferenceId() {
		return this.eqpReferenceId;
	}

	public void setEqpReferenceId(Long eqpReferenceId) {
		this.eqpReferenceId = eqpReferenceId;
	}

	public String getAid() {
		return this.aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public Long getAssetLife() {
		return this.assetLife;
	}

	public void setAssetLife(Long assetLife) {
		this.assetLife = assetLife;
	}

	public String getBarCode() {
		return this.barCode;
	}

	public void setBarCode(String barCode) {
		this.barCode = barCode;
	}

	public String getBatchNumber() {
		return this.batchNumber;
	}

	public void setBatchNumber(String batchNumber) {
		this.batchNumber = batchNumber;
	}

	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public BigDecimal getCustomerReferenceId() {
		return this.customerReferenceId;
	}

	public void setCustomerReferenceId(BigDecimal customerReferenceId) {
		this.customerReferenceId = customerReferenceId;
	}

	public Date getDecommisionDate() {
		return this.decommisionDate;
	}

	public void setDecommisionDate(Date decommisionDate) {
		this.decommisionDate = decommisionDate;
	}

	public BigDecimal getDistFromX() {
		return this.distFromX;
	}

	public void setDistFromX(BigDecimal distFromX) {
		this.distFromX = distFromX;
	}

	public BigDecimal getDistFromY() {
		return this.distFromY;
	}

	public void setDistFromY(BigDecimal distFromY) {
		this.distFromY = distFromY;
	}

	public BigDecimal getDistFromZ() {
		return this.distFromZ;
	}

	public void setDistFromZ(BigDecimal distFromZ) {
		this.distFromZ = distFromZ;
	}

	public Date getDueDate() {
		return this.dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getEms() {
		return this.ems;
	}

	public void setEms(String ems) {
		this.ems = ems;
	}

	public String getEqpClei() {
		return this.eqpClei;
	}

	public void setEqpClei(String eqpClei) {
		this.eqpClei = eqpClei;
	}

	public BigDecimal getEqpDepth() {
		return this.eqpDepth;
	}

	public void setEqpDepth(BigDecimal eqpDepth) {
		this.eqpDepth = eqpDepth;
	}

	public BigDecimal getEqpHeight() {
		return this.eqpHeight;
	}

	public void setEqpHeight(BigDecimal eqpHeight) {
		this.eqpHeight = eqpHeight;
	}

	public String getEqpManufacturer() {
		return this.eqpManufacturer;
	}

	public void setEqpManufacturer(String eqpManufacturer) {
		this.eqpManufacturer = eqpManufacturer;
	}

	public String getEqpModel() {
		return this.eqpModel;
	}

	public void setEqpModel(String eqpModel) {
		this.eqpModel = eqpModel;
	}

	public String getEqpName() {
		return this.eqpName;
	}

	public void setEqpName(String eqpName) {
		this.eqpName = eqpName;
	}

	public Date getEqpPurchaseDate() {
		return this.eqpPurchaseDate;
	}

	public void setEqpPurchaseDate(Date eqpPurchaseDate) {
		this.eqpPurchaseDate = eqpPurchaseDate;
	}

	public String getEqpPurchasePrice() {
		return this.eqpPurchasePrice;
	}

	public void setEqpPurchasePrice(String eqpPurchasePrice) {
		this.eqpPurchasePrice = eqpPurchasePrice;
	}

	public String getEqpSource() {
		return this.eqpSource;
	}

	public void setEqpSource(String eqpSource) {
		this.eqpSource = eqpSource;
	}

	public String getEqpVendor() {
		return this.eqpVendor;
	}

	public void setEqpVendor(String eqpVendor) {
		this.eqpVendor = eqpVendor;
	}

	public BigDecimal getEqpWidth() {
		return this.eqpWidth;
	}

	public void setEqpWidth(BigDecimal eqpWidth) {
		this.eqpWidth = eqpWidth;
	}

	public String getEquipmentSpecName() {
		return this.equipmentSpecName;
	}

	public void setEquipmentSpecName(String equipmentSpecName) {
		this.equipmentSpecName = equipmentSpecName;
	}

	public BigDecimal getEquipmentSpecRefId() {
		return this.equipmentSpecRefId;
	}

	public void setEquipmentSpecRefId(BigDecimal equipmentSpecRefId) {
		this.equipmentSpecRefId = equipmentSpecRefId;
	}

	public String getFieldId() {
		return this.fieldId;
	}

	public void setFieldId(String fieldId) {
		this.fieldId = fieldId;
	}

	public String getFrRefKeyName() {
		return this.frRefKeyName;
	}

	public void setFrRefKeyName(String frRefKeyName) {
		this.frRefKeyName = frRefKeyName;
	}

	public String getFrRefKeyValue() {
		return this.frRefKeyValue;
	}

	public void setFrRefKeyValue(String frRefKeyValue) {
		this.frRefKeyValue = frRefKeyValue;
	}

	public String getFrame() {
		return this.frame;
	}

	public void setFrame(String frame) {
		this.frame = frame;
	}

	public String getFunctionalType() {
		return this.functionalType;
	}

	public void setFunctionalType(String functionalType) {
		this.functionalType = functionalType;
	}

	public String getHardwareRevision() {
		return this.hardwareRevision;
	}

	public void setHardwareRevision(String hardwareRevision) {
		this.hardwareRevision = hardwareRevision;
	}

	public String getHiLocationReference() {
		return this.hiLocationReference;
	}

	public void setHiLocationReference(String hiLocationReference) {
		this.hiLocationReference = hiLocationReference;
	}

	public BigDecimal getHiLocationType() {
		return this.hiLocationType;
	}

	public void setHiLocationType(BigDecimal hiLocationType) {
		this.hiLocationType = hiLocationType;
	}

	public Date getIneffectDate() {
		return this.ineffectDate;
	}

	public void setIneffectDate(Date ineffectDate) {
		this.ineffectDate = ineffectDate;
	}

	public Date getInstalledDate() {
		return this.installedDate;
	}

	public void setInstalledDate(Date installedDate) {
		this.installedDate = installedDate;
	}

	public String getIpv4Address() {
		return this.ipv4Address;
	}

	public void setIpv4Address(String ipv4Address) {
		this.ipv4Address = ipv4Address;
	}

	public String getIpv6Address() {
		return this.ipv6Address;
	}

	public void setIpv6Address(String ipv6Address) {
		this.ipv6Address = ipv6Address;
	}

	public String getIsMultiTidShelf() {
		return this.isMultiTidShelf;
	}

	public void setIsMultiTidShelf(String isMultiTidShelf) {
		this.isMultiTidShelf = isMultiTidShelf;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifiedTimeStamp() {
		return this.lastModifiedTimeStamp;
	}

	public void setLastModifiedTimeStamp(Date lastModifiedTimeStamp) {
		this.lastModifiedTimeStamp = lastModifiedTimeStamp;
	}

	public String getLineUp() {
		return this.lineUp;
	}

	public void setLineUp(String lineUp) {
		this.lineUp = lineUp;
	}

	public String getLocationClli() {
		return this.locationClli;
	}

	public void setLocationClli(String locationClli) {
		this.locationClli = locationClli;
	}

	public String getLogicalShelf() {
		return this.logicalShelf;
	}

	public void setLogicalShelf(String logicalShelf) {
		this.logicalShelf = logicalShelf;
	}

	public String getLowLocationReference() {
		return this.lowLocationReference;
	}

	public void setLowLocationReference(String lowLocationReference) {
		this.lowLocationReference = lowLocationReference;
	}

	public BigDecimal getLowLocationType() {
		return this.lowLocationType;
	}

	public void setLowLocationType(BigDecimal lowLocationType) {
		this.lowLocationType = lowLocationType;
	}

	public String getMaterialId() {
		return this.materialId;
	}

	public void setMaterialId(String materialId) {
		this.materialId = materialId;
	}

	public String getMgmtIpAddress() {
		return this.mgmtIpAddress;
	}

	public void setMgmtIpAddress(String mgmtIpAddress) {
		this.mgmtIpAddress = mgmtIpAddress;
	}

	public BigDecimal getNoOfSlots() {
		return this.noOfSlots;
	}

	public void setNoOfSlots(BigDecimal noOfSlots) {
		this.noOfSlots = noOfSlots;
	}

	public Date getOrderDate() {
		return this.orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getOrderNumber() {
		return this.orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public BigDecimal getParentEqpReferenceId() {
		return this.parentEqpReferenceId;
	}

	public void setParentEqpReferenceId(BigDecimal parentEqpReferenceId) {
		this.parentEqpReferenceId = parentEqpReferenceId;
	}

	public String getParentEqpType() {
		return this.parentEqpType;
	}

	public void setParentEqpType(String parentEqpType) {
		this.parentEqpType = parentEqpType;
	}

	public BigDecimal getParentShelfReferenceId() {
		return this.parentShelfReferenceId;
	}

	public void setParentShelfReferenceId(BigDecimal parentShelfReferenceId) {
		this.parentShelfReferenceId = parentShelfReferenceId;
	}

	public String getPartNum() {
		return this.partNum;
	}

	public void setPartNum(String partNum) {
		this.partNum = partNum;
	}

	public String getPhysicalShelfPosition() {
		return this.physicalShelfPosition;
	}

	public void setPhysicalShelfPosition(String physicalShelfPosition) {
		this.physicalShelfPosition = physicalShelfPosition;
	}

	public String getPointCode() {
		return this.pointCode;
	}

	public void setPointCode(String pointCode) {
		this.pointCode = pointCode;
	}

	public Date getScheduledDate() {
		return this.scheduledDate;
	}

	public void setScheduledDate(Date scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getShelfType() {
		return this.shelfType;
	}

	public void setShelfType(String shelfType) {
		this.shelfType = shelfType;
	}

	public BigDecimal getSiteReferenceId() {
		return this.siteReferenceId;
	}

	public void setSiteReferenceId(BigDecimal siteReferenceId) {
		this.siteReferenceId = siteReferenceId;
	}

	public String getSoftwareRevision() {
		return this.softwareRevision;
	}

	public void setSoftwareRevision(String softwareRevision) {
		this.softwareRevision = softwareRevision;
	}

	public String getTidLogical() {
		return this.tidLogical;
	}

	public void setTidLogical(String tidLogical) {
		this.tidLogical = tidLogical;
	}

	public String getTidPhysical() {
		return this.tidPhysical;
	}

	public void setTidPhysical(String tidPhysical) {
		this.tidPhysical = tidPhysical;
	}

	public String getWireCenter() {
		return this.wireCenter;
	}

	public void setWireCenter(String wireCenter) {
		this.wireCenter = wireCenter;
	}

	public DirContainerType getDirContainerType() {
		return this.dirContainerType;
	}

	public void setDirContainerType(DirContainerType dirContainerType) {
		this.dirContainerType = dirContainerType;
	}

	public String getDirEqpType() {
		return EntityValidator.validateType(this.dirEqpType, this.getClass());	
	}

	public void setDirEqpType(String dirEqpType) {
		this.dirEqpType = dirEqpType;
	}

	public String getDirInvStatus() {
		return EntityValidator.validateStatus(dirInvStatus, this.getClass());
	}

	public void setDirInvStatus(String dirInvStatus) {
		this.dirInvStatus = dirInvStatus;
	}

	public List<Slot> getSlots() {
		return this.slots;
	}

	public void setSlots(List<Slot> slots) {
		this.slots = slots;
	}

	public Slot addSlot(Slot slot) {
		getSlots().add(slot);
		slot.setEquipment(this);
		slot.setEqpReferenceId(this.getEqpReferenceId());

		return slot;
	}

	public Slot removeSlot(Slot slot) {
		getSlots().remove(slot);
		slot.setEquipment(null);
		slot.setEqpReferenceId(null);

		return slot;
	}

	public String getAssetOwner() {
		return assetOwner;
	}

	public void setAssetOwner(String assetOwner) {
		this.assetOwner = assetOwner;
	}

	public String getSubLocation() {
		return subLocation;
	}

	public void setSubLocation(String subLocation) {
		this.subLocation = subLocation;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getNetworkDomain() {
		return networkDomain;
	}

	public void setNetworkDomain(String networkDomain) {
		this.networkDomain = networkDomain;
	}

	public String getProjectReferenceId() {
		return projectReferenceId;
	}

	public void setProjectReferenceId(String projectReferenceId) {
		this.projectReferenceId = projectReferenceId;
	}

	public String getInstanceType() {
		return instanceType;
	}

	public void setInstanceType(String instanceType) {
		this.instanceType = instanceType;
	}

	public Long getPhysicalEquipmentReferenceId() {
		return physicalEquipmentReferenceId;
	}

	public void setPhysicalEquipmentReferenceId(Long physicalEquipmentReferenceId) {
		this.physicalEquipmentReferenceId = physicalEquipmentReferenceId;
	}

	public String getMgmtTelnetPort() {
		return mgmtTelnetPort;
	}

	public void setMgmtTelnetPort(String mgmtTelnetPort) {
		this.mgmtTelnetPort = mgmtTelnetPort;
	}

	public Integer getMgmtSSHPort() {
		return mgmtSSHPort;
	}

	public void setMgmtSSHPort(Integer mgmtSSHPort) {
		this.mgmtSSHPort = mgmtSSHPort;
	}
	
	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getUtIndicator() {
		return utIndicator;
	}

	public void setUtIndicator(String utIndicator) {
		this.utIndicator = utIndicator;
	}

	@Override
	public String toString() {
		return "Equipment [eqpReferenceId=" + eqpReferenceId + ", aid=" + aid + ", alternateName=" + alternateName
				+ ", assetLife=" + assetLife + ", barCode=" + barCode + ", batchNumber=" + batchNumber + ", comments="
				+ comments + ", customerReferenceId=" + customerReferenceId + ", decommisionDate=" + decommisionDate
				+ ", distFromX=" + distFromX + ", distFromY=" + distFromY + ", distFromZ=" + distFromZ + ", dueDate="
				+ dueDate + ", ems=" + ems + ", eqpClei=" + eqpClei + ", eqpDepth=" + eqpDepth + ", eqpHeight="
				+ eqpHeight + ", eqpManufacturer=" + eqpManufacturer + ", eqpModel=" + eqpModel + ", eqpName=" + eqpName
				+ ", eqpPurchaseDate=" + eqpPurchaseDate + ", eqpPurchasePrice=" + eqpPurchasePrice + ", eqpSource="
				+ eqpSource + ", eqpVendor=" + eqpVendor + ", eqpWidth=" + eqpWidth + ", equipmentSpecName="
				+ equipmentSpecName + ", equipmentSpecRefId=" + equipmentSpecRefId + ", fieldId=" + fieldId
				+ ", frRefKeyName=" + frRefKeyName + ", frRefKeyValue=" + frRefKeyValue + ", frame=" + frame
				+ ", functionalType=" + functionalType + ", hardwareRevision=" + hardwareRevision
				+ ", hiLocationReference=" + hiLocationReference + ", hiLocationType=" + hiLocationType
				+ ", ineffectDate=" + ineffectDate + ", installedDate=" + installedDate + ", ipv4Address=" + ipv4Address
				+ ", ipv6Address=" + ipv6Address + ", isMultiTidShelf=" + isMultiTidShelf + ", lastModifiedBy="
				+ lastModifiedBy + ", lastModifiedTimeStamp=" + lastModifiedTimeStamp + ", lineUp=" + lineUp
				+ ", locationClli=" + locationClli + ", logicalShelf=" + logicalShelf + ", lowLocationReference="
				+ lowLocationReference + ", lowLocationType=" + lowLocationType + ", materialId=" + materialId
				+ ", mgmtIpAddress=" + mgmtIpAddress + ", noOfSlots=" + noOfSlots + ", orderDate=" + orderDate
				+ ", orderNumber=" + orderNumber + ", parentEqpReferenceId=" + parentEqpReferenceId + ", parentEqpType="
				+ parentEqpType + ", parentShelfReferenceId=" + parentShelfReferenceId + ", partNum=" + partNum
				+ ", physicalShelfPosition=" + physicalShelfPosition + ", pointCode=" + pointCode + ", scheduledDate="
				+ scheduledDate + ", serialNumber=" + serialNumber + ", shelfType=" + shelfType + ", siteReferenceId="
				+ siteReferenceId + ", softwareRevision=" + softwareRevision + ", tidLogical=" + tidLogical
				+ ", tidPhysical=" + tidPhysical + ", wireCenter=" + wireCenter + ", dirContainerType="
				+ dirContainerType + ", dirEqpType=" + dirEqpType + ", dirInvStatus=" + dirInvStatus + ", slots="
				+ slots + ", assetOwner=" + assetOwner + ", subLocation=" + subLocation + ", customerName="
				+ customerName + ", networkType=" + networkType + ", networkDomain=" + networkDomain
				+ ", projectReferenceId=" + projectReferenceId + ", instanceType=" + instanceType
				+ ", physicalEquipmentReferenceId=" + physicalEquipmentReferenceId + ", mgmtTelnetPort="
				+ mgmtTelnetPort + ", mgmtSSHPort=" + mgmtSSHPort + ", hostName=" + hostName + ", utIndicator="
				+ utIndicator + ", matedPair=" + matedPair+ "]";
	}
	
}