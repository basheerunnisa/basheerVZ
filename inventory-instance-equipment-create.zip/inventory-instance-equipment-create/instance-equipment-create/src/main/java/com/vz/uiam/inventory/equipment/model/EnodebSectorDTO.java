package com.vz.uiam.inventory.equipment.model;

public class EnodebSectorDTO {

	private Long antenaDegree;
	private Long azimuth;
	private Long centerlineFt;
	private Long cellId;
	private String pci;
	private String antenaEnvironment;
	private Long maxGainAzimuth;
	private String coverageArea;
	private EnodebBandDTO band;
	
	public Long getAntenaDegree() {
		return antenaDegree;
	}
	public void setAntenaDegree(Long antenaDegree) {
		this.antenaDegree = antenaDegree;
	}
	public Long getAzimuth() {
		return azimuth;
	}
	public void setAzimuth(Long azimuth) {
		this.azimuth = azimuth;
	}
	public Long getCenterlineFt() {
		return centerlineFt;
	}
	public void setCenterlineFt(Long centerlineFt) {
		this.centerlineFt = centerlineFt;
	}
	public Long getCellId() {
		return cellId;
	}
	public void setCellId(Long cellId) {
		this.cellId = cellId;
	}
	public String getPci() {
		return pci;
	}
	public void setPci(String pci) {
		this.pci = pci;
	}
	public String getAntenaEnvironment() {
		return antenaEnvironment;
	}
	public void setAntenaEnvironment(String antenaEnvironment) {
		this.antenaEnvironment = antenaEnvironment;
	}
	public Long getMaxGainAzimuth() {
		return maxGainAzimuth;
	}
	public void setMaxGainAzimuth(Long maxGainAzimuth) {
		this.maxGainAzimuth = maxGainAzimuth;
	}
	public String getCoverageArea() {
		return coverageArea;
	}
	public void setCoverageArea(String coverageArea) {
		this.coverageArea = coverageArea;
	}
	public EnodebBandDTO getBand() {
		return band;
	}
	public void setBand(EnodebBandDTO band) {
		this.band = band;
	}
	
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "EnodebSectorDTO [antenaDegree=" + antenaDegree + ", azimuth=" + azimuth + ", centerlineFt="
				+ centerlineFt + ", cellId=" + cellId + ", pci=" + pci + ", antenaEnvironment=" + antenaEnvironment
				+ ", maxGainAzimuth=" + maxGainAzimuth + ", coverageArea=" + coverageArea + ", band=" + band + "]";
	}
}
