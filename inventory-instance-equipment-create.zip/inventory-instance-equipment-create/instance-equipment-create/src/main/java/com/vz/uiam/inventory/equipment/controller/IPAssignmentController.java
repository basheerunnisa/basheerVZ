/**
 * 
 */
package com.vz.uiam.inventory.equipment.controller;


import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ValidationUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.common.audit.exception.MethodFailureException;
import com.vz.uiam.common.monitor.performance.PerformanceMetrics;
import com.vz.uiam.inventory.equipment.enumeration.ErrorCodeEnum;
import com.vz.uiam.inventory.equipment.model.validator.LoopBackIPAssignmentValidator;
import com.vz.uiam.inventory.equipment.service.DirectoryService;
import com.vz.uiam.inventory.equipment.service.IPAssignmentService;
import com.vz.uiam.inventory.instance.rest.api.model.IPAssignmentDTO;
import com.vz.uiam.inventory.instance.rest.api.model.IPAssignmentResponseDTO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * <p>
 * This class is used to assign IPs to Routers
 * </p>
 * 
 * @author Chintan Patel
 * @date 06-Nov-2017
 *
 */
@RestController
@RequestMapping("/inventory/equipments")
@Api(value = "Loopback IP Assignment", description = "Loopback back IP for RI")
@PreAuthorize("hasAnyAuthority('ROLE:IVAPP_USER','ROLE:IVAPP_TESTER')")
public class IPAssignmentController {

	private static final Logger LOGGER = LoggerFactory.getLogger(IPAssignmentController.class);
	
	@Autowired
	private IPAssignmentService ipAssignmentService;
	
	@Autowired
	private LoopBackIPAssignmentValidator loopBackIPAssignmentValidator;

	@RequestMapping(value = "/assignIP", method = RequestMethod.POST, produces = "application/json")
	@PerformanceMetrics(sla = 1500)
	@ApiOperation(value = "Returns Status of IP Assignment", notes = "Returns true after after IP assignment for loopback Equipment. SLA:1500", response = Boolean.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Sucessfully Assigned IP Address to loopback Equipment"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Fail to assign IP Address loopback for Equipment "),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	public IPAssignmentResponseDTO assignIPForEqp(@RequestBody IPAssignmentDTO ipAssignmentDTO, HttpServletRequest request,
			BindingResult errors) throws BindException {
		IPAssignmentResponseDTO response=null;
		DirectoryService.clearCache();
		
		ValidationUtils.invokeValidator(loopBackIPAssignmentValidator, ipAssignmentDTO, errors);
		if (errors.hasErrors()) {
			throw new BindException(errors);
		}
		
		LOGGER.info("Entering assignIPForEqp with URL [" + request.getRequestURL() + "]" +" and request ipAssignmentDTO: {}  ",ipAssignmentDTO);
		try {
			
			response = ipAssignmentService.assignIPForEquipment(ipAssignmentDTO);
			
		} catch (Exception e) {
			LOGGER.error("Exception in assignment of IP for Equipment", e);
			throw new MethodFailureException(ErrorCodeEnum.IP_ASSIGNMENT_FAILURE.getCode(),
					String.format(ErrorCodeEnum.IP_ASSIGNMENT_FAILURE.getDescription()),
					"Assignment of IP for router is failed");
		}
		return response;
	}
}
