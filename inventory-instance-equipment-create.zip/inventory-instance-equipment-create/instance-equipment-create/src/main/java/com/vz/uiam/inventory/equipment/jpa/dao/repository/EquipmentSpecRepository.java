package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.EquipmentSpec;

@Transactional
public interface EquipmentSpecRepository extends JpaRepository<EquipmentSpec, Long> {

    List<EquipmentSpec> findByNameAndSpecVersion(String specName, long specVersion);

    EquipmentSpec findByName(String name);

    List<EquipmentSpec> findByPartNum(String partNum);
    
    EquipmentSpec findOneByPartNumIgnoreCase(String partNum);
    
    EquipmentSpec findOneByPartNumIgnoreCaseAndUtIndicator(String partNum, String utIndicator);
    
    List<EquipmentSpec> findByNameAndUtIndicator(String name, String utIndicator);
}