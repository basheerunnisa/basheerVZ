package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * 
 * @author Justin Wheeler
 *
 */
@Embeddable
public class EquipmentDomainMapPk implements Serializable {

	private static final long serialVersionUID = 6953148758767455843L;

	@Column(name = "EQP_REFERENCE_ID")
	private Long eqpReferenceId;
	
	@Column(name = "DOMAIN_ID")
	private Integer domainId;

	
	public EquipmentDomainMapPk(){
		super();
	}
	public EquipmentDomainMapPk(Long eqpReferenceId, Integer domainId) {
		this();
		this.eqpReferenceId = eqpReferenceId;
		this.domainId = domainId;
	}

	
	public Long getEqpReferenceId() {
		return eqpReferenceId;
	}
	public void setEqpReferenceId(Long eqpReferenceId) {
		this.eqpReferenceId = eqpReferenceId;
	}
	public Integer getDomainId() {
		return domainId;
	}
	public void setDomainId(Integer domainId) {
		this.domainId = domainId;
	}
	
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((domainId == null) ? 0 : domainId.hashCode());
		result = prime * result + ((eqpReferenceId == null) ? 0 : eqpReferenceId.hashCode());
		return result;
	}
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EquipmentDomainMapPk other = (EquipmentDomainMapPk) obj;
		if (domainId == null) {
			if (other.domainId != null)
				return false;
		} else if (!domainId.equals(other.domainId))
			return false;
		if (eqpReferenceId == null) {
			if (other.eqpReferenceId != null)
				return false;
		} else if (!eqpReferenceId.equals(other.eqpReferenceId))
			return false;
		return true;
	}
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "EquipmentDomainMapPk [eqpReferenceId=" + eqpReferenceId + ", domainId=" + domainId + "]";
	}
}