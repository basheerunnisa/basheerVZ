package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.javers.core.metamodel.annotation.TypeName;

import com.vz.uiam.inventory.equipment.model.validator.EntityValidator;

/**
 * The persistent class for the SITE database table.
 * 
 */
@Entity
@Table(name = "SITE")
@TypeName("Site")
@NamedQuery(name = "Site.findAll", query = "SELECT s FROM Site s")
public class Site implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SITE_REFERENCE_ID")
	private long siteReferenceId;

	private String address;

	@Column(name = "BASE_NUM")
	private String baseNum;

	private String city;

	private String clli;

	private String comments;

	private String contacts;

	private String country;

	private String county;

	@Column(name = "MARKET")
	private String market;
	
	@Column(name = "CUSTOMER_ID")
	private String customerId;

	@Column(name = "\"FLOOR\"")
	private String floor;

	@Column(name = "FLOOR_PLAN_DEPTH")
	private BigDecimal floorPlanDepth;

	@Column(name = "FLOOR_PLAN_HEIGHT")
	private BigDecimal floorPlanHeight;

	@Column(name = "FLOOR_PLAN_NAME")
	private String floorPlanName;

	@Column(name = "FLOOR_PLAN_ORIGIN_X")
	private BigDecimal floorPlanOriginX;

	@Column(name = "FLOOR_PLAN_ORIGIN_Y")
	private BigDecimal floorPlanOriginY;

	@Column(name = "FLOOR_PLAN_WIDTH")
	private BigDecimal floorPlanWidth;

	@Column(name = "FR_REF_KEY_NAME")
	private String frRefKeyName;

	@Column(name = "FR_REF_KEY_VALUE")
	private String frRefKeyValue;

	@Temporal(TemporalType.DATE)
	@Column(name = "INSTALL_DATE")
	private Date installDate;

	@Column(name = "LAST_MODIFIED_BY")
	private String lastModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_MODIFIED_TIME_STAMP")
	private Date lastModifiedTimeStamp;

	private String lata;

	private String latitude;

	private String longitude;

	private String owner;

	@Column(name = "PARENT_SITE_REF_ID")
	private BigDecimal parentSiteRefId;

	private String region;

	private String restrictions;

	private String room;

	@Column(name = "SITE_NAME")
	private String siteName;

	@Column(name = "\"STATE\"")
	private String state;

	private String status;

	@Column(name = "\"TYPE\"")
	private String type;

	@Column(name = "ZIP_CODE")
	private String zipCode;

	public Site() {
	}

	public long getSiteReferenceId() {
		return this.siteReferenceId;
	}

	public void setSiteReferenceId(long siteReferenceId) {
		this.siteReferenceId = siteReferenceId;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBaseNum() {
		return this.baseNum;
	}

	public void setBaseNum(String baseNum) {
		this.baseNum = baseNum;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getClli() {
		return this.clli;
	}

	public void setClli(String clli) {
		this.clli = clli;
	}

	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getContacts() {
		return this.contacts;
	}

	public void setContacts(String contacts) {
		this.contacts = contacts;
	}

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCounty() {
		return this.county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getCustomerId() {
		return this.customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getFloor() {
		return this.floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public BigDecimal getFloorPlanDepth() {
		return this.floorPlanDepth;
	}

	public void setFloorPlanDepth(BigDecimal floorPlanDepth) {
		this.floorPlanDepth = floorPlanDepth;
	}

	public BigDecimal getFloorPlanHeight() {
		return this.floorPlanHeight;
	}

	public void setFloorPlanHeight(BigDecimal floorPlanHeight) {
		this.floorPlanHeight = floorPlanHeight;
	}

	public String getFloorPlanName() {
		return this.floorPlanName;
	}

	public void setFloorPlanName(String floorPlanName) {
		this.floorPlanName = floorPlanName;
	}

	public BigDecimal getFloorPlanOriginX() {
		return this.floorPlanOriginX;
	}

	public void setFloorPlanOriginX(BigDecimal floorPlanOriginX) {
		this.floorPlanOriginX = floorPlanOriginX;
	}

	public BigDecimal getFloorPlanOriginY() {
		return this.floorPlanOriginY;
	}

	public void setFloorPlanOriginY(BigDecimal floorPlanOriginY) {
		this.floorPlanOriginY = floorPlanOriginY;
	}

	public BigDecimal getFloorPlanWidth() {
		return this.floorPlanWidth;
	}

	public void setFloorPlanWidth(BigDecimal floorPlanWidth) {
		this.floorPlanWidth = floorPlanWidth;
	}

	public String getFrRefKeyName() {
		return this.frRefKeyName;
	}

	public void setFrRefKeyName(String frRefKeyName) {
		this.frRefKeyName = frRefKeyName;
	}

	public String getFrRefKeyValue() {
		return this.frRefKeyValue;
	}

	public void setFrRefKeyValue(String frRefKeyValue) {
		this.frRefKeyValue = frRefKeyValue;
	}

	public Date getInstallDate() {
		return this.installDate;
	}

	public void setInstallDate(Date installDate) {
		this.installDate = installDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifiedTimeStamp() {
		return this.lastModifiedTimeStamp;
	}

	public void setLastModifiedTimeStamp(Date lastModifiedTimeStamp) {
		this.lastModifiedTimeStamp = lastModifiedTimeStamp;
	}

	public String getLata() {
		return this.lata;
	}

	public void setLata(String lata) {
		this.lata = lata;
	}

	public String getLatitude() {
		return this.latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return this.longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getOwner() {
		return this.owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public BigDecimal getParentSiteRefId() {
		return this.parentSiteRefId;
	}

	public void setParentSiteRefId(BigDecimal parentSiteRefId) {
		this.parentSiteRefId = parentSiteRefId;
	}

	public String getRegion() {
		return this.region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getRestrictions() {
		return this.restrictions;
	}

	public void setRestrictions(String restrictions) {
		this.restrictions = restrictions;
	}

	public String getRoom() {
		return this.room;
	}

	public void setRoom(String room) {
		this.room = room;
	}

	public String getSiteName() {
		return this.siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStatus() {
		return EntityValidator.validateStatus(status, this.getClass());
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getZipCode() {
		return this.zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

}