package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.javers.core.metamodel.annotation.TypeName;


/**
 * The persistent class for the BANDWIDTH database table.
 * 
 */
@Entity
@Table(name="BANDWIDTH")
@TypeName("Bandwidth")
@NamedQuery(name="Bandwidth.findAll", query="SELECT b FROM Bandwidth b")
public class Bandwidth implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="BANDWIDTH_NAME")
	private String bandwidthName;

	@Column(name="BANDWIDTH_ID")
	private BigDecimal bandwidthId;

	@Column(name="BIT_RATE")
	private BigDecimal bitRate;

	@Column(name="UNIT_OF_MEASURE")
	private BigDecimal unitOfMeasure;

	public Bandwidth() {
	}

	public String getBandwidthName() {
		return this.bandwidthName;
	}

	public void setBandwidthName(String bandwidthName) {
		this.bandwidthName = bandwidthName;
	}

	public BigDecimal getBandwidthId() {
		return this.bandwidthId;
	}

	public void setBandwidthId(BigDecimal bandwidthId) {
		this.bandwidthId = bandwidthId;
	}

	public BigDecimal getBitRate() {
		return this.bitRate;
	}

	public void setBitRate(BigDecimal bitRate) {
		this.bitRate = bitRate;
	}

	public BigDecimal getUnitOfMeasure() {
		return this.unitOfMeasure;
	}

	public void setUnitOfMeasure(BigDecimal unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}

}