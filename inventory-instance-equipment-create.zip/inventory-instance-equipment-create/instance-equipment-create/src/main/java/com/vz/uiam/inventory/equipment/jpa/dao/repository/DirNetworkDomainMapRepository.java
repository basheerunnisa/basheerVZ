package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import org.javers.spring.annotation.JaversSpringDataAuditable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.DirNetworkDomainMap;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirNetworkDomainMapPk;


@Transactional
@JaversSpringDataAuditable
public interface DirNetworkDomainMapRepository extends JpaRepository<DirNetworkDomainMap, DirNetworkDomainMapPk>{
	
}

