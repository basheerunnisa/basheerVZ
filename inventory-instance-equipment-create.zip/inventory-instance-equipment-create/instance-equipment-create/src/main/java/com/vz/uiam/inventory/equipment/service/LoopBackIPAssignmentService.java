package com.vz.uiam.inventory.equipment.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.uiam.common.audit.exception.MethodFailureException;
import com.vz.uiam.inventory.equipment.enumeration.DirInventoryConfigGroups;
import com.vz.uiam.inventory.equipment.enumeration.ErrorCodeEnum;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInventoryConfig;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInventoryConfigRepository;
import com.vz.uiam.inventory.equipment.model.NetworkIpv4;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateConstant;
import com.vz.uiam.inventory.instance.rest.api.model.AssignNextAvailNonPreassignDTO;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;

@Component
public class LoopBackIPAssignmentService {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoopBackIPAssignmentService.class);
	
	@Autowired
	private IPAssignmentRestService ipAssignmentRestService;
	
	@Autowired
	private DirInventoryConfigRepository dirInventoryConfigRepository;

	@Autowired
	private IPAssignmentService ipAssignmentService;

	/**
	 * <p>
	 * This method is doing following operation
	 * </p>
	 * <li>if equipmentRefId in null then get equipmentrefId from EQUIPMENT
	 * table</li>
	 * <li>set value of AssignNextAvailNonPreassignDTO for ipAssignment service</li>
	 * <li>called ipAssignmentService for to setup IPV4 ipAddress1 and
	 * ipAddress2</li>
	 * 
	 * @param ipAssignmentDTO
	 * @return
	 */
	public List<AttributesDTO> assignLoopBackIPForEqp(Equipment equipment) {
		LOGGER.info("Request for assignLoopBackIPForEqp: {} ", equipment);
		Map<String, String> ipAddressMap = new HashMap<>();
		LOGGER.info("processIpAddress based on shelfType {} ", equipment.getShelfType());
		if (InstanceEquipmentCreateConstant.SHELF_TYPE_MSERI.equalsIgnoreCase(equipment.getShelfType())) {
			processIpAddressForMSERI(equipment, ipAddressMap);
		} else if (InstanceEquipmentCreateConstant.SHELF_TYPE_NGPON2.equalsIgnoreCase(equipment.getShelfType())) {
			processIpAddressForNGPON2(equipment, ipAddressMap);
		}
		return ipAssignmentService.buildEqpAttributes(InstanceEquipmentCreateConstant.LOOP_BACK, equipment,
				ipAddressMap, equipment.getFunctionalType());
	}
	
	/**
	 * <p>
	 * This is method to populate DTO for next available IP
	 * </p>
	 * 
	 * @param poolName
	 * @param equipmentRefID
	 * @return
	 */
	private AssignNextAvailNonPreassignDTO populateAssignNextAvailPreassignDTO(String poolName, String tidLogical,
			String comment) {
		AssignNextAvailNonPreassignDTO assignNextAvailNonPreassignDTO = new AssignNextAvailNonPreassignDTO();
		assignNextAvailNonPreassignDTO.setNetSize(InstanceEquipmentCreateConstant.NET_SIZE);
		assignNextAvailNonPreassignDTO.setNoOfIps(InstanceEquipmentCreateConstant.NUMBER_OF_A_SITE_IPS);
		assignNextAvailNonPreassignDTO.setComment(comment);
		assignNextAvailNonPreassignDTO.setSite(tidLogical != null ? tidLogical : InstanceEquipmentCreateConstant.NA);

		String poolValue = fetchPoolName(poolName);
		assignNextAvailNonPreassignDTO.setPoolName(poolValue);
		assignNextAvailNonPreassignDTO.setPoolType(poolValue);
		LOGGER.info("Corresponding Pool Name from DB Config: {}", poolValue);

		return assignNextAvailNonPreassignDTO;
	}

	/**
	 * <p>
	 * fetch pool name from DIR_INVENTORY_CONFIG table
	 * </p>
	 * 
	 * @param poolName
	 * @return
	 */
	private String fetchPoolName(String poolName) {
		DirInventoryConfig dirInventoryConfig = dirInventoryConfigRepository
				.findByGroupNameAndConfigName(DirInventoryConfigGroups.LOOP_BACK_IP_ASSIGNMENT.value(), poolName);
		if (null != dirInventoryConfig) {
			return dirInventoryConfig.getConfigValue();
		}
		return null;
	}

	/**
	 * <p>
	 * This method does following operation
	 * </p>
	 * <li>check if attributeName is for DARKNET_IP_POOL_NAME or
	 * EXTERNAL_IP_POOL_NAME</li>
	 * <li>call the ipAssignmentService to get the IP address</li>
	 * <li>call the attributeSpecificationService to add that IP in attribute
	 * name</li>
	 * 
	 * @param tidLogical
	 * @param attributeName
	 * @return
	 */
	private String assignIpv4(String tidLogical, String attributeName,String shelfType) {
		LOGGER.info("Request to assign Ip addresses for Loopback with tidLogical :{} and attributeName : {} and shelfType : {}",tidLogical, attributeName,shelfType);
		
		AssignNextAvailNonPreassignDTO assignNextAvailNonPreassignDTO = getNextAvailNonPreassignDTO(tidLogical, attributeName,shelfType);
		NetworkIpv4 ipv4AssignmentResponse = ipAssignmentRestService
				.assignNextAvailableIp(assignNextAvailNonPreassignDTO);

		if (ipv4AssignmentResponse.getCidr() == null) {
			LOGGER.error("Ip Address is null for loopback request");
			throw new MethodFailureException(ErrorCodeEnum.INVALID_IP_ASSIGNMENT.getCode(),
					ErrorCodeEnum.INVALID_IP_ASSIGNMENT.getDescription(), "assignment IP is empty");
		}
		String ipv4Address = ipv4AssignmentResponse.getCidr().replaceFirst(InstanceEquipmentCreateConstant.REGEX,
				InstanceEquipmentCreateConstant.REPLACEMENT);
		LOGGER.info("Assigned Loop back IP for Equipment IPV4 ipaddress:{} ", ipv4Address);

		return ipv4Address;
	}

	/**
	 * <p>
	 * This method will process the AssignNextAvailNonPreassignDTO on the basis of pool name and attribute name
	 * </p>
	 * 
	 * @param poolName
	 * @return
	 */
	private AssignNextAvailNonPreassignDTO getNextAvailNonPreassignDTO(String tidLogical, String attributeName,
			String shelfType) {
		LOGGER.info("calling AssignNextAvailNonPreassignDTO tidLogical :{} and attributeName : {}", tidLogical,
				attributeName);
		AssignNextAvailNonPreassignDTO assignNextAvailNonPreassignDTO = null;
		if (attributeName.equals(InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_1)) {

			if (InstanceEquipmentCreateConstant.SHELF_TYPE_MSERI.equalsIgnoreCase(shelfType)) {

				assignNextAvailNonPreassignDTO = populateAssignNextAvailPreassignDTO(
						InstanceEquipmentCreateConstant.DARKNET_IP_POOL_NAME, tidLogical,
						InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_1);

			} else if (InstanceEquipmentCreateConstant.SHELF_TYPE_NGPON2.equalsIgnoreCase(shelfType)) {
				assignNextAvailNonPreassignDTO = populateAssignNextAvailPreassignDTO(
						InstanceEquipmentCreateConstant.VRIS_INFRASTRUCTURE_POOL_NAME, tidLogical,
						InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_1);
			}

		}else {
			assignNextAvailNonPreassignDTO = populateAssignNextAvailPreassignDTO(
					InstanceEquipmentCreateConstant.EXTERNAL_IP_POOL_NAME, tidLogical,
					InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_2);
		}
		return assignNextAvailNonPreassignDTO;
	}
	
	/**
	 * <p>
	 * This method will process and store the ipAddress value for NGPON2 
	 * </p>
	 * 
	 * @param equipment
	 * @param Map<String, String> ipAddressMap
	 * @return
	 */
	
	private void processIpAddressForNGPON2(Equipment equipment, Map<String, String> ipAddressMap) {
		LOGGER.info("calling processIpAddressForMSERI  Equipment: {}", equipment);
		LOGGER.info("calling assignIpv4 for NGPON2 Ip Address ");
		String ipAddressNGPON2 = assignIpv4(equipment.getTidLogical(),
				InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_1,equipment.getShelfType());
		
		ipAddressMap.put(InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_1, ipAddressNGPON2);
		ipAddressMap.forEach((key, value) -> LOGGER.info("ipAddressMap key:{} --> value: {}", key, value));
	}

	/**
	 * <p>
	 * This method will process and store the internal and external ipAddress values for MSERI
	 * </p>
	 * 
	 * @param equipment
	 * @param Map<String, String> ipAddressMap
	 * @return
	 */
	
	private void processIpAddressForMSERI(Equipment equipment, Map<String, String> ipAddressMap) {
		LOGGER.info("calling processIpAddressForMSERI  Equipment: {}", equipment);
		LOGGER.info("calling assignIpv4 for internalIPAddress");
		String internalIPAddress = assignIpv4(equipment.getTidLogical(),
				InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_1,equipment.getShelfType());
		LOGGER.info("calling assignIpv4 for externalIPAddress");
		String externalIPAddress = assignIpv4(equipment.getTidLogical(),
				InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_2,equipment.getShelfType());
		ipAddressMap.put(InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_1, internalIPAddress);
		ipAddressMap.put(InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_2, externalIPAddress);
		ipAddressMap.forEach((key, value) -> LOGGER.info("ipAddressMap key:{} --> value: {}", key, value));
	}
	
}