package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.javers.core.metamodel.annotation.TypeName;

import com.vz.uiam.inventory.equipment.model.validator.EntityValidator;

/**
 * The persistent class for the PORT_SPEC database table.
 * 
 */
@Entity
@Table(name = "PORT_SPEC")
@TypeName("PortSpec")
@NamedQuery(name = "PortSpec.findAll", query = "SELECT p FROM PortSpec p")
public class PortSpec implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PORT_SPEC_REF_ID")
	private long portSpecRefId;

	private String aid;

	@Column(name = "ALIAS_AID")
	private String aliasAid;

	@Column(name = "ASSOCIATED_SPEC_REF_ID")
	private BigDecimal associatedSpecRefId;

	private String bandwidth;

	@Column(name = "CONNECTOR_TYPE")
	private String connectorType;

	private String description;

	private String direction;

	@Column(name = "DISPATCH_PORT_NAME")
	private String dispatchPortName;

	@Column(name = "FUNCTIONAL_TYPE")
	private String functionalType;

	@Column(name = "LAST_MODIFIED_BY")
	private String lastModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_MODIFIED_TIME_STAMP")
	private Date lastModifiedTimeStamp;

	@Column(name = "PARENT_PORT_SPEC_ID")
	private BigDecimal parentPortSpecId;

	@Column(name = "PORT_NAME")
	private String portName;

	@Column(name = "PORT_NUM")
	private Long portNum;

	@Column(name = "PORT_STATUS")
	private String portStatus;

	@Column(name = "RELATED_SPEC_ID")
	private BigDecimal relatedSpecId;

	private String relationship;

	@Column(name = "ROLE")
	private String role;

	@Column(name = "SPEC_VERSION")
	private BigDecimal specVersion;

	@Column(name = "TP_TYPE")
	private String tpType;

	@ManyToOne
	@JoinColumn(name = "CARD_SPEC_REF_ID")
	private CardSpec cardSpec;

	@Column(name = "PORT_TYPE")
	private String dirPortType;

	@Column(name = "EQUIPMENT_SPEC_REF_ID")
	private Long equipmentSpecRefId;

	public PortSpec() {
	}

	public long getPortSpecRefId() {
		return this.portSpecRefId;
	}

	public void setPortSpecRefId(long portSpecRefId) {
		this.portSpecRefId = portSpecRefId;
	}

	public String getAid() {
		return this.aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public String getAliasAid() {
		return this.aliasAid;
	}

	public void setAliasAid(String aliasAid) {
		this.aliasAid = aliasAid;
	}

	public BigDecimal getAssociatedSpecRefId() {
		return this.associatedSpecRefId;
	}

	public void setAssociatedSpecRefId(BigDecimal associatedSpecRefId) {
		this.associatedSpecRefId = associatedSpecRefId;
	}

	public String getBandwidth() {
		return this.bandwidth;
	}

	public void setBandwidth(String bandwidth) {
		this.bandwidth = bandwidth;
	}

	public String getConnectorType() {
		return this.connectorType;
	}

	public void setConnectorType(String connectorType) {
		this.connectorType = connectorType;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDirection() {
		return this.direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getDispatchPortName() {
		return this.dispatchPortName;
	}

	public void setDispatchPortName(String dispatchPortName) {
		this.dispatchPortName = dispatchPortName;
	}

	public String getFunctionalType() {
		return this.functionalType;
	}

	public void setFunctionalType(String functionalType) {
		this.functionalType = functionalType;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifiedTimeStamp() {
		return this.lastModifiedTimeStamp;
	}

	public void setLastModifiedTimeStamp(Date lastModifiedTimeStamp) {
		this.lastModifiedTimeStamp = lastModifiedTimeStamp;
	}

	public BigDecimal getParentPortSpecId() {
		return this.parentPortSpecId;
	}

	public void setParentPortSpecId(BigDecimal parentPortSpecId) {
		this.parentPortSpecId = parentPortSpecId;
	}

	public String getPortName() {
		return this.portName;
	}

	public void setPortName(String portName) {
		this.portName = portName;
	}

	public Long getPortNum() {
		return this.portNum;
	}

	public void setPortNum(Long portNum) {
		this.portNum = portNum;
	}

	public String getPortStatus() {
		return EntityValidator.validateStatus(portStatus, this.getClass());
	}

	public void setPortStatus(String portStatus) {
		this.portStatus = portStatus;
	}

	public BigDecimal getRelatedSpecId() {
		return this.relatedSpecId;
	}

	public void setRelatedSpecId(BigDecimal relatedSpecId) {
		this.relatedSpecId = relatedSpecId;
	}

	public String getRelationship() {
		return this.relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getRole() {
		return this.role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public BigDecimal getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(BigDecimal specVersion) {
		this.specVersion = specVersion;
	}

	public String getTpType() {
		return this.tpType;
	}

	public void setTpType(String tpType) {
		this.tpType = tpType;
	}

	public CardSpec getCardSpec() {
		return this.cardSpec;
	}

	public void setCardSpec(CardSpec cardSpec) {
		this.cardSpec = cardSpec;
	}

	public String getDirPortType() {
		return EntityValidator.validateType(dirPortType, this.getClass());	
	}

	public void setDirPortType(String dirPortType) {
		this.dirPortType = dirPortType;
	}

	public Long getEquipmentSpecRefId() {
		return equipmentSpecRefId;
	}

	public void setEquipmentSpecRefId(Long equipmentSpecRefId) {
		this.equipmentSpecRefId = equipmentSpecRefId;
	}
}