package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.javers.core.metamodel.annotation.TypeName;


/**
 * The persistent class for the SLOT_CARD_SPEC_MAP database table.
 * 
 */
@Entity
@Table(name="SLOT_CARD_SPEC_MAP")
@TypeName("SlotCardSpecMap")
@NamedQuery(name="SlotCardSpecMap.findAll", query="SELECT s FROM SlotCardSpecMap s")
public class SlotCardSpecMap implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	SlotCardSpecMapPk slotCardSpecMapPk;
	
	@Column(name="IS_DEFAULT")
	private String isDefault;

	@Column(name="LAST_MODIFIED_BY")
	private String lastModifiedBy;
	
	@Temporal(TemporalType.DATE)
	@Column(name="LAST_MODIFIED_TIME_STAMP")
	private Date lastModifiedTimeStamp;
	
	public SlotCardSpecMap() {
	}

	public String getIsDefault() {
		return this.isDefault;
	}

	public void setIsDefault(String isDefault) {
		this.isDefault = isDefault;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifiedTimeStamp() {
		return this.lastModifiedTimeStamp;
	}

	public void setLastModifiedTimeStamp(Date lastModifiedTimeStamp) {
		this.lastModifiedTimeStamp = lastModifiedTimeStamp;
	}

	public SlotCardSpecMapPk getSlotCardSpecMapPk() {
		return slotCardSpecMapPk;
	}

	public void setSlotCardSpecMapPk(SlotCardSpecMapPk slotCardSpecMapPk) {
		this.slotCardSpecMapPk = slotCardSpecMapPk;
	}

	@Override
	public String toString() {
		return "SlotCardSpecMap [slotCardSpecMapPk=" + slotCardSpecMapPk + ", isDefault=" + isDefault
				+ ", lastModifiedBy=" + lastModifiedBy + ", lastModifiedTimeStamp=" + lastModifiedTimeStamp + "]";
	}

}