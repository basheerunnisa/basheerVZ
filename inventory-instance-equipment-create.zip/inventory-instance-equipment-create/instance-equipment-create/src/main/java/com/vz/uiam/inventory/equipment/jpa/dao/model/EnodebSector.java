package com.vz.uiam.inventory.equipment.jpa.dao.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "ENODEB_SECTOR")
public class EnodebSector {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ENODEB_SECTOR_ID")
	private Long sectorId;
	
	@JsonManagedReference
	@ManyToOne
	@JoinColumn(name = "ENODEB_ID")
	private EnodebDetails details;
	
	@Column(name = "ANTENA_DEGREE", nullable = false)
	private Long antenaDegree;
	
	@Column(name = "AZIMUTH", nullable = false)
	private Long azimuth;
	
	@Column(name = "CELL_ID", nullable = false)
	private Long cellId;
	
	@Column(name = "CENTERLINE_FT", nullable = false)
	private Long centerlineFt;
	
	@Column(name = "PCI", nullable = false)
	private String pci;
	
	@Column(name = "MAX_GAIN_AZIMUTH")
	private Long maxGainAzimuth;
	
	@Column(name = "ANTENA_ENVIRONMENT", nullable = false)
	private String antenaEnvironment;
	
	@OneToOne
	@JoinColumn(name = "BAND_CLASS")
	private DirEnodebBand band;
	
	@Lob
	@Column(name = "COVERAGE_AREA")
	private String coverageArea;

	
	public Long getSectorId() {
		return sectorId;
	}
	public void setSectorId(Long sectorId) {
		this.sectorId = sectorId;
	}
	public EnodebDetails getDetails() {
		return details;
	}
	public void setDetails(EnodebDetails details) {
		this.details = details;
	}
	public Long getAntenaDegree() {
		return antenaDegree;
	}
	public void setAntenaDegree(Long antenaDegree) {
		this.antenaDegree = antenaDegree;
	}
	public Long getAzimuth() {
		return azimuth;
	}
	public void setAzimuth(Long azimuth) {
		this.azimuth = azimuth;
	}
	public Long getCellId() {
		return cellId;
	}
	public void setCellId(Long cellId) {
		this.cellId = cellId;
	}
	public Long getCenterlineFt() {
		return centerlineFt;
	}
	public void setCenterlineFt(Long centerlineFt) {
		this.centerlineFt = centerlineFt;
	}
	public String getPci() {
		return pci;
	}
	public void setPci(String pci) {
		this.pci = pci;
	}
	public Long getMaxGainAzimuth() {
		return maxGainAzimuth;
	}
	public void setMaxGainAzimuth(Long maxGainAzimuth) {
		this.maxGainAzimuth = maxGainAzimuth;
	}
	public String getAntenaEnvironment() {
		return antenaEnvironment;
	}
	public void setAntenaEnvironment(String antenaEnvironment) {
		this.antenaEnvironment = antenaEnvironment;
	}
	public DirEnodebBand getBand() {
		return band;
	}
	public void setBand(DirEnodebBand band) {
		this.band = band;
	}
	public String getCoverageArea() {
		return coverageArea;
	}
	public void setCoverageArea(String coverageArea) {
		this.coverageArea = coverageArea;
	}
	
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "EnodebSector [sectorId=" + sectorId + ", antenaDegree=" + antenaDegree + ", azimuth=" + azimuth
				+ ", cellId=" + cellId + ", centerlineFt=" + centerlineFt + ", pci=" + pci + ", maxGainAzimuth="
				+ maxGainAzimuth + ", antenaEnvironment=" + antenaEnvironment + ", band=" + band + "]";
	}
}
