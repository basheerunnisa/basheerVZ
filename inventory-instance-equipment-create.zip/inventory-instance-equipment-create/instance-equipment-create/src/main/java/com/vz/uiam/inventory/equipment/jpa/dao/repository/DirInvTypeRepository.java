package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.util.List;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvType;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvTypePk;

@Transactional
public interface DirInvTypeRepository extends JpaRepository<DirInvType, DirInvTypePk> {

	DirInvType findByPkTypeAndPkEntityNameIgnoreCase(String type, String name);
	
	@Cacheable("dirInvType")
	List<DirInvType> findByPkEntityNameIgnoreCase(String name);

	@Cacheable("dirInvType")
	List<DirInvType> findByPkEntityNameIgnoreCaseIn(List<String> entities);

}

