package com.vz.uiam.inventory.equipment.model;

import java.util.Date;

/**
 * EntityEventData is a wrapper class for the message payload to be published to
 * Kafka topics.
 * 
 * @author DIXITSH
 *
 */
public class EntityEventData {

	private String entityType;
	private Long entityReference;
	private String operation;
	private Object entityPayload;
	private Date timestamp;

	public EntityEventData(String entityType, Long entityReference, String operation, Object entityPayload) {
		super();
		this.entityType = entityType;
		this.entityReference = entityReference;
		this.operation = operation;
		this.entityPayload = entityPayload;
		this.timestamp = new Date();
	}

	public EntityEventData() {
		super();
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public Long getEntityReference() {
		return entityReference;
	}

	public void setEntityReference(Long entityReference) {
		this.entityReference = entityReference;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public Object getEntityPayload() {
		return entityPayload;
	}

	public void setEntityPayload(Object entityPayload) {
		this.entityPayload = entityPayload;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public String toString() {
		return "EntityEventData [entityType=" + entityType + ", entityReference=" + entityReference + ", operation="
				+ operation + ", entityPayload=" + entityPayload + ", timestamp=" + timestamp + "]";
	}

}
