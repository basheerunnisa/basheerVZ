package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.javers.core.metamodel.annotation.TypeName;

@Entity
@Table(name="EQUIPMENT_DOMAIN_MAP")
@TypeName("EquipmentDomainMap")
public class EqpDomainMap implements Serializable {
	private static final long serialVersionUID = 1L; 
	
		
	@EmbeddedId
	private EqpDomainMapPk eqpDomainMapPk;


	public EqpDomainMapPk getEqpDomainMapPk() {
		return eqpDomainMapPk;
	}


	public void setEqpDomainMapPk(EqpDomainMapPk eqpDomainMapPk) {
		this.eqpDomainMapPk = eqpDomainMapPk;
	}


	@Override
	public String toString() {
		return "EqpDomainMap [eqpDomainMapPk=" + eqpDomainMapPk + "]";
	}

		
	

}
