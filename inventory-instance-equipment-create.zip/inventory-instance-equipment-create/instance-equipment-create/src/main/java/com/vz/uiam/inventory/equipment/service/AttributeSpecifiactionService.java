package com.vz.uiam.inventory.equipment.service;

/**<p>This class is for adding the attributes in EQUIPMENT_ATTRIBUTE</p>
 * @author Chintan Patel
 * @date 06-Nov-2017
 *
 */
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import com.vz.uiam.common.audit.exception.MethodFailureException;
import com.vz.uiam.inventory.equipment.enumeration.ErrorCodeEnum;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateConstant;
import com.vz.uiam.inventory.instance.rest.api.client.InventoryAttributesControllerClientInstance;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;

@Service
public class AttributeSpecifiactionService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AttributeSpecifiactionService.class);
	
	private static final ObjectMapper MAPPER = new ObjectMapper();

	@Autowired
	private InventoryAttributesControllerClientInstance specificationAttributesClient;

	/**
	 * <p>
	 * This method is for setting up client for specificationAttributesClient
	 * </p>
	 * 
	 * @param specificationAttributesClient
	 */
	public void setSpecificationAttributesClient(
			InventoryAttributesControllerClientInstance specificationAttributesClient) {
		this.specificationAttributesClient = specificationAttributesClient;
	}

	/**
	 * <p>
	 * This method is for adding IPV4 attribute with IPV4 Loop back IP address
	 * </p>
	 * 
	 * @param ipAttributes
	 * @param eqpReferenceId
	 * @return
	 */
	public List<AttributesDTO> addIpToAttributeSpecification(List<AttributesDTO> attributes, Long eqpReferenceId) {
		List<AttributesDTO> attributesList = null;
		try {
			LOGGER.info("Specification attribute request to add attributes:{} ", MAPPER.writeValueAsString(attributes));

			attributesList = specificationAttributesClient
					.insertInventoryAttributes(InstanceEquipmentCreateConstant.ENTITY_NAME, eqpReferenceId, attributes);
		} catch (HttpClientErrorException | HttpServerErrorException e) {
			LOGGER.error("Error while calling attribute-specification with error details: {}", e);
			throw new MethodFailureException(ErrorCodeEnum.SPECIFICATION_ATTRIBUTE_SERVICE_CALL_ERROR.getCode(),
					ErrorCodeEnum.SPECIFICATION_ATTRIBUTE_SERVICE_CALL_ERROR.getDescription(),Long.toString(eqpReferenceId));
		} catch (Exception e) {
			LOGGER.error("Unable to call attribute service with error {}", e);
			throw new MethodFailureException(ErrorCodeEnum.SPECIFICATION_ATTRIBUTE_SERVICE_CALL_ERROR.getCode(),
					ErrorCodeEnum.SPECIFICATION_ATTRIBUTE_SERVICE_CALL_ERROR.getDescription(), Long.toString(eqpReferenceId));
		}
		
		return attributesList;
	}

}
