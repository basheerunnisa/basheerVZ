package com.vz.uiam.inventory.equipment.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vz.uiam.inventory.equipment.exception.DataNotFoundException;
import com.vz.uiam.inventory.equipment.jpa.dao.model.AuxiliaryEquipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EnodebDetails;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EnodebSector;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EquipmentAttributes;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.AuxiliaryRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EnodebDetailsRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EnodebSectorRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentAttributesRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.equipment.model.AuxiliaryDTO;
import com.vz.uiam.inventory.equipment.model.EnodebDetailsDTO;
import com.vz.uiam.inventory.equipment.model.EnodebSectorDTO;
import com.vz.uiam.inventory.equipment.model.mapper.ResourceMapper;

@Service
public class SupportEquipmentCreateService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SupportEquipmentCreateService.class);

	@Autowired
	private AuxiliaryRepository auxiliaryRepository;
	@Autowired
	private EnodebDetailsRepository enodebDetailsRepository;
	@Autowired
	private EnodebSectorRepository enodebSectorRepository;
	@Autowired
	private EquipmentAttributesRepository equipmentAttributesRepository;
	@Autowired
	private EquipmentRepository equipmentRepository;
	@Autowired
	private ResourceMapper resourceMapper;
	
	public List<AuxiliaryEquipment> createAuxiliary(List<AuxiliaryDTO> requestBody){
		
		if(requestBody == null){
			LOGGER.warn("Warning: Request Body is null. Returning empty.");
			return new ArrayList<>();
		}
		
		LOGGER.info("Attempting to Create {} Auxiliary Equipment for the given Request Body | {}", requestBody.size(), requestBody);
		
		List<AuxiliaryEquipment> converted = resourceMapper.convertToAuxiliaryFromDTO(requestBody);
		return auxiliaryRepository.save(converted);
	}
	
	public boolean createEnodebs(EnodebDetailsDTO enodebRequest) {
		return createEnodebs(Arrays.asList(enodebRequest));
	}
	
	public boolean createEnodebs(List<EnodebDetailsDTO> enodebRequest) {
		
		Set<String> enodebIds = enodebRequest.stream().map(EnodebDetailsDTO::getEnodebId).collect(Collectors.toSet());
		List<EnodebDetails> existingEnodebs = enodebDetailsRepository.findByEnodebIdIn(enodebIds);
		
		if(existingEnodebs != null && !existingEnodebs.isEmpty()){
			LOGGER.warn("WARNING: Enodeb Ids given already exist. This application will NOT alter existing records. | {}", enodebIds);
			return false;
		}
		
		LOGGER.info("Attempting to Create {} Enodebs", enodebRequest.size());
		
		List<EnodebDetails> enodebDetails = resourceMapper.convertToEnodebDetails(enodebRequest);
		populateEquipmentReferenceIds(enodebDetails);
		populateFromEquipment(enodebDetails);

		LOGGER.info("Saving {} Enodeb Details", enodebDetails.size());
		enodebDetailsRepository.save(enodebDetails);
		
		enodebDetails.forEach(enodeb -> {
			enodeb.sync();
			
			LOGGER.info("Saving {} Enodeb Sectors", enodeb.getSectors().size());
			enodeb.setSectors(enodebSectorRepository.save(enodeb.getSectors()));
		});
		
		LOGGER.info("Saved {} Records", enodebDetails.size());
		return !enodebDetails.isEmpty();
	}
	
	public boolean createEnodebSectors(EnodebDetails existingDetails, EnodebSectorDTO enodebRequest) {
			
		LOGGER.info("Attempting to Create an Enodeb Sector for Enodeb Id: {}", existingDetails.getEnodebId());
		
		EnodebSector enodebSector = resourceMapper.convertToEnodebSector(enodebRequest);
		enodebSector.setDetails(existingDetails);		
		enodebSector = enodebSectorRepository.save(enodebSector);
		
		LOGGER.info("Saved Record!");
		return enodebSector != null;
	}
	
	private void populateEquipmentReferenceIds(List<EnodebDetails> enodebDetails) {
		
		Set<String> uniqueEnodebIds = enodebDetails.stream().map(EnodebDetails::getEnodebId).collect(Collectors.toSet());
		List<EquipmentAttributes> attributes = equipmentAttributesRepository.getEquipmentAttributesByEnodebIds(uniqueEnodebIds);
		
		enodebDetails.forEach(e -> {
			List<Long> equipmentIds = attributes.stream().filter(a -> 
				e.getEnodebId().equals(a.getEqpValue())).map(EquipmentAttributes::getEqpReferenceId).collect(Collectors.toList());
			
			if(equipmentIds == null || equipmentIds.isEmpty()) {
				 LOGGER.error("equipmentReferenceId not found for enodebId " + e.getEnodebId());
				 throw new DataNotFoundException("Equipment Attributes", "Not Found", "Enodeb Id:" + e.getEnodebId() + ". Did not match!");
			}
			e.setEqpReferenceId(equipmentIds.get(0));
		});
	}

	private void populateFromEquipment(List<EnodebDetails> enodebDetails) {

		Set<Long> equipmentIds = enodebDetails.stream().map(EnodebDetails::getEqpReferenceId).collect(Collectors.toSet());
		List<Equipment> foundEquipment = equipmentRepository.findByEqpReferenceIdIn(equipmentIds);
		
		enodebDetails.forEach(e -> {
			List<Equipment> tmp = foundEquipment.stream().filter(eqp -> 
				e.getEqpReferenceId().equals(eqp.getEqpReferenceId())).collect(Collectors.toList());
			
			if(tmp.isEmpty()) {
				 LOGGER.error("equipment not found for eqpReferenceId " + e.getEqpReferenceId());
				 throw new DataNotFoundException("Equipment", "Not Found", "EQUIPMENT_ATTRIBUTES.EQP_REFERENCE_ID: " + e.getEqpReferenceId() + " did not match.");
			}
			Equipment curEqp = tmp.get(0);
			e.setSiteReferenceId(curEqp.getSiteReferenceId().longValue());
			e.setEnodebName(curEqp.getEqpName());
		});
	}
}