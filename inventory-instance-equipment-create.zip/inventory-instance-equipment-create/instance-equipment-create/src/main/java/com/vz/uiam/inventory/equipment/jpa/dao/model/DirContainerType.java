package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.javers.core.metamodel.annotation.TypeName;


/**
 * The persistent class for the DIR_CONTAINER_TYPE database table.
 * 
 */
@Entity
@Table(name="DIR_CONTAINER_TYPE")
@TypeName("DirContainerType")
@NamedQuery(name="DirContainerType.findAll", query="SELECT d FROM DirContainerType d")
public class DirContainerType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "CONTAINER")
	private String container;

	@Column(name="CONTAINER_ID")
	private BigDecimal containerId;

	private String description;

	@Column(name="DISPLAY_SEQ")
	private BigDecimal displaySeq;

	public DirContainerType() {
	}

	public String getContainer() {
		return this.container;
	}

	public void setContainer(String container) {
		this.container = container;
	}

	public BigDecimal getContainerId() {
		return this.containerId;
	}

	public void setContainerId(BigDecimal containerId) {
		this.containerId = containerId;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getDisplaySeq() {
		return this.displaySeq;
	}

	public void setDisplaySeq(BigDecimal displaySeq) {
		this.displaySeq = displaySeq;
	}

}