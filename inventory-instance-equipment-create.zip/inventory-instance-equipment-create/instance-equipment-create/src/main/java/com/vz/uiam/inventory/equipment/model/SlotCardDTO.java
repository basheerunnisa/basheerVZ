package com.vz.uiam.inventory.equipment.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.springframework.hateoas.ResourceSupport;

public class SlotCardDTO extends ResourceSupport implements Serializable {
    /**
     
     * This field corresponds to the database column XNG.CARD_INST.CARD_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Integer cardInstId;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.EQUIP_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Integer equipInstId;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.SLOT
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String slot;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.TYPE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String type;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.STATUS
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String status;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.ALT_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String altId;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.ORDERED
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Date ordered;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.DUE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Date due;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.INSTALLED
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Date installed;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.IN_SERVICE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Date inService;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.SCHED_DATE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Date schedDate;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.DECOMMISSION
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Date decommission;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.SERIAL_NO
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String serialNo;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.BATCH_NO
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String batchNo;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.BAR_CODE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String barCode;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.PURCHASE_PRICE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private BigDecimal purchasePrice;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.PURCHASE_DATE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Date purchaseDate;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.ASSET_LIFE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private BigDecimal assetLife;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.MAXPORTS
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Integer maxports;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.DESCRIPTION
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String description;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.UNEQUIPPED
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String unequipped;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.CARD_TPLT_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Integer cardTpltInstId;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.LAST_MOD_BY
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String lastModBy;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.LAST_MOD_TS
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Date lastModTs;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.PARENT_CARD_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Integer parentCardInstId;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.NBR_SUB_CARDS
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Short nbrSubCards;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.SLOT_OCCUPANCY
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Short slotOccupancy;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.SLOT_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Integer slotInstId;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.DYN_PORT_NAME_GEN_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Integer dynPortNameGenId;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.ROLE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String role;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.NAME
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String name;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.FR_REF_KEY_NAME
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String frRefKeyName;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.FR_REF_KEY_VALUE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String frRefKeyValue;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.MFG_PART_NUMBER
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String mfgPartNumber;

    /**
     
     * This field corresponds to the database column XNG.CARD_INST.AID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String aid;

    /**
     
     * This field corresponds to the database table XNG.CARD_INST
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private static final long serialVersionUID = 1L;

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.CARD_INST_ID
     *
     * @return the value of XNG.CARD_INST.CARD_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    
    /* Added for slot/card search */
    private Integer siteInstId;
    /**
	 * @return the siteInstId
	 */
	public Integer getSiteInstId() {
		return siteInstId;
	}

	/**
	 * @param siteInstId the siteInstId to set
	 */
	public void setSiteInstId(Integer siteInstId) {
		this.siteInstId = siteInstId;
	}

	public Integer getCardInstId() {
        return cardInstId;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.CARD_INST_ID
     *
     * @param cardInstId the value for XNG.CARD_INST.CARD_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setCardInstId(Integer cardInstId) {
        this.cardInstId = cardInstId;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.EQUIP_INST_ID
     *
     * @return the value of XNG.CARD_INST.EQUIP_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Integer getEquipInstId() {
        return equipInstId;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.EQUIP_INST_ID
     *
     * @param equipInstId the value for XNG.CARD_INST.EQUIP_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setEquipInstId(Integer equipInstId) {
        this.equipInstId = equipInstId;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.SLOT
     *
     * @return the value of XNG.CARD_INST.SLOT
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getSlot() {
        return slot;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.SLOT
     *
     * @param slot the value for XNG.CARD_INST.SLOT
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setSlot(String slot) {
        this.slot = slot == null ? null : slot.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.TYPE
     *
     * @return the value of XNG.CARD_INST.TYPE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getType() {
        return type;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.TYPE
     *
     * @param type the value for XNG.CARD_INST.TYPE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.STATUS
     *
     * @return the value of XNG.CARD_INST.STATUS
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getStatus() {
        return status;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.STATUS
     *
     * @param status the value for XNG.CARD_INST.STATUS
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.ALT_ID
     *
     * @return the value of XNG.CARD_INST.ALT_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getAltId() {
        return altId;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.ALT_ID
     *
     * @param altId the value for XNG.CARD_INST.ALT_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setAltId(String altId) {
        this.altId = altId == null ? null : altId.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.ORDERED
     *
     * @return the value of XNG.CARD_INST.ORDERED
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Date getOrdered() {
        return ordered;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.ORDERED
     *
     * @param ordered the value for XNG.CARD_INST.ORDERED
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setOrdered(Date ordered) {
        this.ordered = ordered;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.DUE
     *
     * @return the value of XNG.CARD_INST.DUE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Date getDue() {
        return due;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.DUE
     *
     * @param due the value for XNG.CARD_INST.DUE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setDue(Date due) {
        this.due = due;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.INSTALLED
     *
     * @return the value of XNG.CARD_INST.INSTALLED
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Date getInstalled() {
        return installed;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.INSTALLED
     *
     * @param installed the value for XNG.CARD_INST.INSTALLED
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setInstalled(Date installed) {
        this.installed = installed;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.IN_SERVICE
     *
     * @return the value of XNG.CARD_INST.IN_SERVICE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Date getInService() {
        return inService;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.IN_SERVICE
     *
     * @param inService the value for XNG.CARD_INST.IN_SERVICE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setInService(Date inService) {
        this.inService = inService;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.SCHED_DATE
     *
     * @return the value of XNG.CARD_INST.SCHED_DATE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Date getSchedDate() {
        return schedDate;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.SCHED_DATE
     *
     * @param schedDate the value for XNG.CARD_INST.SCHED_DATE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setSchedDate(Date schedDate) {
        this.schedDate = schedDate;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.DECOMMISSION
     *
     * @return the value of XNG.CARD_INST.DECOMMISSION
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Date getDecommission() {
        return decommission;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.DECOMMISSION
     *
     * @param decommission the value for XNG.CARD_INST.DECOMMISSION
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setDecommission(Date decommission) {
        this.decommission = decommission;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.SERIAL_NO
     *
     * @return the value of XNG.CARD_INST.SERIAL_NO
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getSerialNo() {
        return serialNo;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.SERIAL_NO
     *
     * @param serialNo the value for XNG.CARD_INST.SERIAL_NO
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo == null ? null : serialNo.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.BATCH_NO
     *
     * @return the value of XNG.CARD_INST.BATCH_NO
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getBatchNo() {
        return batchNo;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.BATCH_NO
     *
     * @param batchNo the value for XNG.CARD_INST.BATCH_NO
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo == null ? null : batchNo.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.BAR_CODE
     *
     * @return the value of XNG.CARD_INST.BAR_CODE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getBarCode() {
        return barCode;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.BAR_CODE
     *
     * @param barCode the value for XNG.CARD_INST.BAR_CODE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setBarCode(String barCode) {
        this.barCode = barCode == null ? null : barCode.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.PURCHASE_PRICE
     *
     * @return the value of XNG.CARD_INST.PURCHASE_PRICE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public BigDecimal getPurchasePrice() {
        return purchasePrice;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.PURCHASE_PRICE
     *
     * @param purchasePrice the value for XNG.CARD_INST.PURCHASE_PRICE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setPurchasePrice(BigDecimal purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.PURCHASE_DATE
     *
     * @return the value of XNG.CARD_INST.PURCHASE_DATE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Date getPurchaseDate() {
        return purchaseDate;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.PURCHASE_DATE
     *
     * @param purchaseDate the value for XNG.CARD_INST.PURCHASE_DATE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setPurchaseDate(Date purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.ASSET_LIFE
     *
     * @return the value of XNG.CARD_INST.ASSET_LIFE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public BigDecimal getAssetLife() {
        return assetLife;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.ASSET_LIFE
     *
     * @param assetLife the value for XNG.CARD_INST.ASSET_LIFE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setAssetLife(BigDecimal assetLife) {
        this.assetLife = assetLife;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.MAXPORTS
     *
     * @return the value of XNG.CARD_INST.MAXPORTS
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Integer getMaxports() {
        return maxports;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.MAXPORTS
     *
     * @param maxports the value for XNG.CARD_INST.MAXPORTS
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setMaxports(Integer maxports) {
        this.maxports = maxports;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.DESCRIPTION
     *
     * @return the value of XNG.CARD_INST.DESCRIPTION
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getDescription() {
        return description;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.DESCRIPTION
     *
     * @param description the value for XNG.CARD_INST.DESCRIPTION
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.UNEQUIPPED
     *
     * @return the value of XNG.CARD_INST.UNEQUIPPED
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getUnequipped() {
        return unequipped;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.UNEQUIPPED
     *
     * @param unequipped the value for XNG.CARD_INST.UNEQUIPPED
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setUnequipped(String unequipped) {
        this.unequipped = unequipped == null ? null : unequipped.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.CARD_TPLT_INST_ID
     *
     * @return the value of XNG.CARD_INST.CARD_TPLT_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Integer getCardTpltInstId() {
        return cardTpltInstId;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.CARD_TPLT_INST_ID
     *
     * @param cardTpltInstId the value for XNG.CARD_INST.CARD_TPLT_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setCardTpltInstId(Integer cardTpltInstId) {
        this.cardTpltInstId = cardTpltInstId;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.LAST_MOD_BY
     *
     * @return the value of XNG.CARD_INST.LAST_MOD_BY
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getLastModBy() {
        return lastModBy;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.LAST_MOD_BY
     *
     * @param lastModBy the value for XNG.CARD_INST.LAST_MOD_BY
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setLastModBy(String lastModBy) {
        this.lastModBy = lastModBy == null ? null : lastModBy.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.LAST_MOD_TS
     *
     * @return the value of XNG.CARD_INST.LAST_MOD_TS
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Date getLastModTs() {
        return lastModTs;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.LAST_MOD_TS
     *
     * @param lastModTs the value for XNG.CARD_INST.LAST_MOD_TS
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setLastModTs(Date lastModTs) {
        this.lastModTs = lastModTs;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.PARENT_CARD_INST_ID
     *
     * @return the value of XNG.CARD_INST.PARENT_CARD_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Integer getParentCardInstId() {
        return parentCardInstId;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.PARENT_CARD_INST_ID
     *
     * @param parentCardInstId the value for XNG.CARD_INST.PARENT_CARD_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setParentCardInstId(Integer parentCardInstId) {
        this.parentCardInstId = parentCardInstId;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.NBR_SUB_CARDS
     *
     * @return the value of XNG.CARD_INST.NBR_SUB_CARDS
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Short getNbrSubCards() {
        return nbrSubCards;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.NBR_SUB_CARDS
     *
     * @param nbrSubCards the value for XNG.CARD_INST.NBR_SUB_CARDS
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setNbrSubCards(Short nbrSubCards) {
        this.nbrSubCards = nbrSubCards;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.SLOT_OCCUPANCY
     *
     * @return the value of XNG.CARD_INST.SLOT_OCCUPANCY
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Short getSlotOccupancy() {
        return slotOccupancy;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.SLOT_OCCUPANCY
     *
     * @param slotOccupancy the value for XNG.CARD_INST.SLOT_OCCUPANCY
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setSlotOccupancy(Short slotOccupancy) {
        this.slotOccupancy = slotOccupancy;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.SLOT_INST_ID
     *
     * @return the value of XNG.CARD_INST.SLOT_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Integer getSlotInstId() {
        return slotInstId;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.SLOT_INST_ID
     *
     * @param slotInstId the value for XNG.CARD_INST.SLOT_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setSlotInstId(Integer slotInstId) {
        this.slotInstId = slotInstId;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.DYN_PORT_NAME_GEN_ID
     *
     * @return the value of XNG.CARD_INST.DYN_PORT_NAME_GEN_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Integer getDynPortNameGenId() {
        return dynPortNameGenId;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.DYN_PORT_NAME_GEN_ID
     *
     * @param dynPortNameGenId the value for XNG.CARD_INST.DYN_PORT_NAME_GEN_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setDynPortNameGenId(Integer dynPortNameGenId) {
        this.dynPortNameGenId = dynPortNameGenId;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.ROLE
     *
     * @return the value of XNG.CARD_INST.ROLE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getRole() {
        return role;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.ROLE
     *
     * @param role the value for XNG.CARD_INST.ROLE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setRole(String role) {
        this.role = role == null ? null : role.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.NAME
     *
     * @return the value of XNG.CARD_INST.NAME
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getName() {
        return name;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.NAME
     *
     * @param name the value for XNG.CARD_INST.NAME
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.FR_REF_KEY_NAME
     *
     * @return the value of XNG.CARD_INST.FR_REF_KEY_NAME
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getFrRefKeyName() {
        return frRefKeyName;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.FR_REF_KEY_NAME
     *
     * @param frRefKeyName the value for XNG.CARD_INST.FR_REF_KEY_NAME
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setFrRefKeyName(String frRefKeyName) {
        this.frRefKeyName = frRefKeyName == null ? null : frRefKeyName.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.FR_REF_KEY_VALUE
     *
     * @return the value of XNG.CARD_INST.FR_REF_KEY_VALUE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getFrRefKeyValue() {
        return frRefKeyValue;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.FR_REF_KEY_VALUE
     *
     * @param frRefKeyValue the value for XNG.CARD_INST.FR_REF_KEY_VALUE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setFrRefKeyValue(String frRefKeyValue) {
        this.frRefKeyValue = frRefKeyValue == null ? null : frRefKeyValue.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.MFG_PART_NUMBER
     *
     * @return the value of XNG.CARD_INST.MFG_PART_NUMBER
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getMfgPartNumber() {
        return mfgPartNumber;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.MFG_PART_NUMBER
     *
     * @param mfgPartNumber the value for XNG.CARD_INST.MFG_PART_NUMBER
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setMfgPartNumber(String mfgPartNumber) {
        this.mfgPartNumber = mfgPartNumber == null ? null : mfgPartNumber.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column XNG.CARD_INST.AID
     *
     * @return the value of XNG.CARD_INST.AID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getAid() {
        return aid;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column XNG.CARD_INST.AID
     *
     * @param aid the value for XNG.CARD_INST.AID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setAid(String aid) {
        this.aid = aid == null ? null : aid.trim();
    }
    
    @Override
	public String toString(){
    	return "CardDTO[cardInstId="+cardInstId+", equipInstId="+equipInstId+", slot="+slot
    			+", type="+type+", status="+status+", altId="+altId+", ordered="+ordered
    			+", due="+due+", installed="+installed+", inService="+inService+", schedDate="+schedDate+", decommission="+decommission
    			+", serialNo="+serialNo+", batchNo="+batchNo+", barCode="+barCode+", purchasePrice="+purchasePrice
    			+", purchaseDate="+purchaseDate+", assetLife="+assetLife+", maxports="+maxports+", description="+description
    			+", unequipped="+unequipped+", cardTpltInstId="+cardTpltInstId+", lastModBy="+lastModBy
    			+", lastModTs="+lastModTs+", parentCardInstId="+parentCardInstId
    			+", nbrSubCards="+nbrSubCards+", slotOccupancy="+slotOccupancy+", slotInstId="+slotInstId
    			+", dynPortNameGenId="+dynPortNameGenId+", role="+role+", name="+name
    			+", frRefKeyName="+frRefKeyName+", frRefKeyValue="+frRefKeyValue
    			+", mfgPartNumber="+mfgPartNumber+", aid="+aid+"]";
    }
}