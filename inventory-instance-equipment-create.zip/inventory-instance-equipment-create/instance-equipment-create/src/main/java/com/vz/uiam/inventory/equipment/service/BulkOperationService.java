package com.vz.uiam.inventory.equipment.service;



import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;

import com.vz.uiam.common.usermanagement.rest.model.DirDomainsDTO;
import com.vz.uiam.inventory.equipment.controller.EquipmentController;
import com.vz.uiam.inventory.equipment.controller.EquipmentRackController;
import com.vz.uiam.inventory.equipment.exception.DataNotFoundException;
import com.vz.uiam.inventory.equipment.model.BulkEquipRequestDTO;
import com.vz.uiam.inventory.equipment.model.EntityResponseDTO;
import com.vz.uiam.inventory.equipment.model.EquipDomainOperationDTO;
import com.vz.uiam.inventory.equipment.model.EquipmentDTO;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.model.Status;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateConstant;


@Service
public class BulkOperationService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BulkOperationService.class);
	
	@Autowired
	EquipmentController equipmentController;
	
	@Autowired
	EquipmentRackController equipmentRackController;
	
	@Autowired
	private EquipmentService equipmentService;
	
	@Autowired 
	private DomainService domainService;
	
	public EntityResponseDTO createEquipment(BulkEquipRequestDTO bulkEquipRequestDTO, String userID, HttpServletRequest request){
		EntityResponseDTO response = new EntityResponseDTO();
		List<Status> statusList = new ArrayList<>();
		if(bulkEquipRequestDTO.getEquipmentDTOV1() != null && !bulkEquipRequestDTO.getEquipmentDTOV1().isEmpty()){
			statusList.addAll(createShelf(bulkEquipRequestDTO.getEquipmentDTOV1(), userID, request));
		}
		if(bulkEquipRequestDTO.getEquipmentDTO() != null && !bulkEquipRequestDTO.getEquipmentDTO().isEmpty()) {
			statusList.addAll(createRack(bulkEquipRequestDTO.getEquipmentDTO(), userID, request));
		}
		response.setStatusList(statusList);
		return response;
	}

	public List<Status> createShelf(List<EquipmentDTOV1> equipmentDTOV1, String userID, HttpServletRequest request) {
		
		List<Status> statusList = new ArrayList<>();
		for(EquipmentDTOV1 equipment:equipmentDTOV1){
			Status status = new Status();			
			status.setName(equipment.getName());
			status.setContainer("SHELF");
			try{
				BindingResult errors =  new BeanPropertyBindingResult(equipment, EquipmentDTOV1.class.getName());
				EquipmentDTOV1 equipResponse = equipmentController.createShelf(equipment, userID, request, errors); 
				status.setEquipmentReference(equipResponse.getEquipmentReference());
				status.setStatusCode(InstanceEquipmentCreateConstant.SUCCESS);
				status.setStatusCode(InstanceEquipmentCreateConstant.CREATE_SUCCESS_SHELF);
			}catch (Exception e) {
				LOGGER.error("error", e);
				status.setStatusCode(InstanceEquipmentCreateConstant.FAILURE);
				status.setStatusCode(InstanceEquipmentCreateConstant.CREATE_FAILURE_SHELF);
			}
			statusList.add(status);
		}
		return statusList;
	}
	
	public List<Status> createRack(List<EquipmentDTO> equipmentDTO, String userID, HttpServletRequest request) {
		
		List<Status> statusList = new ArrayList<>();
		for(EquipmentDTO equipment:equipmentDTO){
			Status status = new Status();			
			status.setName(equipment.getName());
			status.setContainer("RACK");
			try{
				BindingResult errors =  new BeanPropertyBindingResult(equipment, EquipmentDTO.class.getName());
				EquipmentDTO equipResponse =  equipmentRackController.addRack(equipment, userID, request, errors);
				status.setEquipmentReference(equipResponse.getEquipmentReference());
				status.setStatusCode(InstanceEquipmentCreateConstant.SUCCESS);
				status.setStatusCode(InstanceEquipmentCreateConstant.CREATE_SUCCESS_RACK);
			}catch (Exception e) {
				LOGGER.error("error", e);
				status.setStatusCode(InstanceEquipmentCreateConstant.FAILURE);
				status.setStatusCode(InstanceEquipmentCreateConstant.CREATE_FAILURE_RACK);
			}
			statusList.add(status);
		}		
		return statusList;
	}
	
	public EntityResponseDTO bulkDomainCreation(List<EquipDomainOperationDTO> equipDomainOperationDTO, HttpServletRequest request){
		
		LOGGER.info("Start of BulkOperationService:: bulkDomainCreation()");
		
		EntityResponseDTO response = new EntityResponseDTO();
		List<Status> statusList = new ArrayList<>();
		List<Integer> domainsMappedToUser = domainService.findListOfDomainsMappedToRequestUser(request);
		if(domainsMappedToUser!= null && !domainsMappedToUser.isEmpty()){
			for(EquipDomainOperationDTO equipDomainDTO :equipDomainOperationDTO){				
				Status status = new Status();
				status.setEquipmentReference(equipDomainDTO.getEquipmentReference());
				List<DirDomainsDTO> domainList = new ArrayList<>();
				try{
					for(DirDomainsDTO domain: equipDomainDTO.getDomains()){
						if(domainsMappedToUser.contains(domain.getDomainId())){
							domainList.add(domain);
						}
					}
					EquipmentDTO eqp = new EquipmentDTO();
					eqp.setDomianNames(domainList);
					if(!domainList.isEmpty()){
						equipmentService.createEquipmentDomains(equipDomainDTO.getEquipmentReference(), eqp, request);
						status.setStatusCode(InstanceEquipmentCreateConstant.SUCCESS);
						status.setStatusMsg(InstanceEquipmentCreateConstant.DOMAIN_ADD_SUCCESS);
					} else{
						status.setStatusCode(InstanceEquipmentCreateConstant.FAILURE);
						status.setStatusMsg("Domain List is Empty");
					}				
				}catch (Exception e) {
					LOGGER.error("ERROR: {}", e);
					status.setStatusCode(InstanceEquipmentCreateConstant.FAILURE);
					status.setStatusMsg(InstanceEquipmentCreateConstant.DOMAIN_ADD_FAIL);
				}
				statusList.add(status);
			}
		} else{
			throw new DataNotFoundException("BulkOperationService#bulkDomainCreation", "Data Not Found", 
		              "Can't Find Domains for the mapped user #");
		}
		response.setStatusList(statusList);
		LOGGER.info("End of BulkOperationService:: bulkDomainCreation()");
		return response;		
	}
	
}
