package com.vz.uiam.inventory.equipment.exception;

import org.springframework.validation.FieldError;

import com.vz.uiam.inventory.equipment.enumeration.ErrorCodeEnum;

public class BadRequestException extends RuntimeException {

	private static final long serialVersionUID = -3992797190692194686L;
	final FieldError error;

	public BadRequestException(FieldError error) {
		super(error.getField() + " " + error.getCode() + " " +  error.getDefaultMessage());
		this.error  = error;
	}
	public BadRequestException(ErrorCodeEnum error){
		this(new FieldError(error.name(), error.getCode(), error.getDescription()));
	}

	public FieldError getError() {
		return error;
	}
	
}