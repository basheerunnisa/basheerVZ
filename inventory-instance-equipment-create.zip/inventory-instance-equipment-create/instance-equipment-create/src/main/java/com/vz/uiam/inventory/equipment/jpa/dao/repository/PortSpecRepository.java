package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.CardSpec;
import com.vz.uiam.inventory.equipment.jpa.dao.model.PortSpec;



@Transactional
public interface PortSpecRepository extends JpaRepository<PortSpec,Long> {

	List<PortSpec> findAllByCardSpec(List<Long> cardSpecIdList);

	List<PortSpec> findAllByCardSpecCardSpecRefId(Long cardSpecId);

	PortSpec findByPortSpecRefId(long portSpecRefId);

	List<PortSpec> findPortSpecsByParentPortSpecId(BigDecimal portSpecRefId);

	List<PortSpec> findByCardSpecOrderByDirectionAsc(CardSpec cardSpec);

	List<PortSpec> findByCardSpecCardSpecRefIdOrderByDirectionAsc(Long cardSpecRefId);

	List<PortSpec> findPortSpecsByParentPortSpecIdOrderByDirectionAsc(BigDecimal portSpecRefId);
	
	List<PortSpec> findByEquipmentSpecRefIdOrderByDirectionAsc(Long equipmentSpecRefId);

}