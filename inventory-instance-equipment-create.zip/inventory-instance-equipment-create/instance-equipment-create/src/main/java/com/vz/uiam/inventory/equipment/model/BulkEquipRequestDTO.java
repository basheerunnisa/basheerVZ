package com.vz.uiam.inventory.equipment.model;

import java.util.List;

public class BulkEquipRequestDTO {
		
	private List<EquipmentDTO> equipmentDTO;
	private List<EquipmentDTOV1> equipmentDTOV1;	
	
	
	public List<EquipmentDTO> getEquipmentDTO() {
		return equipmentDTO;
	}
	public void setEquipmentDTO(List<EquipmentDTO> equipmentDTO) {
		this.equipmentDTO = equipmentDTO;
	}
	public List<EquipmentDTOV1> getEquipmentDTOV1() {
		return equipmentDTOV1;
	}
	public void setEquipmentDTOV1(List<EquipmentDTOV1> equipmentDTOV1) {
		this.equipmentDTOV1 = equipmentDTOV1;
	}	
	
}
