package com.vz.uiam.inventory.equipment.model.validator;

import org.parboiled.common.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.vz.uiam.inventory.equipment.enumeration.ErrorCodeEnum;
import com.vz.uiam.inventory.equipment.model.VirtualEquipmentRequest;
import com.vz.uiam.inventory.equipment.service.VirtualEquipmentCreateService;


@Service
public class CreateVirtualEquipmentValidator implements Validator {

	private static final Logger LOGGER = LoggerFactory.getLogger(CreateVirtualEquipmentValidator.class);
	
	@Autowired
	private VirtualEquipmentCreateService virtualEquipmentService;
	
	/*
	 * (non-Javadoc)
	 * @see org.springframework.validation.Validator#supports(java.lang.Class)
	 */
	@Override
	public boolean supports(Class<?> arg0) {
		return VirtualEquipmentRequest.class.equals(arg0);
	}

	/*
	 * (non-Javadoc)
	 * @see org.springframework.validation.Validator#validate(java.lang.Object, org.springframework.validation.Errors)
	 */
	@Override
	public void validate(Object object, Errors errors) {
		
		VirtualEquipmentRequest equipReq = (VirtualEquipmentRequest) object;
		
		LOGGER.info("Create virtual equipment: Create Virtual Equipment Validator for physical eqp id: " + equipReq.getPhysicalEquipmentSpecId());

		if(equipReq.getPhysicalEquipmentSpecId() == null || equipReq.getPhysicalEquipmentSpecId() <= 0){
			errors.reject(ErrorCodeEnum.PHYSICAL_EQP_REQ_INVALID.getCode(), ErrorCodeEnum.PHYSICAL_EQP_REQ_INVALID.getDescription());
		}
		if(StringUtils.isEmpty(equipReq.getVirtualEquipmentTid())){
			errors.reject(ErrorCodeEnum.INV_VIRTUAL_EQP_TID.getCode(), ErrorCodeEnum.INV_VIRTUAL_EQP_TID.getDescription());
		}
		else if(virtualEquipmentService.checkForExistingVirtualEquipmentByEqpIdAndTid(equipReq.getPhysicalEquipmentSpecId(), equipReq.getVirtualEquipmentTid())){
			errors.reject(ErrorCodeEnum.VIRTUAL_EQP_WITH_TID_EXISTS.getCode(), ErrorCodeEnum.VIRTUAL_EQP_WITH_TID_EXISTS.getDescription());
		}	
	}
}
