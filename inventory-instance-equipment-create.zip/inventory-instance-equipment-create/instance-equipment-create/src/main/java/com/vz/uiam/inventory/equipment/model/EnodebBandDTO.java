package com.vz.uiam.inventory.equipment.model;

public class EnodebBandDTO {

	private Long bandClass;
	private String bandCategory;
	private String channelNumber;
	private Short sequence;
	
	public Long getBandClass() {
		return bandClass;
	}
	public void setBandClass(Long bandClass) {
		this.bandClass = bandClass;
	}
	public String getBandCategory() {
		return bandCategory;
	}
	public void setBandCategory(String bandCategory) {
		this.bandCategory = bandCategory;
	}
	public String getChannelNumber() {
		return channelNumber;
	}
	public void setChannelNumber(String channelNumber) {
		this.channelNumber = channelNumber;
	}
	public Short getSequence() {
		return sequence;
	}
	public void setSequence(Short sequence) {
		this.sequence = sequence;
	}
	
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "EnodebBandDTO [bandClass=" + bandClass + ", bandCategory=" + bandCategory + ", channelNumber="
				+ channelNumber + ", sequence=" + sequence + "]";
	}
}
