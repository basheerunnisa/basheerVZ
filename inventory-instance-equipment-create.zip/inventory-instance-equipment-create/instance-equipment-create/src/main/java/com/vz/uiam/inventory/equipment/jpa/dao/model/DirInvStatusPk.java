package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Creating the composite primary key for DIR_INV_STATUS table
 * 
 * @author ERWINER
 *
 */
@Embeddable
public class DirInvStatusPk implements Serializable {

	private static final long serialVersionUID = 5145349675771824957L;

	@Column(name = "INV_STATUS")
	private String status;

	@Column(name = "ENTITY_NAME")
	private String entityName;

	public DirInvStatusPk() {
		super();
	}

	public DirInvStatusPk(String status, String entityName) {
		this();
		this.status = status;
		this.entityName = entityName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DirInvStatusPk [status=" + status + ", entityName=" + entityName + "]";
	}

}
