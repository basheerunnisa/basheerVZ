package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.javers.core.metamodel.annotation.TypeName;

import com.vz.uiam.inventory.equipment.model.validator.EntityValidator;

/**
 * The persistent class for the SLOT_SPEC database table.
 * 
 */
@Entity
@Table(name = "SLOT_SPEC")
@TypeName("SlotSpec")
@NamedQuery(name = "SlotSpec.findAll", query = "SELECT s FROM SlotSpec s")
public class SlotSpec implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SLOT_SPEC_REF_ID")
	private long slotSpecRefId;

	private String aid;

	@Column(name = "DEPTH")
	private BigDecimal depth;

	private String description;

	@Column(name = "DIST_FROM_X")
	private BigDecimal distFromX;

	@Column(name = "DIST_FROM_Y")
	private BigDecimal distFromY;

	@Column(name = "DIST_FROM_Z")
	private BigDecimal distFromZ;

	private BigDecimal height;

	@Column(name = "LAST_MODIFIED_BY")
	private String lastModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_MODIFIED_TIME_STAMP")
	private Date lastModifiedTimeStamp;

	@Column(name = "LOGICAL_SLOT_NAME")
	private String logicalSlotName;

	@Column(name = "PARENT_CARD_SPEC_ID")
	private BigDecimal parentCardSpecId;

	@Column(name = "SIDE_IND")
	private String sideInd;

	@Column(name = "SLOT_NAME")
	private String slotName;

	@Column(name = "SLOT_NUMBER")
	private String slotNumber;

	@Column(name = "SLOT_STATUS")
	private String slotStatus;

	private BigDecimal width;

	@Column(name = "TRAFFIC_BEARING")
	private Boolean trafficBearing;

	@OneToMany(mappedBy = "slotCardSpecMapPk.slotSpecRefId")
	private List<SlotCardSpecMap> slotCardSpecMaps;

	@ManyToOne
	@JoinColumn(name = "EQUIPMENT_SPEC_REF_ID")
	private EquipmentSpec equipmentSpec;

	@Column(name = "SLOT_POSITION")
	private String slotPosition;

	
	@Column(name = "PLANE")
	private String plane;
	
	public SlotSpec() {
	}

	public long getSlotSpecRefId() {
		return this.slotSpecRefId;
	}

	public void setSlotSpecRefId(long slotSpecRefId) {
		this.slotSpecRefId = slotSpecRefId;
	}

	public String getAid() {
		return this.aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public BigDecimal getDepth() {
		return this.depth;
	}

	public void setDepth(BigDecimal depth) {
		this.depth = depth;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getDistFromX() {
		return this.distFromX;
	}

	public void setDistFromX(BigDecimal distFromX) {
		this.distFromX = distFromX;
	}

	public BigDecimal getDistFromY() {
		return this.distFromY;
	}

	public void setDistFromY(BigDecimal distFromY) {
		this.distFromY = distFromY;
	}

	public BigDecimal getDistFromZ() {
		return this.distFromZ;
	}

	public void setDistFromZ(BigDecimal distFromZ) {
		this.distFromZ = distFromZ;
	}

	public BigDecimal getHeight() {
		return this.height;
	}

	public void setHeight(BigDecimal height) {
		this.height = height;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifiedTimeStamp() {
		return this.lastModifiedTimeStamp;
	}

	public void setLastModifiedTimeStamp(Date lastModifiedTimeStamp) {
		this.lastModifiedTimeStamp = lastModifiedTimeStamp;
	}

	public String getLogicalSlotName() {
		return this.logicalSlotName;
	}

	public void setLogicalSlotName(String logicalSlotName) {
		this.logicalSlotName = logicalSlotName;
	}

	public BigDecimal getParentCardSpecId() {
		return this.parentCardSpecId;
	}

	public void setParentCardSpecId(BigDecimal parentCardSpecId) {
		this.parentCardSpecId = parentCardSpecId;
	}

	public String getSideInd() {
		return this.sideInd;
	}

	public void setSideInd(String sideInd) {
		this.sideInd = sideInd;
	}

	public String getSlotName() {
		return this.slotName;
	}

	public void setSlotName(String slotName) {
		this.slotName = slotName;
	}

	public String getSlotNumber() {
		return this.slotNumber;
	}

	public void setSlotNumber(String slotNumber) {
		this.slotNumber = slotNumber;
	}

	public String getSlotStatus() {
		return EntityValidator.validateStatus(slotStatus, this.getClass());
	}

	public void setSlotStatus(String slotStatus) {
		this.slotStatus = slotStatus;
	}

	public BigDecimal getWidth() {
		return this.width;
	}

	public void setWidth(BigDecimal width) {
		this.width = width;
	}

	public List<SlotCardSpecMap> getSlotCardSpecMaps() {
		return this.slotCardSpecMaps;
	}

	public void setSlotCardSpecMaps(List<SlotCardSpecMap> slotCardSpecMaps) {
		this.slotCardSpecMaps = slotCardSpecMaps;
	}

	public EquipmentSpec getEquipmentSpec() {
		return this.equipmentSpec;
	}

	public void setEquipmentSpec(EquipmentSpec equipmentSpec) {
		this.equipmentSpec = equipmentSpec;
	}

	public String getSlotPosition() {
		return slotPosition;
	}

	public void setSlotPosition(String slotPosition) {
		this.slotPosition = slotPosition;
	}

	public Boolean getTrafficBearing() {
		return trafficBearing;
	}

	public void setTrafficBearing(Boolean trafficBearing) {
		this.trafficBearing = trafficBearing;
	}

	public String getPlane() {
		return plane;
	}

	public void setPlane(String plane) {
		this.plane = plane;
	}

}