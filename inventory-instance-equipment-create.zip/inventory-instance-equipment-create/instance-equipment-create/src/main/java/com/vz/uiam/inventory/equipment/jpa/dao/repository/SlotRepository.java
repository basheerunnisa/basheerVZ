package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.Slot;



@Transactional
public interface SlotRepository extends JpaRepository<Slot,Long> {

	Slot findBySlotReferenceId(Long cardSlotRefId);

	List<Slot> findByEqpReferenceId(Long eqpReferenceId);

	@Query(value = "SELECT * FROM SLOT s WHERE EQP_REFERENCE_ID = :eqpReferenceId AND PARENT_CARD_REFERENCE_ID IS NULL", nativeQuery = true)
	List<Slot> findEligibleParentSlotsForVirtualEquipment(@Param("eqpReferenceId") Long eqpReferenceId);
}