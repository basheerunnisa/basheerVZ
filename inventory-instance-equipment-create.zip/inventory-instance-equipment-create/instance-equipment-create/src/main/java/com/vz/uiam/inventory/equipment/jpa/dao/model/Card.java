package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.javers.core.metamodel.annotation.TypeName;

import com.vz.uiam.inventory.equipment.model.validator.EntityValidator;

/**
 * The persistent class for the CARD database table.
 * 
 */
@Entity
@Table(name = "CARD")
@TypeName("Card")
@NamedQuery(name = "Card.findAll", query = "SELECT c FROM Card c")
public class Card implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "CARD_REFERENCE_ID")
	private Long cardReferenceId;

	@Column(name = "AID")
	private String aid;

	@Column(name = "ASSET_LIFE")
	private BigDecimal assetLife;

	@Column(name = "BAR_CODE")
	private String barCode;

	@Column(name = "BATCH_NO")
	private String batchNo;

	@Column(name = "CARD_DEPTH")
	private BigDecimal cardDepth;

	@Column(name = "CARD_DESCRIPTION")
	private String cardDescription;

	@Column(name = "CARD_FUNCTIONAL_TYPE")
	private String cardFunctionalType;

	@Column(name = "CARD_HEIGHT")
	private BigDecimal cardHeight;

	@Column(name = "CARD_NAME")
	private String cardName;

	@Temporal(TemporalType.DATE)
	@Column(name = "CARD_ORDERED_DATE")
	private Date cardOrderedDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "CARD_PURCHASE_DATE")
	private Date cardPurchaseDate;

	@Column(name = "CARD_PURCHASE_PRICE")
	private String cardPurchasePrice;

	@Temporal(TemporalType.DATE)
	@Column(name = "CARD_REMOVAL_DATE")
	private Date cardRemovalDate;

	@Column(name = "CARD_ROLE")
	private String cardRole;

	@Column(name = "CARD_SERIAL_NO")
	private String cardSerialNo;

	@Column(name = "CARD_SPEC_REF_ID")
	private Long cardSpecRefId;

	@Column(name = "CARD_WIDTH")
	private BigDecimal cardWidth;

	private String clei;

	@Temporal(TemporalType.DATE)
	private Date due;

	@Column(name = "EQP_REFERENCE_ID")
	private Long eqpReferenceId;

	@Column(name = "EQP_SOURCE")
	private String eqpSource;

	@Column(name = "FR_REF_KEY_NAME")
	private String frRefKeyName;

	@Column(name = "FR_REF_KEY_VALUE")
	private String frRefKeyValue;

	@Temporal(TemporalType.DATE)
	@Column(name = "IN_SERVICE_DATE")
	private Date inServiceDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "INSTALLED_DATE")
	private Date installedDate;

	@Column(name = "IP_ADDRESS")
	private String ipAddress;

	@Column(name = "IS_CHASSIS")
	private String isChassis;

	@Column(name = "LAST_MODIFIED_BY")
	private String lastModifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_MODIFIED_TIME_STAMP")
	private Date lastModifiedTimeStamp;

	private String manufacturer;

	@Column(name = "MATERIAL_ID")
	private String materialId;

	@Column(name = "MAX_PORTS")
	private BigDecimal maxPorts;

	@Column(name = "NBR_SUB_CARDS")
	private BigDecimal nbrSubCards;

	@Column(name = "ORDER_NUMBER")
	private String orderNumber;

	@Column(name = "PARENT_CARD_REF_ID")
	private Long parentCardRefId;

	@Column(name = "PART_NUM")
	private String partNum;

	@Temporal(TemporalType.DATE)
	@Column(name = "SCHEDULED_DATE")
	private Date scheduledDate;

	@Column(name = "SLOT_NAME")
	private String slotName;

	@Column(name = "SLOT_OCC_X")
	private BigDecimal slotOccX;

	@Column(name = "SLOT_OCC_Y")
	private BigDecimal slotOccY;

	@Column(name = "SLOT_OCCUPANCY")
	private BigDecimal slotOccupancy;

	private BigDecimal subslots;

	@Column(name = "SW_REVISION")
	private String swRevision;

	@Column(name = "CARD_TYPE")
	private String cardType;

	@Column(name = "INV_STATUS")
	private String invStatus;

	@Column(name = "TRAFFIC_BEARING")
	private Boolean trafficBearing;

	@ManyToOne
	@JoinColumn(name = "SLOT_REFERENCE_ID")
	private Slot slot;

	public Card() {
	}

	public Long getCardReferenceId() {
		return this.cardReferenceId;
	}

	public void setCardReferenceId(Long cardReferenceId) {
		this.cardReferenceId = cardReferenceId;
	}

	public String getAid() {
		return this.aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public BigDecimal getAssetLife() {
		return this.assetLife;
	}

	public void setAssetLife(BigDecimal assetLife) {
		this.assetLife = assetLife;
	}

	public String getBarCode() {
		return this.barCode;
	}

	public void setBarCode(String barCode) {
		this.barCode = barCode;
	}

	public String getBatchNo() {
		return this.batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public BigDecimal getCardDepth() {
		return this.cardDepth;
	}

	public void setCardDepth(BigDecimal cardDepth) {
		this.cardDepth = cardDepth;
	}

	public String getCardDescription() {
		return this.cardDescription;
	}

	public void setCardDescription(String cardDescription) {
		this.cardDescription = cardDescription;
	}

	public String getCardFunctionalType() {
		return this.cardFunctionalType;
	}

	public void setCardFunctionalType(String cardFunctionalType) {
		this.cardFunctionalType = cardFunctionalType;
	}

	public BigDecimal getCardHeight() {
		return this.cardHeight;
	}

	public void setCardHeight(BigDecimal cardHeight) {
		this.cardHeight = cardHeight;
	}

	public String getCardName() {
		return this.cardName;
	}

	public void setCardName(String cardName) {
		this.cardName = cardName;
	}

	public Date getCardOrderedDate() {
		return this.cardOrderedDate;
	}

	public void setCardOrderedDate(Date cardOrderedDate) {
		this.cardOrderedDate = cardOrderedDate;
	}

	public Date getCardPurchaseDate() {
		return this.cardPurchaseDate;
	}

	public void setCardPurchaseDate(Date cardPurchaseDate) {
		this.cardPurchaseDate = cardPurchaseDate;
	}

	public String getCardPurchasePrice() {
		return this.cardPurchasePrice;
	}

	public void setCardPurchasePrice(String cardPurchasePrice) {
		this.cardPurchasePrice = cardPurchasePrice;
	}

	public Date getCardRemovalDate() {
		return this.cardRemovalDate;
	}

	public void setCardRemovalDate(Date cardRemovalDate) {
		this.cardRemovalDate = cardRemovalDate;
	}

	public String getCardRole() {
		return this.cardRole;
	}

	public void setCardRole(String cardRole) {
		this.cardRole = cardRole;
	}

	public String getCardSerialNo() {
		return this.cardSerialNo;
	}

	public void setCardSerialNo(String cardSerialNo) {
		this.cardSerialNo = cardSerialNo;
	}

	public Long getCardSpecRefId() {
		return this.cardSpecRefId;
	}

	public void setCardSpecRefId(Long cardSpecRefId) {
		this.cardSpecRefId = cardSpecRefId;
	}

	public BigDecimal getCardWidth() {
		return this.cardWidth;
	}

	public void setCardWidth(BigDecimal cardWidth) {
		this.cardWidth = cardWidth;
	}

	public String getClei() {
		return this.clei;
	}

	public void setClei(String clei) {
		this.clei = clei;
	}

	public Date getDue() {
		return this.due;
	}

	public void setDue(Date due) {
		this.due = due;
	}

	public Long getEqpReferenceId() {
		return this.eqpReferenceId;
	}

	public void setEqpReferenceId(Long eqpReferenceId) {
		this.eqpReferenceId = eqpReferenceId;
	}

	public String getEqpSource() {
		return this.eqpSource;
	}

	public void setEqpSource(String eqpSource) {
		this.eqpSource = eqpSource;
	}

	public String getFrRefKeyName() {
		return this.frRefKeyName;
	}

	public void setFrRefKeyName(String frRefKeyName) {
		this.frRefKeyName = frRefKeyName;
	}

	public String getFrRefKeyValue() {
		return this.frRefKeyValue;
	}

	public void setFrRefKeyValue(String frRefKeyValue) {
		this.frRefKeyValue = frRefKeyValue;
	}

	public Date getInServiceDate() {
		return this.inServiceDate;
	}

	public void setInServiceDate(Date inServiceDate) {
		this.inServiceDate = inServiceDate;
	}

	public Date getInstalledDate() {
		return this.installedDate;
	}

	public void setInstalledDate(Date installedDate) {
		this.installedDate = installedDate;
	}

	public String getIpAddress() {
		return this.ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getIsChassis() {
		return this.isChassis;
	}

	public void setIsChassis(String isChassis) {
		this.isChassis = isChassis;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifiedTimeStamp() {
		return this.lastModifiedTimeStamp;
	}

	public void setLastModifiedTimeStamp(Date lastModifiedTimeStamp) {
		this.lastModifiedTimeStamp = lastModifiedTimeStamp;
	}

	public String getManufacturer() {
		return this.manufacturer;

	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getMaterialId() {
		return this.materialId;
	}

	public void setMaterialId(String materialId) {
		this.materialId = materialId;
	}

	public BigDecimal getMaxPorts() {
		return this.maxPorts;
	}

	public void setMaxPorts(BigDecimal maxPorts) {
		this.maxPorts = maxPorts;
	}

	public BigDecimal getNbrSubCards() {
		return this.nbrSubCards;
	}

	public void setNbrSubCards(BigDecimal nbrSubCards) {
		this.nbrSubCards = nbrSubCards;
	}

	public String getOrderNumber() {
		return this.orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public Long getParentCardRefId() {
		return this.parentCardRefId;
	}

	public void setParentCardRefId(Long parentCardRefId) {
		this.parentCardRefId = parentCardRefId;
	}

	public String getPartNum() {
		return this.partNum;
	}

	public void setPartNum(String partNum) {
		this.partNum = partNum;
	}

	public Date getScheduledDate() {
		return this.scheduledDate;
	}

	public void setScheduledDate(Date scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public String getSlotName() {
		return this.slotName;
	}

	public void setSlotName(String slotName) {
		this.slotName = slotName;
	}

	public BigDecimal getSlotOccX() {
		return this.slotOccX;
	}

	public void setSlotOccX(BigDecimal slotOccX) {
		this.slotOccX = slotOccX;
	}

	public BigDecimal getSlotOccY() {
		return this.slotOccY;
	}

	public void setSlotOccY(BigDecimal slotOccY) {
		this.slotOccY = slotOccY;
	}

	public BigDecimal getSlotOccupancy() {
		return this.slotOccupancy;
	}

	public void setSlotOccupancy(BigDecimal slotOccupancy) {
		this.slotOccupancy = slotOccupancy;
	}

	public BigDecimal getSubslots() {
		return this.subslots;
	}

	public void setSubslots(BigDecimal subslots) {
		this.subslots = subslots;
	}

	public String getSwRevision() {
		return this.swRevision;
	}

	public void setSwRevision(String swRevision) {
		this.swRevision = swRevision;
	}

	public String getCardType() {
		return EntityValidator.validateType(cardType, this.getClass());	
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getInvStatus() {
		return EntityValidator.validateStatus(this.invStatus, this.getClass());
	}

	public void setInvStatus(String invStatus) {
		this.invStatus = invStatus;
	}

	public Slot getSlot() {
		return slot;
	}

	public void setSlot(Slot slot) {
		this.slot = slot;
	}

	public Boolean getTrafficBearing() {
		return trafficBearing;
	}

	public void setTrafficBearing(Boolean trafficBearing) {
		this.trafficBearing = trafficBearing;
	}

}