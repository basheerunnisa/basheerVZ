package com.vz.uiam.inventory.equipment.service;

import java.io.IOException;
import java.util.List;

/**
 * <p>
 * This is the service for IP Assignment
 * </p>
 * 
 * @author Chintan Patel
 * @date 10-Nov-2017
 *
 */
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.common.usermanagement.utility.UserUtilities;
import com.vz.uiam.inventory.equipment.enumeration.ErrorCodeEnum;
import com.vz.uiam.inventory.equipment.exception.AssignmentServiceFailureException;
import com.vz.uiam.inventory.equipment.model.NetworkIpv4;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateConstant;
import com.vz.uiam.inventory.instance.rest.api.model.AssignNextAvailNonPreassignDTO;
import com.vz.uiam.inventory.instance.rest.api.model.AssignmentServiceErrorResponseDTO;

@Service
public class IPAssignmentRestService {

	private static final Logger LOGGER = LoggerFactory.getLogger(IPAssignmentRestService.class);

	@Autowired
	private String ipAssignmentServiceUrl;

	@Autowired
	private String svcUserName;

	@Autowired
	private String svcPassword;
	
	@Autowired
	private RestTemplate restTemplate;

	/**
	 * <p>
	 * This method is userd to get IPV4 ipAddress
	 * </p>
	 * 
	 * @param assignNextAvailNonPreassignDTO
	 * @return
	 */
	public NetworkIpv4 assignNextAvailableIp(AssignNextAvailNonPreassignDTO assignNextAvailNonPreassignDTO) {
		HttpStatus httpStatus = null;
		NetworkIpv4 ipAssignmentResponse = null;
		String errorResponseBody = null;
		long startTime = System.currentTimeMillis();
		List<AssignmentServiceErrorResponseDTO> assignmentServiceErrorResponseDTOs = null;
		ObjectMapper mapper = null;
		String assignUrl = ipAssignmentServiceUrl + "assignmentService/assignedNetworkByNetSizeSplit/"
				+ InstanceEquipmentCreateConstant.IP_VERSION_4;
		LOGGER.info("Attempting call Assignment service with url: {} , and request: {}", assignUrl,
				assignNextAvailNonPreassignDTO);

		try {
			mapper = new ObjectMapper();
			LOGGER.info("Ip Assignment Request details for :{} ,{}", assignNextAvailNonPreassignDTO.getComment(),
					mapper.writeValueAsString(assignNextAvailNonPreassignDTO));

			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders = UserUtilities.addSecurityHeader(httpHeaders, svcUserName, svcPassword);
			HttpEntity<AssignNextAvailNonPreassignDTO> entityRequest = new HttpEntity<AssignNextAvailNonPreassignDTO>(
					assignNextAvailNonPreassignDTO, httpHeaders);

			HttpEntity<NetworkIpv4> entityResponse = restTemplate.exchange(assignUrl, HttpMethod.POST, entityRequest,
					NetworkIpv4.class);

			long endTime = System.currentTimeMillis();
			LOGGER.debug("Total time taken to get Response from IP Assignment Service for:{} --->: {}",
					assignNextAvailNonPreassignDTO.getComment(), endTime-startTime);
			ipAssignmentResponse = entityResponse.getBody();
			httpStatus = HttpStatus.OK;
		} catch (HttpClientErrorException | HttpServerErrorException e) {
			LOGGER.error("Unable to call assignment-service: statusCode: {} message: {} message1: {} responseBody: {}",
					e.getStatusCode(), e, e.getMessage(), e.getResponseBodyAsString());
			httpStatus = e.getStatusCode();
			errorResponseBody = e.getResponseBodyAsString();
			String errorCode = null;
			String errorMessage = null;
			try {
				assignmentServiceErrorResponseDTOs = mapper.readValue(errorResponseBody,
						new TypeReference<List<AssignmentServiceErrorResponseDTO>>() {
						});
			} catch (IOException ex) {
				LOGGER.info("Error while deserializing the ErrorResponseDTO from assignment-service, error details: {}"
						+ ex);
				throw new AssignmentServiceFailureException(InstanceEquipmentCreateConstant.ERROR,
						ErrorCodeEnum.UNABLE_TO_DESERIALIZE_ERROR_RESPONSE_FROM_ASSIGNMENT_SERVICE.getCode(),
						String.format(ErrorCodeEnum.UNABLE_TO_DESERIALIZE_ERROR_RESPONSE_FROM_ASSIGNMENT_SERVICE
								.getDescription(), errorResponseBody));
			}
			LOGGER.info("The exception from response body is :" + errorResponseBody);
			if (!assignmentServiceErrorResponseDTOs.isEmpty() && assignmentServiceErrorResponseDTOs != null) {
				errorCode = assignmentServiceErrorResponseDTOs.get(0).getCode();
				errorMessage = assignmentServiceErrorResponseDTOs.get(0).getMessage();
			} else {
				errorCode = ErrorCodeEnum.ASSIGNMENT_SERVICE_CALL_ERROR.getCode();
				errorMessage = String.format(ErrorCodeEnum.ASSIGNMENT_SERVICE_CALL_ERROR.getDescription(),
						errorResponseBody);
			}
			throw new AssignmentServiceFailureException(InstanceEquipmentCreateConstant.ERROR, errorCode, errorMessage);
		} catch (Exception e) {
			LOGGER.error("Unable to call Assignment service with error {}", e);
			throw new AssignmentServiceFailureException(InstanceEquipmentCreateConstant.ERROR,
					ErrorCodeEnum.ASSIGNMENT_SERVICE_CALL_ERROR.getCode(),
					String.format(ErrorCodeEnum.ASSIGNMENT_SERVICE_CALL_ERROR.getDescription(), errorResponseBody));
		}
		if ((HttpStatus.OK == httpStatus) && ipAssignmentResponse != null) {
			LOGGER.info("SUCCESS in Calling Assignment Service with Circuit:{} comments:{}, ",
					assignNextAvailNonPreassignDTO.getComment(), assignNextAvailNonPreassignDTO.getSite());
		} else {
			LOGGER.error("FAILURE in Calling Assignment Service :{} " , ipAssignmentResponse);
			throw new AssignmentServiceFailureException(InstanceEquipmentCreateConstant.ERROR,
					ErrorCodeEnum.ASSIGNMENT_SERVICE_CALL_ERROR.getCode(),
					String.format(ErrorCodeEnum.ASSIGNMENT_SERVICE_CALL_ERROR.getDescription(), errorResponseBody));
		}

		return ipAssignmentResponse;

	}

}
