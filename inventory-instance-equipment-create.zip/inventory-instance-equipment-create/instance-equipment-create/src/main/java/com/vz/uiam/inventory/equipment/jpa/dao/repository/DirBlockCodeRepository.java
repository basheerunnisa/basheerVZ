package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.DirBlockCode;

/**
 * <p>
 * JPA repository for DB table -> DIR_BLOCK_CODE
 * 
 * @author Asif Billa
 * @date 20-June-2017
 *
 */
@Transactional
public interface DirBlockCodeRepository extends JpaRepository<DirBlockCode, String> {

	DirBlockCode findByBlockReasonCode(String blockReasonCode);
	
}