package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import org.javers.spring.annotation.JaversSpringDataAuditable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.EquipmentDomainMap;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EquipmentDomainMapPk;

@Transactional
@JaversSpringDataAuditable
public interface EquipmentDomainMapRepository extends JpaRepository<EquipmentDomainMap, EquipmentDomainMapPk> {

}
