package com.vz.uiam.inventory.equipment.jpa.dao.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.javers.core.metamodel.annotation.TypeName;

@Entity
@Table(name = "DIR_INVENTORY_CONFIG")
@TypeName("DirInventoryConfig")
@NamedQuery(name = "DirInventoryConfig.findAll", query = "SELECT d FROM DirInventoryConfig d")
public class DirInventoryConfig {

	@Id
	@Column(name = "CONFIG_ID")
	private Long configId;

	@Column(name = "GROUP_NAME")
	private String groupName;
	
	@Column(name = "CONFIG_NAME")
	private String configName;

	@Column(name = "CONFIG_VALUE")
	private String configValue;

	@Column(name = "SEQUENCE")
	private Short sequence;

	@Column(name = "DESCRIPTION")
	private String description;

	public Long getConfigId() {
		return configId;
	}

	public void setConfigId(Long configId) {
		this.configId = configId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getConfigName() {
		return configName;
	}

	public void setConfigName(String configName) {
		this.configName = configName;
	}

	public String getConfigValue() {
		return configValue;
	}

	public void setConfigValue(String configValue) {
		this.configValue = configValue;
	}

	public Short getSequence() {
		return sequence;
	}

	public void setSequence(Short sequence) {
		this.sequence = sequence;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "DirInventoryConfig [configId=" + configId + ", groupName=" + groupName + ", configName=" + configName
				+ ", configValue=" + configValue + ", sequence=" + sequence + ", description=" + description + "]";
	}

}
