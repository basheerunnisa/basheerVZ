package com.vz.uiam.inventory.equipment.config;

import java.text.SimpleDateFormat;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestTemplate;

import com.vz.uiam.inventory.equipment.jpa.dao.model.AuxiliaryEquipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Card;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EnodebDetails;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EnodebSector;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Slot;
import com.vz.uiam.inventory.equipment.model.AuxiliaryDTO;
import com.vz.uiam.inventory.equipment.model.CardDTO;
import com.vz.uiam.inventory.equipment.model.EnodebDetailsDTO;
import com.vz.uiam.inventory.equipment.model.EnodebSectorDTO;
import com.vz.uiam.inventory.equipment.model.EquipmentDTO;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.model.SlotDTO;
import com.vz.uiam.inventory.equipment.model.mapper.ResourceMapper;
import com.vz.uiam.inventory.equipment.service.KafkaEventPublisher;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Configuration
@EnableTransactionManagement
@EnableEurekaClient
public class AppConfig {

	@Value("${ivapp.service.username}")
	private String svcUserName;

	@Value("${ivapp.service.password}")
	private String svcPassword;

	@Value("${services.specification-attributes.url}")
	private String specificationAttributesUrl;
	
	@Value("${services.ip.assignment.url}")
	private String ipAssignmentServiceUrl;
	
	@Bean
    String ipAssignmentServiceUrl() {
	return ipAssignmentServiceUrl;
    } 

	@Bean
	@ConfigurationProperties(prefix = "inventory.datasource")
	DataSource invDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean
	Jackson2ObjectMapperBuilder jacksonBuilder() {
		Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder();
		builder.indentOutput(true).dateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
		return builder;
	}
 
	@Bean
	ResourceMapper resourceMapper() {
		return new ResourceMapper();
	}

	@Bean
	String svcUserName() {
		return svcUserName;
	}

	@Bean
	String svcPassword() {
		return svcPassword;
	}

	@Bean
	String specificationAttributesUrl(){
		return specificationAttributesUrl;
	}
	
	@Bean
	MapperFacade mapperFacade() {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();

		factory.classMap(Equipment.class, EquipmentDTOV1.class).field("eqpReferenceId", "equipmentReference")
				.field("distFromX", "distToBase").field("distFromY", "distToLeft").field("distFromZ", "distToFront")
				.field("eqpClei", "clei").field("eqpDepth", "depth").field("eqpHeight", "height")
				.field("eqpManufacturer", "vendor").field("eqpModel", "model").field("eqpName", "name")
				.field("eqpName", "shelfName").field("eqpPurchaseDate", "purchaseDate")
				.field("eqpPurchasePrice", "purchasePrice").field("eqpWidth", "width")
				.field("ineffectDate", "inServiceDate").field("lastModifiedBy", "modifiedUser")
				.field("lastModifiedTimeStamp", "modifiedTimeStamp").field("locationClli", "clli")
				.field("mgmtIpAddress", "ipAddress").field("orderDate", "orderedDate").field("partNum", "mfgPartNumber")
				.field("equipmentSpecName", "templateName").field("logicalShelf", "logicalShelf")
				.field("physicalShelfPosition", "physicalShelf").field("tidPhysical", "targetId").byDefault()
				.register();

		factory.classMap(Equipment.class, EquipmentDTO.class).field("eqpReferenceId", "equipmentReference")
				.field("distFromX", "distToBase").field("distFromY", "distToLeft").field("distFromZ", "distToFront")
				.field("eqpClei", "clei").field("eqpDepth", "depth").field("eqpHeight", "height")
				.field("eqpManufacturer", "vendor").field("eqpModel", "model").field("eqpName", "name")
				.field("eqpPurchaseDate", "purchaseDate").field("eqpPurchasePrice", "purchasePrice")
				.field("eqpWidth", "width").field("equipmentSpecName", "templateName")
				.field("ineffectDate", "inServiceDate").field("lastModifiedBy", "modifiedUser")
				.field("lastModifiedTimeStamp", "modifiedTimeStamp").field("locationClli", "clli")
				.field("logicalShelf", "logicalShelf").field("mgmtIpAddress", "ipAddress")
				.field("orderDate", "orderedDate").field("partNum", "mfgPartNumber")
				.field("physicalShelfPosition", "physicalShelf").field("tidPhysical", "targetId").byDefault()
				.register();

		factory.classMap(Card.class, CardDTO.class).field("invStatus", "cardStatus")
				.field("parentCardRefId", "parentCardId").field("orderNumber", "workOrderNumber")
				.field("eqpReferenceId", "equipmentInstId").field("cardSpecRefId", "cardSpecId")
				.field("cardReferenceId", "cardId").byDefault().register();

		factory.classMap(Slot.class, SlotDTO.class).field("slotReferenceId", "slotInstId")
				.field("slotNumber", "relOrder").field("parentCardReferenceId", "parentCardInstId")
				.field("cardReferenceId", "cardInstId").field("height", "dimHeight").field("width", "dimWidth")
				.field("depth", "dimDepth").field("distFromX", "dimDistToBase").field("distFromY", "dimDistToLeft")
				.field("distFromZ", "dimDistToFront").byDefault().register();

		factory.classMap(AuxiliaryEquipment.class, AuxiliaryDTO.class).byDefault().register();
		factory.classMap(EnodebDetails.class, EnodebDetailsDTO.class).byDefault().register();
		factory.classMap(EnodebSector.class, EnodebSectorDTO.class).byDefault().register();
	
		return factory.getMapperFacade();
	}

	@Bean
	KafkaEventPublisher kafkaEventPublisher() {
		return new KafkaEventPublisher();
	}

	@Bean
	EntityValidatorBean beanStatusValidator() {
		return new EntityValidatorBean();
	}

	@Bean
	RestTemplate restTemplate() {
		return new RestTemplate();
	}


}
