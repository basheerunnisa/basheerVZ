package com.vz.uiam.inventory.equipment.model.validator;

import java.util.Collection;
import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.vz.uiam.inventory.equipment.jpa.dao.repository.AuxiliaryRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.SiteRepository;
import com.vz.uiam.inventory.equipment.model.AuxiliaryDTO;

@Component
public class AuxiliaryCreateValidator implements Validator {

	@Autowired
	private AuxiliaryRepository auxiliaryRepository;
	@Autowired
	private SiteRepository siteRepository;
	
	/*
	 * (non-Javadoc)
	 * @see org.springframework.validation.Validator#supports(java.lang.Class)
	 */
	@Override
	public boolean supports(Class<?> clazz) {
		
		Class<?>[] classes = new Class<?>[]{
			AuxiliaryDTO.class,
			Collection.class
		};
		for(Class<?> c : classes){
			if(c.isAssignableFrom(clazz)){
				return true;
			}
		}
		return false;
	}
	
	/*
	 * (non-Javadoc)
	 * @see org.springframework.validation.Validator#validate(java.lang.Object, org.springframework.validation.Errors)
	 */
	@Override
	public void validate(Object target, Errors errors) {
		
		if(target instanceof Collection){
			Iterator<?> i = ((Collection<?>) target).iterator();
			while(i.hasNext()){
				validate(i.next(), errors);
			}
			return;
		}
		
		AuxiliaryDTO auxDTO = (AuxiliaryDTO) target;
		
		if(auxDTO.getHostname() == null) {
			errors.reject(Integer.toString(HttpStatus.BAD_REQUEST.value()), "Hostname is Mandatory!");
			
		} else {
			if(auxiliaryRepository.findByHostnameIgnoreCase(auxDTO.getHostname()) != null){
				errors.reject(Integer.toString(HttpStatus.BAD_REQUEST.value()), "Hostname already exists and must be unique ignoring case.");
			}
		}
		if(auxDTO.getSiteReferenceId() == null){
			errors.reject(Integer.toString(HttpStatus.BAD_REQUEST.value()), "Site Reference Id is Mandatory.");
		} else {
			if(siteRepository.findOne(auxDTO.getSiteReferenceId()) == null){
				errors.reject(Integer.toString(HttpStatus.BAD_REQUEST.value()), "Site Reference Id must reference an actual Site.");
			}
		}
		if(auxDTO.getAuxType() == null || auxDTO.getAuxType().trim().isEmpty()){
			errors.reject(Integer.toString(HttpStatus.BAD_REQUEST.value()), "Type is Mandatory.");
		}
		if(auxDTO.getAuxStatus() == null || auxDTO.getAuxStatus().trim().isEmpty()){
			errors.reject(Integer.toString(HttpStatus.BAD_REQUEST.value()), "Status is Mandatory.");
		}
	}
}













