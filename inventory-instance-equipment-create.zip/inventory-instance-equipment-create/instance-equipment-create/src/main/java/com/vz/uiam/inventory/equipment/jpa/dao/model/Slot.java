package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.javers.core.metamodel.annotation.TypeName;

import com.vz.uiam.inventory.equipment.model.validator.EntityValidator;

/**
 * The persistent class for the SLOT database table.
 * 
 */
@Entity
@Table(name = "SLOT")
@TypeName("Slot")
@NamedQuery(name = "Slot.findAll", query = "SELECT s FROM Slot s")

public class Slot implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SLOT_REFERENCE_ID")
	private Long slotReferenceId;

	private String aid;

	@Column(name = "CARD_REFERENCE_ID")
	private Long cardReferenceId;

	@Column(name = "DEPTH")
	private BigDecimal depth;

	@Column(name = "DIST_FROM_X")
	private BigDecimal distFromX;

	@Column(name = "DIST_FROM_Y")
	private BigDecimal distFromY;

	@Column(name = "DIST_FROM_Z")
	private BigDecimal distFromZ;

	@Column(name = "FR_REF_KEY_NAME")
	private String frRefKeyName;

	@Column(name = "FR_REF_KEY_VALUE")
	private String frRefKeyValue;

	private BigDecimal height;

	@Column(name = "LAST_MODIFIED_BY")
	private String lastModifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_MODIFIED_TIME_STAMP")
	private Date lastModifiedTimeStamp;

	@Column(name = "LOGICAL_SLOT_NAME")
	private String logicalSlotName;

	@Column(name = "PARENT_CARD_REFERENCE_ID")
	private Long parentCardReferenceId;

	@Column(name = "SIDE_IND")
	private String sideInd;

	@Column(name = "SLOT_NAME")
	private String slotName;

	@Column(name = "SLOT_NUMBER")
	private String slotNumber;

	@Column(name = "SLOT_POSITION")
	private String slotPosition;

	@Column(name = "SLOT_SPEC_REF_ID")
	private Long slotSpecRefId;

	private BigDecimal width;

	@Column(name = "TRAFFIC_BEARING")
	private Boolean trafficBearing;

	@OneToMany(mappedBy = "slot")
	private List<Card> cards;

	@Column(name = "SLOT_STATUS")
	private String dirSlotStatus;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "EQP_REFERENCE_ID", insertable = false, updatable = false)
	private Equipment equipment;

	@Column(name = "INSTANCE_TYPE")
	private String instanceType;

	@Column(name = "PHYSICAL_SLOT_REFERENCE_ID")
	private Long physicalSlotReferenceId;

	@Column(name = "EQP_REFERENCE_ID")
	private Long eqpReferenceId;

	@Column(name = "PLANE")
	private String plane;
	
	public Slot() {
	}

	public Long getSlotReferenceId() {
		return this.slotReferenceId;
	}

	public void setSlotReferenceId(Long slotReferenceId) {
		this.slotReferenceId = slotReferenceId;
	}

	public String getAid() {
		return this.aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public Long getCardReferenceId() {
		return this.cardReferenceId;
	}

	public void setCardReferenceId(Long cardReferenceId) {
		this.cardReferenceId = cardReferenceId;
	}

	public BigDecimal getDepth() {
		return this.depth;
	}

	public void setDepth(BigDecimal depth) {
		this.depth = depth;
	}

	public BigDecimal getDistFromX() {
		return this.distFromX;
	}

	public void setDistFromX(BigDecimal distFromX) {
		this.distFromX = distFromX;
	}

	public BigDecimal getDistFromY() {
		return this.distFromY;
	}

	public void setDistFromY(BigDecimal distFromY) {
		this.distFromY = distFromY;
	}

	public BigDecimal getDistFromZ() {
		return this.distFromZ;
	}

	public void setDistFromZ(BigDecimal distFromZ) {
		this.distFromZ = distFromZ;
	}

	public String getFrRefKeyName() {
		return this.frRefKeyName;
	}

	public void setFrRefKeyName(String frRefKeyName) {
		this.frRefKeyName = frRefKeyName;
	}

	public String getPlane() {
		return plane;
	}

	public void setPlane(String plane) {
		this.plane = plane;
	}

	public String getFrRefKeyValue() {
		return this.frRefKeyValue;
	}

	public void setFrRefKeyValue(String frRefKeyValue) {
		this.frRefKeyValue = frRefKeyValue;
	}

	public BigDecimal getHeight() {
		return this.height;
	}

	public void setHeight(BigDecimal height) {
		this.height = height;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifiedTimeStamp() {
		return this.lastModifiedTimeStamp;
	}

	public void setLastModifiedTimeStamp(Date lastModifiedTimeStamp) {
		this.lastModifiedTimeStamp = lastModifiedTimeStamp;
	}

	public String getLogicalSlotName() {
		return this.logicalSlotName;
	}

	public void setLogicalSlotName(String logicalSlotName) {
		this.logicalSlotName = logicalSlotName;
	}

	public Long getParentCardReferenceId() {
		return this.parentCardReferenceId;
	}

	public void setParentCardReferenceId(Long parentCardReferenceId) {
		this.parentCardReferenceId = parentCardReferenceId;
	}

	public String getSideInd() {
		return this.sideInd;
	}

	public void setSideInd(String sideInd) {
		this.sideInd = sideInd;
	}

	public String getSlotName() {
		return this.slotName;
	}

	public void setSlotName(String slotName) {
		this.slotName = slotName;
	}

	public String getSlotNumber() {
		return this.slotNumber;
	}

	public void setSlotNumber(String slotNumber) {
		this.slotNumber = slotNumber;
	}

	public String getSlotPosition() {
		return this.slotPosition;
	}

	public void setSlotPosition(String slotPosition) {
		this.slotPosition = slotPosition;
	}

	public Long getSlotSpecRefId() {
		return this.slotSpecRefId;
	}

	public void setSlotSpecRefId(Long slotSpecRefId) {
		this.slotSpecRefId = slotSpecRefId;
	}

	public BigDecimal getWidth() {
		return this.width;
	}

	public void setWidth(BigDecimal width) {
		this.width = width;
	}

	public List<Card> getCards() {
		return this.cards;
	}

	public void setCards(List<Card> cards) {
		this.cards = cards;
	}

	public Card addCard(Card card) {
		getCards().add(card);
		card.setSlot(this);

		return card;
	}

	public Card removeCard(Card card) {
		getCards().remove(card);
		card.setSlot(null);

		return card;
	}

	public String getDirSlotStatus() {
		return EntityValidator.validateStatus(dirSlotStatus, this.getClass());
	}

	public void setDirSlotStatus(String dirSlotStatus) {
		this.dirSlotStatus = dirSlotStatus;
	}

	public Equipment getEquipment() {
		return this.equipment;
	}

	public void setEquipment(Equipment equipment) {
		this.equipment = equipment;
	}

	public Boolean getTrafficBearing() {
		return trafficBearing;
	}

	public void setTrafficBearing(Boolean trafficBearing) {
		this.trafficBearing = trafficBearing;
	}

	public String getInstanceType() {
		return instanceType;
	}

	public void setInstanceType(String instanceType) {
		this.instanceType = instanceType;
	}

	public Long getPhysicalSlotReferenceId() {
		return physicalSlotReferenceId;
	}

	public void setPhysicalSlotReferenceId(Long physicalSlotReferenceId) {
		this.physicalSlotReferenceId = physicalSlotReferenceId;
	}

	public Long getEqpReferenceId() {
		return eqpReferenceId;
	}

	public void setEqpReferenceId(Long eqpReferenceId) {
		this.eqpReferenceId = eqpReferenceId;
	}

}