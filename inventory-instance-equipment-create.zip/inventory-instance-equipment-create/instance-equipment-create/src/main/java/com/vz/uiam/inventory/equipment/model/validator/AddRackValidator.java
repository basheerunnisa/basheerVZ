package com.vz.uiam.inventory.equipment.model.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;

import com.vz.uiam.inventory.equipment.enumeration.ErrorCodeEnum;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.equipment.model.EquipmentDTO;
import com.vz.uiam.inventory.equipment.service.EquipmentService;

/**
 * 
 * @author Senthil Kulandaivelan
 *
 */
@Service
public class AddRackValidator extends RackValidator {

	@Autowired
	private EquipmentRepository equipmentRepository;
	
	/*
	 * (non-Javadoc)
	 * @see com.vz.uiam.inventory.equipment.model.validator.RackValidator#supports(java.lang.Class)
	 */
	@Override
	public boolean supports(Class<?> arg0) {
		return EquipmentDTO.class.equals(arg0);
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.vz.uiam.inventory.equipment.model.validator.RackValidator#validate(java.lang.Object, org.springframework.validation.Errors)
	 */
	@Override
	public void validate(Object obj, Errors errors) {

		EquipmentDTO equipment = (EquipmentDTO) obj;

		// Validate Mandatory
		
		if (!EquipmentService.validateNotNull(equipment.getContainer())){
			errors.reject(ErrorCodeEnum.CONTAINER_NULL.getCode(), ErrorCodeEnum.CONTAINER_NULL.getDescription());
		}		
		if(!EquipmentService.validateNotNull(equipment.getStatus())){
			errors.reject(ErrorCodeEnum.STATUS_NULL.getCode(), ErrorCodeEnum.STATUS_NULL.getDescription());
		}
		if(!EquipmentService.validateNotNull(equipment.getFrame())){
			errors.reject(ErrorCodeEnum.FRAME_NULL.getCode(), ErrorCodeEnum.FRAME_NULL.getDescription());
		}
		
		// Validate Site
		
		if((equipment.getSiteReference() == null || equipment.getSiteReference() < 1) 
				&& (equipment.getClli() == null || equipment.getClli().trim().isEmpty())){
			errors.reject(ErrorCodeEnum.CLLI_SITE_REF_ID_NULL.getCode(), ErrorCodeEnum.CLLI_SITE_REF_ID_NULL.getDescription());
		}
		
		// Validate Equipment Specification

		if((equipment.getTemplateReference() == null || equipment.getTemplateReference() < 1L)
				&& (equipment.getTemplateName() == null || equipment.getTemplateName().trim().isEmpty())
				&& (equipment.getMfgPartNumber() == null || equipment.getMfgPartNumber().trim().isEmpty())) {
			errors.reject(ErrorCodeEnum.TEMP_REF_MFG_NUM.getCode(), ErrorCodeEnum.TEMP_REF_MFG_NUM.getDescription());
		}
		
		// Validate FR_REF_KEY_NAME/VALUE
		
		if (EquipmentService.validateNotNull(equipment.getFrRefKeyName()) 
				&& EquipmentService.validateNotNull(equipment.getFrRefKeyValue())
				&& !equipmentRepository.findByFrRefKeyNameAndFrRefKeyValue(
						equipment.getFrRefKeyName(), equipment.getFrRefKeyValue()).isEmpty()) {
			
			errors.reject(ErrorCodeEnum.FR_REF_KEY_EXIST.getCode(), ErrorCodeEnum.FR_REF_KEY_EXIST.getDescription());
		}
		
		//validate HOST_NAME
		
		if(EquipmentService.validateNotNull(equipment.getHostName())){
			errors.reject(ErrorCodeEnum.NO_RACK_HOST_NAME.getCode(), ErrorCodeEnum.NO_RACK_HOST_NAME.getDescription());
		}
	}
}
