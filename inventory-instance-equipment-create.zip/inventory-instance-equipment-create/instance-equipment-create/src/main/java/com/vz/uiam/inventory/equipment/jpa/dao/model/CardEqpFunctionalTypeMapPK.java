package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class CardEqpFunctionalTypeMapPK implements Serializable{

	private static final long serialVersionUID = 1L;

	@Column(name = "PART_NUM")
	private String partNumber;
	
	@Column(name = "FUNCTIONAL_TYPE")
	private String functionalType;
	
	public String getPartNumber() {
		return partNumber;
	}
	
	public String getFunctionalType() {
		return functionalType;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	
	public void setFunctionalType(String functionalType) {
		this.functionalType = functionalType;
	}

}
