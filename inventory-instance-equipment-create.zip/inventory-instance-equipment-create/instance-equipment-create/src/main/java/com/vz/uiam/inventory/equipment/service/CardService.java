package com.vz.uiam.inventory.equipment.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.enumeration.Entity;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Bandwidth;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Card;
import com.vz.uiam.inventory.equipment.jpa.dao.model.CardEqpFunctionalTypeMap;
import com.vz.uiam.inventory.equipment.jpa.dao.model.CardSpec;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirBlockCode;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvStatus;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvType;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirPortAllocation;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Port;
import com.vz.uiam.inventory.equipment.jpa.dao.model.PortSpec;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Slot;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.CardEqpFunctionalTypeMapRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.CardRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.CardSpecRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirBlockCodeRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInvStatusRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInvTypeRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.PortRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.PortSpecRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.SlotRepository;
import com.vz.uiam.inventory.equipment.model.CardDTO;
import com.vz.uiam.inventory.equipment.model.mapper.ResourceMapper;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateConstant;

@Service
public class CardService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CardService.class);

	@Autowired
	private CardRepository cardRepository;

	@Autowired
	private SlotRepository slotRepository;

	@Autowired
	private CardSpecRepository cardSpecRepository;

	@Autowired
	private PortRepository portRepository;

	@Autowired
	private DirInvStatusRepository dirInvStatusRepository;

	@Autowired
	private ResourceMapper resourceMapper;

	@Autowired
	private EquipmentRepository equipmentRepository;

	@Autowired
	private DirInvTypeRepository dirInvTypeRepository;
	
	@Autowired
	private DirectoryService directoryService;

	@Autowired
	private PortSpecRepository portSpecRepository;

	@Autowired
	private CardEqpFunctionalTypeMapRepository cardEqpFunctionalTypeMapRepository;

	@Autowired
	private DirBlockCodeRepository dirBlockCodeRepository;
	
	@Transactional
	public CardDTO installCard(CardDTO cardDTO, boolean isSharedEquipment) {

		if (cardDTO.getCardSpecId() == null || cardDTO.getCardSpecId() < 1) {
			cardDTO.setErrorCode("10002");
			cardDTO.setErrorMessage("Invalid Card SpecId");
			return cardDTO;
		}

		if (cardDTO.getShelfInstId() == null || cardDTO.getShelfInstId() < 1) {
			cardDTO.setErrorCode("10003");
			cardDTO.setErrorMessage("Invalid EquipmentInstId");
			return cardDTO;
		}

		Card card = resourceMapper.convertToCard(cardDTO);
		CardSpec cardSpec = cardSpecRepository.findOne(card.getCardSpecRefId());

		if (cardSpec == null) {
			cardDTO.setErrorCode("10003");
			cardDTO.setErrorMessage("Card Spec not found");
			return cardDTO;
		}

		Slot slot = slotRepository.findBySlotReferenceId(cardDTO.getSlotInstId());
		if (slot == null) {
			cardDTO.setErrorCode("10001");
			cardDTO.setErrorMessage("Card already slotted");
			return cardDTO;
		}
		Long equipShelfId = cardDTO.getShelfInstId();

		cardDTO.setCardName((cardSpec != null && cardSpec.getName() != null) ? cardSpec.getName() : "");
		String cardType = cardSpec.getDirCardType() != null ? cardSpec.getDirCardType() : null;
		DirInvType dirCardType = null;
		if (cardSpec != null && cardSpec.getDirCardType() != null) {
			dirCardType = dirInvTypeRepository.findByPkTypeAndPkEntityNameIgnoreCase(cardType, "CARD");
		}
		card.setCardType(dirCardType.getType());
		Equipment equipment = equipmentRepository.findOne(equipShelfId);
		if (equipment != null) {
			LOGGER.info("Equipment Id in installCard:" + equipment.getEqpReferenceId());
		} else {
			LOGGER.info("Equipment is null or empty");
		}

		String cardStatus = null;
		DirInvStatus dirInvStatus = null;

		if (cardDTO.getCardStatus() != null && cardDTO.getCardStatus().longValue() > 0) {
			dirInvStatus = dirInvStatusRepository.findByInvStatusId(new Long(cardDTO.getCardStatus()));
			cardStatus = dirInvStatus.getStatus();
		} else if (cardDTO.getCardStatusName() != null) {
			cardStatus = cardDTO.getCardStatusName();
		} else {
			cardStatus = InstanceEquipmentCreateConstant.CARD_STATUS;
		}

		List<PortSpec> portSpecs = null;

		if (card != null) {
			/** insert into card table **/
			
			Date curDate = new Date(System.currentTimeMillis());

			card.setCardDepth(cardSpec.getDepth());
			card.setCardDescription(cardSpec.getDescription());
			card.setCardFunctionalType(cardSpec.getCardFunctionalType());
			card.setCardHeight(cardSpec.getHeight());
			card.setCardWidth(cardSpec.getWidth());
			card.setClei(cardSpec.getClei());
			card.setEqpSource(cardSpec.getEquipmentVendor());
			card.setInServiceDate(curDate);
			card.setInstalledDate(curDate);
			card.setInvStatus(cardStatus);
			card.setIsChassis(cardSpec.getIsChassis());
			card.setLastModifiedBy(cardDTO.getModifiedBy());
			card.setLastModifiedTimeStamp(curDate);
			card.setManufacturer(cardSpec.getManufacturer());
			card.setMaterialId(cardSpec.getMaterialId());
			card.setMaxPorts(cardSpec.getNumOfPorts());
			card.setNbrSubCards(cardSpec.getNbrSubCards());
			card.setOrderNumber(cardDTO.getCardOrderNumber());
			card.setPartNum(cardSpec.getPartNum());
			card.setSlot(slot);
			card.setSlotName(slot.getSlotName());
			card.setSlotOccupancy(cardSpec.getSlotsOccupied());
			card.setTrafficBearing(cardSpec.getTrafficBearing());
			
			card.setCardName(cardSpec.getName() != null ? cardSpec.getName() : "");
			card.setParentCardRefId(slot.getParentCardReferenceId() != null ? slot.getParentCardReferenceId().longValue() : null);
			card.setSlotOccX(cardSpec.getSlotOccX() != null ? new BigDecimal(cardSpec.getSlotOccX()) : null);
			card.setSlotOccY(cardSpec.getSlotOccY() != null ? new BigDecimal(cardSpec.getSlotOccY()) : null);
			
			Card cardRef = cardRepository.save(card);	
			LOGGER.info("Created Card: {}", cardRef);
		
			String slotConstant = directoryService.findSlotStatusConstant();
			DirInvStatus dirInvStatusForSlot = directoryService.findStatusByEntity(Entity.SLOT, slotConstant);
			
			slot.setCardReferenceId(cardRef.getCardReferenceId());
			slot.setDirSlotStatus(dirInvStatusForSlot.getStatus());
			
			slot = slotRepository.save(slot);
			LOGGER.info("Updated Slot: {}", slot);

			cardDTO.setCardId(cardRef.getCardReferenceId());
			cardDTO.setCardName(cardRef.getCardName());
			cardDTO.setCardStatus(dirInvStatus.getInvStatusId().longValue());
			cardDTO.setCardType(cardRef.getCardType());
			cardDTO.setIpAddress(cardRef.getIpAddress());
			cardDTO.setStatus(dirInvStatus.getInvStatusId().longValue());
			cardDTO.setTrafficBearing(cardRef.getTrafficBearing());
			cardDTO.add(new Link("/card/" + cardRef.getCardReferenceId(), "Card"));

			if (card.getCardSpecRefId() != null) {
				portSpecs = portSpecRepository.findByCardSpecCardSpecRefIdOrderByDirectionAsc(card.getCardSpecRefId());
				createPhysicalAndLogicalPort(cardRef, portSpecs, equipment, isSharedEquipment);
			}
		}

		/** Update Shelf Type based on card part number **/
		List<CardEqpFunctionalTypeMap> cardEquipmentMap = cardEqpFunctionalTypeMapRepository
				.findByCardEqpFunctionalTypeMapPkPartNumber(cardSpec.getPartNum());
		if (cardEquipmentMap != null && !cardEquipmentMap.isEmpty()) {
			String newfuncTionalType = cardEquipmentMap.get(0).getCardEqpFunctionalTypeMapPK().getFunctionalType();
			LOGGER.info("New Functional Type :" + newfuncTionalType);
			equipment.setFunctionalType(newfuncTionalType);
			equipmentRepository.save(equipment);
		}

		return cardDTO;
	}

	public void createPhysicalAndLogicalPort(Card card, List<PortSpec> portSpecs, Equipment equipment, boolean isSharedEquipment) {
		
		String defaultPortStatus = directoryService.findStatusByEntity(Entity.PORT, InstanceEquipmentCreateConstant.SPARE).getStatus();
		String defaultBlockReasonCode = null;
		
		LOGGER.info("Port Status :" + defaultPortStatus + "]");

		Map<String, Long> bandwidthMap = new HashMap<>();
		List<Bandwidth> bandwidthList = directoryService.findBandwidths();
		List<DirPortAllocation> portAllocations = directoryService.findPortAllocations();
		
		bandwidthList.forEach(bw -> bandwidthMap.put(bw.getBandwidthName(), bw.getBandwidthId().longValue()));

		if (isSharedEquipment) {
			processSharedResource(card, portSpecs, equipment, bandwidthMap, portAllocations);
		} 
		else {
			LOGGER.info("Attempting to Create {} Ports with default status: {} and default Block Reason Code: {}", 
					portSpecs.size(), defaultPortStatus, defaultBlockReasonCode);
			
			for (int index = 0; portSpecs != null && index < portSpecs.size(); index++) {
				createPortEntries(card, portSpecs, equipment, defaultPortStatus, bandwidthMap, index, defaultBlockReasonCode);
			}
		}
	}

	/**
	 * <p>
	 * This method creating the Port entries in DB
	 * </p>
	 * 
	 * @param card
	 * @param portSpecs
	 * @param equipment
	 * @param portStatus
	 * @param bandwidthMap
	 * @param index
	 */
	private void createPortEntries(Card card, List<PortSpec> portSpecs, Equipment equipment, String portStatus,
			Map<String, Long> bandwidthMap, int index, String blockReasonCode) {
		
		if (InstanceEquipmentCreateConstant.PHYSICAL.equalsIgnoreCase(portSpecs.get(index).getTpType())) {
			LOGGER.info("portSpecs.size:" + portSpecs.size());

			// Physical PORT
			Port physicalPort = new Port();
			physicalPort.setPortReferenceId(null);
			physicalPort.setPortName((portSpecs.get(index) != null && portSpecs.get(index).getPortName() != null)
					? portSpecs.get(index).getPortName() : null);
			physicalPort.setPortStatus(portStatus);
			physicalPort.setBlockReasonCode(blockReasonCode);
			physicalPort.setTpType(portSpecs.get(index).getTpType());
			LOGGER.info("portSpecs.get(index).getPortNum()" + portSpecs.get(index).getPortNum());
			if (portSpecs.get(index) != null && portSpecs.get(index).getPortNum() != null
					&& portSpecs.get(index).getPortNum() > 0) {
				physicalPort.setPortNumber(portSpecs.get(index).getPortNum());
			}

			physicalPort.setFunctionalType((portSpecs.get(index) != null && portSpecs.get(index).getTpType() != null)
					? portSpecs.get(index).getTpType() : null);
			physicalPort.setPortSpecReferenceId(
					(portSpecs.get(index) != null && portSpecs.get(index).getPortSpecRefId() != 0L)
							? portSpecs.get(index).getPortSpecRefId() : 0);
			physicalPort.setCableReferenceId(null);
			physicalPort.setTidLogical(null);
			physicalPort.setLastModifiedTimeStamp(new Date());
			physicalPort.setConnectorType(portSpecs.get(index).getConnectorType());
			physicalPort.setLastModifiedBy(InstanceEquipmentCreateConstant.SYSTEM);
			BigDecimal parentPortRefId = portSpecs.get(index).getParentPortSpecId();
			physicalPort.setParentPortRefId(parentPortRefId != null ? parentPortRefId.longValue() : null);
			physicalPort.setPortSpecReferenceId(portSpecs.get(index).getPortSpecRefId());
			physicalPort.setSiteReferenceId(equipment.getSiteReferenceId().longValue());

			physicalPort.setParentPortRefId(null);
			if (portSpecs.get(index).getBandwidth() != null) {
				physicalPort.setBandwidthRefrenceId(bandwidthMap.get(portSpecs.get(index).getBandwidth()));
				physicalPort.setBandwidthName(portSpecs.get(index).getBandwidth());
			} else {
				physicalPort.setBandwidthRefrenceId(null);
				physicalPort.setBandwidthName(null);
			}

			if (equipment != null) {
				LOGGER.info("Equipment Id while creating Physical port:" + equipment.getEqpReferenceId());
				physicalPort.setEqpReferenceId(equipment.getEqpReferenceId());
			}
			physicalPort.setAliasAid((portSpecs.get(index) != null && portSpecs.get(index).getAliasAid() != null)
					? portSpecs.get(index).getAliasAid() : InstanceEquipmentCreateConstant.NOT_APPLICABLE);
			if (null != card) {
				/** Ports on Card **/
				physicalPort.setSlotReferenceId(card.getSlot().getSlotReferenceId());
				physicalPort.setLastModifiedBy(card.getLastModifiedBy());
				physicalPort.setCardReferenceId(card.getCardReferenceId());
			}

			physicalPort.setRelation(portSpecs.get(index).getRelationship());
			physicalPort.setDirection(portSpecs.get(index).getDirection());
			physicalPort.setDirPortType(portSpecs.get(index).getDirPortType());
			physicalPort.setDescription(portSpecs.get(index).getDescription());
			physicalPort.setDispatchPortName(portSpecs.get(index).getDispatchPortName());

			/** Identify Related Port if any **/
			updatePortAndRelatedPort(physicalPort);
			long portSpecRefId = portSpecs.get(index).getPortSpecRefId();
			createLogicalPorts(portSpecRefId, portStatus, physicalPort, card, equipment, bandwidthMap);
		}
	}

	/**
	 * <p>
	 * For a Shared Equipment Allocate Ports for business domains (WIRELINE,
	 * WIRELESS, etc.) Based on the Priority, Allocation Type & Allocations
	 * </p>
	 * 
	 * @param card
	 * @param portSpecs
	 * @param equipment
	 * @param portStatus
	 * @param bandwidthMap
	 */
	private void processSharedResource(Card card, List<PortSpec> portSpecs, Equipment equipment, Map<String, Long> bandwidthMap, 
			List<DirPortAllocation> dirPortAllocationList) {
		
		DirBlockCode dirBlockCode = null;
		String sharedPortStatus = null;

		// List<DirPortAllocation> dirPortAllocationList = dirPortAllocationRepository.findAll();

		List<DirPortAllocation> dirPortAllocationListSorted = dirPortAllocationList.stream()
				.sorted((dpa1, dpa2) -> dpa1.getPriority().compareTo(dpa2.getPriority())).collect(Collectors.toList());

		/*
		 * Sorting the list of port-specs as per the Port Number
		 */
		// -- Need to sort the port spec list based on Port Number &
		// Direction -- RX/TX Port
		List<PortSpec> portSpecsSorted = portSpecs.stream()
				.sorted((ps1, ps2) -> ps1.getPortNum().compareTo(ps2.getPortNum())).collect(Collectors.toList());

		int startIndex = 0;
		int endIndex = 0;
		int remainingNumberOfPorts = 0;
		for (DirPortAllocation dirPortAllocation : dirPortAllocationListSorted) {
			String allocationType = dirPortAllocation.getAllocationType();
			int allocation = dirPortAllocation.getAllocation();
			String blockReasonCode = dirPortAllocation.getBlockReasonCode();
			int numberOfPortsToBeReserved = 0;

			dirBlockCode = dirBlockCodeRepository.findByBlockReasonCode(blockReasonCode);
			sharedPortStatus = dirBlockCode.getStatus();

			if (InstanceEquipmentCreateConstant.PERCENTAGE.equalsIgnoreCase(allocationType)) {
				numberOfPortsToBeReserved = ((portSpecs.size()) * allocation) / 100;
			} else if (InstanceEquipmentCreateConstant.NUMBER.equalsIgnoreCase(allocationType)) {
				numberOfPortsToBeReserved = dirPortAllocation.getAllocation();
			}
			LOGGER.info("Attempting to reserve {} ports with Status: {} , Block Reason Code: {}",
					numberOfPortsToBeReserved, sharedPortStatus, blockReasonCode);
			endIndex += numberOfPortsToBeReserved;
			for (; portSpecs != null && startIndex < endIndex; startIndex++) {

				createPortEntries(card, portSpecsSorted, equipment, sharedPortStatus, bandwidthMap, startIndex,
						blockReasonCode);
			}
			LOGGER.info("Successfully reserved {} ports with Status: {} ,Block Reason Code: {}",
					numberOfPortsToBeReserved, sharedPortStatus, blockReasonCode);
		}
		/*
		 * If there are still ports available which is not reserved for any
		 * service line, create port as block reason code = null
		 */
		remainingNumberOfPorts = portSpecs.size() - endIndex;
		if (remainingNumberOfPorts > 0) {
			String defaultPortStatus = InstanceEquipmentCreateConstant.SPARE;
			for (int index = 0; portSpecs != null && index < remainingNumberOfPorts; index++) {
				createPortEntries(card, portSpecsSorted, equipment, defaultPortStatus, bandwidthMap, startIndex, null);
			}
		}
	}

	private void updatePortAndRelatedPort(Port physicalPort) {
		Port relatedPortRx = null;
		if (physicalPort.getRelation() != null && physicalPort.getDirection() != null
				&& ("TX").equals(physicalPort.getDirection()) && ("TX/RX").equals(physicalPort.getRelation())) {
			if (null == physicalPort.getCardReferenceId()) {
				relatedPortRx = portRepository.getRelatedPort(physicalPort.getPortSpecReferenceId(),
						physicalPort.getEqpReferenceId(), "RX");
			} else {
				relatedPortRx = portRepository.findByCardReferenceIdAndPortNumberAndDirectionAndParentPortRefIdIsNull(
						physicalPort.getCardReferenceId(), physicalPort.getPortNumber(), "RX");
			}
			if (relatedPortRx != null) {
				physicalPort.setRelatedPortRefId(relatedPortRx.getPortReferenceId());
				physicalPort.setRelatedSpecRefId(new BigDecimal(relatedPortRx.getPortSpecReferenceId()));
			}
		}

		Port potRef = portRepository.save(physicalPort);

		if (relatedPortRx != null) {
			Long relatedPortRefId = potRef.getPortReferenceId();
			Long relatedSpecRefId = potRef.getPortSpecReferenceId();
			Long portReferenceId = relatedPortRx.getPortReferenceId();
			portRepository.updatePort(relatedPortRefId, relatedSpecRefId, portReferenceId);
		}

	}

	private void createLogicalPorts(long portSpecRefId, String portStatus, Port physicalPort, Card card,
			Equipment equipment, Map<String, Long> bandwidthMap) {
		
		// LogicalPort creation
		List<PortSpec> portLists = portSpecRepository
				.findPortSpecsByParentPortSpecIdOrderByDirectionAsc(new BigDecimal(portSpecRefId));
		if (portLists != null) {
			for (int k = 0; k < portLists.size(); k++) {
				// Logical PORT
				Port logicalPort = new Port();
				logicalPort.setPortReferenceId(null);
				logicalPort.setPortName((portLists.get(k) != null && portLists.get(k).getPortName() != null)
						? portLists.get(k).getPortName() : null);
				logicalPort.setPortStatus(portStatus);
				LOGGER.info("portLists.get(k).getPortNum()" + portLists.get(k).getPortNum());

				if (portLists.get(k) != null && portLists.get(k).getPortNum() > 0) {
					logicalPort.setPortNumber(portLists.get(k).getPortNum());
				}

				logicalPort.setFunctionalType((portLists.get(k) != null && portLists.get(k).getTpType() != null)
						? portLists.get(k).getTpType() : null);
				logicalPort
						.setPortSpecReferenceId((portLists.get(k) != null && portLists.get(k).getPortSpecRefId() != 0)
								? portLists.get(k).getPortSpecRefId() : 0);
				logicalPort.setTidLogical(null);
				logicalPort.setTpType(portLists.get(k).getTpType());
				logicalPort.setLastModifiedTimeStamp(new Date());
				logicalPort.setAliasAid(InstanceEquipmentCreateConstant.LOGICAL);
				logicalPort.setLastModifiedBy("SYSTEM");
				logicalPort.setRelation((portLists.get(k) != null && portLists.get(k).getRelationship() != null)
						? portLists.get(k).getRelationship() : "NA");
				logicalPort.setDirection((portLists.get(k) != null && portLists.get(k).getDirection() != null)
						? portLists.get(k).getDirection() : "NA");
				if (null != card) {
					/** Ports on Card **/
					logicalPort.setCardReferenceId(card.getCardReferenceId());
					logicalPort.setSlotReferenceId(card.getSlot().getSlotReferenceId());
				}
				logicalPort.setDirPortType(portLists.get(k).getDirPortType());
				logicalPort.setParentPortRefId(physicalPort.getPortReferenceId());
				logicalPort.setConnectorType(portLists.get(k).getConnectorType());
				logicalPort.setSiteReferenceId(equipment.getSiteReferenceId().longValue());

				if (equipment != null) {
					LOGGER.info("Equipment Id while creating Logical port:" + equipment.getEqpReferenceId());
					logicalPort.setEqpReferenceId(equipment.getEqpReferenceId());
				}

				if (portLists.get(k).getBandwidth() != null) {

					logicalPort.setBandwidthRefrenceId(bandwidthMap.get(portLists.get(k).getBandwidth()));
					logicalPort.setBandwidthName(portLists.get(k).getBandwidth());
				} else {
					logicalPort.setBandwidthRefrenceId(null);
					logicalPort.setBandwidthName(null);
				}
				logicalPort.setCableReferenceId(null);
				logicalPort.setDescription(portLists.get(k).getDescription());
				logicalPort.setDispatchPortName(portLists.get(k).getDispatchPortName());

				/** Identify Related Port if any **/
				Port logicalPortRx = getRelatedLogicalPort(logicalPort);

				/** save logicalPort **/
				Port portRefLogical = portRepository.save(logicalPort);

				if (logicalPortRx != null) {
					Long relatedPortRefId = portRefLogical.getPortReferenceId();
					Long relatedSpecRefId = portRefLogical.getPortSpecReferenceId();
					Long portReferenceId = logicalPortRx.getPortReferenceId();
					portRepository.updatePort(relatedPortRefId, relatedSpecRefId, portReferenceId);
				}
			}
		}
	}

	private Port getRelatedLogicalPort(Port logicalPort) {
		Port logicalPortRx = null;
		if (logicalPort.getRelation() != null && logicalPort.getDirection() != null
				&& ("TX").equals(logicalPort.getDirection()) && ("TX/RX").equals(logicalPort.getRelation())) {
			if (null == logicalPort.getCardReferenceId()) {
				logicalPortRx = portRepository.getRelatedPort(logicalPort.getPortSpecReferenceId(),
						logicalPort.getEqpReferenceId(), "RX");
			} else {
				logicalPortRx = portRepository
						.findByCardReferenceIdAndPortNumberAndDirectionAndTpTypeAndParentPortRefId(
								logicalPort.getCardReferenceId(), logicalPort.getPortNumber(), "RX",
								InstanceEquipmentCreateConstant.LOGICAL, logicalPort.getParentPortRefId());
			}

			if (logicalPortRx != null) {
				logicalPort.setRelatedPortRefId(logicalPortRx.getPortReferenceId());
				logicalPort.setRelatedSpecRefId(new BigDecimal(logicalPortRx.getPortSpecReferenceId()));
			}
		}
		return logicalPortRx;
	}

}
