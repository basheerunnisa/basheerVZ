package com.vz.uiam.inventory.equipment.model.validator;

import java.util.Collection;
import java.util.Iterator;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.vz.uiam.inventory.equipment.model.EnodebDetailsDTO;
import com.vz.uiam.inventory.equipment.model.EnodebSectorDTO;

@Component
public class EnodebCreateValidator implements Validator{

	/*
	 * (non-Javadoc)
	 * @see org.springframework.validation.Validator#supports(java.lang.Class)
	 */
	@Override
	public boolean supports(Class<?> clazz) {
		
		Class<?>[] classes = new Class<?>[]{
			EnodebDetailsDTO.class,
			Collection.class
		};
		for(Class<?> c : classes){
			if(c.isAssignableFrom(clazz)){
				return true;
			}
		}
		return false;
	}
	
	/*
	 * (non-Javadoc)
	 * @see org.springframework.validation.Validator#validate(java.lang.Object, org.springframework.validation.Errors)
	 */
	@Override
	public void validate(Object target, Errors errors) {
		
		if(target instanceof Collection){
			Iterator<?> i = ((Collection<?>) target).iterator();
			while(i.hasNext()){
				validate(i.next(), errors);
			}
			return;
		}
		
		EnodebDetailsDTO enodebDetailsDTO = (EnodebDetailsDTO) target;
		
		if(enodebDetailsDTO.getEnodebId() == null || enodebDetailsDTO.getEnodebId().trim().isEmpty()) {
			errors.reject(Integer.toString(HttpStatus.BAD_REQUEST.value()), "EnodebId is empty!");
		}
		if(enodebDetailsDTO.getSectors() != null && !enodebDetailsDTO.getSectors().isEmpty()){
			enodebDetailsDTO.getSectors().forEach(sec -> validateSector(sec, errors));
		}
	}

	private void validateSector(EnodebSectorDTO sector, Errors errors) {
		
		if(sector.getCellId() == null || sector.getCellId() < 0L){
			errors.reject(Integer.toString(HttpStatus.BAD_REQUEST.value()), "Cell Id is Invalid");
		}
		if(sector.getBand() == null || (sector.getBand().getBandClass() == null || sector.getBand().getBandClass() < 0L)){
			errors.reject(Integer.toString(HttpStatus.BAD_REQUEST.value()), "Band Class Invalid");
		}
	}
}