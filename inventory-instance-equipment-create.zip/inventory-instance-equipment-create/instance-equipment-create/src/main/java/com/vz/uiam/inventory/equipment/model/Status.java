package com.vz.uiam.inventory.equipment.model;

import java.io.Serializable;

public class Status implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long equipmentReference;
	private String statusCode;
	private String statusMsg;
	private String name;
	private String container;
	
	
	public Long getEquipmentReference() {
		return equipmentReference;
	}
	public void setEquipmentReference(Long equipmentReference) {
		this.equipmentReference = equipmentReference;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusMsg() {
		return statusMsg;
	}
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContainer() {
		return container;
	}
	public void setContainer(String container) {
		this.container = container;
	}
	@Override
	public String toString() {
		return "Status [equipmentReference=" + equipmentReference + ", statusCode=" + statusCode + ", statusMsg=" + statusMsg + ", name="
				+ name + ", container=" + container + "]";
	}	
}