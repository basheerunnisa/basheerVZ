package com.vz.uiam.inventory.equipment.config;

import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.vz.uiam.inventory.equipment.enumeration.Entity;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvStatus;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvType;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInvStatusRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInvTypeRepository;
import com.vz.uiam.inventory.equipment.model.validator.EntityValidator;


public class EntityValidatorBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(EntityValidatorBean.class);
	
	@Autowired
	private DirInvStatusRepository statusRepo;
	@Autowired
	private DirInvTypeRepository typeRepo;

	@PostConstruct
	public void init() {
		
		List<String> entities = Entity.getEntities();
		List<DirInvStatus> statuses = statusRepo.findByPkEntityNameIgnoreCaseIn(entities);
		List<DirInvType> types = typeRepo.findByPkEntityNameIgnoreCaseIn(entities);
		
		Collections.sort(entities);
		LOGGER.info("Cached {} Statuses & {} Types for Entities: {}", statuses.size(), types.size(), entities);
		
		EntityValidator.initialize(statusRepo, typeRepo);
		EntityValidator.validateColor();
	}

}
