package com.vz.uiam.inventory.equipment.config;

import static com.google.common.base.Predicates.or;
import static springfox.documentation.builders.PathSelectors.regex;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.google.common.base.Predicate;

@Configuration
@EnableSwagger2
@ComponentScan(basePackages = "com.vz.uiam.inventory.equipment")
public class SwaggerConfig {

    @Bean
    public Docket restfulApi() {
	return new Docket(DocumentationType.SWAGGER_2).groupName("inventory-api").select().paths(paths()).build().apiInfo(apiInfo());
    }

    private Predicate<String> paths() {
	return or(regex("/inventory/equipment.*"), 
			  regex("/equipment.*"), 
			  regex("/inventory/equipments/virtual.*"),
			  regex("/configuration.*"));

    }

    private ApiInfo apiInfo() {

	return new ApiInfo("IVAPP2.0 Inventory", "IVAPP2.0 Inventory Services: TaaS", "1.0", "http://oneconfluence.verizon.com/display/UIAM/Equipment",
		"karthik.a.amarnath@verizon.com", "Licence", "http://oneconfluence.verizon.com/display/UIAM/Equipment");
    }
}