/**
 *
 */
package com.vz.uiam.inventory.equipment.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vz.uiam.common.usermanagement.rest.model.DirDomainsDTO;
import com.vz.uiam.inventory.equipment.enumeration.Entity;
import com.vz.uiam.inventory.equipment.enumeration.ErrorCodeEnum;
import com.vz.uiam.inventory.equipment.exception.BadRequestException;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirContainerType;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvStatus;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvType;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EquipmentAttributes;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EquipmentDomainMap;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EquipmentSpec;
import com.vz.uiam.inventory.equipment.jpa.dao.model.PortSpec;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Site;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Slot;
import com.vz.uiam.inventory.equipment.jpa.dao.model.SlotSpec;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Vlan;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.CardSpecRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentAttributesRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentDomainMapRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.PortSpecRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.SiteRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.SlotCardSpecMapRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.SlotRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.SlotSpecRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.VlanRepository;
import com.vz.uiam.inventory.equipment.model.EquipmentDTO;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.model.mapper.ResourceMapper;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateConstant;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;

/**
 * @author Karthik Amarnath
 */

@Service
public class EquipmentService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EquipmentService.class);

	@Autowired
	private AttributesService attributesService;
	@Autowired
	private CardService cardService;
	@Autowired
	private CardSpecRepository cardSpecRepository;
	@Autowired
	private DirectoryService directoryService;
	@Autowired
	private EquipmentDomainMapRepository equipmentDomainMapRepository;
	@Autowired
	private EquipmentRepository equipmentRepository;
	@Autowired
	private EquipmentAttributesRepository equipmentAttributesRepository;
	@Autowired
	private PortSpecRepository portSpecRepository;
	@Autowired
	private SiteRepository siteRepository;
	@Autowired
	private SlotCardSpecMapRepository slotCardSpecMapRepository;
	@Autowired
	private SlotRepository slotRepository;
	@Autowired
	private SlotSpecRepository slotSpecRepository;
	@Autowired
	private VlanRepository vlanRepository;
	@Autowired
	private ResourceMapper resourceMapper;
	@Autowired
	private EquipmentCreateService equipmentCreateService;

	public EquipmentDTO addRack(EquipmentDTO equipmentDTO, HttpServletRequest httpRequest) {

		boolean isSharedEquipment = validateSharedEquipment(equipmentDTO.getAttributeList());

		Site site = directoryService.findSite(equipmentDTO);
		EquipmentSpec equipSpec = directoryService.findEquipmentSpec(equipmentDTO);
		DirContainerType dirContainerType = directoryService.findContainer(equipmentDTO.getContainer());
		DirInvStatus dirInvStatus = directoryService.findStatusByEntityWithDefault(Entity.EQUIPMENT,
				equipmentDTO.getStatus(), "PENDING_IN");
		DirInvType dirEqpType = null;

		validateExists(site.getSiteReferenceId(), equipmentDTO.getFrame(), dirContainerType.getContainer());

		if (equipmentDTO.getType() != null && !equipmentDTO.getType().isEmpty()) {
			dirEqpType = directoryService.findTypeByEntity(Entity.EQUIPMENT, equipmentDTO.getType());
		} else {
			dirEqpType = directoryService.findTypeByEntity(Entity.EQUIPMENT_SPEC, equipSpec.getDirEqpType());
		}

		String networkDomain = null;
		if (equipmentDTO.getNetworkDomain() != null && !equipmentDTO.getNetworkDomain().isEmpty()) {
			networkDomain = equipmentDTO.getNetworkDomain();
		} else if (equipSpec.getManufacturer() != null && equipmentDTO.getNetworkType() != null
				&& site.getRegion() != null) {
			networkDomain = directoryService.findNetworkDomain(equipSpec.getManufacturer(),
					equipmentDTO.getNetworkType(), site.getRegion());
		}

		String mgmtTeletPort = null;
		if ((equipmentDTO.getRawTelnetPort() != null && !equipmentDTO.getRawTelnetPort().trim().isEmpty())
				|| (equipmentDTO.getNormalTelnetPort() != null
						&& !equipmentDTO.getNormalTelnetPort().trim().isEmpty())) {
			mgmtTeletPort = "RAW:" + (equipmentDTO.getRawTelnetPort() + "").trim() + "," + "NORMAL:"
					+ (equipmentDTO.getNormalTelnetPort() + "").trim();
		}

		Equipment rackDecomEquipment = null;

		if (equipmentDTO.getFrRefKeyName() != null && !equipmentDTO.getFrRefKeyName().trim().isEmpty()
				&& equipmentDTO.getFrRefKeyValue() != null && !equipmentDTO.getFrRefKeyValue().trim().isEmpty()) {

			rackDecomEquipment = equipmentRepository.findFirstByFrRefKeyNameAndFrRefKeyValue(
					equipmentDTO.getFrRefKeyName().trim(), equipmentDTO.getFrRefKeyValue().trim());

			if (rackDecomEquipment != null
					&& InstanceEquipmentCreateConstant.PENDING_DECOM.equals(rackDecomEquipment.getDirInvStatus())) {
				equipmentCreateService.autoDecomShelfFromRack(rackDecomEquipment.getFrRefKeyName(),
						rackDecomEquipment.getFrRefKeyValue());
			}

		}

		Equipment equipment = new Equipment();

		equipment.setAid(equipmentDTO.getAid());
		equipment.setAlternateName(equipmentDTO.getAlternateName());
		equipment.setBarCode(equipmentDTO.getBarCode());
		equipment.setBatchNumber(equipmentDTO.getBatchNumber());
		equipment.setComments(equipmentDTO.getComments());
		equipment.setDecommisionDate(equipmentDTO.getDecommisionDate());
		equipment.setDirContainerType(dirContainerType);
		equipment.setDirEqpType(dirEqpType.getType());
		equipment.setDirInvStatus(dirInvStatus.getStatus());
		equipment.setDueDate(equipmentDTO.getDueDate());
		equipment.setEms(equipmentDTO.getEms());
		equipment.setEqpClei(equipmentDTO.getClei());
		equipment.setEqpManufacturer(equipSpec.getManufacturer());
		equipment.setEqpModel(equipSpec.getModel());
		if (equipmentDTO.getName() != null && !equipmentDTO.getName().isEmpty()) {
			equipment.setEqpName(equipmentDTO.getName());
		} else if (equipmentDTO.getFrame() != null) {
			equipment.setEqpName(equipmentDTO.getFrame());
		}
		equipment.setEqpPurchaseDate(equipmentDTO.getPurchaseDate());
		equipment.setEquipmentSpecName(equipSpec.getName());
		equipment.setFieldId(equipmentDTO.getFieldId());
		equipment.setFrRefKeyName(equipmentDTO.getFrRefKeyName());
		equipment.setFrRefKeyValue(equipmentDTO.getFrRefKeyValue());
		equipment.setFrame(equipmentDTO.getFrame());
		equipment.setFunctionalType(equipSpec.getFunctionalType());
		equipment.setHardwareRevision(equipmentDTO.getHardwareRevision());
		equipment.setIneffectDate(equipmentDTO.getInServiceDate());
		if (equipmentDTO.getInstalledDate() != null)
			equipment.setInstalledDate(equipmentDTO.getInstalledDate());
		else
			equipment.setInstalledDate(new Date());
		equipment.setIsMultiTidShelf(equipmentDTO.getIsMultiTidShelf());
		equipment.setLastModifiedBy(equipmentDTO.getModifiedUser());
		equipment.setLastModifiedTimeStamp(new Date());
		equipment.setLineUp(equipmentDTO.getLineUp());
		equipment.setLocationClli(equipmentDTO.getClli());
		equipment.setMgmtIpAddress(equipmentDTO.getIpAddress());
		equipment.setMgmtSSHPort(equipmentDTO.getMgmtSSHPort());
		equipment.setMgmtTelnetPort(mgmtTeletPort);
		equipment.setNetworkDomain(networkDomain);
		equipment.setNetworkType(equipmentDTO.getNetworkType());
		equipment.setOrderNumber(equipmentDTO.getOrderNumber());
		equipment.setPartNum(equipSpec.getPartNum());
		equipment.setPointCode(equipmentDTO.getPointCode());
		equipment.setProjectReferenceId(equipmentDTO.getProjectReferenceId());
		equipment.setScheduledDate(equipmentDTO.getScheduledDate());
		equipment.setSerialNumber(equipmentDTO.getSerialNumber());
		equipment.setShelfType(equipSpec.getFunctionalType());
		equipment.setSiteReferenceId(new BigDecimal(site.getSiteReferenceId()));
		equipment.setSoftwareRevision(equipmentDTO.getSoftwareRevision());
		equipment.setTidLogical(equipmentDTO.getTargetId());

		equipment.setAssetLife(
				validateNotNull(equipmentDTO.getAssetLife()) ? equipmentDTO.getAssetLife().longValue() : null);
		equipment.setCustomerReferenceId(validateNotNull(equipmentDTO.getCustomerReference())
				? new BigDecimal(equipmentDTO.getCustomerReference()) : null);
		equipment.setDistFromX(validateNotNull(equipmentDTO.getDistToFront()) ? equipmentDTO.getDistToFront()
				: equipSpec.getDistFromX());
		equipment.setDistFromY(validateNotNull(equipmentDTO.getDistToLeft()) ? equipmentDTO.getDistToLeft()
				: equipSpec.getDistFromY());
		equipment.setDistFromZ(validateNotNull(equipmentDTO.getDistToBase()) ? equipmentDTO.getDistToBase()
				: equipSpec.getDistFromZ());
		equipment.setEqpDepth(
				validateNotNull(equipmentDTO.getDepth()) ? equipmentDTO.getDepth() : equipSpec.getEqpDepth());
		equipment.setEqpHeight(
				validateNotNull(equipmentDTO.getHeight()) ? equipmentDTO.getHeight() : equipSpec.getEqpHeight());
		equipment.setEqpPurchasePrice(
				validateNotNull(equipmentDTO.getPurchasePrice()) ? equipmentDTO.getPurchasePrice().toString() : null);
		equipment.setEqpVendor(
				validateNotNull(equipmentDTO.getVendor()) ? equipmentDTO.getVendor() : equipSpec.getEquipmentVendor());
		equipment.setEqpWidth(
				validateNotNull(equipmentDTO.getWidth()) ? equipmentDTO.getWidth() : equipSpec.getEqpWidth());
		equipment.setEquipmentSpecRefId(validateNotNull(equipSpec.getEquipmentSpecRefId())
				? new BigDecimal(equipSpec.getEquipmentSpecRefId()) : null);
		equipment.setHiLocationReference(validateNotNull(equipmentDTO.getFloor()) ? equipmentDTO.getFloor() : null);
		equipment.setLogicalShelf(validateNotNull(equipmentDTO.getLogicalShelf()) ? equipmentDTO.getPhysicalShelf()
				: equipSpec.getDefaultLogicalShelf());
		equipment.setParentEqpReferenceId(validateNotNull(equipmentDTO.getParentEqReference())
				? new BigDecimal(equipmentDTO.getParentEqReference()) : null);
		equipment.setParentShelfReferenceId(validateNotNull(equipmentDTO.getParentShelfReference())
				? new BigDecimal(equipmentDTO.getParentShelfReference()) : null);
		equipment.setPhysicalShelfPosition(validateNotNull(equipmentDTO.getPhysicalShelf())
				? equipmentDTO.getPhysicalShelf() : equipSpec.getDefaultPhysicalShelf());

		Equipment rackRef = equipmentRepository.save(equipment);
		createEquipmentDomains(rackRef.getEqpReferenceId(), equipmentDTO, httpRequest);

		LOGGER.info("Equipment Created is {}", rackRef.getEqpReferenceId());

		DirInvStatus cardStatus = directoryService.findStatusByEntity(Entity.CARD, "PENDING_IN");

		slotSpecRepository
				.findByEquipmentSpecEquipmentSpecRefIdAndParentCardSpecIdIsNull(equipSpec.getEquipmentSpecRefId())
				.forEach(slotSpec -> createSlot(rackRef.getEqpReferenceId(), slotSpec, rackRef,
						equipmentDTO.getModifiedUser(), equipment.getOrderNumber(), isSharedEquipment, cardStatus));

		List<PortSpec> portSpecList = portSpecRepository
				.findByEquipmentSpecRefIdOrderByDirectionAsc(equipSpec.getEquipmentSpecRefId());
		if (!portSpecList.isEmpty()) {
			cardService.createPhysicalAndLogicalPort(null, portSpecList, rackRef, isSharedEquipment);
		}

		List<Slot> slotList = slotRepository.findByEqpReferenceId(rackRef.getEqpReferenceId());
		rackRef.setSlots(slotList);

		return resourceMapper.convertToEquipmentDTO(rackRef);
	}

	public List<AttributesDTO> createEquipmentAttributes(Long eqpReferenceId, String eqpType, String eqpFunctionalType,
			List<AttributesDTO> equipmentAttributesDTOList) {

		LOGGER.info(
				"Attempting to Create Equipment Attributes for Equipment Reference: {} & Equipment Type: {} and Functional Type: {} | {}",
				eqpReferenceId, eqpType, eqpFunctionalType, equipmentAttributesDTOList);

		List<AttributesDTO> equipmentAttributesList = new ArrayList<AttributesDTO>();
		if (equipmentAttributesDTOList != null && !equipmentAttributesDTOList.isEmpty()) {
			try {
				validateAttributeDTOList(equipmentAttributesDTOList, eqpType, eqpFunctionalType);
				equipmentAttributesList = attributesService.insertInventoryAttributes("EQUIPMENT", eqpReferenceId,
						equipmentAttributesDTOList);
				if (equipmentAttributesList != null && !equipmentAttributesList.isEmpty()) {
					LOGGER.info("Equipment Attributes created:" + equipmentAttributesList.toString()
							+ " \n EquipmentReferenceId = " + eqpReferenceId);
				}
			} catch (Exception e) {
				LOGGER.info("Error in saving Equipment Attributes:", e);
			}
		}
		return equipmentAttributesList;
	}

	private void validateAttributeDTOList(List<AttributesDTO> equipmentAttributesDTOList, String eqpType,
			String functionalType) {

		equipmentAttributesDTOList.stream()
				.filter(a -> a.getAttrInvDescptName() == null || a.getAttrInvDescptName().isEmpty()).forEach(a -> {
					a.setEntityType(eqpType);
					a.setFunctionalType(functionalType);
				});
	}

	public void updateVlanAttribute(EquipmentDTOV1 shelf, EquipmentDTOV1 equipment) {

		if (!InstanceEquipmentCreateConstant.EQP_TYPE_CSR.equalsIgnoreCase(shelf.getType().trim())) {
			return;
		}

		LOGGER.info("Attempting to Create VLAN Attributes for CSR Equipment");

		String firstVlan = null, secondVlan = null;
		boolean firstVlanExist = false, secondVlanExist = false;
		List<Equipment> eqList = equipmentRepository
				.findBySiteReferenceIdAndDirEqpType(new BigDecimal(equipment.getsiteReference()), shelf.getType());
		if (!eqList.isEmpty() && eqList.size() > 1) {
			LOGGER.info("HUB scenario Found two CSR equipments with locationId:{} ", equipment.getsiteReference());
			Equipment existingEquipment = eqList.stream()
					.filter(x -> !shelf.getEquipmentReference().equals(x.getEqpReferenceId())).findAny().orElse(null);
			List<EquipmentAttributes> oldEqpAttributes = equipmentAttributesRepository
					.findByEqpReferenceIdAndEqpGroupName(existingEquipment.getEqpReferenceId(),
							InstanceEquipmentCreateConstant.VLAN_INFORMATION_GROUP);
			for (EquipmentAttributes equipmentAttributes : oldEqpAttributes) {
				if (equipmentAttributes.getEqpName()
						.equalsIgnoreCase(InstanceEquipmentCreateConstant.VLAN_ATTRIBUTE_FIRST)) {
					firstVlan = equipmentAttributes.getEqpValue();
				}
				if (equipmentAttributes.getEqpName()
						.equalsIgnoreCase(InstanceEquipmentCreateConstant.VLAN_ATTRIBUTE_SECOND)) {
					secondVlan = equipmentAttributes.getEqpValue();
				}
			}
		} else {
			Site site = siteRepository.findBySiteReferenceId(equipment.getsiteReference());
			if (site.getMarket() != null && !site.getMarket().trim().isEmpty() && equipment.getVendor() != null
					&& !equipment.getVendor().trim().isEmpty()) {
				Vlan vlan = vlanRepository.findFirstByMarketAndVendorAndStatusOrderByFirstVlanAsc(site.getMarket(),
						equipment.getVendor(), InstanceEquipmentCreateConstant.VLAN_STATUS_AVAILABLE.toString());
				if (vlan != null) {
					vlan.setStatus(InstanceEquipmentCreateConstant.VLAN_STATUS_RESERVED);
					vlanRepository.save(vlan);
					firstVlan = Long.toString(vlan.getFirstVlan());
					secondVlan = Long.toString(vlan.getSecondVlan());
				}
			}
		}
		if (equipment.getAttributeList() != null && !equipment.getAttributeList().isEmpty()) {
			for (AttributesDTO attributesDTO : equipment.getAttributeList()) {
				if (attributesDTO.getAttrGroupName()
						.equalsIgnoreCase(InstanceEquipmentCreateConstant.VLAN_INFORMATION_GROUP)
						&& attributesDTO.getAttrName()
								.equalsIgnoreCase(InstanceEquipmentCreateConstant.VLAN_ATTRIBUTE_FIRST)) {
					attributesDTO.setAttrValue(firstVlan);
					firstVlanExist = true;
				}
				if (attributesDTO.getAttrGroupName()
						.equalsIgnoreCase(InstanceEquipmentCreateConstant.VLAN_INFORMATION_GROUP)
						&& attributesDTO.getAttrName()
								.equalsIgnoreCase(InstanceEquipmentCreateConstant.VLAN_ATTRIBUTE_SECOND)) {
					attributesDTO.setAttrValue(secondVlan);
					secondVlanExist = true;
				}
			}
		} else {
			equipment.setAttributeList(new ArrayList<AttributesDTO>());
		}
		if (!firstVlanExist) {
			AttributesDTO attributesDTO = new AttributesDTO();
			attributesDTO.setAttrGroupName(InstanceEquipmentCreateConstant.VLAN_INFORMATION_GROUP);
			attributesDTO.setAttrName(InstanceEquipmentCreateConstant.VLAN_ATTRIBUTE_FIRST);
			attributesDTO.setAttrValue(firstVlan);
			attributesDTO.setReferenceId(shelf.getEquipmentReference());
			attributesDTO.setEntityName(InstanceEquipmentCreateConstant.ENTITY_EQUIPMENT);
			attributesDTO.setAttrInvDescptName(InstanceEquipmentCreateConstant.CSR_EQUIPMENT_INV_DESCRIPTOR_NAME);
			equipment.getAttributeList().add(attributesDTO);
		}
		if (!secondVlanExist) {
			AttributesDTO attributesDTO = new AttributesDTO();
			attributesDTO.setAttrGroupName(InstanceEquipmentCreateConstant.VLAN_INFORMATION_GROUP);
			attributesDTO.setAttrName(InstanceEquipmentCreateConstant.VLAN_ATTRIBUTE_SECOND);
			attributesDTO.setAttrValue(secondVlan);
			attributesDTO.setReferenceId(shelf.getEquipmentReference());
			attributesDTO.setEntityName(InstanceEquipmentCreateConstant.ENTITY_EQUIPMENT);
			attributesDTO.setAttrInvDescptName(InstanceEquipmentCreateConstant.CSR_EQUIPMENT_INV_DESCRIPTOR_NAME);
			equipment.getAttributeList().add(attributesDTO);
		}
	}

	// Helper Methods

	public void createSlot(long eqpShelfId, SlotSpec slotSpec, Equipment equipmentRef, String modifiedBy,
			String orderNumber, boolean isSharedEquipment, DirInvStatus cardStatus) {

		Slot slot = new Slot();

		slot.setAid(slotSpec.getAid());
		slot.setDepth(slotSpec.getDepth());
		slot.setDirSlotStatus(slotSpec.getSlotStatus());
		slot.setDistFromX(slotSpec.getDistFromX());
		slot.setDistFromY(slotSpec.getDistFromY());
		slot.setDistFromZ(slotSpec.getDistFromZ());
		slot.setEqpReferenceId(equipmentRef.getEqpReferenceId());
		slot.setEquipment(equipmentRef);
		slot.setHeight(slotSpec.getHeight());
		slot.setLastModifiedBy(modifiedBy);
		slot.setLastModifiedTimeStamp(new Date());
		slot.setLogicalSlotName(slotSpec.getLogicalSlotName());
		slot.setLogicalSlotName(slotSpec.getSlotName());
		slot.setSideInd(slotSpec.getSideInd());
		slot.setSlotName(slotSpec.getSlotName());
		slot.setSlotNumber(slotSpec.getSlotNumber());
		slot.setSlotPosition(slotSpec.getSlotPosition());
		slot.setSlotSpecRefId(slotSpec.getSlotSpecRefId());
		slot.setTrafficBearing(slotSpec.getTrafficBearing());
		slot.setWidth(slotSpec.getWidth());
		slot.setPlane(slotSpec.getPlane());

		Slot slotRef = slotRepository.save(slot);

		LOGGER.info("Slot Created is {}", slotRef.getSlotReferenceId());

	}

	/**
	 * Creates Equipment Domain Map records for the given Equipment Id for
	 * Domains based on input & user.
	 * 
	 * @param equipmentId
	 * @param equipmentDTO
	 * @param principalName
	 * @param requestUserName
	 */
	public void createEquipmentDomains(Long equipmentId, EquipmentDTOV1 equipmentDTO, HttpServletRequest httpRequest) {

		EquipmentDTO tmp = new EquipmentDTO();
		tmp.setDomianNames(equipmentDTO.getDomianNames());

		createEquipmentDomains(equipmentId, tmp, httpRequest);
	}

	/**
	 * Creates Equipment Domain Map records for the given Equipment Id for
	 * Domains based on input & user.
	 * 
	 * @param equipmentId
	 * @param equipmentDTO
	 * @param principalName
	 * @param requestUserName
	 */
	public void createEquipmentDomains(Long equipmentId, EquipmentDTO equipmentDTO, HttpServletRequest httpRequest) {

		List<EquipmentDomainMap> equipmentDomains = new ArrayList<>();
		List<String> domainNamesInput = equipmentDTO.getDomianNames() != null
				? equipmentDTO.getDomianNames().stream().map(DirDomainsDTO::getDomainName).collect(Collectors.toList())
				: new ArrayList<>();

		directoryService.findRequestedDomains(domainNamesInput, httpRequest).forEach(d -> {
			equipmentDomains.add(new EquipmentDomainMap(equipmentId, d.getDomainId()));
		});

		List<EquipmentDomainMap> domains = equipmentDomainMapRepository.save(equipmentDomains);
		LOGGER.info("Created {} Equipment Domains", domains.size());
	}

	/**
	 * Validates that the Shelf that is about to be created does not already
	 * exist.
	 * 
	 * @param siteReferenceId
	 * @param frame
	 * @param physicalShelf
	 * @param container
	 */
	public void validateExists(Long siteReferenceId, String frame, String physicalShelf, String container) {

		if (!equipmentRepository.findBySiteReferenceIdAndPhysicalShelfPositionAndFrameAndDirContainerTypeContainer(
				new BigDecimal(siteReferenceId), physicalShelf, frame, container).isEmpty()) {

			throw new BadRequestException(ErrorCodeEnum.SHELF_EXIST);
		}
	}

	/**
	 * Validates that the Rack that is about to be created does not already
	 * exist.
	 * 
	 * @param siteReferenceId
	 * @param frame
	 * @param container
	 */
	public void validateExists(Long siteReferenceId, String frame, String container) {

		if (!equipmentRepository.findBySiteReferenceIdAndEqpNameAndDirContainerTypeContainer(
				new BigDecimal(siteReferenceId), frame, container).isEmpty()) {

			throw new BadRequestException(ErrorCodeEnum.FRAME_EXIST);
		}
	}

	// Static Helper Methods

	/**
	 * 
	 * @param object
	 * @return true/false where true means the object is not null/empty.
	 */
	public static <T> boolean validateNotNull(T object) {

		boolean response = false;

		if (object instanceof String) {
			response = object != null ? !((String) object).trim().isEmpty() : false;
		} else if (object instanceof Number) {
			response = object != null ? ((Number) object).doubleValue() > 0.0 : false;
		} else if (object instanceof Collection) {
			response = object != null ? !((Collection<?>) object).isEmpty() : false;
		} else {
			response = object != null;
		}
		return response;
	}

	/**
	 * 
	 * This method validates whether a Equipment is shared or not based on the
	 * Attribute DTO
	 * 
	 * @param attributes
	 * @return
	 */
	public static boolean validateSharedEquipment(List<AttributesDTO> attributes) {

		LOGGER.info("Attempting to Validate Shared Port");

		AttributesDTO attribute = null;

		if (attributes != null && !attributes.isEmpty()) {
			attribute = attributes.stream()
					.filter((p) -> InstanceEquipmentCreateConstant.ATTRIBUTE_NAME.equalsIgnoreCase(p.getAttrName())
							&& InstanceEquipmentCreateConstant.ATTRIBUTE_VALUE.equalsIgnoreCase(p.getAttrValue()))
					.findAny().orElse(null);
		}
		return attribute != null;
	}
}
