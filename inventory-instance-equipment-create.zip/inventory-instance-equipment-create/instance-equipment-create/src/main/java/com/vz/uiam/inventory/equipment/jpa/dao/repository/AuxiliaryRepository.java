package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.vz.uiam.inventory.equipment.jpa.dao.model.AuxiliaryEquipment;

@Repository
@Transactional
public interface AuxiliaryRepository extends JpaRepository<AuxiliaryEquipment, Long> {
	
	AuxiliaryEquipment findByHostnameIgnoreCase(String hostname);
}
