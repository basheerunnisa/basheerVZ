package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.javers.core.metamodel.annotation.TypeName;


/**
 * The persistent class for the DIR_INV_DEF_ATTRIBUTE database table.
 * 
 */
@Entity
@Table(name="DIR_INV_DEF_ATTRIBUTE")
@TypeName("DirInvDefAttribute")
@NamedQuery(name="DirInvDefAttribute.findAll", query="SELECT d FROM DirInvDefAttribute d")
public class DirInvDefAttribute implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="INV_DEF_ATTR_ID")
	private long invDefAttrId;

	@Column(name="DATA_TYPE")
	private String dataType;

	@Column(name="DISPLAY_NAME")
	private String displayName;

	@Column(name="INV_DEF_ATTR_NAME")
	private String invDefAttrName;

	//bi-directional many-to-one association to DirInventoryDefinition
	@OneToMany(mappedBy="dirInvDefAttribute")
	private List<DirInventoryDefinition> dirInventoryDefinitions;

	//bi-directional many-to-one association to DirInvDefAttrValueList
	@OneToMany(mappedBy="dirInvDefAttribute")
	private List<DirInvDefAttrValueList> dirInvDefAttrValueLists;

	public DirInvDefAttribute() {
	}

	public long getInvDefAttrId() {
		return this.invDefAttrId;
	}

	public void setInvDefAttrId(long invDefAttrId) {
		this.invDefAttrId = invDefAttrId;
	}

	public String getDataType() {
		return this.dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getDisplayName() {
		return this.displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getInvDefAttrName() {
		return this.invDefAttrName;
	}

	public void setInvDefAttrName(String invDefAttrName) {
		this.invDefAttrName = invDefAttrName;
	}

	public List<DirInventoryDefinition> getDirInventoryDefinitions() {
		return this.dirInventoryDefinitions;
	}

	public void setDirInventoryDefinitions(List<DirInventoryDefinition> dirInventoryDefinitions) {
		this.dirInventoryDefinitions = dirInventoryDefinitions;
	}

	public DirInventoryDefinition addDirInventoryDefinition(DirInventoryDefinition dirInventoryDefinition) {
		getDirInventoryDefinitions().add(dirInventoryDefinition);
		dirInventoryDefinition.setDirInvDefAttribute(this);

		return dirInventoryDefinition;
	}

	public DirInventoryDefinition removeDirInventoryDefinition(DirInventoryDefinition dirInventoryDefinition) {
		getDirInventoryDefinitions().remove(dirInventoryDefinition);
		dirInventoryDefinition.setDirInvDefAttribute(null);

		return dirInventoryDefinition;
	}

	public List<DirInvDefAttrValueList> getDirInvDefAttrValueLists() {
		return this.dirInvDefAttrValueLists;
	}

	public void setDirInvDefAttrValueLists(List<DirInvDefAttrValueList> dirInvDefAttrValueLists) {
		this.dirInvDefAttrValueLists = dirInvDefAttrValueLists;
	}

	public DirInvDefAttrValueList addDirInvDefAttrValueList(DirInvDefAttrValueList dirInvDefAttrValueList) {
		getDirInvDefAttrValueLists().add(dirInvDefAttrValueList);
		dirInvDefAttrValueList.setDirInvDefAttribute(this);

		return dirInvDefAttrValueList;
	}

	public DirInvDefAttrValueList removeDirInvDefAttrValueList(DirInvDefAttrValueList dirInvDefAttrValueList) {
		getDirInvDefAttrValueLists().remove(dirInvDefAttrValueList);
		dirInvDefAttrValueList.setDirInvDefAttribute(null);

		return dirInvDefAttrValueList;
	}

}