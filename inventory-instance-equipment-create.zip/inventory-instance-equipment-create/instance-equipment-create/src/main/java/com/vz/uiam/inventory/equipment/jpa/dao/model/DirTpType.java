package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.javers.core.metamodel.annotation.TypeName;


/**
 * The persistent class for the DIR_TP_TYPE database table.
 * 
 */
@Entity
@Table(name="DIR_TP_TYPE")
@TypeName("DirTpType")
@NamedQuery(name="DirTpType.findAll", query="SELECT d FROM DirTpType d")
public class DirTpType implements Serializable {
	private static final long serialVersionUID = 1L;

	private String description;

	@Column(name="DISPLAY_SEQ")
	private BigDecimal displaySeq;

	@Column(name="TP_TYPE")
	private String tpType;

	@Id
	@Column(name="TP_TYPE_ID")
	private BigDecimal tpTypeId;

	public DirTpType() {
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getDisplaySeq() {
		return this.displaySeq;
	}

	public void setDisplaySeq(BigDecimal displaySeq) {
		this.displaySeq = displaySeq;
	}

	public String getTpType() {
		return this.tpType;
	}

	public void setTpType(String tpType) {
		this.tpType = tpType;
	}

	public BigDecimal getTpTypeId() {
		return this.tpTypeId;
	}

	public void setTpTypeId(BigDecimal tpTypeId) {
		this.tpTypeId = tpTypeId;
	}

}