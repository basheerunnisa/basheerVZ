package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.javers.core.metamodel.annotation.TypeName;

/**
 * <p>
 * This Persistent class is used for the DB table -> DIR_BLOCK_CODE
 * </p>
 * 
 * @author Asif Billa
 * @date 20-June-2017
 *
 */
@Entity
@Table(name = "DIR_BLOCK_CODE")
@TypeName("DirBlockCode")
@NamedQuery(name = "DirBlockCode.findAll", query = "SELECT d FROM DirBlockCode d")
public class DirBlockCode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "STATUS")
	private String status;

	@Id
	@Column(name = "BLOCK_REASON_CODE")
	private String blockReasonCode;

	@Column(name = "DESCRIPTION")
	private String description;

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the blockReasonCode
	 */
	public String getBlockReasonCode() {
		return blockReasonCode;
	}

	/**
	 * @param blockReasonCode
	 *            the blockReasonCode to set
	 */
	public void setBlockReasonCode(String blockReasonCode) {
		this.blockReasonCode = blockReasonCode;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DirBlockCode [status=");
		builder.append(status);
		builder.append(", blockReasonCode=");
		builder.append(blockReasonCode);
		builder.append(", description=");
		builder.append(description);
		builder.append("]");
		return builder.toString();
	}

}