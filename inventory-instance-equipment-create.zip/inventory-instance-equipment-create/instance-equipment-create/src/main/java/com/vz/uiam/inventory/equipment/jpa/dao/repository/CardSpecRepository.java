package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.CardSpec;



@Transactional
public interface CardSpecRepository extends JpaRepository<CardSpec,Long> {

    List<CardSpec> findAllBySlotCardSpecMaps(List<Long> cardSpecIdList);

    CardSpec findByName(String name);
}