package com.vz.uiam.inventory.equipment.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ValidationUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.common.monitor.performance.PerformanceMetrics;
import com.vz.uiam.inventory.equipment.enumeration.EntityOperation;
import com.vz.uiam.inventory.equipment.enumeration.EntityType;
import com.vz.uiam.inventory.equipment.exception.MethodFailureException;
import com.vz.uiam.inventory.equipment.model.EntityEventData;
import com.vz.uiam.inventory.equipment.model.EquipmentDTO;
import com.vz.uiam.inventory.equipment.model.validator.AddRackValidator;
import com.vz.uiam.inventory.equipment.service.DirectoryService;
import com.vz.uiam.inventory.equipment.service.EquipmentService;
import com.vz.uiam.inventory.equipment.service.KafkaEventPublisher;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author Karthik Amarnath
 *
 */
@RestController
@RequestMapping("/equipment/")
@Api(value = "Equipment Instance creation Task handler", description = "API for Equipment Instace create Task Handler")
@PreAuthorize("hasAnyAuthority('ROLE:IVAPP_USER','ROLE:IVAPP_TESTER')")
public class EquipmentRackController {

	private static final Logger LOGGER = LoggerFactory.getLogger(EquipmentRackController.class);

	@Autowired
	private EquipmentService equipmentService;
	@Autowired
	private AddRackValidator addRackValidator;
	@Autowired
	private KafkaEventPublisher kafkaEventPublisher;

	@RequestMapping(value = "rack/v1", method = RequestMethod.POST)
	@PerformanceMetrics(sla = 500)
	@ApiOperation(value = "Add rack and return rack details", notes = "Add and returns a Rack detail. SLA:500", response = EquipmentDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully added rack details", response = EquipmentDTO.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Rack details with given rack id does not exist"), })
	public EquipmentDTO addRack(@RequestBody EquipmentDTO equipmentDTO,
			@RequestHeader(value = "USER_ID", required = false) String userID, 
			HttpServletRequest httpRequest, BindingResult errors) throws BindException {

		DirectoryService.clearCache();
		
		LOGGER.info("EquipmentController:addRack:Input [" + equipmentDTO + "] ");

		ValidationUtils.invokeValidator(addRackValidator, equipmentDTO, errors);

		if (errors.hasErrors()) {
			throw new BindException(errors);
		}

		if (userID != null && userID != "") {
			equipmentDTO.setModifiedUser(userID);
		}

		EquipmentDTO rack = equipmentService.addRack(equipmentDTO, httpRequest);

		if (rack == null) {
			throw new MethodFailureException("Rack Not Found");
		}

		List<AttributesDTO> equipmentAttributesDTOList = equipmentDTO.getAttributeList();
		String eqpFunctionalType = rack.getFunctionalEquipType() != null ? String.valueOf(rack.getFunctionalEquipType()) : null;
		rack.setAttributeList(equipmentService.createEquipmentAttributes(
				rack.getEquipmentReference(), rack.getType(), eqpFunctionalType, equipmentAttributesDTOList));
		
		kafkaEventPublisher.publishData(new EntityEventData(EntityType.SHELF.toString(), rack.getEquipmentReference(),
				EntityOperation.INSERT.toString(), equipmentDTO));
		return rack;
	}
}
