/**
 * 
 */
package com.vz.uiam.inventory.equipment.util;

import java.util.Collection;

/**
 * <p>
 * Constants used for instance-equipment-create app
 * </p>
 * 
 * @author Asif Billa
 * @date 13-June-2017
 *
 */
public class InstanceEquipmentCreateConstant {

	public static final String LOGICAL = "LOGICAL";
	public static final String CARD_STATUS = "AVAILABLE";
	public static final String RESERVED = "RESERVED";
	public static final String SPARE = "SPARE";
	public static final String ATTRIBUTE_INV_DESCRIPTOR_NAME = "LGX-PATCH-PANEL";
	public static final String ATTRIBUTE_NAME = "PANEL_INDICATOR";
	public static final String ATTRIBUTE_VALUE = "VZW_SHARED";
	public static final String PERCENTAGE = "Percentage";
	public static final String NUMBER = "Number";
	public static final String PHYSICAL = "PHYSICAL";
	public static final String SYSTEM = "SYSTEM";
	public static final String NOT_APPLICABLE = "NA";
	// added for MSE - virtual equipment creation
	public static final String INSTANCE_TYPE_VIRTUAL = "virtual";
	public static final String VIRTUAL_EQP_NAME_SUFFIX = "/RI";
	public static final String TYPE_RI = "RI";
	public static final String SHELF_TYPE_MSERI = "MSERI";
	
	public static final String MSE_RI_INV_DESCRIPTOR_NAME = "MSE-Routing-Instance";
	// added for DIR_INV_STATUS table change
	public static final String INV_CARD = "CARD";
	public static final String INV_EQP = "EQUIPMENT";
	public static final String INV_SLOT = "SLOT";
	public static final String INV_PORT = "PORT";
	
	// Added for Vlan functionality
	public static final String EQP_TYPE_CSR = "CSR";
	
	public static final String VLAN_STATUS_AVAILABLE = "AVAILABLE";
	public static final String VLAN_STATUS_RESERVED = "RESERVED";
	
	public static final String VLAN_INFORMATION_GROUP = "VLAN_INFORMATION";
	public static final String VLAN_ATTRIBUTE_FIRST = "VLAN1";
	public static final String VLAN_ATTRIBUTE_SECOND = "VLAN2";
	
	public static final String ENTITY_EQUIPMENT = "EQUIPMENT";
	
	public static final String CSR_EQUIPMENT_INV_DESCRIPTOR_NAME = "CSR-EQUIPMENT";

	//added for Loopback IP for RI
	public static final String EQUIPMENT_ID = "EQUIPMENT_ID";
	public static final String IP_ASSIGNMENT_INDICATOR = "ASSIGN_IP";
	public static final Integer NUMBER_OF_A_SITE_IPS = 1;
	public static final Integer NET_SIZE= 32;
	public static final String DARKNET_IP_POOL_NAME = "DARKNET_IP_POOL_NAME";
	public static final String EXTERNAL_IP_POOL_NAME = "EXTERNAL_IP_POOL_NAME";
	public static final String POOL_TYPE = "MSE";
	public static final String IP_VERSION_4 = "ipv4";
	public static final String REGEX= "/\\d+";
	public static final String ERROR = "ERROR";
	public static final String REPLACEMENT= "";
	public static final String ATTRIBUTE_GROUP_NAME= "ATTRIBUTE_GROUP_NAME";
	public static final String ATTR_INV_DESCPT_NAME= "MSE-Routing-Instance";
	public static final String LOOPBAACK_IPV4_IPADDRESS_1= "Loopback-IP-Address1(IPv4)";
	public static final String LOOPBAACK_IPV4_IPADDRESS_2= "Loopback-IP-Address2(IPv4)";
	public static final String ENTITY_NAME= "EQUIPMENT";
	public static final String LOOPBACK_IP_CONFIG_NAME = "ELIGIBLE_SHELF_TYPE";
	public static final String INTERNAL_IP_ADDRESS = "Internal IP Address";
	public static final String EXTERNAL_IP_ADDRESS = "External IP Address";
	public static final String EMPTY = "";
	public static final String NA = "NA";
	
	// constants for fabric interconnect
	public static final String SU_RI_FABRIC_INTERCONNECT_IP_ADDRESS = "SU-RI-Fabric-InterConnect-IPv4-Address";
	public static final String CURRENT_RI_FABRIC_INTERCONNECT_IP_ADDRESS = "Current-RI-Fabric-InterConnect-IPv4-Address";
	public static final String OTHER_RI_FABRIC_INTERCONNECT_IP_ADDRESS = "Other-RI-Fabric-InterConnect-IPv4-Address";
	public static final Integer NUMBER_OF_IPS = 2;
	public static final String SU_RI_HOSTNAME = "SU-RI-HostName";
	public static final String OTHER_RI_HOSTNAME = "Other-RI-HostName";
	public static final String LOOPBACK_IP_ADDRESS_GRP = "LOOPBACK_IP_ADDRESS_GRP";
	public static final String OTHER_RI = "OTHER-RI";
	public static final String SU_RI = "SU-RI";
	public static final String VRI_SU = "vRI-SU";
	public static final String LOOP_BACK = "LOOP-BACK";
	public static final Integer PUBLIC_IP_P2P_NET_SIZE= 31;
	
	public static final String SHELF_TYPE_NGPON2 = "NGPON2";
	public static final String LOOPBACK_IPADDRESS_FOR_NGPON2 = "Loopback_Ipv4_NGPON2";
	public static final String VRIS_INFRASTRUCTURE_POOL_NAME = "VRIS_INFRASTRUCTURE_POOL_NAME";
	
	public static final String CREATE_SUCCESS_SHELF = "SHELF CREATED SUCCESSFULLY";
    public static final String CREATE_FAILURE_SHELF = "SHELF NOT CREATED SUCCESSFULLY";
    public static final String CREATE_SUCCESS_RACK = "RACK CREATED SUCCESSFULLY";
    public static final String CREATE_FAILURE_RACK = "RACK NOT CREATED SUCCESSFULLY";
    public static final String SUCCESS = "SUCCESS";
    public static final String FAILURE = "FAIL";
        
	public static final String DOMAIN_ADD_SUCCESS = "Domain added successfully";
	
	public static final String DOMAIN_ADD_FAIL = "Domain add failed";
	
    public static final String PENDING_DECOM = "PENDING_DECOM";
    public static final String CONTAINER_SHELF = "SHELF";
    
	/**
	 * 
	 * @param object
	 * @return true/false where true means the object is not null/empty. 
	 */
	public static <T> boolean validateNotNull(T object){
		
		boolean response = false;
		
		if(object instanceof String){
			response = object != null ? !((String)object).trim().isEmpty() : false;
		}
		else if(object instanceof Number){	
			response = object != null ? ((Number)object).doubleValue() > 0.0 : false;
		}
		else if(object instanceof Collection){
			response = object != null ? !((Collection<?>)object).isEmpty() : false;
		}
		else {
			response = object != null;
		}
		return response;
	}
}

