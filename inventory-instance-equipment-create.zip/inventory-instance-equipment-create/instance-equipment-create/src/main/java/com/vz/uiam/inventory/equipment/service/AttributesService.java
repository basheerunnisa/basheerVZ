package com.vz.uiam.inventory.equipment.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.validation.FieldError;
import org.springframework.web.client.RestTemplate;

import com.vz.uiam.common.usermanagement.utility.UserUtilities;
import com.vz.uiam.inventory.equipment.exception.BadRequestException;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;

@Service
public class AttributesService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AttributesService.class);
	
	@Autowired
	private String specificationAttributesUrl;
	@Autowired
	private String svcUserName;
	@Autowired
	private String svcPassword;
	
	public List<AttributesDTO> insertInventoryAttributes(String entityName, Long referenceId, List<AttributesDTO> requestBody){
		
		final String url = specificationAttributesUrl + "inventory/EQUIPMENT/" + referenceId + "/attributes";

		if(requestBody == null || requestBody.isEmpty()){
			return new ArrayList<>();
		}
		
		LOGGER.info("Calling: " + url + " with " + requestBody);
		
		List<AttributesDTO> locatedAttributes = null;
		RestTemplate template = new RestTemplate();
		
		try {
			HttpEntity<List<AttributesDTO>> entity = new HttpEntity<>(requestBody, UserUtilities.addSecurityHeader(null, svcUserName, svcPassword));
			ParameterizedTypeReference<List<AttributesDTO>> genericReference = new ParameterizedTypeReference<List<AttributesDTO>>(){};
			locatedAttributes = template.exchange(url, HttpMethod.POST, entity, genericReference).getBody();
		
			if(locatedAttributes == null){
				locatedAttributes = new ArrayList<>();
			}
			
			LOGGER.info("Retrieved {} Attributes", locatedAttributes.size());
		} 
		catch (Exception e){
			LOGGER.error("ERROR: {}", e);
			if("400 Bad Request".equalsIgnoreCase(e.getMessage())) {
				throw new BadRequestException(new FieldError("Specification-Attributes", 
						"Url: '" + url, "' Returned Bad Request"));
			}
			locatedAttributes = new ArrayList<>();
		}
		return locatedAttributes;
	}
}