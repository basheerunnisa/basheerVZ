package com.vz.uiam.inventory.equipment.model.validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInvStatus;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInvStatusRepository;
import com.vz.uiam.inventory.equipment.model.EquipmentDTO;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateConstant;

/**
 * 
 * @author Senthil Kulandaivelan
 *
 */
@Service
public class RackValidator implements Validator {
	private static final Logger LOGGER = LoggerFactory.getLogger(RackValidator.class);

	@Autowired
	DirInvStatusRepository dirInvStatusRepository;

	@Override
	public boolean supports(Class<?> arg0) {
		return EquipmentDTO.class.equals(arg0);
	}

	public EquipmentDTO validateEquipmentReference(EquipmentDTO equipmentDTO, Errors errors) {
		return null;
	}

	@Override
	public void validate(Object object, Errors errors) {

		EquipmentDTO equipmentDTO = (EquipmentDTO) object;

		/* Initiate DB Query for Circuit type, Status and Topology */

		DirInvStatus dirInvStatus = null;
		if (equipmentDTO.getStatus() != null && !"".equals(equipmentDTO.getStatus())) {
			dirInvStatus = dirInvStatusRepository.findByPkStatusAndPkEntityNameIgnoreCase(equipmentDTO.getStatus(),
					InstanceEquipmentCreateConstant.INV_EQP);
			if (dirInvStatus == null) {
				errors.rejectValue("Status", "status.validationerror", "Status could not be validated");
			} else {
				LOGGER.debug("Status is {} ",
						dirInvStatus.getStatus() + " for Entity Type:  " + dirInvStatus.getEntityName());
			}

		}

	}

}
