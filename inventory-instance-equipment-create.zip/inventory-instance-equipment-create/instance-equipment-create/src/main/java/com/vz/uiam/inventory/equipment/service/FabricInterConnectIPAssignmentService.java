package com.vz.uiam.inventory.equipment.service;

/**
 * <p>
 * This service assigns loop back IP to Fabric Interconnect Chassis
 * </p>
 *  
 * @author Anju Rajput
 * @date 01-Feb-2018
 *
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vz.uiam.common.audit.exception.MethodFailureException;
import com.vz.uiam.inventory.equipment.enumeration.DirInventoryConfigGroups;
import com.vz.uiam.inventory.equipment.enumeration.ErrorCodeEnum;
import com.vz.uiam.inventory.equipment.enumeration.RoutingInstanceFunctionalTypes;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInventoryConfig;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInventoryConfigRepository;
import com.vz.uiam.inventory.equipment.model.NetworkIpv4;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateConstant;
import com.vz.uiam.inventory.instance.rest.api.model.AssignNextAvailNonPreassignDTO;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;

@Service
public class FabricInterConnectIPAssignmentService {

	private static final Logger LOGGER = LoggerFactory.getLogger(FabricInterConnectIPAssignmentService.class);

	@Autowired
	private IPAssignmentRestService ipAssignmentRestService;

	@Autowired
	private IPAssignmentService ipAssignmentService;

	@Autowired
	private DirInventoryConfigRepository dirInventoryConfigRepository;

	
	/**
	 * This method will assign IP's for Fabric Interconnect Chassis
	 * 
	 * @param ipAssignmentDTO
	 * @return
	 */
	public List<List<AttributesDTO>> assignP2PIPForFabricInterConnectRI(Equipment currentRIEquipment, Equipment suRIequipment) {
		LOGGER.info("Request for assignP2PIPForFabricInterConnectRI with currentRIEquipment: {} and suRIequipment :{}",currentRIEquipment,suRIequipment);
		List<List<AttributesDTO>> allRIAttributeslist = new ArrayList<>();
		List<AttributesDTO> currentRIAttributes = null;
		List<AttributesDTO> suRIAttributes = null;
		Map<String, String> suRIAttributesMap = null;
		Map<String, String> currentRIAttributesMap = null;


		// Check RI with Eqp_Functional_Type
		if (currentRIEquipment != null && currentRIEquipment.getFunctionalType() != null && RoutingInstanceFunctionalTypes.contains(currentRIEquipment.getFunctionalType())) {
			// assignIP
			List<String> riIPAddresses = assignIpv4(currentRIEquipment.getTidLogical());

			// Populate current RI Attributes
			currentRIAttributesMap = ipAssignmentService.buildAttributesMap(InstanceEquipmentCreateConstant.OTHER_RI,
					riIPAddresses, suRIequipment.getTidLogical());
			// Building Eqp Attributes for the current RI , passing the SU-RI
			// functional Type to identify the Fabric IP Group Name
			currentRIAttributes = ipAssignmentService.buildEqpAttributes(InstanceEquipmentCreateConstant.OTHER_RI,
					currentRIEquipment, currentRIAttributesMap, suRIequipment.getFunctionalType());

			LOGGER.info("RI attributes formed: {}", currentRIAttributes);

			// Populate SU-RI Attributes
			suRIAttributesMap = ipAssignmentService.buildAttributesMap(InstanceEquipmentCreateConstant.SU_RI,
					riIPAddresses, currentRIEquipment.getTidLogical());

			// Building Eqp Attributes for the SU RI , passing the Current-RI
			// functional Type to identify the Fabric IP Group Name
			suRIAttributes = ipAssignmentService.buildEqpAttributes(InstanceEquipmentCreateConstant.SU_RI,
					suRIequipment, suRIAttributesMap, currentRIEquipment.getFunctionalType());

			LOGGER.info("SU-RI attributes formed: {}", suRIAttributes);

			allRIAttributeslist.add(currentRIAttributes);
			allRIAttributeslist.add(suRIAttributes);
		}
		LOGGER.info("Fabric Interconnect's attribute List : {}",allRIAttributeslist);
		return allRIAttributeslist;
	}
	
	
	/**
	 * <p>
	 * This is method to populate DTO for next available IP
	 * </p>
	 * 
	 * @param poolName
	 * @param equipmentRefID
	 * @return
	 */
	private AssignNextAvailNonPreassignDTO populateAssignNextAvailPreassignDTO(String tidLogical) {
		AssignNextAvailNonPreassignDTO assignNextAvailNonPreassignDTO = new AssignNextAvailNonPreassignDTO();
		assignNextAvailNonPreassignDTO.setNetSize(InstanceEquipmentCreateConstant.PUBLIC_IP_P2P_NET_SIZE);
		assignNextAvailNonPreassignDTO.setNoOfIps(InstanceEquipmentCreateConstant.NUMBER_OF_IPS);
		assignNextAvailNonPreassignDTO.setComment(InstanceEquipmentCreateConstant.SU_RI_FABRIC_INTERCONNECT_IP_ADDRESS);
		assignNextAvailNonPreassignDTO.setSite(tidLogical != null ? tidLogical : InstanceEquipmentCreateConstant.NA);

		// Fetching the IPs from the TAC IP Pool
		String poolValue = fetchPoolName();
		LOGGER.info("Corresponding Pool Name from DB Config: {}", poolValue);
		assignNextAvailNonPreassignDTO.setPoolName(poolValue);
		assignNextAvailNonPreassignDTO.setPoolType(poolValue);
		return assignNextAvailNonPreassignDTO;
	}

	/**
	 * <p>
	 * This method does following operation
	 * </p>
	 * <li>check if attributeName is for DARKNET_IP_POOL_NAME or
	 * EXTERNAL_IP_POOL_NAME</li>
	 * <li>call the ipAssignmentService to get the IP address</li>
	 * <li>call the attributeSpecificationService to add that IP in attribute
	 * name</li>
	 * 
	 * @param tidLogical
	 * @param attributeName
	 * @return
	 */
	public List<String> assignIpv4(String tidLogical) {

		List<String> ipAddressList = new ArrayList<>();

		NetworkIpv4 ipv4AssignmentResponse = ipAssignmentRestService
				.assignNextAvailableIp(populateAssignNextAvailPreassignDTO(tidLogical));
		if (ipv4AssignmentResponse.getCidrList() == null || ipv4AssignmentResponse.getCidrList().isEmpty()) {
			LOGGER.error("Ip Address is null");
			throw new MethodFailureException(ErrorCodeEnum.INVALID_IP_ASSIGNMENT.getCode(),
					ErrorCodeEnum.INVALID_IP_ASSIGNMENT.getDescription(), "assignment IP is empty");
		}
		// Extracting two IP's from the available IP list
		// Assuming the IP Addresses would be in Ascending order
		String suRIIpAddress = ipv4AssignmentResponse.getCidrList().get(0)
				.replaceFirst(InstanceEquipmentCreateConstant.REGEX, InstanceEquipmentCreateConstant.REPLACEMENT);
		String currentRIIpAddress = ipv4AssignmentResponse.getCidrList().get(1)
				.replaceFirst(InstanceEquipmentCreateConstant.REGEX, InstanceEquipmentCreateConstant.REPLACEMENT);

		ipAddressList.add(suRIIpAddress);
		ipAddressList.add(currentRIIpAddress);

		LOGGER.info("assigned Fabric InterConnect IP for RI IPV4 ipaddress:{} ", ipAddressList);

		return ipAddressList;
	}

	/**
	 * <p>
	 * fetch pool name from DIR_INVENTORY_CONFIG table
	 * </p>
	 * 
	 * @param poolName
	 * @return
	 */
	public String fetchPoolName() {
		DirInventoryConfig dirInventoryConfig = dirInventoryConfigRepository.findByGroupNameAndConfigName(
				DirInventoryConfigGroups.LOOP_BACK_IP_ASSIGNMENT.value(), InstanceEquipmentCreateConstant.EXTERNAL_IP_POOL_NAME);
		if (null != dirInventoryConfig) {
			return dirInventoryConfig.getConfigValue();
		}
		return null;
	}

}