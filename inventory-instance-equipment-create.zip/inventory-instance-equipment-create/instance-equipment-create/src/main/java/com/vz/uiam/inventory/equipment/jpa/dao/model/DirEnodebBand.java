package com.vz.uiam.inventory.equipment.jpa.dao.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DIR_ENODEB_BAND")
public class DirEnodebBand {

	@Id
	@Column(name = "BAND_CLASS")
	private Long bandClass;

	@Column(name = "BAND_CATEGORY", nullable = false)
	private String bandCategory;

	@Column(name = "CHANNEL_NUMBER", nullable = false)
	private String channelNumber;
	
	@Column(name = "DISPLAY_SEQUENCE", nullable = false)
	private Short sequence;

	
	public Long getBandClass() {
		return bandClass;
	}
	public void setBandClass(Long bandClass) {
		this.bandClass = bandClass;
	}
	public String getBandCategory() {
		return bandCategory;
	}
	public void setBandCategory(String bandCategory) {
		this.bandCategory = bandCategory;
	}
	public String getChannelNumber() {
		return channelNumber;
	}
	public void setChannelNumber(String channelNumber) {
		this.channelNumber = channelNumber;
	}
	public Short getSequence() {
		return sequence;
	}
	public void setSequence(Short sequence) {
		this.sequence = sequence;
	}
	
	
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DirEnodebBand [bandClass=" + bandClass + ", bandCategory=" + bandCategory + ", channelNumber="
				+ channelNumber + ", sequence=" + sequence + "]";
	}
}
