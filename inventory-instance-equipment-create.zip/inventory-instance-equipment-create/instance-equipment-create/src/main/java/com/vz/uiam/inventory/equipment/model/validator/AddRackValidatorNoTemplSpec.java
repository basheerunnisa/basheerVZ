package com.vz.uiam.inventory.equipment.model.validator;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;

import com.vz.uiam.common.usermanagement.rest.model.DirDomainsDTO;
import com.vz.uiam.common.usermanagement.service.SecurityUserDetailsService;
import com.vz.uiam.inventory.equipment.enumeration.ErrorCodeEnum;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;

/**
 * 
 * @author Senthil Kulandaivelan
 *
 */
@Service
public class AddRackValidatorNoTemplSpec extends RackValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(AddRackValidatorNoTemplSpec.class);

	@Autowired
	private EquipmentRepository equipmentRepository;
	@Autowired
	private SecurityUserDetailsService securityUserDetailsService;

	/*
	 * (non-Javadoc)
	 * @see com.vz.uiam.inventory.equipment.model.validator.RackValidator#supports(java.lang.Class)
	 */
	@Override
	public boolean supports(Class<?> arg0) {
		return EquipmentDTOV1.class.equals(arg0);
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.vz.uiam.inventory.equipment.model.validator.RackValidator#validate(java.lang.Object, org.springframework.validation.Errors)
	 */
	@Override
	public void validate(Object obj, Errors errors) {

		EquipmentDTOV1 equipmentDTO = (EquipmentDTOV1) obj;

		if (equipmentDTO.getDomianNames() != null && !equipmentDTO.getDomianNames().isEmpty()) {
			List<String> domainNameList = new ArrayList<String>();
			List<DirDomainsDTO> dirDomains = securityUserDetailsService.getDomainsForEntity(null, null);
			if (dirDomains != null && !dirDomains.isEmpty()) {
				for (DirDomainsDTO domainNames : dirDomains) {
					domainNameList.add(domainNames.getDomainName());
					LOGGER.info("adding values from domainNameList{}" + domainNameList.toString());
				}
				for (DirDomainsDTO domainNames : equipmentDTO.getDomianNames()) {
					if (!domainNameList.contains(domainNames.getDomainName())) {
						errors.reject(ErrorCodeEnum.INV_DOMAIN.getCode(), ErrorCodeEnum.INV_DOMAIN.getDescription());
						break;
					}
				}
			}

		}
		
		/** Adding Frame mandatory **/
		if (equipmentDTO.getFrame() == null || equipmentDTO.getFrame().trim().isEmpty()) {
			errors.reject(ErrorCodeEnum.FRAME_NULL.getCode(), ErrorCodeEnum.FRAME_NULL.getDescription());
		}

		/** Adding Clli or SiteRefId mandatory **/
		if ((equipmentDTO.getClli() == null || equipmentDTO.getClli().trim().isEmpty())
				&& (equipmentDTO.getsiteReference() == null || equipmentDTO.getsiteReference() <= 0)) {
			errors.reject(ErrorCodeEnum.CLLI_SITE_REF_ID_NULL.getCode(),
					ErrorCodeEnum.CLLI_SITE_REF_ID_NULL.getDescription());
		}

		/** Adding Status is mandatory **/
		if (equipmentDTO.getStatus() == null || equipmentDTO.getStatus().trim().isEmpty()) {
			errors.reject(ErrorCodeEnum.STATUS_NULL.getCode(), ErrorCodeEnum.STATUS_NULL.getDescription());
		}

		/** Container value check **/
		if (equipmentDTO.getcontainer() == null || equipmentDTO.getcontainer().trim().isEmpty()) {
			errors.reject(ErrorCodeEnum.CONTAINER_NULL.getCode(), ErrorCodeEnum.CONTAINER_NULL.getDescription());
		}

		if (equipmentDTO.getClli() != null && equipmentDTO.getFrame() != null && equipmentDTO.getcontainer() != null) {
			validateFrame(equipmentDTO, errors);
		}

		if (equipmentDTO.getsiteReference() != null && equipmentDTO.getsiteReference() > 0
				&& equipmentDTO.getFrame()!= null && equipmentDTO.getcontainer() != null) {
			validateFrameWithSiteId(equipmentDTO, errors);
		}
	}

	public void validateFrame(EquipmentDTOV1 equipmentDTO, Errors errors) {
		List<Equipment> equipmentList = equipmentRepository.findByLocationClliAndFrameAndDirContainerTypeContainer(
				equipmentDTO.getClli(), equipmentDTO.getFrame(), equipmentDTO.getcontainer());
		if (equipmentList != null && !equipmentList.isEmpty()) {
			errors.reject(ErrorCodeEnum.FRAME_EXIST.getCode(), ErrorCodeEnum.FRAME_EXIST.getDescription());
		}
	}

	public void validateFrameWithSiteId(EquipmentDTOV1 equipmentDTO, Errors errors) {
		List<Equipment> equipmentList = equipmentRepository.findBySiteReferenceIdAndEqpNameAndDirContainerTypeContainer(
				new BigDecimal(equipmentDTO.getsiteReference()), equipmentDTO.getFrame(), equipmentDTO.getcontainer());
		if (equipmentList != null && !equipmentList.isEmpty()) {
			errors.reject(ErrorCodeEnum.FRAME_EXIST.getCode(), ErrorCodeEnum.FRAME_EXIST.getDescription());
		}
	}

	public void validateName(EquipmentDTOV1 equipmentDTO, Errors errors) {

		if (equipmentDTO.getName() != null && !equipmentDTO.getName().trim().isEmpty()) {
			List<Equipment> equipmentList = equipmentRepository.findByEqpName(equipmentDTO.getName());
			if (equipmentList != null && !equipmentList.isEmpty()) {
				errors.reject(ErrorCodeEnum.NAME_EXIST.getCode(), ErrorCodeEnum.NAME_EXIST.getDescription());
			}
		} else {
			errors.reject(ErrorCodeEnum.NAME_REQ.getCode(), ErrorCodeEnum.NAME_REQ.getDescription());
		}
	}

}
