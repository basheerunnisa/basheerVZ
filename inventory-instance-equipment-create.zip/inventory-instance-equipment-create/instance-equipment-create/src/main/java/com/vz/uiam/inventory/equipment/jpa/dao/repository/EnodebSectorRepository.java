package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.vz.uiam.inventory.equipment.jpa.dao.model.EnodebSector;

@Transactional
public interface EnodebSectorRepository extends JpaRepository<EnodebSector, Long> {
	
	@Query(value = "SELECT * FROM ENODEB_SECTOR WHERE ENODEB_ID = :enodebId", nativeQuery = true)
	List<EnodebSector> getByEnodebId(@Param("enodebId") String enodebId);
}
