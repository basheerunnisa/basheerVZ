/**
 * 
 */
package com.vz.uiam.inventory.equipment.model.validator;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.vz.uiam.inventory.equipment.enumeration.EntityType;
import com.vz.uiam.inventory.equipment.enumeration.ErrorCodeEnum;
import com.vz.uiam.inventory.equipment.exception.DataConflictException;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.equipment.model.EquipmentDTOV1;
import com.vz.uiam.inventory.equipment.model.SlotDTO;
import com.vz.uiam.inventory.equipment.model.mapper.ResourceMapper;
import com.vz.uiam.inventory.equipment.service.EquipmentService;

/**
 * @author Karthik Amarnath
 *
 */
@Service
public class CreateEquipmentValidator implements Validator {

	private static final String ICON_SHELF = "ICON_SHELF";
	private static final String ICON_RACK = "ICON_RACK";
	private static final String PATCH_PANEL = "PATCH_PANEL";
	
	public enum CreationType {	
		NON_TEMPLATE,
		TEMPLATE
	}

	private CreationType creationType;
	
	public void setCreationType(CreationType creationType){
		this.creationType = creationType;
	}
	
	@Autowired
	private EquipmentRepository equipmentRepository;
	
	@Autowired
	private ResourceMapper resourceMapper;

	/*
	 * (non-Javadoc)
	 * @see org.springframework.validation.Validator#supports(java.lang.Class)
	 */
	@Override
	public boolean supports(Class<?> arg0) {
		Class<?>[] supportedClasses = {
				EquipmentDTOV1.class,
				Collection.class
			};
			
		for(Class<?> c : supportedClasses){
			if(c.isAssignableFrom(arg0)){
				return true;
			}
		}
		return false;
	}

	/*
	 * (non-Javadoc)
	 * @see org.springframework.validation.Validator#validate(java.lang.Object, org.springframework.validation.Errors)
	 */
	@Override
	public void validate(Object arg0, Errors errors) {
		
		if(arg0 instanceof Collection<?>){
			Iterator<?> i = ((Collection<?>) arg0).iterator();
			
			while(i.hasNext()){
				validate(i.next(), errors);
			}
			return;
		}
		EquipmentDTOV1 equipment = (EquipmentDTOV1) arg0;
		
		// Validate Mandatory
		if (creationType == CreationType.NON_TEMPLATE && (!EquipmentService.validateNotNull(equipment.getName()))) {
			errors.reject(ErrorCodeEnum.NAME_NULL.getCode(), ErrorCodeEnum.NAME_NULL.getDescription());
		}
	
		if (!EquipmentService.validateNotNull(equipment.getcontainer())){
			errors.reject(ErrorCodeEnum.CONTAINER_NULL.getCode(), ErrorCodeEnum.CONTAINER_NULL.getDescription());
		}
		
		// Validate Site
		
		if((equipment.getsiteReference() == null || equipment.getsiteReference() < 1L) 
				&& (equipment.getClli() == null || equipment.getClli().trim().isEmpty())){
			errors.reject(ErrorCodeEnum.CLLI_SITE_REF_ID_NULL.getCode(), ErrorCodeEnum.CLLI_SITE_REF_ID_NULL.getDescription());
		}
		
		// Validate Equipment Specification

		if(creationType == CreationType.TEMPLATE 
				&& (equipment.getTemplateReference() == null || equipment.getTemplateReference() < 1L)
				&& (equipment.getTemplateName() == null || equipment.getTemplateName().trim().isEmpty())
				&& (equipment.getMfgPartNumber() == null || equipment.getMfgPartNumber().trim().isEmpty())) {
			errors.reject(ErrorCodeEnum.TEMP_REF_MFG_NUM.getCode(), ErrorCodeEnum.TEMP_REF_MFG_NUM.getDescription());
		}
		
		if (creationType == CreationType.TEMPLATE
				&& (equipment.getShelfType() != null && PATCH_PANEL.equalsIgnoreCase(equipment.getShelfType()))
				&& (equipment.getUtIndicator() != null && !(isYOrN(equipment.getUtIndicator())))) {
			errors.reject(ErrorCodeEnum.INVALID_INDICATORS.getCode(),
					ErrorCodeEnum.INVALID_INDICATORS.getDescription());
		}

		// Validate Frame
		
		if (!(equipment.getFunctionalEquipTypeName() != null 
				&& "UCPE".equalsIgnoreCase(equipment.getFunctionalEquipTypeName().trim()))
				&& (equipment.getparentEqReference() == null || equipment.getparentEqReference() < 1L)
				&& (equipment.getFrame() == null || equipment.getFrame().trim().isEmpty())) {
			errors.reject(ErrorCodeEnum.FRAME_NULL.getCode(), ErrorCodeEnum.FRAME_NULL.getDescription());
		}
		
		// Validate physicalTid and Shelf creation
		
		if (creationType == CreationType.TEMPLATE 
				&& EquipmentService.validateNotNull(equipment.getTargetId())
				&& !equipmentRepository.findByTidPhysical(equipment.getTargetId()).isEmpty()
				&& (equipment.getFrRefParentKeyValue() == null || equipment.getFrRefParentKeyValue().isEmpty()) ) {
		throw new DataConflictException("targetId", String.valueOf(equipment.getTargetId()), "Another equipment has the same TargetId");
		}
		
		// Validate Slot Name
		
		if (EquipmentService.validateNotNull(equipment.getSlotDTOList())) {
			SlotDTO invalidSlot = equipment.getSlotDTOList().stream().filter(s -> !EquipmentService.validateNotNull(s.getSlotName())).findAny().orElse(null);
			if(invalidSlot != null){
				errors.reject(ErrorCodeEnum.SLOT_NAME_NULL.getCode(), ErrorCodeEnum.SLOT_NAME_NULL.getDescription());
			}
		}

		// Validate FR_REF_KEY_NAME/VALUE
		
		if (EquipmentService.validateNotNull(equipment.getFrRefKeyName()) 
				&& EquipmentService.validateNotNull(equipment.getFrRefKeyValue())
				&& !equipmentRepository.findByFrRefKeyNameAndFrRefKeyValue(
						equipment.getFrRefKeyName(), equipment.getFrRefKeyValue()).isEmpty()) {
			
			errors.reject(ErrorCodeEnum.FR_REF_KEY_EXIST.getCode(), ErrorCodeEnum.FR_REF_KEY_EXIST.getDescription());
		}
		
		// Validate HOST NAME
		if (EquipmentService.validateNotNull(equipment.getHostName()) && 
				equipmentRepository.countByHostNameIgnoreCase(equipment.getHostName()) > 0) {

			errors.reject(ErrorCodeEnum.HOST_NAME_EXIST.getCode(), ErrorCodeEnum.HOST_NAME_EXIST.getDescription());
		}
		
	}
	
	/**
	 * validates the physicalTid
	 * 
	 * @param equipmentDTO
	 * @param errors
	 * @return
	 */
	public EquipmentDTOV1 validatePhysicalTid(EquipmentDTOV1 equipmentDTO, Errors errors) {

		if (equipmentDTO != null && equipmentDTO.getFrRefParentKeyValue() != null
				&& !equipmentDTO.getFrRefParentKeyValue().isEmpty()
				&& EquipmentService.validateNotNull(equipmentDTO.getTargetId())
				&& !equipmentDTO.getTargetId().isEmpty()) {

			List<Equipment> eqpList = equipmentRepository.findByTidPhysical(equipmentDTO.getTargetId());
			if (eqpList != null && !eqpList.isEmpty()) {
				boolean check = false;
				Equipment eqpObj = eqpList.get(0);

				if (eqpObj != null) {
					if (eqpObj.getTidPhysical() != null && eqpObj.getLocationClli() != null && eqpObj.getFrame() != null
							&& eqpObj.getHiLocationReference() != null) {
						check = ((eqpObj.getTidPhysical().equalsIgnoreCase(equipmentDTO.getTargetId()))
								&& (eqpObj.getLocationClli().equalsIgnoreCase(equipmentDTO.getClli()))
								&& (eqpObj.getFrame().equalsIgnoreCase(equipmentDTO.getFrame()))
								&& (eqpObj.getHiLocationReference().equalsIgnoreCase(equipmentDTO.getFloor()))) ? true
										: false;
					}

					if (check) {
						if (eqpObj.getFrRefKeyName() != null && eqpObj.getFrRefKeyName().equalsIgnoreCase(ICON_SHELF)) {
							if (eqpObj.getFrRefKeyValue() == null) {
								eqpObj.setFrRefKeyValue(equipmentDTO.getFrRefKeyValue());
								eqpObj = equipmentRepository.save(eqpObj);
							} else if (eqpObj.getFrRefKeyValue() != null && !equipmentDTO.getFrRefKeyValue()
									.equalsIgnoreCase(eqpObj.getFrRefKeyValue())) {
								errors.reject(ErrorCodeEnum.DIFFERENT_SHELF_STAMP_ID.getCode(),
										String.format(ErrorCodeEnum.DIFFERENT_SHELF_STAMP_ID.getDescription(),
												eqpObj.getFrRefKeyValue()) + eqpObj.getLocationClli() + " ,"
												+ eqpObj.getFrame() + " ," + eqpObj.getHiLocationReference());
							}
						} else if ((eqpObj.getFrRefKeyName() != null
								&& !eqpObj.getFrRefKeyName().equalsIgnoreCase(ICON_SHELF))
								|| eqpObj.getFrRefKeyName() == null) {
							eqpObj.setFrRefKeyName(ICON_SHELF);
							eqpObj.setFrRefKeyValue(equipmentDTO.getFrRefKeyValue());
							eqpObj = equipmentRepository.save(eqpObj);
						}

						return resourceMapper.convertToEquipmentDTOV1(eqpObj);
					} else {
						errors.reject(ErrorCodeEnum.PHYSICAL_TID_EXIST_WITH_DIFFERENT_VALUES.getCode(),
								ErrorCodeEnum.PHYSICAL_TID_EXIST_WITH_DIFFERENT_VALUES.getDescription()
										+ eqpObj.getTidPhysical() + ", " + eqpObj.getLocationClli() + ", "
										+ eqpObj.getFrame() + ", " + eqpObj.getHiLocationReference());
					}
				}
			}
		}
		return null;
	}
	
	/**
	 * validates the shelf creation
	 * 
	 * @param equipmentDTO
	 * @param errors
	 * @return
	 */
	public void validateShelfCreation(EquipmentDTOV1 equipmentDTO, Errors errors) {

		if (equipmentDTO != null && equipmentDTO.getFrRefParentKeyValue() != null
				&& !equipmentDTO.getFrRefParentKeyValue().isEmpty()) {
			List<Equipment> rackList = null;

			if (equipmentDTO.getFloor() != null && !equipmentDTO.getFloor().isEmpty()) {
				rackList = equipmentRepository
						.findByLocationClliAndFrameAndHiLocationReferenceAndDirContainerTypeContainer(
								equipmentDTO.getClli(), equipmentDTO.getFrame(), equipmentDTO.getFloor(),
								EntityType.RACK.toString());
			} else {
				rackList = equipmentRepository.findByLocationClliAndFrameAndDirContainerTypeContainer(
						equipmentDTO.getClli(), equipmentDTO.getFrame(), EntityType.RACK.toString());
			}

			if (rackList != null && !rackList.isEmpty()) {
				Equipment rack = rackList.get(0);

				if (rack != null) {
					if (rack.getFrRefKeyName() != null && rack.getFrRefKeyName().equalsIgnoreCase(ICON_RACK)) {
						if (rack.getFrRefKeyValue() == null) {
							rack.setFrRefKeyValue(equipmentDTO.getFrRefParentKeyValue());
							equipmentRepository.save(rack);
						} else if (rack.getFrRefKeyValue() != null
								&& !equipmentDTO.getFrRefParentKeyValue().equalsIgnoreCase(rack.getFrRefKeyValue())) {
							errors.reject(ErrorCodeEnum.DIFFERENT_RACK_STAMP_ID.getCode(),
									String.format(ErrorCodeEnum.DIFFERENT_RACK_STAMP_ID.getDescription(),
											rack.getFrRefKeyValue()) + rack.getLocationClli() + " ," + rack.getFrame()
											+ " ," + rack.getHiLocationReference());
						}
					} else if ((rack.getFrRefKeyName() != null && !rack.getFrRefKeyName().equalsIgnoreCase(ICON_RACK))
							|| rack.getFrRefKeyName() == null) {
						rack.setFrRefKeyName(ICON_RACK);
						rack.setFrRefKeyValue(equipmentDTO.getFrRefParentKeyValue());
						equipmentRepository.save(rack);
					}
				}
			} else {
				errors.reject(ErrorCodeEnum.RACK_NOT_FOUND.getCode(), ErrorCodeEnum.RACK_NOT_FOUND.getDescription()
						+ equipmentDTO.getClli() + " ," + equipmentDTO.getFrame() + " ," + equipmentDTO.getFloor());
			}
		}
	}

	public static boolean isYOrN(String value) {
		return value != null && ("Y".equalsIgnoreCase(value.trim()) || "N".equalsIgnoreCase(value.trim()));
	}
}