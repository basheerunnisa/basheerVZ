package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "ENODEB_DETAILS")
public class EnodebDetails {

	@Id
	@Column(name = "ENODEB_ID")
	private String enodebId;
	
	@Column(name = "EQP_REFERENCE_ID", nullable = false)
	private Long eqpReferenceId;
	
	@Column(name = "SITE_REFERENCE_ID", nullable = false)
	private Long siteReferenceId;
	
	@Column(name = "ENODEB_NAME", nullable = false)
	private String enodebName;
	
	@Column(name = "TRANS_CELL_TYPE", nullable = false)
	private String cellType;
	
	@Column(name = "LATITUDE")
	private Double latitude;
	
	@Column(name = "LONGITUDE")
	private Double longitude;
	
	@JsonBackReference
	@OneToMany(mappedBy = "details", fetch = FetchType.EAGER)
	private List<EnodebSector> sectors;


	public String getEnodebId() {
		return enodebId;
	}
	public void setEnodebId(String enodebId) {
		this.enodebId = enodebId;
	}
	public Long getEqpReferenceId() {
		return eqpReferenceId;
	}
	public void setEqpReferenceId(Long eqpReferenceId) {
		this.eqpReferenceId = eqpReferenceId;
	}
	public Long getSiteReferenceId() {
		return siteReferenceId;
	}
	public void setSiteReferenceId(Long siteReferenceId) {
		this.siteReferenceId = siteReferenceId;
	}
	public String getEnodebName() {
		return enodebName;
	}
	public void setEnodebName(String enodebName) {
		this.enodebName = enodebName;
	}
	public String getCellType() {
		return cellType;
	}
	public void setCellType(String cellType) {
		this.cellType = cellType;
	}
	public Double getLatitude() {
		return latitude;
	}
	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}
	public Double getLongitude() {
		return longitude;
	}
	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}
	public List<EnodebSector> getSectors() {
		return sectors;
	}
	public void setSectors(List<EnodebSector> sectors) {
		this.sectors = sectors;
	}
	
	public void sync(){
		if(sectors != null){
			sectors.forEach(sec -> sec.setDetails(this));
		}
	}
	
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "EnodebDetails [enodebId=" + enodebId + ", eqpReferenceId=" + eqpReferenceId + ", siteReferenceId="
				+ siteReferenceId + ", enodebName=" + enodebName + ", cellType=" + cellType + ", latitude=" + latitude
				+ ", longitude=" + longitude + ", sectors=" + sectors + "]";
	}	
}
