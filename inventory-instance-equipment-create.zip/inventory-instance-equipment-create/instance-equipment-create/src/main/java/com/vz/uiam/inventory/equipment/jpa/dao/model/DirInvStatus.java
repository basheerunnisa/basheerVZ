package com.vz.uiam.inventory.equipment.jpa.dao.model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * The persistent class for the DIR_INV_STATUS database table.
 * 
 */

@Entity
@Table(name = "DIR_INV_STATUS")
public class DirInvStatus {

	@EmbeddedId
	private DirInvStatusPk pk;

	@Column(name = "DISPLAY_SEQ")
	private Short displaySequence;

	@Column(name = "COLOR_CODE")
	private String colorCode;

	@Column(name = "INV_STATUS_ID")
	private Long invStatusId;

	public DirInvStatus() {
		super();
	}

	public DirInvStatus(String status, String entityName, Short displaySequence, String colorCode) {
		this();
		this.pk = new DirInvStatusPk(status, entityName);
		this.displaySequence = displaySequence;
		this.colorCode = colorCode;
	}

	public DirInvStatusPk getPk() {
		return pk;
	}

	public void setPk(DirInvStatusPk pk) {
		this.pk = pk;
	}

	public Short getDisplaySequence() {
		return displaySequence;
	}

	public void setDisplaySequence(Short displaySequence) {
		this.displaySequence = displaySequence;
	}

	public String getColorCode() {
		return colorCode;
	}

	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}

	public String getStatus() {
		return pk != null ? pk.getStatus() : null;
	}

	public void setStatus(String status) {
		if (pk != null) {
			this.pk.setStatus(status);
		}
	}

	public String getEntityName() {
		return pk != null ? pk.getEntityName() : null;
	}

	public void setEntityName(String entityName) {
		if (pk != null) {
			this.pk.setEntityName(entityName);
		}
	}

	public Long getInvStatusId() {
		return invStatusId;
	}

	public void setInvStatusId(Long invStatusId) {
		this.invStatusId = invStatusId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DirInvStatus [pk=" + pk + ", displaySequence=" + displaySequence + ", colorCode=" + colorCode + "]";
	}
}