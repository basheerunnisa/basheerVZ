package com.vz.uiam.inventory.equipment.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.hateoas.ResourceSupport;

import com.vz.uiam.common.usermanagement.rest.model.DirDomainsDTO;
import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;

public class EquipmentDTO extends ResourceSupport implements Serializable {

	private Long equipmentReference;
	private String type;
	private String vendor;
	private String model;
	private String name;
	private Integer siteReference;
	private Integer parentEqReference;
	private String status;
	private String container;
	private String eqClass;
	private BigDecimal height;
	private BigDecimal width;
	private BigDecimal depth;
	private BigDecimal distToBase;
	private BigDecimal distToLeft;
	private BigDecimal distToFront;
	private String lineUp;
	private String frame;
	private String logicalShelf;
	private String softwareRevision;
	private String hardwareRevision;
	private String pointCode;
	private String ems;
	private String targetId;
	private String orderNumber;
	private Date orderedDate;
	private Date dueDate;
	private Date installedDate;
	private Date inServiceDate;
	private Date scheduledDate;
	private Date decommisionDate;
	private String serialNumber;
	private String batchNumber;
	private String barCode;
	private BigDecimal purchasePrice;
	private Date purchaseDate;
	private BigDecimal assetLife;
	private String comments;
	private Date modifiedTimeStamp;
	private String modifiedUser;
	private String alternateName;
	private String clli;
	private String clei;
	private Integer templateReference;
	private String templateName;
	private Integer customerReference;
	private String ipAddress;
	private Integer parentShelfReference;
	private String isMultiTidShelf;
	private String physicalShelf;
	private String functionalEquipType;
	private String mfgPartNumber;
	private String aid;
	private String fieldId;
	private String frRefKeyName;
	private String frRefKeyValue;
	private String workOrderNumber;
	private String tid_l;

	private String assetOwner;
	private String subLocation;
	private String customerName;
	private String shelfType;
	private String ipv4Address;
	private String ipv6Address;


	private String floor;
	private List<DirDomainsDTO> domianNames;
	private List<AttributesDTO> attributeList;
	private List<SlotDTO> slotDTOList;
	private Integer totalPorts;
	private Integer availablePorts;
	private Integer usedPorts;
	private String networkDomain;
	private String projectReferenceId;


	private String rawTelnetPort;
	private String normalTelnetPort;
	private Integer mgmtSSHPort;
	private String hostName;
	
	public Integer getTotalPorts() {
		return totalPorts;
	}

	public void setTotalPorts(Integer totalPorts) {
		this.totalPorts = totalPorts;
	}

	public Integer getAvailablePorts() {
		return availablePorts;
	}

	public void setAvailablePorts(Integer availablePorts) {
		this.availablePorts = availablePorts;
	}

	public Integer getUsedPorts() {
		return usedPorts;
	}

	public void setUsedPorts(Integer usedPorts) {
		this.usedPorts = usedPorts;
	}
	public List<AttributesDTO> getAttributeList() {
		return attributeList;
	}

	public void setAttributeList(List<AttributesDTO> attributeList) {
		this.attributeList = attributeList;
	}

	private String networkType;

	private static final long serialVersionUID = 1L;

	public Long getEquipmentReference() {
		return equipmentReference;
	}

	public void setEquipmentReference(Long equipmentReference) {
		this.equipmentReference = equipmentReference;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getName() {
		return name;
	}

	public Integer getSiteReference() {
		return siteReference;
	}

	public void setSiteReference(Integer siteReference) {
		this.siteReference = siteReference;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getParentEqReference() {
		return parentEqReference;
	}

	public void setParentEqReference(Integer parentEqReference) {
		this.parentEqReference = parentEqReference;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getContainer() {
		return container;
	}

	public void setContainer(String container) {
		this.container = container;
	}

	public String getEqClass() {
		return eqClass;
	}

	public void setEqClass(String eqClass) {
		this.eqClass = eqClass;
	}

	public BigDecimal getHeight() {
		return height;
	}

	public void setHeight(BigDecimal height) {
		this.height = height;
	}

	public BigDecimal getWidth() {
		return width;
	}

	public void setWidth(BigDecimal width) {
		this.width = width;
	}

	public BigDecimal getDepth() {
		return depth;
	}

	public void setDepth(BigDecimal depth) {
		this.depth = depth;
	}

	public BigDecimal getDistToBase() {
		return distToBase;
	}

	public void setDistToBase(BigDecimal distToBase) {
		this.distToBase = distToBase;
	}

	public BigDecimal getDistToLeft() {
		return distToLeft;
	}

	public void setDistToLeft(BigDecimal distToLeft) {
		this.distToLeft = distToLeft;
	}

	public BigDecimal getDistToFront() {
		return distToFront;
	}

	public void setDistToFront(BigDecimal distToFront) {
		this.distToFront = distToFront;
	}

	public String getLineUp() {
		return lineUp;
	}

	public void setLineUp(String lineUp) {
		this.lineUp = lineUp;
	}

	public String getFrame() {
		return frame;
	}

	public void setFrame(String frame) {
		this.frame = frame;
	}

	public String getLogicalShelf() {
		return logicalShelf;
	}

	public void setLogicalShelf(String logicalShelf) {
		this.logicalShelf = logicalShelf;
	}

	public String getSoftwareRevision() {
		return softwareRevision;
	}

	public void setSoftwareRevision(String softwareRevision) {
		this.softwareRevision = softwareRevision;
	}

	public String getHardwareRevision() {
		return hardwareRevision;
	}

	public void setHardwareRevision(String hardwareRevision) {
		this.hardwareRevision = hardwareRevision;
	}

	public String getPointCode() {
		return pointCode;
	}

	public void setPointCode(String pointCode) {
		this.pointCode = pointCode;
	}

	public String getEms() {
		return ems;
	}

	public void setEms(String ems) {
		this.ems = ems;
	}

	public String getTargetId() {
		return targetId;
	}

	public void setTargetId(String targetId) {
		this.targetId = targetId;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public Date getOrderedDate() {
		return orderedDate;
	}

	public void setOrderedDate(Date orderedDate) {
		this.orderedDate = orderedDate;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public Date getInstalledDate() {
		return installedDate;
	}

	public void setInstalledDate(Date installedDate) {
		this.installedDate = installedDate;
	}

	public Date getInServiceDate() {
		return inServiceDate;
	}

	public void setInServiceDate(Date inServiceDate) {
		this.inServiceDate = inServiceDate;
	}

	public Date getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(Date scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public Date getDecommisionDate() {
		return decommisionDate;
	}

	public void setDecommisionDate(Date decommisionDate) {
		this.decommisionDate = decommisionDate;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getBatchNumber() {
		return batchNumber;
	}

	public void setBatchNumber(String batchNumber) {
		this.batchNumber = batchNumber;
	}

	public String getBarCode() {
		return barCode;
	}

	public void setBarCode(String barCode) {
		this.barCode = barCode;
	}

	public BigDecimal getPurchasePrice() {
		return purchasePrice;
	}

	public void setPurchasePrice(BigDecimal purchasePrice) {
		this.purchasePrice = purchasePrice;
	}

	public Date getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public BigDecimal getAssetLife() {
		return assetLife;
	}

	public void setAssetLife(BigDecimal assetLife) {
		this.assetLife = assetLife;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Date getModifiedTimeStamp() {
		return modifiedTimeStamp;
	}

	public void setModifiedTimeStamp(Date modifiedTimeStamp) {
		this.modifiedTimeStamp = modifiedTimeStamp;
	}

	public String getModifiedUser() {
		return modifiedUser;
	}

	public void setModifiedUser(String modifiedUser) {
		this.modifiedUser = modifiedUser;
	}

	public String getAlternateName() {
		return alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getClli() {
		return clli;
	}

	public void setClli(String clli) {
		this.clli = clli;
	}

	public String getClei() {
		return clei;
	}

	public void setClei(String clei) {
		this.clei = clei;
	}

	public Integer getTemplateReference() {
		return templateReference;
	}

	public void setTemplateReference(Integer templateReference) {
		this.templateReference = templateReference;
	}

	public Integer getCustomerReference() {
		return customerReference;
	}

	public void setCustomerReference(Integer customerReference) {
		this.customerReference = customerReference;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public Integer getParentShelfReference() {
		return parentShelfReference;
	}

	public void setParentShelfReference(Integer parentShelfReference) {
		this.parentShelfReference = parentShelfReference;
	}

	public String getIsMultiTidShelf() {
		return isMultiTidShelf;
	}

	public void setIsMultiTidShelf(String isMultiTidShelf) {
		this.isMultiTidShelf = isMultiTidShelf;
	}

	public String getPhysicalShelf() {
		return physicalShelf;
	}

	public void setPhysicalShelf(String physicalShelf) {
		this.physicalShelf = physicalShelf;
	}

	public String getFunctionalEquipType() {
		return functionalEquipType;
	}

	public void setFunctionalEquipType(String functionalEquipType) {
		this.functionalEquipType = functionalEquipType;
	}

	public String getMfgPartNumber() {
		return mfgPartNumber;
	}

	public void setMfgPartNumber(String mfgPartNumber) {
		this.mfgPartNumber = mfgPartNumber;
	}

	public String getAid() {
		return aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public String getFieldId() {
		return fieldId;
	}

	public void setFieldId(String fieldId) {
		this.fieldId = fieldId;
	}

	public String getFrRefKeyName() {
		return frRefKeyName;
	}

	public void setFrRefKeyName(String frRefKeyName) {
		this.frRefKeyName = frRefKeyName;
	}

	public String getFrRefKeyValue() {
		return frRefKeyValue;
	}

	public void setFrRefKeyValue(String frRefKeyValue) {
		this.frRefKeyValue = frRefKeyValue;
	}

	public String getWorkOrderNumber() {
		return workOrderNumber;
	}

	public void setWorkOrderNumber(String workOrderNumber) {
		this.workOrderNumber = workOrderNumber;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getTid_l() {
		return tid_l;
	}

	public void setTid_l(String tid_l) {
		this.tid_l = tid_l;
	}

	public String getAssetOwner() {
		return assetOwner;
	}

	public void setAssetOwner(String assetOwner) {
		this.assetOwner = assetOwner;
	}

	public String getSubLocation() {
		return subLocation;
	}

	public void setSubLocation(String subLocation) {
		this.subLocation = subLocation;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getShelfType() {
		return shelfType;
	}

	public void setShelfType(String shelfType) {
		this.shelfType = shelfType;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public List<DirDomainsDTO> getDomianNames() {
		return domianNames;
	}

	public void setDomianNames(List<DirDomainsDTO> domianNames) {
		this.domianNames = domianNames;
	}

	

	public String getNetworkType() {
		return networkType;
	}

	public void setNetworkType(String networkType) {
		this.networkType = networkType;
	}

	public String getIpv4Address() {
		return ipv4Address;
	}

	public void setIpv4Address(String ipv4Address) {
		this.ipv4Address = ipv4Address;
	}

	public String getIpv6Address() {
		return ipv6Address;
	}

	public void setIpv6Address(String ipv6Address) {
		this.ipv6Address = ipv6Address;
	}

	public String getNetworkDomain() {
		return networkDomain;
	}

	public void setNetworkDomain(String networkDomain) {
		this.networkDomain = networkDomain;
	}
	
	public String getProjectReferenceId() {
		return projectReferenceId;
	}

	public void setProjectReferenceId(String projectReferenceId) {
		this.projectReferenceId = projectReferenceId;
	}
	
	public String getRawTelnetPort() {
		return rawTelnetPort;
	}

	public void setRawTelnetPort(String rawTelnetPort) {
		this.rawTelnetPort = rawTelnetPort;
	}
	
	public String getNormalTelnetPort() {
		return normalTelnetPort;
	}

	public void setNormalTelnetPort(String normalTelnetPort) {
		this.normalTelnetPort = normalTelnetPort;
	}

	public Integer getMgmtSSHPort() {
		return mgmtSSHPort;
	}

	public void setMgmtSSHPort(Integer mgmtSSHPort) {
		this.mgmtSSHPort = mgmtSSHPort;
	}

    public List<SlotDTO> getSlotDTOList() {
        return slotDTOList;
    }

    public void setSlotDTOList(List<SlotDTO> slotDTOList) {
        this.slotDTOList = slotDTOList;
    }

    public String getHostName(){
		return hostName;
	}
    
	public void setHostName(String hostName){
		this.hostName = hostName;
	}
	
    @Override
    public String toString() {
        return "EquipmentDTO{" +
                "equipmentReference=" + equipmentReference +
                ", type='" + type + '\'' +
                ", vendor='" + vendor + '\'' +
                ", model='" + model + '\'' +
                ", name='" + name + '\'' +
                ", siteReference=" + siteReference +
                ", parentEqReference=" + parentEqReference +
                ", status='" + status + '\'' +
                ", container='" + container + '\'' +
                ", eqClass='" + eqClass + '\'' +
                ", height=" + height +
                ", width=" + width +
                ", depth=" + depth +
                ", distToBase=" + distToBase +
                ", distToLeft=" + distToLeft +
                ", distToFront=" + distToFront +
                ", lineUp='" + lineUp + '\'' +
                ", frame='" + frame + '\'' +
                ", logicalShelf='" + logicalShelf + '\'' +
                ", softwareRevision='" + softwareRevision + '\'' +
                ", hardwareRevision='" + hardwareRevision + '\'' +
                ", pointCode='" + pointCode + '\'' +
                ", ems='" + ems + '\'' +
                ", targetId='" + targetId + '\'' +
                ", orderNumber='" + orderNumber + '\'' +
                ", orderedDate=" + orderedDate +
                ", dueDate=" + dueDate +
                ", installedDate=" + installedDate +
                ", inServiceDate=" + inServiceDate +
                ", scheduledDate=" + scheduledDate +
                ", decommisionDate=" + decommisionDate +
                ", serialNumber='" + serialNumber + '\'' +
                ", batchNumber='" + batchNumber + '\'' +
                ", barCode='" + barCode + '\'' +
                ", purchasePrice=" + purchasePrice +
                ", purchaseDate=" + purchaseDate +
                ", assetLife=" + assetLife +
                ", comments='" + comments + '\'' +
                ", modifiedTimeStamp=" + modifiedTimeStamp +
                ", modifiedUser='" + modifiedUser + '\'' +
                ", alternateName='" + alternateName + '\'' +
                ", clli='" + clli + '\'' +
                ", clei='" + clei + '\'' +
                ", templateReference=" + templateReference +
                ", templateName='" + templateName + '\'' +
                ", customerReference=" + customerReference +
                ", ipAddress='" + ipAddress + '\'' +
                ", parentShelfReference=" + parentShelfReference +
                ", isMultiTidShelf='" + isMultiTidShelf + '\'' +
                ", physicalShelf='" + physicalShelf + '\'' +
                ", functionalEquipType=" + functionalEquipType +
                ", mfgPartNumber='" + mfgPartNumber + '\'' +
                ", aid='" + aid + '\'' +
                ", fieldId='" + fieldId + '\'' +
                ", frRefKeyName='" + frRefKeyName + '\'' +
                ", frRefKeyValue='" + frRefKeyValue + '\'' +
                ", workOrderNumber='" + workOrderNumber + '\'' +
                ", tid_l='" + tid_l + '\'' +
                ", assetOwner='" + assetOwner + '\'' +
                ", subLocation='" + subLocation + '\'' +
                ", customerName='" + customerName + '\'' +
                ", shelfType='" + shelfType + '\'' +
                ", ipv4Address='" + ipv4Address + '\'' +
                ", ipv6Address='" + ipv6Address + '\'' +
                ", floor='" + floor + '\'' +
                ", domianNames=" + domianNames +
                ", attributeList=" + attributeList +
                ", slotDTOList=" + slotDTOList +
                ", totalPorts=" + totalPorts +
                ", availablePorts=" + availablePorts +
                ", usedPorts=" + usedPorts +
                ", networkDomain='" + networkDomain + '\'' +
                ", projectReferenceId=" + projectReferenceId +
                ", rawTelnetPort=" + rawTelnetPort +
                ", normalTelnetPort=" + normalTelnetPort +
                ", mgmtSSHPort=" + mgmtSSHPort +
                ", networkType='" + networkType + '\'' +
                ", hostName=" + hostName + 
                '}';
    }
}