package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.util.List;

import org.javers.spring.annotation.JaversSpringDataAuditable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.EquipmentAttributes;

@Transactional
@JaversSpringDataAuditable
public interface EquipmentAttributesRepository extends JpaRepository<EquipmentAttributes, Long> {

	List<EquipmentAttributes> findByEqpReferenceId(Long eqpReferenceId);
	
	List<EquipmentAttributes> findByEqpReferenceIdAndEqpGroupName(Long eqpReferenceId, String groupName);
	
	@Query(value="SELECT * FROM EQUIPMENT_ATTRIBUTES WHERE EQP_GROUP_NAME = 'EQUIPMENT_INFORMATION' "
			   + "AND EQP_NAME = 'Equipment ID' AND EQP_VALUE IN ( :enodebIds )", nativeQuery = true)
	<T extends Iterable<String>> List<EquipmentAttributes> getEquipmentAttributesByEnodebIds(@Param("enodebIds") T enodebIds);	
}