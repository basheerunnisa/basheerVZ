package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "CARD_EQP_FUNCTIONAL_TYPE_MAP")
public class CardEqpFunctionalTypeMap implements Serializable{

	private static final long serialVersionUID = 1L;

	@Column(name = "FUNCTIONAL_TYPE_ID")
	private Integer functionalTypeId;
	
	@EmbeddedId
	private CardEqpFunctionalTypeMapPK cardEqpFunctionalTypeMapPk;

	public Integer getFunctionalTypeId() {
		return functionalTypeId;
	}

	public void setFunctionalTypeId(Integer functionalTypeId) {
		this.functionalTypeId = functionalTypeId;
	}

	public CardEqpFunctionalTypeMapPK getCardEqpFunctionalTypeMapPK() {
		return cardEqpFunctionalTypeMapPk;
	}

	public void setCardEqpFunctionalTypeMapPK(CardEqpFunctionalTypeMapPK cardEqpFunctionalTypeMapPK) {
		this.cardEqpFunctionalTypeMapPk = cardEqpFunctionalTypeMapPK;
	}
	
}
