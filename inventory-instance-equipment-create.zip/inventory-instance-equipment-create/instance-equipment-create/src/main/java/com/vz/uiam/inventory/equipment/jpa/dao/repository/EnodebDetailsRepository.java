package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vz.uiam.inventory.equipment.jpa.dao.model.EnodebDetails;

@Transactional
public interface EnodebDetailsRepository extends JpaRepository<EnodebDetails, String> {
	
	<T extends Iterable<String>> List<EnodebDetails> findByEnodebIdIn(T enodebIds);
}
