package com.vz.uiam.inventory.equipment.jpa.dao.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AUXILIARY_EQUIPMENT")
public class AuxiliaryEquipment {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "AUX_ID")
	private Long auxId;
	
	@Column(name = "HOSTNAME", unique = true)
	private String hostname;
	
	@Column(name = "AUX_TYPE")
	private String auxType;
	
	@Column(name = "AUX_STATUS")
	private String auxStatus;
	
	@Column(name = "SITE_REFERENCE_ID")
	private Long siteReferenceId;

	public Long getAuxId() {
		return auxId;
	}

	public void setAuxId(Long auxId) {
		this.auxId = auxId;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public String getAuxType() {
		return auxType;
	}

	public void setAuxType(String auxType) {
		this.auxType = auxType;
	}

	public String getAuxStatus() {
		return auxStatus;
	}

	public void setAuxStatus(String auxStatus) {
		this.auxStatus = auxStatus;
	}

	public Long getSiteReferenceId() {
		return siteReferenceId;
	}

	public void setSiteReferenceId(Long siteReferenceId) {
		this.siteReferenceId = siteReferenceId;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AuxiliaryEquipment [auxId=" + auxId + ", hostname=" + hostname + ", auxType=" + auxType + ", auxStatus="
				+ auxStatus + ", siteReferenceId=" + siteReferenceId + "]";
	}
}
