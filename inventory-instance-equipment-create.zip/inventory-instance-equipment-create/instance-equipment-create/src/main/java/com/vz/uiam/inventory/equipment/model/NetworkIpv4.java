package com.vz.uiam.inventory.equipment.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.vz.uiam.inventory.instance.rest.api.model.AdditionalAttributes;

/**
 * <p>
 * This class is used to transfer the response from nonPreAssignedNetwork API
 * </p>
 * 
 * @author Asif Billa
 * @date 14-Sept-2017
 *
 */
public class NetworkIpv4 implements Serializable {

	private static final long serialVersionUID = 1L;

	private String poolName;

	private BigDecimal assignId;

	private String site;

	private BigDecimal siteId;

	private String organization;

	private String domain;

	private String netName;

	private String comments;

	private String applicationName;

	private String createdBy;
        
	@JsonIgnore
	private Date createdDate;

	private String modifiedBy;
        
	@JsonIgnore
	private Date modifiedDate;

	private BigDecimal defaultHoldDays;

	private BigDecimal poolHead;

	private BigDecimal hostCount;

	private BigDecimal homeAs;

	private Character garmSensitivityLevel;

	private BigDecimal poolId;

	private String selectionAlgorithm;

	private String peRouterName;

	private String peInterfaceName;

	private String peSubinterfaceName;

	private String dnsCustomerDomainId;

	private String dnsOddDomain;

	private String dnsEvenDomain;

	private String vPoolGroup;

	private String cidr;

	private String networkStatus;

	private List<AdditionalAttributes> additionalAttributes;

	private String subnetMask;

	private String defaultGateWay;

	private String availableIPGap;
	
	private List<String> cidrList;

	public String getPoolName() {
		return poolName;
	}

	public void setPoolName(String poolName) {
		this.poolName = poolName;
	}

	public BigDecimal getAssignId() {
		return assignId;
	}

	public void setAssignId(BigDecimal assignId) {
		this.assignId = assignId;
	}

	public String getSite() {
		return site;
	}

	public void setSite(String site) {
		this.site = site;
	}

	public BigDecimal getSiteId() {
		return siteId;
	}

	public void setSiteId(BigDecimal siteId) {
		this.siteId = siteId;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getNetName() {
		return netName;
	}

	public void setNetName(String netName) {
		this.netName = netName;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public BigDecimal getDefaultHoldDays() {
		return defaultHoldDays;
	}

	public void setDefaultHoldDays(BigDecimal defaultHoldDays) {
		this.defaultHoldDays = defaultHoldDays;
	}

	public BigDecimal getPoolHead() {
		return poolHead;
	}

	public void setPoolHead(BigDecimal poolHead) {
		this.poolHead = poolHead;
	}

	public BigDecimal getHostCount() {
		return hostCount;
	}

	public void setHostCount(BigDecimal hostCount) {
		this.hostCount = hostCount;
	}

	public BigDecimal getHomeAs() {
		return homeAs;
	}

	public void setHomeAs(BigDecimal homeAs) {
		this.homeAs = homeAs;
	}

	public Character getGarmSensitivityLevel() {
		return garmSensitivityLevel;
	}

	public void setGarmSensitivityLevel(Character garmSensitivityLevel) {
		this.garmSensitivityLevel = garmSensitivityLevel;
	}

	public BigDecimal getPoolId() {
		return poolId;
	}

	public void setPoolId(BigDecimal poolId) {
		this.poolId = poolId;
	}

	public String getSelectionAlgorithm() {
		return selectionAlgorithm;
	}

	public void setSelectionAlgorithm(String selectionAlgorithm) {
		this.selectionAlgorithm = selectionAlgorithm;
	}

	public String getPeRouterName() {
		return peRouterName;
	}

	public void setPeRouterName(String peRouterName) {
		this.peRouterName = peRouterName;
	}

	public String getPeInterfaceName() {
		return peInterfaceName;
	}

	public void setPeInterfaceName(String peInterfaceName) {
		this.peInterfaceName = peInterfaceName;
	}

	public String getPeSubinterfaceName() {
		return peSubinterfaceName;
	}

	public void setPeSubinterfaceName(String peSubinterfaceName) {
		this.peSubinterfaceName = peSubinterfaceName;
	}

	public String getDnsCustomerDomainId() {
		return dnsCustomerDomainId;
	}

	public void setDnsCustomerDomainId(String dnsCustomerDomainId) {
		this.dnsCustomerDomainId = dnsCustomerDomainId;
	}

	public String getDnsOddDomain() {
		return dnsOddDomain;
	}

	public void setDnsOddDomain(String dnsOddDomain) {
		this.dnsOddDomain = dnsOddDomain;
	}

	public String getDnsEvenDomain() {
		return dnsEvenDomain;
	}

	public void setDnsEvenDomain(String dnsEvenDomain) {
		this.dnsEvenDomain = dnsEvenDomain;
	}

	public String getvPoolGroup() {
		return vPoolGroup;
	}

	public void setvPoolGroup(String vPoolGroup) {
		this.vPoolGroup = vPoolGroup;
	}

	public String getCidr() {
		return cidr;
	}

	public void setCidr(String cidr) {
		this.cidr = cidr;
	}

	public String getNetworkStatus() {
		return networkStatus;
	}

	public void setNetworkStatus(String networkStatus) {
		this.networkStatus = networkStatus;
	}

	public List<AdditionalAttributes> getAdditionalAttributes() {
		return additionalAttributes;
	}

	public void setAdditionalAttributes(List<AdditionalAttributes> additionalAttributes) {
		this.additionalAttributes = additionalAttributes;
	}

	public String getSubnetMask() {
		return subnetMask;
	}

	public void setSubnetMask(String subnetMask) {
		this.subnetMask = subnetMask;
	}

	public String getDefaultGateWay() {
		return defaultGateWay;
	}

	public void setDefaultGateWay(String defaultGateWay) {
		this.defaultGateWay = defaultGateWay;
	}

	public String getAvailableIPGap() {
		return availableIPGap;
	}

	public void setAvailableIPGap(String availableIPGap) {
		this.availableIPGap = availableIPGap;
	}
	
	public List<String> getCidrList() {
		return cidrList;
	}

	public void setCidrList(List<String> cidrList) {
		this.cidrList = cidrList;
	}

	@Override
	public String toString() {
		return "NetworkIpv4 [poolName=" + poolName + ", assignId=" + assignId + ", site=" + site + ", siteId=" + siteId
				+ ", organization=" + organization + ", domain=" + domain + ", netName=" + netName + ", comments="
				+ comments + ", applicationName=" + applicationName + ", createdBy=" + createdBy + ", createdDate="
				+ createdDate + ", modifiedBy=" + modifiedBy + ", modifiedDate=" + modifiedDate + ", defaultHoldDays="
				+ defaultHoldDays + ", poolHead=" + poolHead + ", hostCount=" + hostCount + ", homeAs=" + homeAs
				+ ", garmSensitivityLevel=" + garmSensitivityLevel + ", poolId=" + poolId + ", selectionAlgorithm="
				+ selectionAlgorithm + ", peRouterName=" + peRouterName + ", peInterfaceName=" + peInterfaceName
				+ ", peSubinterfaceName=" + peSubinterfaceName + ", dnsCustomerDomainId=" + dnsCustomerDomainId
				+ ", dnsOddDomain=" + dnsOddDomain + ", dnsEvenDomain=" + dnsEvenDomain + ", vPoolGroup=" + vPoolGroup
				+ ", cidr=" + cidr + ", networkStatus=" + networkStatus + ", additionalAttributes="
				+ additionalAttributes + ", subnetMask=" + subnetMask + ", defaultGateWay=" + defaultGateWay
				+ ", availableIPGap=" + availableIPGap + ", cidrList=" + cidrList + "]";
	}

}
