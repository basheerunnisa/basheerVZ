package com.vz.uiam.inventory.equipment.enumeration;

public enum ErrorCodeEnum {

	FRAME_NULL("ERROR", "Frame is empty","INEA0001"),
	CLLI_SITE_REF_ID_NULL("ERROR", "Clli OR SiteReferenceId is empty","INEA0002"),
	TEMP_REF_MFG_NUM("ERROR", "TemplateReference OR MfgPartNumber is empty","INEA0003"),
	STATUS_NULL("ERROR", "Status is empty","INEA0004"),
	FRAME_EXIST("INFO", "Given Rack/Frame is already present in the requested CLLI","INEA0005"), 
	CONTAINER_NULL("ERROR", "Container is empty","INEA0006"), 
	SHELF_EXIST("INFO", "Given physical Shelf/Panel is already present in the given Rack/Frame and CLLI","INEA0007"),
	NAME_NULL("ERROR", "Equipment Name is empty","INEA0008"),
	NAME_EXIST("INFO","Name already in use by another Rack","INEA0009"),
	NAME_REQ("ERROR", "Name is a required field for Rack creation","INEA0010"),
	INV_SITEID("INFO","siteReference is not valid","INEA00011"),
	INV_TEMP_REFID("INFO","templateReference is not valid","INEA00012"),
	INV_STATUS("INFO","status is not valid","INEA00013"),
	INV_CLLI("INFO","clli is not valid","INEA00014"),
	INV_DOMAIN("ERROR","Invalid Domain Name ","INEA00015"),
	SLOT_NAME_NULL("ERROR", "Slot Name is empty","INEA0016"),
	RACK_ERROR("ERROR", "Error in getting Rack details","INEA0017"),
	INV_INPUT("ERROR", "Mandatory fields [CLLI or PhysicalShelf or Frame] missing","INEA0018"),
	INV_MFG_PART_NUM("ERROR", "Invalid Manufacturer Part Number","INEA0019"),
	MFG_PART_NUM_ERROR("ERROR", "Found too many equipment specs for manufacturer part number","INEA0020"), 
	FR_REF_KEY_EXIST("ERROR","FrRefKeyName and FrRefKeyValue already exists","INEA0021"),
	USER_INVALID("ERROR","UserId is not valid in the request header.","INEA0022"),
	VIRTUAL_EQP_FUNCTION_INVALID("ERROR","Virtual Equipment function is not valid.","INEA0023"),
	PHYSICAL_EQP_TID_INVALID("ERROR","Physical Equipment target id(TID) is not valid.","INEA0024"),
	EQP_CREATE("ERROR","Error while equipment creation with cards.","INEA0025"),
	EQP_CREATE_WITH_CARDS("ERROR","Error while equipment creation .","INEA0026"),
	PHYSICAL_EQP_REQ_INVALID("ERROR","Request for Physical Equipment is invalid. Either valid physical equipment reference id or physical target id(TID) should exist.","INEA0027"),
	VIRTUAL_EQP_EXIST_ERROR("ERROR","Virtual equipment for this physical equipment already exists.","INEA0028"),
	INV_VIRTUAL_EQP_TID("ERROR","Mandatory field Virtual equipment logical TID is missing.","INEA0029"),
	VIRTUAL_EQP_WITH_TID_EXISTS("ERROR","Virtual equipment with given logical TID already exists.","INEA0030"),
	IP_ASSIGNMENT_FAILURE("ERROR","Not able to assign IP with the loop back RI for TID_logical:","INEA0031"),
	INVALID_IP_ASSIGNMENT("ERROR","Assigned IP Address or SubnetMask is null","INEA0032"),
	ASSIGNMENT_SERVICE_CALL_ERROR("ERROR","Error while Calling Assignment Service","INEA0033"),
	SPECIFICATION_ATTRIBUTE_SERVICE_CALL_ERROR("ERROR","Error while calling Specification Attribute Service please remove assigned IP manually for equipment reference ID","INEA0034"),
	INVALID_EQUIPMENT_REF_ID_OR_TID_LOGICAL_OR_HOST_NAME("ERROR","In valid EquimentRefId/TidLogical/HostName","INEA0035"),
	SHELF_TYPE_IS_NOT_ELIGIBLE("ERROR", "shelf type is not eligible for Tid Logical/Host Name: %s", "INEA0036"),
	UNABLE_TO_DESERIALIZE_ERROR_RESPONSE_FROM_ASSIGNMENT_SERVICE("ERROR","Error while Deserializing Error Response from Assignment Service with error details","INEA0037"),
	INVALID_TID_LOGICAL("ERROR","More than one records found with the passed in TidLogical: %s, Please provide valid input","INEA0038"),
	MORE_TID_LOGICAL_INVALID_EQP_REF_ID("ERROR","More than one records Tid Logical: %s found with the passed Equipment Ref ID: %s","INEA0039"),
	INVALID_EQP_REF_ID("ERROR","No Tid Logical is Found with the passed in equipment Referrence Id: %s ","INEA0040"),
	IP_ALREADY_ASSIGNED_FOR_LOOP_BACK_MSERI("ERROR","Loop Back IPs: %s & %s are already assigned to the Equipment with Tid Logical:%s","INEA0041"),
	INVALID_ATTRIBUTE_GROUP_NAME("ERROR", "Could not able to get Attribute Group name from INVENTORY_CONFIG","INEA0042"),
	DUPLICATE_TID_LOGICALS("ERROR", "suTIDLogical and tIDLogical cannot be same for given TIDLogical: %s","INEA0043"),
	NO_RELATION_BTW_SU_OTHER_RI("ERROR","No relation exists between su-RI: %s and other-RI: %s, Please provide valid input","INEA0044"),
	NO_SU_RI_EQUIPMENT("ERROR","No SU-RI equipment exists for given TidLogical: %s, Please provide valid input","INEA0045"),
	MORE_SU_RI_EQUIPMENTS("ERROR","More than one SU-RI Equipments found with passed TidLogical: %s, Please provide valid input","INEA0046"),
	HOST_NAME_EXIST("ERROR","Host-Name already in use by another equipment","INEA0047"),
	NO_RACK_HOST_NAME("ERROR", "HostName cannot be provided for a rack","INEA0048"),
	DIFFERENT_SHELF_STAMP_ID("ERROR", "SHELF found but stamped with different ICON SHELF ID: %s for this CLLI, FRAME, FLOOR: ","INEA0049"),
	PHYSICAL_TID_EXIST_WITH_DIFFERENT_VALUES("ERROR", "Physical TID is already present IN DIFFERENT CLLI, FRAME, FLOOR than requested: ","INEA0050"),
	RACK_NOT_FOUND("ERROR", "Failed to find Equipment Rack with CLLI, FRAME, FLOOR: ","INEA0051"),
	DIFFERENT_RACK_STAMP_ID("ERROR", "RACK found but stamped with different ICON RACK ID: %s for this CLLI, FRAME, FLOOR: ","INEA0052"),
	INVALID_INDICATORS("ERROR", "UtIndicator should be Y/N", "INEA0053"),
	IP_ALREADY_ASSIGNED_FOR_LOOP_BACK_NGPON2("ERROR","Loop Back IP: %s  is already assigned to the Equipment with Tid Logical: %s","INEA0054"),
	INVALID_EQP_TID_LOGICAL("ERROR","No Equipment exists with provided tidLogical: %s, Please provide valid input","INEA0055"),
	INVALID_EQP_HOST_NAME("ERROR","No Equipment exists with provided hostName: %s, Please provide valid input","INEA0056"),
	MORE_TID_LOGICAL_INVALID_HOST_NAME("ERROR","More than one records found with the passed host name: %s","INEA0057"),
	DELETE_CARD_API_SERVICE_FAILURE("ERROR","Exception While Calling delete card API service%s","INEA0058"),
	DELETE_SHELF_API_SERVICE_FAILURE("ERROR","Exception While Calling delete shelf API service%s","INEA0059");
	
	private String category;
    private String description;
    private String code;

    ErrorCodeEnum(String category, String description, String code) {
	this.category = category;
	this.description = description;
	this.code=code;
    }

    
    /**
     * @return the category
     */
    public String getCategory() {
	return category;
    }

    /**
     * @return the description
     */
    public String getDescription() {
	return description;
    }

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
}
 