package com.vz.uiam.inventory.equipment.jpa.dao.model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * The persistent class for the DIR_INV_TYPE database table.
 *
 * @author Carlos Rubiano
 * 
 */

@Entity
@Table(name = "DIR_INV_TYPE")
public class DirInvType {

	@EmbeddedId
	private DirInvTypePk pk;

	@Column(name = "DISPLAY_SEQ")
	private Short displaySequence;

	@Column(name = "DESCRIPTION")
	private String description;
	
	public DirInvType() {
		super();
	}

	public DirInvType(String type, String entityName, Short displaySequence, String description) {
		this();
		this.pk = new DirInvTypePk(type, entityName);
		this.displaySequence = displaySequence;
		this.description = description;
	}

	public DirInvTypePk getPk() {
		return pk;
	}

	public void setPk(DirInvTypePk pk) {
		this.pk = pk;
	}

	public Short getDisplaySequence() {
		return displaySequence;
	}

	public void setDisplaySequence(Short displaySequence) {
		this.displaySequence = displaySequence;
	}

	public String getType() {
		return pk != null ? pk.getType() : null;
	}

	public void setType(String type) {
		if (pk != null) {
			this.pk.setType(type);
		}
	}

	public String getEntityName() {
		return pk != null ? pk.getEntityName() : null;
	}

	public void setEntityName(String entityName) {
		if (pk != null) {
			this.pk.setEntityName(entityName);
		}
	}
}