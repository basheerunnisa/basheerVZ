package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.javers.core.metamodel.annotation.TypeName;


/**
 * The persistent class for the DIR_INVENTORY_DEFINITION database table.
 * 
 */
@Entity
@Table(name="DIR_INVENTORY_DEFINITION")
@TypeName("DirInventoryDefinition")
@NamedQuery(name="DirInventoryDefinition.findAll", query="SELECT d FROM DirInventoryDefinition d")
public class DirInventoryDefinition implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="DEFAULT_VALUE")
	private String defaultValue;

	@Column(name="DISPLAY_SEQUENCE")
	private BigDecimal displaySequence;

	@Column(name="GROUP_NAME")
	private String groupName;

	@Column(name="IS_MANDATORY")
	private String isMandatory;

	@Column(name="IS_MODIFIABLE")
	private String isModifiable;

	private String name;

	@Column(name="SUB_TYPE")
	private String subType;

	//bi-directional many-to-one association to DirInventoryDescriptor
	@ManyToOne
	@JoinColumn(name="INV_DESCPT_ID")
	private DirInventoryDescriptor dirInventoryDescriptor;

	//bi-directional many-to-one association to DirInvDefAttribute
	@ManyToOne
	@JoinColumn(name="INV_DEF_ATTR_ID")
	private DirInvDefAttribute dirInvDefAttribute;

	public DirInventoryDefinition() {
	}

	public String getDefaultValue() {
		return this.defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

	public BigDecimal getDisplaySequence() {
		return this.displaySequence;
	}

	public void setDisplaySequence(BigDecimal displaySequence) {
		this.displaySequence = displaySequence;
	}

	public String getGroupName() {
		return this.groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getIsMandatory() {
		return this.isMandatory;
	}

	public void setIsMandatory(String isMandatory) {
		this.isMandatory = isMandatory;
	}

	public String getIsModifiable() {
		return this.isModifiable;
	}

	public void setIsModifiable(String isModifiable) {
		this.isModifiable = isModifiable;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSubType() {
		return this.subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public DirInventoryDescriptor getDirInventoryDescriptor() {
		return this.dirInventoryDescriptor;
	}

	public void setDirInventoryDescriptor(DirInventoryDescriptor dirInventoryDescriptor) {
		this.dirInventoryDescriptor = dirInventoryDescriptor;
	}

	public DirInvDefAttribute getDirInvDefAttribute() {
		return this.dirInvDefAttribute;
	}

	public void setDirInvDefAttribute(DirInvDefAttribute dirInvDefAttribute) {
		this.dirInvDefAttribute = dirInvDefAttribute;
	}

}