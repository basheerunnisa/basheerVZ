package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.javers.core.metamodel.annotation.TypeName;

import com.vz.uiam.inventory.equipment.model.validator.EntityValidator;

/**
 * The persistent class for the CARD_SPEC database table.
 * 
 */
@Entity
@Table(name = "CARD_SPEC")
@TypeName("CardSpec")
@NamedQuery(name = "CardSpec.findAll", query = "SELECT c FROM CardSpec c")
public class CardSpec implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "CARD_SPEC_REF_ID")
	private long cardSpecRefId;

	private String aid;

	@Column(name = "CARD_FUNCTIONAL_TYPE")
	private String cardFunctionalType;

	private String clei;

	@Column(name = "DEPTH")
	private BigDecimal depth;

	private String description;

	@Column(name = "EQUIPMENT_VENDOR")
	private String equipmentVendor;

	private BigDecimal height;

	@Column(name = "IS_CHASSIS")
	private String isChassis;

	@Column(name = "LAST_MODIFIED_BY")
	private String lastModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_MODIFIED_TIME_STAMP")
	private Date lastModifiedTimeStamp;

	private String manufacturer;

	@Column(name = "MATERIAL_ID")
	private String materialId;

	private String model;

	private String name;

	@Column(name = "NBR_SUB_CARDS")
	private BigDecimal nbrSubCards;

	@Column(name = "NUM_OF_PORTS")
	private BigDecimal numOfPorts;

	@Column(name = "PARENT_CARD_SPEC_REF_ID")
	private BigDecimal parentCardSpecRefId;

	@Column(name = "PART_NUM")
	private String partNum;

	private String reach;

	@Column(name = "RECEIVE_POWER")
	private String receivePower;

	@Column(name = "SLOT_OCC_X")
	private String slotOccX;

	@Column(name = "SLOT_OCC_Y")
	private String slotOccY;

	@Column(name = "SLOTS_OCCUPIED")
	private BigDecimal slotsOccupied;

	@Column(name = "SPEC_VERSION")
	private BigDecimal specVersion;

	@Column(name = "TRANSMIT_POWER")
	private String transmitPower;

	@Column(name = "TRANSMITTER_TYPE")
	private String transmitterType;

	@Column(name = "WAVE_LENGTH")
	private String waveLength;

	private BigDecimal width;

	@Column(name = "TRAFFIC_BEARING")
	private Boolean trafficBearing;

	@Column(name = "CARD_TYPE")
	private String dirCardType;
	
	@Column(name = "SPEC_STATUS")
	private String dirSpecStatus;

	// bi-directional many-to-one association to PortSpec
	@OneToMany(mappedBy = "cardSpec")
	private List<PortSpec> portSpecs;

	// bi-directional many-to-one association to SlotCardSpecMap
	@OneToMany(mappedBy = "slotCardSpecMapPk.cardSpecRefId")
	private List<SlotCardSpecMap> slotCardSpecMaps;

	public CardSpec() {
	}

	public long getCardSpecRefId() {
		return this.cardSpecRefId;
	}

	public void setCardSpecRefId(long cardSpecRefId) {
		this.cardSpecRefId = cardSpecRefId;
	}

	public String getAid() {
		return this.aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public String getCardFunctionalType() {
		return this.cardFunctionalType;
	}

	public void setCardFunctionalType(String cardFunctionalType) {
		this.cardFunctionalType = cardFunctionalType;
	}

	public String getClei() {
		return this.clei;
	}

	public void setClei(String clei) {
		this.clei = clei;
	}

	public BigDecimal getDepth() {
		return this.depth;
	}

	public void setDepth(BigDecimal depth) {
		this.depth = depth;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEquipmentVendor() {
		return this.equipmentVendor;
	}

	public void setEquipmentVendor(String equipmentVendor) {
		this.equipmentVendor = equipmentVendor;
	}

	public BigDecimal getHeight() {
		return this.height;
	}

	public void setHeight(BigDecimal height) {
		this.height = height;
	}

	public String getIsChassis() {
		return this.isChassis;
	}

	public void setIsChassis(String isChassis) {
		this.isChassis = isChassis;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifiedTimeStamp() {
		return this.lastModifiedTimeStamp;
	}

	public void setLastModifiedTimeStamp(Date lastModifiedTimeStamp) {
		this.lastModifiedTimeStamp = lastModifiedTimeStamp;
	}

	public String getManufacturer() {
		return this.manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getMaterialId() {
		return this.materialId;
	}

	public void setMaterialId(String materialId) {
		this.materialId = materialId;
	}

	public String getModel() {
		return this.model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigDecimal getNbrSubCards() {
		return this.nbrSubCards;
	}

	public void setNbrSubCards(BigDecimal nbrSubCards) {
		this.nbrSubCards = nbrSubCards;
	}

	public BigDecimal getNumOfPorts() {
		return this.numOfPorts;
	}

	public void setNumOfPorts(BigDecimal numOfPorts) {
		this.numOfPorts = numOfPorts;
	}

	public BigDecimal getParentCardSpecRefId() {
		return this.parentCardSpecRefId;
	}

	public void setParentCardSpecRefId(BigDecimal parentCardSpecRefId) {
		this.parentCardSpecRefId = parentCardSpecRefId;
	}

	public String getPartNum() {
		return this.partNum;
	}

	public void setPartNum(String partNum) {
		this.partNum = partNum;
	}

	public String getReach() {
		return this.reach;
	}

	public void setReach(String reach) {
		this.reach = reach;
	}

	public String getReceivePower() {
		return this.receivePower;
	}

	public void setReceivePower(String receivePower) {
		this.receivePower = receivePower;
	}

	public String getSlotOccX() {
		return this.slotOccX;
	}

	public void setSlotOccX(String slotOccX) {
		this.slotOccX = slotOccX;
	}

	public String getSlotOccY() {
		return this.slotOccY;
	}

	public void setSlotOccY(String slotOccY) {
		this.slotOccY = slotOccY;
	}

	public BigDecimal getSlotsOccupied() {
		return this.slotsOccupied;
	}

	public void setSlotsOccupied(BigDecimal slotsOccupied) {
		this.slotsOccupied = slotsOccupied;
	}

	public BigDecimal getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(BigDecimal specVersion) {
		this.specVersion = specVersion;
	}

	public String getTransmitPower() {
		return this.transmitPower;
	}

	public void setTransmitPower(String transmitPower) {
		this.transmitPower = transmitPower;
	}

	public String getTransmitterType() {
		return this.transmitterType;
	}

	public void setTransmitterType(String transmitterType) {
		this.transmitterType = transmitterType;
	}

	public String getWaveLength() {
		return this.waveLength;
	}

	public void setWaveLength(String waveLength) {
		this.waveLength = waveLength;
	}

	public BigDecimal getWidth() {
		return this.width;
	}

	public void setWidth(BigDecimal width) {
		this.width = width;
	}

	public String getDirCardType() {
		return EntityValidator.validateType(dirCardType, this.getClass());	
	}

	public void setDirCardType(String dirCardType) {
		this.dirCardType = dirCardType;
	}

	public String getDirSpecStatus() {
		return EntityValidator.validateStatus(dirSpecStatus, this.getClass());
	}

	public void setDirSpecStatus(String dirSpecStatus) {
		this.dirSpecStatus = dirSpecStatus;
	}

	public List<PortSpec> getPortSpecs() {
		return this.portSpecs;
	}

	public void setPortSpecs(List<PortSpec> portSpecs) {
		this.portSpecs = portSpecs;
	}

	public PortSpec addPortSpec(PortSpec portSpec) {
		getPortSpecs().add(portSpec);
		portSpec.setCardSpec(this);

		return portSpec;
	}

	public PortSpec removePortSpec(PortSpec portSpec) {
		getPortSpecs().remove(portSpec);
		portSpec.setCardSpec(null);

		return portSpec;
	}

	public List<SlotCardSpecMap> getSlotCardSpecMaps() {
		return this.slotCardSpecMaps;
	}

	public void setSlotCardSpecMaps(List<SlotCardSpecMap> slotCardSpecMaps) {
		this.slotCardSpecMaps = slotCardSpecMaps;
	}

	public Boolean getTrafficBearing() {
		return trafficBearing;
	}

	public void setTrafficBearing(Boolean trafficBearing) {
		this.trafficBearing = trafficBearing;
	}

}