package com.vz.uiam.inventory.equipment.jpa.dao.model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.javers.core.metamodel.annotation.TypeName;

/**
 * 
 * @author Justin Wheeler
 *
 */
@Entity
@Table(name = "EQUIPMENT_DOMAIN_MAP")
@TypeName("EquipmentDomainMap")
public class EquipmentDomainMap {

	@EmbeddedId
	private EquipmentDomainMapPk pk;
	
	@Column(name = "FR_REF_KEY_NAME")
	private String frRefKeyName;
	
	@Column(name = "FR_REF_KEY_VALUE")
	private String frRefKeyValue;
	
	
	public EquipmentDomainMap(){
		super();
		this.pk = new EquipmentDomainMapPk();
	}
	public EquipmentDomainMap(Long eqpReferenceId, Integer domainId) {
		super();
		this.pk = new EquipmentDomainMapPk(eqpReferenceId, domainId);
	}
	
	
	public EquipmentDomainMapPk getPk() {
		return pk;
	}
	public void setPk(EquipmentDomainMapPk pk) {
		this.pk = pk;
	}
	public Long getEqpReferenceId() {
		return pk != null ? pk.getEqpReferenceId() : null;
	}
	public void setEqpReferenceId(Long eqpReferenceId) {
		if(pk != null){
			this.pk.setEqpReferenceId(eqpReferenceId);
		}
	}
	public Integer getDomainId() {
		return pk != null ? pk.getDomainId() : null;
	}
	public void setDomainId(Integer domainId) {
		if(pk != null){
			this.pk.setDomainId(domainId);
		}
	}
	public String getFrRefKeyName() {
		return frRefKeyName;
	}
	public void setFrRefKeyName(String frRefKeyName) {
		this.frRefKeyName = frRefKeyName;
	}
	public String getFrRefKeyValue() {
		return frRefKeyValue;
	}
	public void setFrRefKeyValue(String frRefKeyValue) {
		this.frRefKeyValue = frRefKeyValue;
	}
	
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((frRefKeyName == null) ? 0 : frRefKeyName.hashCode());
		result = prime * result + ((frRefKeyValue == null) ? 0 : frRefKeyValue.hashCode());
		result = prime * result + ((pk == null) ? 0 : pk.hashCode());
		return result;
	}
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EquipmentDomainMap other = (EquipmentDomainMap) obj;
		if (frRefKeyName == null) {
			if (other.frRefKeyName != null)
				return false;
		} else if (!frRefKeyName.equals(other.frRefKeyName))
			return false;
		if (frRefKeyValue == null) {
			if (other.frRefKeyValue != null)
				return false;
		} else if (!frRefKeyValue.equals(other.frRefKeyValue))
			return false;
		if (pk == null) {
			if (other.pk != null)
				return false;
		} else if (!pk.equals(other.pk))
			return false;
		return true;
	}
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "EquipmentDomainMap [pk=" + pk + ", frRefKeyName=" + frRefKeyName + ", frRefKeyValue=" + frRefKeyValue
				+ "]";
	}
}