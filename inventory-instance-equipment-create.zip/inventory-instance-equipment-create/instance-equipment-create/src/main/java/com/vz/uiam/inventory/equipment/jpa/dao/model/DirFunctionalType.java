package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.javers.core.metamodel.annotation.TypeName;


/**
 * The persistent class for the DIR_FUNCTIONAL_TYPE database table.
 * 
 */
@Entity
@Table(name="DIR_FUNCTIONAL_TYPE")
@TypeName("DirFunctionalType")
@NamedQuery(name="DirFunctionalType.findAll", query="SELECT d FROM DirFunctionalType d")
public class DirFunctionalType implements Serializable {
	private static final long serialVersionUID = 1L;

	private String description;

	@Column(name="DISPLAY_SEQ")
	private BigDecimal displaySeq;

	@Column(name="FUNCTIONAL_TYPE")
	private String functionalType;

	@Id
	@Column(name="FUNCTIONAL_TYPE_ID")
	private BigDecimal functionalTypeId;

	public DirFunctionalType() {
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getDisplaySeq() {
		return this.displaySeq;
	}

	public void setDisplaySeq(BigDecimal displaySeq) {
		this.displaySeq = displaySeq;
	}

	public String getFunctionalType() {
		return this.functionalType;
	}

	public void setFunctionalType(String functionalType) {
		this.functionalType = functionalType;
	}

	public BigDecimal getFunctionalTypeId() {
		return this.functionalTypeId;
	}

	public void setFunctionalTypeId(BigDecimal functionalTypeId) {
		this.functionalTypeId = functionalTypeId;
	}

}