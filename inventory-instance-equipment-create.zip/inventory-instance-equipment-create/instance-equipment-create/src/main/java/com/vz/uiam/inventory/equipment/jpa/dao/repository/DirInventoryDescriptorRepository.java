package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import javax.transaction.Transactional;

import org.javers.spring.annotation.JaversSpringDataAuditable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInventoryDescriptor;

/**
 * <p>
 * Entity Class for DB table - > DIR_INVENTORY_DESCRIPTOR
 * 
 * @author Asif Billa
 * @date 21 June 2017
 *
 */
@Transactional
@JaversSpringDataAuditable
public interface DirInventoryDescriptorRepository
		extends JpaRepository<DirInventoryDescriptor, Long>, JpaSpecificationExecutor<DirInventoryDescriptor> {

	DirInventoryDescriptor findByInvDescptId(long invDescptId);

}
