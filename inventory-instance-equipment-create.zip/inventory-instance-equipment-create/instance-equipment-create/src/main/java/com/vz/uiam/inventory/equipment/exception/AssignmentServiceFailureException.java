package com.vz.uiam.inventory.equipment.exception;

/**
 * <p>
 * This Custom exception class is used to convey any exceptions while calling
 * assignment-service via a rest call
 * </p>
 * 
 * @author Asif Billa
 * @date 20-Oct-2017
 *
 */
public class AssignmentServiceFailureException extends RuntimeException {

    private final String status;
    private final String statusCode;
    private final String statusDescription;

    private static final long serialVersionUID = -3992797190692194686L;

    public AssignmentServiceFailureException(String status, String statusCode, String msg) {
	super(status + " " + statusCode + " " + msg);
	this.status = status;
	this.statusCode = statusCode;
	this.statusDescription = msg;
    }

    public String getStatus() {
	return status;
    }

    public String getStatusCode() {
	return statusCode;
    }

    public String getStatusDescription() {
	return statusDescription;
    }

}