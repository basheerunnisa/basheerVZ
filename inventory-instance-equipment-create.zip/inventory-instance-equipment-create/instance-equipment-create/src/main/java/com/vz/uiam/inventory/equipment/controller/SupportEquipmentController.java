package com.vz.uiam.inventory.equipment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ValidationUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.common.monitor.performance.PerformanceMetrics;
import com.vz.uiam.inventory.equipment.exception.DataNotFoundException;
import com.vz.uiam.inventory.equipment.jpa.dao.model.AuxiliaryEquipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EnodebDetails;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EnodebDetailsRepository;
import com.vz.uiam.inventory.equipment.model.AuxiliaryDTO;
import com.vz.uiam.inventory.equipment.model.EnodebDetailsDTO;
import com.vz.uiam.inventory.equipment.model.EnodebSectorDTO;
import com.vz.uiam.inventory.equipment.model.validator.AuxiliaryCreateValidator;
import com.vz.uiam.inventory.equipment.model.validator.EnodebCreateValidator;
import com.vz.uiam.inventory.equipment.service.SupportEquipmentCreateService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@RestController
@RequestMapping("/equipment")
@Api(value = "Enodeb Instance creation Task handler", description = "API for Enodeb Instace create Task Handler")
@PreAuthorize("hasAnyAuthority('ROLE:IVAPP_USER','ROLE:IVAPP_TESTER')")
public class SupportEquipmentController {
	
	@Autowired
	private SupportEquipmentCreateService supportEquipmentCreateService;
	@Autowired
	private AuxiliaryCreateValidator auxiliaryValidator;
	@Autowired
	private EnodebCreateValidator enodebValidator;
	@Autowired
	private EnodebDetailsRepository enodebDetailsRepository;
	
	@RequestMapping(value = "/auxiliary", method = RequestMethod.POST)
	@PerformanceMetrics(sla = 999)
	@ApiOperation(value = "Create Auxiliary Instances", notes = "Inserts into the AUXILIARY_EQUIPMENT table based on input. SLA:999 ms", response = List.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = AuxiliaryEquipment.class),
			@ApiResponse(code = 400, message = "Invalid Input"),
			@ApiResponse(code = 500, message = "Internal Server Error") })
	public List<AuxiliaryEquipment> createAuxiliary(@RequestBody List<AuxiliaryDTO> auxRequest, BindingResult errors) throws BindException {

		ValidationUtils.invokeValidator(auxiliaryValidator, auxRequest, errors);
		if (errors.hasErrors()) {
			throw new BindException(errors);
		}
		return supportEquipmentCreateService.createAuxiliary(auxRequest);
	}
	
	@RequestMapping(value = "/enodeb", method = RequestMethod.POST)
	@PerformanceMetrics(sla = 999)
	@ApiOperation(value = "Create Enodeb Instances", notes = "Inserts into the ENODEB_DETAILS and ENODEB_SECTOR tables based on input. SLA:999 ms", response = boolean.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = boolean.class),
			@ApiResponse(code = 400, message = "Invalid Input provided"),
			@ApiResponse(code = 409, message = "Data Conflict"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	public boolean createEnodeb(@RequestBody List<EnodebDetailsDTO> enodebRequest, BindingResult errors) throws BindException {

		ValidationUtils.invokeValidator(enodebValidator, enodebRequest, errors);

		if (errors.hasErrors()) {
			throw new BindException(errors);
		}
		
		return supportEquipmentCreateService.createEnodebs(enodebRequest);
	}
	
	@RequestMapping(value = "/enodeb/v1", method = RequestMethod.POST)
	@PerformanceMetrics(sla = 999)
	@ApiOperation(value = "Create Enodeb Instance", notes = "Inserts into the ENODEB_DETAILS and ENODEB_SECTOR tables based on input. SLA:999 ms", response = boolean.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = boolean.class),
			@ApiResponse(code = 400, message = "Invalid Input provided"),
			@ApiResponse(code = 409, message = "Data Conflict"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	public boolean createEnodeb(@RequestBody EnodebDetailsDTO enodebRequest, BindingResult errors) throws BindException {

		ValidationUtils.invokeValidator(enodebValidator, enodebRequest, errors);

		if (errors.hasErrors()) {
			throw new BindException(errors);
		}
		
		return supportEquipmentCreateService.createEnodebs(enodebRequest);
	}
	
	@RequestMapping(value = "/enodeb/{enodebId}/sector", method = RequestMethod.POST)
	@PerformanceMetrics(sla = 999)
	@ApiOperation(value = "Create Enodeb Sector Instances", notes = "Inserts into the ENODEB_SECTOR tables based on input. SLA:999 ms", response = List.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = EnodebDetailsDTO.class),
			@ApiResponse(code = 400, message = "Invalid Input provided"),
			@ApiResponse(code = 409, message = "Data Conflict"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	public boolean createEnodebSectors(@PathVariable String enodebId, @RequestBody EnodebSectorDTO enodebSector,  BindingResult errors) throws BindException {

		final EnodebDetails details = enodebDetailsRepository.findOne(enodebId);
		if(details == null){
			throw new DataNotFoundException("EnodebSector:Create", "Data Not Found", 
					"Enodeb Id: " + enodebId + " did not yield result. Please create the Enodeb Details instance before creating Sectors.");
		}
		EnodebDetailsDTO enodebRequest = new EnodebDetailsDTO(enodebId, enodebSector);
		ValidationUtils.invokeValidator(enodebValidator, enodebRequest, errors);

		if (errors.hasErrors()) {
			throw new BindException(errors);
		}
		return supportEquipmentCreateService.createEnodebSectors(details, enodebSector);
	}
}