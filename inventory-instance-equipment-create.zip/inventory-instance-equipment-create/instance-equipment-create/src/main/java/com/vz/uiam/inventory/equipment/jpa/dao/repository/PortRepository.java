package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.Port;



@Transactional

public interface PortRepository extends JpaRepository<Port,Long> {

	Port findByPortReferenceId(Long portId);

	Port findByCardReferenceIdAndPortNumberAndDirectionAndParentPortRefIdIsNull(
			Long cardReferenceId, long portNumber, String string);

	@Modifying
	@Transactional
	@Query(value = "UPDATE PORT SET RELATED_PORT_REF_ID =:relatedPortRefId, RELATED_SPEC_REF_ID =:relatedSpecRefId WHERE PORT_REFERENCE_ID =:portReferenceId", nativeQuery = true)
	Integer updatePort(@Param("relatedPortRefId") Long relatedPortRefId,
			@Param("relatedSpecRefId") Long relatedSpecRefId,
			@Param("portReferenceId") Long portReferenceId);

	Port findByCardReferenceIdAndPortNumberAndDirectionAndTpTypeAndParentPortRefId(Long cardReferenceId,
			long portNumber, String string, String string2, Long parentPortRefId);

	Port findByEqpReferenceIdAndPortNumberAndDirectionAndParentPortRefIdIsNull(long eqpReferenceId, long portNumber,
			String string);

	Port findByEqpReferenceIdAndPortNumberAndDirectionAndTpTypeAndParentPortRefId(long eqpReferenceId, long portNumber,
			String string, String logical, Long parentPortRefId);
	
	@Query(value = "select p.* from PORT p, PORT_SPEC ps " 
			+ "where PORT_SPEC_REFERENCE_ID  = RELATED_SPEC_ID "
			+ "and PORT_SPEC_REF_ID=:portSpecRefId "
			+ "and EQP_REFERENCE_ID=:eqpReferenceId "
			+ "and p.DIRECTION=:direction LIMIT 1", nativeQuery = true)
		Port getRelatedPort(@Param("portSpecRefId") Long portSpecRefId,
				@Param("eqpReferenceId") long eqpReferenceId,
				@Param("direction") String direction);
	
	List<Port> findByEqpReferenceIdAndCardReferenceIdIsNullAndSlotReferenceIdIsNull(Long equipmentReferenceID);
	
	List<Port> findByEqpReferenceId(long eqpReferenceId);
}
