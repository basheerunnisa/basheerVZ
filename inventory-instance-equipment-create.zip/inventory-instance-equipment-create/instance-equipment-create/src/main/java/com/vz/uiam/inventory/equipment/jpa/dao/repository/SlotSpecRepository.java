package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.SlotSpec;




@Transactional
public interface SlotSpecRepository extends JpaRepository<SlotSpec,Long> {

    List<SlotSpec> findAllByEquipmentSpec(List<Long> eqpShelfSpecIdList);

    List<SlotSpec> findByEquipmentSpec(long eqpShelfSpecId);

    List<SlotSpec> findAllByParentCardSpecId(BigDecimal parentSpecId);

    List<SlotSpec> findByEquipmentSpecEquipmentSpecRefId(long bigDecimal);
    
    SlotSpec findBySlotName(String slotName);

	List<SlotSpec> findByEquipmentSpecEquipmentSpecRefIdAndParentCardSpecIdIsNull(Long eqpShelfSpecId);
}