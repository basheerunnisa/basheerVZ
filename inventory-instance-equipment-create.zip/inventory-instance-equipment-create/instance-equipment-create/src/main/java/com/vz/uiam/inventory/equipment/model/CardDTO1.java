package com.vz.uiam.inventory.equipment.model;

import java.io.Serializable;

import org.springframework.hateoas.ResourceSupport;

public class CardDTO1 extends ResourceSupport implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long cardId;

	private String cardName;
	private String cardType;

	private String slotName;
	private String slotNum;
	private String partNum;

	private Long parentCardId;
	private String parentSlotName;

	/**
	 * @return the cardId
	 */
	public Long getCardId() {
		return cardId;
	}

	/**
	 * @param cardId
	 *            the cardId to set
	 */
	public void setCardId(Long cardId) {
		this.cardId = cardId;
	}

	/**
	 * @return the cardName
	 */
	public String getCardName() {
		return cardName;
	}

	/**
	 * @param cardName
	 *            the cardName to set
	 */
	public void setCardName(String cardName) {
		this.cardName = cardName;
	}

	/**
	 * @return the cardType
	 */
	public String getCardType() {
		return cardType;
	}

	/**
	 * @param cardType
	 *            the cardType to set
	 */
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	/**
	 * @return the slotName
	 */
	public String getSlotName() {
		return slotName;
	}

	/**
	 * @param slotName
	 *            the slotName to set
	 */
	public void setSlotName(String slotName) {
		this.slotName = slotName;
	}

	/**
	 * @return the slotNum
	 */
	public String getSlotNum() {
		return slotNum;
	}

	/**
	 * @param slotNum
	 *            the slotNum to set
	 */
	public void setSlotNum(String slotNum) {
		this.slotNum = slotNum;
	}

	/**
	 * @return the partNum
	 */
	public String getPartNum() {
		return partNum;
	}

	/**
	 * @param partNum
	 *            the partNum to set
	 */
	public void setPartNum(String partNum) {
		this.partNum = partNum;
	}

	/**
	 * @return the parentCardId
	 */
	public Long getParentCardId() {
		return parentCardId;
	}

	/**
	 * @param parentCardId
	 *            the parentCardId to set
	 */
	public void setParentCardId(Long parentCardId) {
		this.parentCardId = parentCardId;
	}

	/**
	 * @return the parentSlotName
	 */
	public String getParentSlotName() {
		return parentSlotName;
	}

	/**
	 * @param parentSlotName
	 *            the parentSlotName to set
	 */
	public void setParentSlotName(String parentSlotName) {
		this.parentSlotName = parentSlotName;
	}

	@Override
	public String toString() {
		return "CardDTO [cardType=" + cardType + ", cardId=" + cardId + "]";
	}

}