package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.Bandwidth;





@Transactional
public interface BandwidthRepository extends JpaRepository<Bandwidth, String> {

	Bandwidth findByBandwidthId(BigDecimal Id);
}