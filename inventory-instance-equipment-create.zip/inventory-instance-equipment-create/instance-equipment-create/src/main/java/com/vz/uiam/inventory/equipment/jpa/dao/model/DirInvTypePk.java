package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Creating the composite primary key for DIR_INV_TYPE table
 * 
 * @author Carlos Rubiano 
 *
 */
@Embeddable
public class DirInvTypePk implements Serializable {

	private static final long serialVersionUID = 1975654792902441889L;

	@Column(name = "TYPE")
	private String type;

	@Column(name = "ENTITY_NAME")
	private String entityName;

	public DirInvTypePk() {
		super();
	}

	public DirInvTypePk(String type, String entityName) {
		this();
		this.type = type;
		this.entityName = entityName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DirInvStatusPk [type=" + type + ", entityName=" + entityName + "]";
	}

}
