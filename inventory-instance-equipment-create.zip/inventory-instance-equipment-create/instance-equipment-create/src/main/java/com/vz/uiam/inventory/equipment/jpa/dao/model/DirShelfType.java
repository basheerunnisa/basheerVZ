package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.javers.core.metamodel.annotation.TypeName;


/**
 * The persistent class for the DIR_SHELF_TYPE database table.
 * 
 */
@Entity
@Table(name="DIR_SHELF_TYPE")
@TypeName("DirShelfType")
@NamedQuery(name="DirShelfType.findAll", query="SELECT d FROM DirShelfType d")
public class DirShelfType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="SHELF_TYPE")
	private String shelfType;

	private String description;

	@Column(name="DISPLAY_SEQ")
	private BigDecimal displaySeq;

	@Column(name="SHELF_TYPE_ID")
	private BigDecimal shelfTypeId;

	public DirShelfType() {
	}

	public String getShelfType() {
		return this.shelfType;
	}

	public void setShelfType(String shelfType) {
		this.shelfType = shelfType;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getDisplaySeq() {
		return this.displaySeq;
	}

	public void setDisplaySeq(BigDecimal displaySeq) {
		this.displaySeq = displaySeq;
	}

	public BigDecimal getShelfTypeId() {
		return this.shelfTypeId;
	}

	public void setShelfTypeId(BigDecimal shelfTypeId) {
		this.shelfTypeId = shelfTypeId;
	}

}