package com.vz.uiam.inventory.equipment.enumeration;

/**
 * Enum defined for inventory entity events such as INSERT, UPDATE & DELETE
 * 
 * @author DIXITSH
 *
 */
public enum EntityOperation {

	INSERT("INSERT"), UPDATE("UPDATE"), DELETE("DELETE");

	private String entityOperation;

	EntityOperation(String operation) {
		entityOperation = operation;

	}

	@Override
	public String toString() {
		return this.entityOperation;
	}

}
