package com.vz.uiam.inventory.equipment.service;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vz.uiam.common.usermanagement.rest.model.DirDomainsDTO;
import com.vz.uiam.common.usermanagement.service.SecurityUserDetailsService;

@Service
public class DomainService {

	private static final Logger LOGGER = LoggerFactory.getLogger(DomainService.class);
	
	@Autowired
	private SecurityUserDetailsService securityUserDetailsService;
	
	public List<Integer> findListOfDomainsMappedToRequestUser(HttpServletRequest request) {
		return findListOfDomainsMappedToUser(request.getHeader("USER_ID"), request.getUserPrincipal().getName());
	}
	
	public List<Integer> findListOfDomainsMappedToUser(String userId, String principal) {

		String entityValue = null;
		String entityName = null;
		if (userId != null && !userId.isEmpty()) {
			entityValue = userId;
			entityName = "USER_ID";
		} else {
			entityName = "APP_USER";
			entityValue = principal;
		}

		LOGGER.info("\nEntity-Name:{} and Entity-Value:{} ", entityName, entityValue);
		List<DirDomainsDTO> dirDomainsList = securityUserDetailsService.getDomainsForEntity(entityName, entityValue);
		if (dirDomainsList == null) {
			dirDomainsList = new ArrayList<DirDomainsDTO>();
		}
		List<Integer> listOfDomainIds = new ArrayList<>();
		for (DirDomainsDTO domain : dirDomainsList) {
			listOfDomainIds.add(domain.getDomainId());
		}
		LOGGER.info("\nDOMAINS MAPPED TO USER:{}", listOfDomainIds);

		return listOfDomainIds;
	}
}
