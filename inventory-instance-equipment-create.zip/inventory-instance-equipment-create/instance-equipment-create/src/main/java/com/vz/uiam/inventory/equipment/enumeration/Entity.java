package com.vz.uiam.inventory.equipment.enumeration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.Table;

import com.vz.uiam.inventory.equipment.exception.MethodFailureException;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Card;
import com.vz.uiam.inventory.equipment.jpa.dao.model.CardSpec;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EquipmentSpec;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Port;
import com.vz.uiam.inventory.equipment.jpa.dao.model.PortSpec;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Site;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Slot;
import com.vz.uiam.inventory.equipment.jpa.dao.model.SlotSpec;

/**
 * 
 * @author WHEEJU3
 *
 */
public enum Entity {
	
	CARD(Card.class),
	CARD_SPEC(CardSpec.class),
	EQUIPMENT(Equipment.class),
	EQUIPMENT_SPEC(EquipmentSpec.class),
	PORT(Port.class),
	PORT_SPEC(PortSpec.class),
	SITE(Site.class),
	SLOT(Slot.class),
	SLOT_SPEC(SlotSpec.class);
	
	private final Class<?> instance;
	
	Entity(Class<?> instance){
		this.instance = instance;
	}
	
	/**
	 * 
	 * @return
	 */
	public static final List<String> getEntities(){
		
		List<String> entities = new ArrayList<>();
		
		Arrays.asList(Entity.values()).stream().map(e -> e.instance).forEach(cls -> {
			Table table = cls.getDeclaredAnnotation(Table.class);
			if(table != null){
				entities.add(table.name());
			}
		});
		return entities;
	}
	/**
	 * 
	 * @param clazz
	 * @return
	 */
	public static final String getEntityForClass(final Class<?> clazz){
		
		Table table = clazz.getDeclaredAnnotation(Table.class);
		if(table == null){
			throw new MethodFailureException(
					"Class: " + clazz.getSimpleName() + " does not define the Table annotation");
		}
		return table.name();
	}
}
