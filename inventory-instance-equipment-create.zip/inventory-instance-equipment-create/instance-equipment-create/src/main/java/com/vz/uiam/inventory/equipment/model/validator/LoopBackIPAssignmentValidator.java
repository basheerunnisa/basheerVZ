package com.vz.uiam.inventory.equipment.model.validator;

import java.util.HashMap;

/**
 * <p>
 * This method is for validating IPassignmentDTO
 * </p>
 * 
 * @author Chintan Patel
 * @date 10-Nov-2017
 */

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.vz.uiam.inventory.equipment.enumeration.DirInventoryConfigGroups;
import com.vz.uiam.inventory.equipment.enumeration.ErrorCodeEnum;
import com.vz.uiam.inventory.equipment.jpa.dao.model.DirInventoryConfig;
import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;
import com.vz.uiam.inventory.equipment.jpa.dao.model.EquipmentAttributes;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.DirInventoryConfigRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentAttributesRepository;
import com.vz.uiam.inventory.equipment.jpa.dao.repository.EquipmentRepository;
import com.vz.uiam.inventory.instance.rest.api.model.IPAssignmentDTO;
import com.vz.uiam.inventory.equipment.util.InstanceEquipmentCreateConstant;

@org.springframework.stereotype.Service
public class LoopBackIPAssignmentValidator implements Validator {

	@Autowired
	private EquipmentRepository equipmentRepository;

	@Autowired
	private DirInventoryConfigRepository dirInventoryConfigRepository;

	@Autowired
	private EquipmentAttributesRepository equipmentAttributesRepository;

	/*
	 * (non-Javadoc)
	 * @see org.springframework.validation.Validator#supports(java.lang.Class)
	 */
	@Override
	public boolean supports(Class<?> arg0) {
		return IPAssignmentDTO.class.equals(arg0);
	}

	/*
	 * (non-Javadoc)
	 * @see org.springframework.validation.Validator#validate(java.lang.Object, org.springframework.validation.Errors)
	 */
	@Override
	public void validate(Object arg0, Errors errors) {

		IPAssignmentDTO ipAssignmentDTO = (IPAssignmentDTO) arg0;
		// equipment refrence Id and Tid logical is null and hostName is null
		if ((ipAssignmentDTO.getEquimentRefId() == null && ipAssignmentDTO.gettIDLogical() == null && ipAssignmentDTO.getHostName() == null)
				|| (ipAssignmentDTO.getEquimentRefId() == InstanceEquipmentCreateConstant.EMPTY
						&& ipAssignmentDTO.gettIDLogical() == InstanceEquipmentCreateConstant.EMPTY
						  && ipAssignmentDTO.getHostName() == InstanceEquipmentCreateConstant.EMPTY)) {
			errors.reject(ErrorCodeEnum.INVALID_EQUIPMENT_REF_ID_OR_TID_LOGICAL_OR_HOST_NAME.getCode(),
					ErrorCodeEnum.INVALID_EQUIPMENT_REF_ID_OR_TID_LOGICAL_OR_HOST_NAME.getDescription());
		}
		// if reference id and Tid logical is not null
		else if (ipAssignmentDTO.getEquimentRefId() != null && !ipAssignmentDTO.getEquimentRefId().isEmpty()
				&& ipAssignmentDTO.gettIDLogical() != null && !ipAssignmentDTO.gettIDLogical().isEmpty()) {
			List<Equipment> equipmentList = equipmentRepository.findByTidLogical(ipAssignmentDTO.gettIDLogical());
			if (!isUniqueEquipmentList(equipmentList)) {
				errors.reject(ErrorCodeEnum.MORE_TID_LOGICAL_INVALID_EQP_REF_ID.getCode(),
						String.format(ErrorCodeEnum.MORE_TID_LOGICAL_INVALID_EQP_REF_ID.getDescription(),
								equipmentList.get(0).getTidLogical(), ipAssignmentDTO.getEquimentRefId()));
			}
			if (!isValidSelf(equipmentList.get(0).getShelfType())) {
				errors.reject(ErrorCodeEnum.SHELF_TYPE_IS_NOT_ELIGIBLE.getCode(),
						String.format(ErrorCodeEnum.SHELF_TYPE_IS_NOT_ELIGIBLE.getDescription(),
								equipmentList.get(0).getTidLogical()));
			}
			Map<String, String> ipAddressMap = isIpAssigned(
					equipmentAttributesRepository.findByEqpReferenceId(equipmentList.get(0).getEqpReferenceId()));
			if (!ipAddressMap.isEmpty()) {
				processIpAddressMap(errors, equipmentList, ipAddressMap);
			}
		}
		// if Tid logical is null
		else if (ipAssignmentDTO.getEquimentRefId() != null && !ipAssignmentDTO.getEquimentRefId().isEmpty()) {
			Long eqpRefID = Long.parseLong(ipAssignmentDTO.getEquimentRefId());
			boolean isSuRITidLogical = false;
			Equipment equipment = equipmentRepository.findOne(eqpRefID);
			if (equipment == null) {
				errors.reject(ErrorCodeEnum.INVALID_EQP_REF_ID.getCode(), String
						.format(ErrorCodeEnum.INVALID_EQP_REF_ID.getDescription(), ipAssignmentDTO.getEquimentRefId()));
			} else {
				List<Equipment> equipmentList = equipmentRepository.findByTidLogical(equipment.getTidLogical());
				if (InstanceEquipmentCreateConstant.validateNotNull(equipmentList)
						&& InstanceEquipmentCreateConstant.validateNotNull(equipment.getTidLogical())) {

					processTidLogicalAndShelfTypeValidation(isSuRITidLogical, equipmentList, errors);

					Map<String, String> ipAddressMap = isIpAssigned(equipmentAttributesRepository
							.findByEqpReferenceId(equipmentList.get(0).getEqpReferenceId()));
					if (!ipAddressMap.isEmpty()) {
						processIpAddressMap(errors, equipmentList, ipAddressMap);
					}

					ipAssignmentDTO.settIDLogical(equipment.getTidLogical());
					processSuRIValidation(isSuRITidLogical, equipmentList, ipAssignmentDTO, errors);
				} else {
					errors.reject(ErrorCodeEnum.INVALID_EQP_REF_ID.getCode(), String.format(
							ErrorCodeEnum.INVALID_EQP_REF_ID.getDescription(), ipAssignmentDTO.getEquimentRefId()));
				}
			}
		}
		// if hostName is  not null
		else if (ipAssignmentDTO.getHostName() != null && !ipAssignmentDTO.getHostName().isEmpty()) {
			
			List<Equipment> equipmentList = equipmentRepository.findByHostName(ipAssignmentDTO.getHostName());
			// check whether hostName is valid or not
			if (!InstanceEquipmentCreateConstant.validateNotNull(equipmentList)) {
				errors.reject(ErrorCodeEnum.INVALID_EQP_HOST_NAME.getCode(), String.format(
						ErrorCodeEnum.INVALID_EQP_HOST_NAME.getDescription(), ipAssignmentDTO.getHostName()));
			} else {
				
				processHostNameAndShelfTypeValidation(equipmentList, errors, ipAssignmentDTO);
				
				Map<String, String> ipAddressMap = isIpAssigned(
						equipmentAttributesRepository.findByEqpReferenceId(equipmentList.get(0).getEqpReferenceId()));
				if (!ipAddressMap.isEmpty()) {
					processIpAddressMap(errors, equipmentList, ipAddressMap);
				}
			}
		}
		// if equipment reference id is null
		else if (ipAssignmentDTO.gettIDLogical() != null && !ipAssignmentDTO.gettIDLogical().isEmpty()) {
			boolean isSuRITidLogical = false;

			List<Equipment> equipmentList = equipmentRepository.findByTidLogical(ipAssignmentDTO.gettIDLogical());
			// check whether tid logical is valid or not
			if (!InstanceEquipmentCreateConstant.validateNotNull(equipmentList)) {
				errors.reject(ErrorCodeEnum.INVALID_EQP_TID_LOGICAL.getCode(), String.format(
						ErrorCodeEnum.INVALID_EQP_TID_LOGICAL.getDescription(), ipAssignmentDTO.gettIDLogical()));
			} else {
				processTidLogicalAndShelfTypeValidation(isSuRITidLogical, equipmentList, errors);

				Map<String, String> ipAddressMap = isIpAssigned(
						equipmentAttributesRepository.findByEqpReferenceId(equipmentList.get(0).getEqpReferenceId()));
				if (!ipAddressMap.isEmpty()) {
					processIpAddressMap(errors, equipmentList, ipAddressMap);
				}

				processSuRIValidation(isSuRITidLogical, equipmentList, ipAssignmentDTO, errors);
			}
		}
	}

	/**
	 * <p>
	 * This method will throw error based on equipment shelfType
	 * </p>
	 * 
	 * @param errors
	 * @param equipmentList
	 * @param ipAddressMap
	 * @return
	 */
	private void processIpAddressMap(Errors errors, List<Equipment> equipmentList, Map<String, String> ipAddressMap) {
		if (InstanceEquipmentCreateConstant.SHELF_TYPE_MSERI.equalsIgnoreCase(equipmentList.get(0).getShelfType())) {
			errors.reject(ErrorCodeEnum.IP_ALREADY_ASSIGNED_FOR_LOOP_BACK_MSERI.getCode(),
					String.format(ErrorCodeEnum.IP_ALREADY_ASSIGNED_FOR_LOOP_BACK_MSERI.getDescription(),
							ipAddressMap.get(InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_1),
							ipAddressMap.get(InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_2),
							equipmentList.get(0).getTidLogical()));
		} else if (InstanceEquipmentCreateConstant.SHELF_TYPE_NGPON2
				.equalsIgnoreCase(equipmentList.get(0).getShelfType())) {
			errors.reject(ErrorCodeEnum.IP_ALREADY_ASSIGNED_FOR_LOOP_BACK_NGPON2.getCode(),
					String.format(ErrorCodeEnum.IP_ALREADY_ASSIGNED_FOR_LOOP_BACK_NGPON2.getDescription(),
							ipAddressMap.get(InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_1),
							equipmentList.get(0).getTidLogical()));
		}
	}

	/**
	 * <p>
	 * This method will get the value of assigned ip
	 * </p>
	 * 
	 * @param equipmentAttributes
	 * @return
	 */
	private Map<String, String> isIpAssigned(List<EquipmentAttributes> equipmentAttributes) {
		Map<String, String> ipAddressMap = new HashMap<>();
		for (EquipmentAttributes equipmentAttribute : equipmentAttributes) {
			if (equipmentAttribute.getEqpValue() == null) {
				continue;
			}
			if (equipmentAttribute.getEqpName()
					.equalsIgnoreCase(InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_1)) {
				ipAddressMap.put(InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_1,
						equipmentAttribute.getEqpValue());
			}
			if (equipmentAttribute.getEqpName().equals(InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_2)) {
				ipAddressMap.put(InstanceEquipmentCreateConstant.LOOPBAACK_IPV4_IPADDRESS_2,
						equipmentAttribute.getEqpValue());
			}
		}
		return ipAddressMap;
	}

	/**
	 * <p>
	 * This method is to check if Tid Logical has more than one record
	 * </p>
	 * 
	 * @param equipmentList
	 * @return
	 */
	private boolean isUniqueEquipmentList(List<Equipment> equipmentList) {
		if (!equipmentList.isEmpty() && (equipmentList.size() > 1 || equipmentList.get(0).getTidLogical() == null)) {
			return false;
		}
		return true;
	}

	/**
	 * <p>
	 * This method is to check if provided shelf is valid MSERI,NGPON2 or not
	 * </p>
	 * 
	 * @param shelfType
	 * @return
	 */
	private boolean isValidSelf(String shelfType) {
		
		boolean response = false;
		
		if(shelfType != null && !shelfType.trim().isEmpty()){
			DirInventoryConfig dirInventoryConfig = dirInventoryConfigRepository.findByGroupNameAndConfigNameAndConfigValue(
					DirInventoryConfigGroups.LOOP_BACK_IP_ASSIGNMENT.value(), 
					InstanceEquipmentCreateConstant.LOOPBACK_IP_CONFIG_NAME, shelfType);
			
			if (InstanceEquipmentCreateConstant.validateNotNull(dirInventoryConfig)) {
				response = true;
			}
		}
		return response;
	}
	
	/**
	 * <p>
	 * This method validates suTIDLogical relation with other-RI
	 * </p>
	 * 
	 * @param eqpList
	 * @param suTIDLogical
	 * @return
	 */
	private boolean validateTIDLogical(List<Equipment> eqpList, String suTIDLogical) {
		if (!eqpList.isEmpty()) {
			Optional<Equipment> res = eqpList.stream()
					.filter(e -> e.getTidLogical() != null && e.getTidLogical().equals(suTIDLogical)).findFirst();
			if (res.isPresent()) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * <p>
	 * This method performs validation of SU-RI equipment 
	 * </p>
	 * 
	 * @param isSuRITidLogical
	 * @param equipmentList
	 * @param ipAssignmentDTO
	 * @param errors
	 */
	public void processSuRIValidation(boolean isSuRITidLogical, List<Equipment> equipmentList,
			IPAssignmentDTO ipAssignmentDTO, Errors errors) {
		// if Passed TidLogical is SU-RI Equipment and shelf Type is MSERI, skip
		// below validation
		if (!isSuRITidLogical && InstanceEquipmentCreateConstant.SHELF_TYPE_MSERI
				.equalsIgnoreCase(equipmentList.get(0).getShelfType())) {
			// checking relation between su-RI and other-RI
			boolean isSuRIDerived = false;
			List<Equipment> eqpList = equipmentRepository.getSuEquipments(ipAssignmentDTO.gettIDLogical(),
					InstanceEquipmentCreateConstant.VRI_SU);
			if (eqpList.isEmpty()) {
				errors.reject(ErrorCodeEnum.NO_SU_RI_EQUIPMENT.getCode(), String
						.format(ErrorCodeEnum.NO_SU_RI_EQUIPMENT.getDescription(), ipAssignmentDTO.gettIDLogical()));
			} else if (!isUniqueEquipmentList(eqpList)) {
				errors.reject(ErrorCodeEnum.MORE_SU_RI_EQUIPMENTS.getCode(), String
						.format(ErrorCodeEnum.MORE_SU_RI_EQUIPMENTS.getDescription(), ipAssignmentDTO.gettIDLogical()));
			} else if (ipAssignmentDTO.getSuTIDLogical() == null || ipAssignmentDTO.getSuTIDLogical().isEmpty()) {
				ipAssignmentDTO.setSuTIDLogical(eqpList.get(0).getTidLogical());
				isSuRIDerived = true;
			}

			// suTidLogical validation
			// validate only when suTidLogical available in
			// ipAssignmentDTO
			if (InstanceEquipmentCreateConstant.validateNotNull(ipAssignmentDTO.getSuTIDLogical()) && !isSuRIDerived
					&& !validateTIDLogical(eqpList, ipAssignmentDTO.getSuTIDLogical())) {
				errors.reject(ErrorCodeEnum.NO_RELATION_BTW_SU_OTHER_RI.getCode(),
						String.format(ErrorCodeEnum.NO_RELATION_BTW_SU_OTHER_RI.getDescription(),
								ipAssignmentDTO.getSuTIDLogical(), ipAssignmentDTO.gettIDLogical()));
			}
		}
		// if suTIDLogical and tIDLogical are same
		if (InstanceEquipmentCreateConstant.validateNotNull(ipAssignmentDTO.getSuTIDLogical())
				&& ipAssignmentDTO.gettIDLogical().equals(ipAssignmentDTO.getSuTIDLogical())) {
			errors.reject(ErrorCodeEnum.DUPLICATE_TID_LOGICALS.getCode(), String
					.format(ErrorCodeEnum.DUPLICATE_TID_LOGICALS.getDescription(), ipAssignmentDTO.gettIDLogical()));
		}
	}
	
	/**
	 * <p>
	 * This method validates tidLogical and shelf type for passed equipment
	 * </p>
	 * 
	 * @param isSuRITidLogical
	 * @param equipmentList
	 * @param errors
	 */
	public void processTidLogicalAndShelfTypeValidation(boolean isSuRITidLogical, List<Equipment> equipmentList,
			Errors errors) {
		if (!isUniqueEquipmentList(equipmentList)) {
			errors.reject(ErrorCodeEnum.INVALID_TID_LOGICAL.getCode(), String
					.format(ErrorCodeEnum.INVALID_TID_LOGICAL.getDescription(), equipmentList.get(0).getTidLogical()));
		} else {
			// when tidLogical is su-RI equipment, flag will set
			if (InstanceEquipmentCreateConstant.validateNotNull(equipmentList)
					&& InstanceEquipmentCreateConstant.validateNotNull(equipmentList.get(0).getFunctionalType())
					&& equipmentList.get(0).getFunctionalType()
							.equalsIgnoreCase(InstanceEquipmentCreateConstant.VRI_SU)) {
				isSuRITidLogical = true;
			}
		}
		if (!isValidSelf(equipmentList.get(0).getShelfType())) {
			errors.reject(ErrorCodeEnum.SHELF_TYPE_IS_NOT_ELIGIBLE.getCode(), String.format(
					ErrorCodeEnum.SHELF_TYPE_IS_NOT_ELIGIBLE.getDescription(), equipmentList.get(0).getTidLogical()));
		}
	}
	
	
	/**
	 * <p>
	 * This method validates host name and shelf type for passed equipment
	 * </p>
	 * 
	 * @param isSuRITidLogical
	 * @param equipmentList
	 * @param errors
	 */
	public void processHostNameAndShelfTypeValidation( List<Equipment> equipmentList,
			Errors errors,IPAssignmentDTO ipAssignmentDTO) {
	    if(equipmentList.size()>1) {
			errors.reject(ErrorCodeEnum.MORE_TID_LOGICAL_INVALID_HOST_NAME.getCode(), String
					.format(ErrorCodeEnum.MORE_TID_LOGICAL_INVALID_HOST_NAME.getDescription(), ipAssignmentDTO.getHostName()));
		}
		
		if (!isValidSelf(equipmentList.get(0).getShelfType())) {
			errors.reject(ErrorCodeEnum.SHELF_TYPE_IS_NOT_ELIGIBLE.getCode(), String.format(
					ErrorCodeEnum.SHELF_TYPE_IS_NOT_ELIGIBLE.getDescription(), ipAssignmentDTO.getHostName()));
		}
	}
}
