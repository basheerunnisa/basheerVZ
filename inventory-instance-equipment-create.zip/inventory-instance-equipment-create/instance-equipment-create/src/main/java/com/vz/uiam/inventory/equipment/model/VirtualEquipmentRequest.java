package com.vz.uiam.inventory.equipment.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.hateoas.ResourceSupport;

import com.vz.uiam.inventory.instance.rest.api.model.AttributesDTO;

public class VirtualEquipmentRequest extends ResourceSupport implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long physicalEquipmentSpecId;
	private List<AttributesDTO> attributeList;
	private String mgmtIpAddress;
	private String virtualEquipmentTid;
	private String functionalType;
	
	public Long getPhysicalEquipmentSpecId() {
		return physicalEquipmentSpecId;
	}
	public void setPhysicalEquipmentSpecId(Long physicalEquipmentSpecId) {
		this.physicalEquipmentSpecId = physicalEquipmentSpecId;
	}
		
	@Override
	public String toString() {
		return "VirtualEquipmentRequest [physicalEquipmentSpecId=" + physicalEquipmentSpecId + ", attributeList="
				+ attributeList + ", mgmtIpAddress=" + mgmtIpAddress + ", virtualEquipmentTid=" + virtualEquipmentTid
				+ "]";
	}
	
	public List<AttributesDTO> getAttributeList() {
		return attributeList;
	}
	public void setAttributeList(List<AttributesDTO> attributeList) {
		this.attributeList = attributeList;
	}
	public String getMgmtIpAddress() {
		return mgmtIpAddress;
	}
	public void setMgmtIpAddress(String mgmtIpAddress) {
		this.mgmtIpAddress = mgmtIpAddress;
	}
	public String getVirtualEquipmentTid() {
		return virtualEquipmentTid;
	}
	public void setVirtualEquipmentTid(String virtualEquipmentTid) {
		this.virtualEquipmentTid = virtualEquipmentTid;
	}
	public String getFunctionalType() {
		return functionalType;
	}
	public void setFunctionalType(String functionalType) {
		this.functionalType = functionalType;
	}

}