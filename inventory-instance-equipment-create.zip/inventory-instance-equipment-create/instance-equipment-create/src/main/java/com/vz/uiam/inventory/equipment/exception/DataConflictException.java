/**
 * 
 */
package com.vz.uiam.inventory.equipment.exception;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * @author Karthik Amarnath
 *
 */
@ResponseStatus(value = HttpStatus.CONFLICT)
public class DataConflictException extends RuntimeException {

    private static final Log LOGGER = LogFactory.getLog(DataConflictException.class);
    private static final long serialVersionUID = -3992797190692194686L;


    public DataConflictException(String type, String identifier, String msg) {
	super(type + " [ " + identifier + " ]" + getCustMsg(msg));
    }


    public  static final String getCustMsg(String argErr) {
	String str1stLineMsg = "";
	String strCustMsg = "";
	int intLastInd;
	LOGGER.error("ORIGINAL MSG:" + argErr);
	String[] arr = argErr.split("\n");
	if (arr != null && arr.length > 1) {
	    str1stLineMsg = argErr.split("\n")[1];
	    intLastInd = lastIndexOfRegex(str1stLineMsg, "ORA-\\d");
	    if (intLastInd > 0) {
		strCustMsg = str1stLineMsg.substring(intLastInd);
	    }
	} else
	    strCustMsg = argErr;
	LOGGER.info("CUSTOMER MSG:" + strCustMsg);
	return strCustMsg;
    }

    public static int lastIndexOfRegex(String argMsg, String argFindStr) {
	Pattern pattern = Pattern.compile(argFindStr);
	Matcher matcher = pattern.matcher(argMsg);
	int lastIndex = -1;

	while (matcher.find()) {
	    lastIndex = matcher.start();
	}
	return lastIndex;
    }

}
