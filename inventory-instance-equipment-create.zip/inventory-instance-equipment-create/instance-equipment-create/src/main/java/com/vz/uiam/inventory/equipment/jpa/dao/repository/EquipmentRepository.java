package com.vz.uiam.inventory.equipment.jpa.dao.repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import org.javers.spring.annotation.JaversSpringDataAuditable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.Equipment;

@Transactional
@JaversSpringDataAuditable
public interface EquipmentRepository extends JpaRepository<Equipment, Long> {

	List<Equipment> findByTidPhysical(String tidPhysical);

	List<Equipment> findByTidLogical(String tidLogical);

	List<Equipment> findByEqpName(String eqpName);
	
	List<Equipment> findByHostName(String hostName);

	Equipment findByEqpReferenceId(Long id);

	List<Equipment> findByEqpReferenceIdIn(Set<Long> equipmentReferenceIds);

	Equipment findByEqpReferenceIdAndTidPhysical(long equipId, String tidPhysical);

	List<Equipment> findBySiteReferenceIdAndFrameAndDirContainerTypeContainer(BigDecimal locationId, String frame,
			String eqpType);
	
	Equipment findOneBySiteReferenceIdAndFrameAndDirContainerTypeContainer(Long locationId, String frame,
			String eqpType);

	List<Equipment> findByLocationClliAndFrameAndDirContainerTypeContainer(String locationClli, String frame,
			String contaniner);

	List<Equipment> findBySiteReferenceIdAndEqpNameAndDirContainerTypeContainer(BigDecimal locationId, String eqpName,
			String contaniner);

	List<Equipment> findByLocationClliAndPhysicalShelfPositionAndFrameAndDirContainerTypeContainer(String locationClli,
			String physicalShelfPosition, String frame, String contaniner);

	List<Equipment> findBySiteReferenceIdAndPhysicalShelfPositionAndFrameAndDirContainerTypeContainer(
			BigDecimal siteReferenceId, String physicalShelfPosition, String frame, String container);

	List<Equipment> findByFrRefKeyNameAndFrRefKeyValue(String frRefKeyName, String frRefKeyValue);

	List<Equipment> findByPhysicalEquipmentReferenceId(Long equipId);

	List<Equipment> findByPhysicalEquipmentReferenceIdAndTidLogicalAndInstanceType(long equipId, String tidLogical,
			String instanceType);

	List<Equipment> findByTidPhysicalAndInstanceType(String tidPhysical, String instanceType);

	List<Equipment> findBySiteReferenceIdAndDirEqpType(BigDecimal locationId, String dirEqpType);
	
	List<Equipment> findByTidLogicalAndInstanceType(String tidLogical, String instanceType);
	
	@Query(value = "SELECT * from EQUIPMENT suEqp where suEqp.PHYSICAL_EQUIPMENT_REFERENCE_ID in ( "
			+ "SELECT  otherEqp.PHYSICAL_EQUIPMENT_REFERENCE_ID from EQUIPMENT otherEqp where otherEqp.TID_LOGICAL = :tidLogical) and suEqp.FUNCTIONAL_TYPE = :suFunctionalType",nativeQuery = true)
	List<Equipment> getSuEquipments(@Param("tidLogical") String tidLogical,
			@Param("suFunctionalType") String suFunctionalType);
	
	int countByHostNameIgnoreCase(String hostname);
	
	List<Equipment> findByLocationClliAndFrameAndHiLocationReferenceAndDirContainerTypeContainer(String locationClli, String frame,
			String hiLocationReference, String contaniner);
	
	Equipment findFirstByFrRefKeyNameAndFrRefKeyValueAndDirContainerTypeContainer(String frRefKeyName, String frRefKeyValue,String dirContainerType);
	List<Equipment> findByFrRefKeyNameAndFrRefKeyValueAndDirContainerTypeContainer(String frRefKeyName, String frRefKeyValue,String dirContainerType);
	Equipment findFirstByFrRefKeyNameAndFrRefKeyValue(String frRefKeyName, String frRefKeyValue);
}