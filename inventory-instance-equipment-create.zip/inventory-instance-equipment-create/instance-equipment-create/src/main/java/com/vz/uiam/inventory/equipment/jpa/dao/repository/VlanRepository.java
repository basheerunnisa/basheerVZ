package com.vz.uiam.inventory.equipment.jpa.dao.repository;


import org.javers.spring.annotation.JaversSpringDataAuditable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.inventory.equipment.jpa.dao.model.Vlan;

@Transactional
@JaversSpringDataAuditable
public interface VlanRepository extends JpaRepository<Vlan, Long> {

	Vlan findFirstByMarketAndVendorAndStatusOrderByFirstVlanAsc(String market, String vendor, String status);

}
