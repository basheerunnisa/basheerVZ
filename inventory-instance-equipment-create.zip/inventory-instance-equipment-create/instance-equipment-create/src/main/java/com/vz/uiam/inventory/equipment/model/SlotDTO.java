package com.vz.uiam.inventory.equipment.model;

import java.io.Serializable;
import java.math.BigDecimal;

import org.springframework.hateoas.ResourceSupport;

public class SlotDTO extends ResourceSupport  implements Serializable {
    /**
     
     * This field corresponds to the database column XNG.SLOT_INST.SLOT_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Long slotInstId;

    /**
     
     * This field corresponds to the database column XNG.SLOT_INST.EQUIP_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Long equipInstId;

    /**
     
     * This field corresponds to the database column XNG.SLOT_INST.PARENT_CARD_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Long parentCardInstId;

    /**
     
     * This field corresponds to the database column XNG.SLOT_INST.SLOT
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String slot;

    /**
     
     * This field corresponds to the database column XNG.SLOT_INST.CARD_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private Long cardInstId;

    /**
     
     * This field corresponds to the database column XNG.SLOT_INST.REL_ORDER
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String relOrder;

    /**
     
     * This field corresponds to the database column XNG.SLOT_INST.DIM_HEIGHT
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private BigDecimal dimHeight;

    /**
     
     * This field corresponds to the database column XNG.SLOT_INST.DIM_WIDTH
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private BigDecimal dimWidth;

    /**
     
     * This field corresponds to the database column XNG.SLOT_INST.DIM_DEPTH
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private BigDecimal dimDepth;

    /**
     
     * This field corresponds to the database column XNG.SLOT_INST.DIM_DIST_TO_BASE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private BigDecimal dimDistToBase;

    /**
     
     * This field corresponds to the database column XNG.SLOT_INST.DIM_DIST_TO_LEFT
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private BigDecimal dimDistToLeft;

    /**
     
     * This field corresponds to the database column XNG.SLOT_INST.DIM_DIST_TO_FRONT
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private BigDecimal dimDistToFront;

    /**
     
     * This field corresponds to the database column XNG.SLOT_INST.DESCRIPTION
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String description;

    /**
     
     * This field corresponds to the database column XNG.SLOT_INST.FR_REF_KEY_NAME
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String frRefKeyName;

    /**
     
     * This field corresponds to the database column XNG.SLOT_INST.FR_REF_KEY_VALUE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String frRefKeyValue;

    /**
     
     * This field corresponds to the database column XNG.SLOT_INST.AID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    private String aid;

    /**
     
     * This field corresponds to the database table XNG.SLOT_INST
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    
    private String slotName;
    
    private String plane;
    
    private Boolean trafficBearing; 
       
    private static final long serialVersionUID = 1L;

    /**
     
     * This method returns the value of the database column XNG.SLOT_INST.SLOT_INST_ID
     *
     * @return the value of XNG.SLOT_INST.SLOT_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Long getSlotInstId() {
        return slotInstId;
    }

    /**
     
     * This method sets the value of the database column XNG.SLOT_INST.SLOT_INST_ID
     *
     * @param slotInstId the value for XNG.SLOT_INST.SLOT_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setSlotInstId(Long slotInstId) {
        this.slotInstId = slotInstId;
    }

    /**
     
     * This method returns the value of the database column XNG.SLOT_INST.EQUIP_INST_ID
     *
     * @return the value of XNG.SLOT_INST.EQUIP_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Long getEquipInstId() {
        return equipInstId;
    }

    /**
     
     * This method sets the value of the database column XNG.SLOT_INST.EQUIP_INST_ID
     *
     * @param equipInstId the value for XNG.SLOT_INST.EQUIP_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setEquipInstId(Long equipInstId) {
        this.equipInstId = equipInstId;
    }

    /**
     
     * This method returns the value of the database column XNG.SLOT_INST.PARENT_CARD_INST_ID
     *
     * @return the value of XNG.SLOT_INST.PARENT_CARD_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Long getParentCardInstId() {
        return parentCardInstId;
    }

    /**
     
     * This method sets the value of the database column XNG.SLOT_INST.PARENT_CARD_INST_ID
     *
     * @param parentCardInstId the value for XNG.SLOT_INST.PARENT_CARD_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setParentCardInstId(Long parentCardInstId) {
        this.parentCardInstId = parentCardInstId;
    }

    /**
     
     * This method returns the value of the database column XNG.SLOT_INST.SLOT
     *
     * @return the value of XNG.SLOT_INST.SLOT
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getSlot() {
        return slot;
    }

    /**
     
     * This method sets the value of the database column XNG.SLOT_INST.SLOT
     *
     * @param slot the value for XNG.SLOT_INST.SLOT
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setSlot(String slot) {
        this.slot = slot == null ? null : slot.trim();
    }

    /**
     
     * This method returns the value of the database column XNG.SLOT_INST.CARD_INST_ID
     *
     * @return the value of XNG.SLOT_INST.CARD_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public Long getCardInstId() {
        return cardInstId;
    }

    /**
     
     * This method sets the value of the database column XNG.SLOT_INST.CARD_INST_ID
     *
     * @param cardInstId the value for XNG.SLOT_INST.CARD_INST_ID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setCardInstId(Long cardInstId) {
        this.cardInstId = cardInstId;
    }

    /**
     
     * This method returns the value of the database column XNG.SLOT_INST.REL_ORDER
     *
     * @return the value of XNG.SLOT_INST.REL_ORDER
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getRelOrder() {
        return relOrder;
    }

    /**
     
     * This method sets the value of the database column XNG.SLOT_INST.REL_ORDER
     *
     * @param relOrder the value for XNG.SLOT_INST.REL_ORDER
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setRelOrder(String relOrder) {
        this.relOrder = relOrder;
    }

    /**
     
     * This method returns the value of the database column XNG.SLOT_INST.DIM_HEIGHT
     *
     * @return the value of XNG.SLOT_INST.DIM_HEIGHT
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public BigDecimal getDimHeight() {
        return dimHeight;
    }

    /**
     
     * This method sets the value of the database column XNG.SLOT_INST.DIM_HEIGHT
     *
     * @param dimHeight the value for XNG.SLOT_INST.DIM_HEIGHT
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setDimHeight(BigDecimal dimHeight) {
        this.dimHeight = dimHeight;
    }

    /**
     
     * This method returns the value of the database column XNG.SLOT_INST.DIM_WIDTH
     *
     * @return the value of XNG.SLOT_INST.DIM_WIDTH
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public BigDecimal getDimWidth() {
        return dimWidth;
    }

    /**
     
     * This method sets the value of the database column XNG.SLOT_INST.DIM_WIDTH
     *
     * @param dimWidth the value for XNG.SLOT_INST.DIM_WIDTH
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setDimWidth(BigDecimal dimWidth) {
        this.dimWidth = dimWidth;
    }

    /**
     
     * This method returns the value of the database column XNG.SLOT_INST.DIM_DEPTH
     *
     * @return the value of XNG.SLOT_INST.DIM_DEPTH
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public BigDecimal getDimDepth() {
        return dimDepth;
    }

    /**
     
     * This method sets the value of the database column XNG.SLOT_INST.DIM_DEPTH
     *
     * @param dimDepth the value for XNG.SLOT_INST.DIM_DEPTH
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setDimDepth(BigDecimal dimDepth) {
        this.dimDepth = dimDepth;
    }

    /**
     
     * This method returns the value of the database column XNG.SLOT_INST.DIM_DIST_TO_BASE
     *
     * @return the value of XNG.SLOT_INST.DIM_DIST_TO_BASE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public BigDecimal getDimDistToBase() {
        return dimDistToBase;
    }

    /**
     
     * This method sets the value of the database column XNG.SLOT_INST.DIM_DIST_TO_BASE
     *
     * @param dimDistToBase the value for XNG.SLOT_INST.DIM_DIST_TO_BASE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setDimDistToBase(BigDecimal dimDistToBase) {
        this.dimDistToBase = dimDistToBase;
    }

    /**
     
     * This method returns the value of the database column XNG.SLOT_INST.DIM_DIST_TO_LEFT
     *
     * @return the value of XNG.SLOT_INST.DIM_DIST_TO_LEFT
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public BigDecimal getDimDistToLeft() {
        return dimDistToLeft;
    }

    /**
     
     * This method sets the value of the database column XNG.SLOT_INST.DIM_DIST_TO_LEFT
     *
     * @param dimDistToLeft the value for XNG.SLOT_INST.DIM_DIST_TO_LEFT
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setDimDistToLeft(BigDecimal dimDistToLeft) {
        this.dimDistToLeft = dimDistToLeft;
    }

    /**
     
     * This method returns the value of the database column XNG.SLOT_INST.DIM_DIST_TO_FRONT
     *
     * @return the value of XNG.SLOT_INST.DIM_DIST_TO_FRONT
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public BigDecimal getDimDistToFront() {
        return dimDistToFront;
    }

    /**
     
     * This method sets the value of the database column XNG.SLOT_INST.DIM_DIST_TO_FRONT
     *
     * @param dimDistToFront the value for XNG.SLOT_INST.DIM_DIST_TO_FRONT
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setDimDistToFront(BigDecimal dimDistToFront) {
        this.dimDistToFront = dimDistToFront;
    }

    /**
     
     * This method returns the value of the database column XNG.SLOT_INST.DESCRIPTION
     *
     * @return the value of XNG.SLOT_INST.DESCRIPTION
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getDescription() {
        return description;
    }

    /**
     
     * This method sets the value of the database column XNG.SLOT_INST.DESCRIPTION
     *
     * @param description the value for XNG.SLOT_INST.DESCRIPTION
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    /**
     
     * This method returns the value of the database column XNG.SLOT_INST.FR_REF_KEY_NAME
     *
     * @return the value of XNG.SLOT_INST.FR_REF_KEY_NAME
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getFrRefKeyName() {
        return frRefKeyName;
    }

    /**
     
     * This method sets the value of the database column XNG.SLOT_INST.FR_REF_KEY_NAME
     *
     * @param frRefKeyName the value for XNG.SLOT_INST.FR_REF_KEY_NAME
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setFrRefKeyName(String frRefKeyName) {
        this.frRefKeyName = frRefKeyName == null ? null : frRefKeyName.trim();
    }

    /**
     
     * This method returns the value of the database column XNG.SLOT_INST.FR_REF_KEY_VALUE
     *
     * @return the value of XNG.SLOT_INST.FR_REF_KEY_VALUE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getFrRefKeyValue() {
        return frRefKeyValue;
    }

    /**
     
     * This method sets the value of the database column XNG.SLOT_INST.FR_REF_KEY_VALUE
     *
     * @param frRefKeyValue the value for XNG.SLOT_INST.FR_REF_KEY_VALUE
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setFrRefKeyValue(String frRefKeyValue) {
        this.frRefKeyValue = frRefKeyValue == null ? null : frRefKeyValue.trim();
    }

    /**
     
     * This method returns the value of the database column XNG.SLOT_INST.AID
     *
     * @return the value of XNG.SLOT_INST.AID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public String getAid() {
        return aid;
    }

    /**
     
     * This method sets the value of the database column XNG.SLOT_INST.AID
     *
     * @param aid the value for XNG.SLOT_INST.AID
     *
     *  Thu Apr 02 18:10:43 EDT 2015
     */
    public void setAid(String aid) {
        this.aid = aid == null ? null : aid.trim();
    }

	public String getSlotName() {
		return slotName;
	}

	public void setSlotName(String slotName) {
		this.slotName = slotName;
	}
	
	public Boolean getTrafficBearing() {
		return trafficBearing;
	}

	public void setTrafficBearing(Boolean trafficBearing) {		
		this.trafficBearing = trafficBearing;
	}
	
}