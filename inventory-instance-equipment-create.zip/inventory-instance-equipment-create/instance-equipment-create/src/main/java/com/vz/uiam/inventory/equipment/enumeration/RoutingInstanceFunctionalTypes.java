package com.vz.uiam.inventory.equipment.enumeration;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Anju Rajput
 * @date 01-Feb-2018
 *
 */
public enum RoutingInstanceFunctionalTypes {

	INET("vRI-INET"), INFR("vRI-INFR"), SSE("vRI-SSE"), VPN("vRI-VPN");

	private String functionalTypes;

	private RoutingInstanceFunctionalTypes(String functionalTypes) {
		this.functionalTypes = functionalTypes;
	}

	/**
	 * @return the functionalTypes
	 */
	public String getFunctionalTypes() {
		return functionalTypes;
	}

	private static final Map<String, RoutingInstanceFunctionalTypes> routingInstanceFunctionalTypesMap = new HashMap<>();

	static {
		for (RoutingInstanceFunctionalTypes rIFunctionalTypes : RoutingInstanceFunctionalTypes.values()) {
			routingInstanceFunctionalTypesMap.put(rIFunctionalTypes.getFunctionalTypes(), rIFunctionalTypes);
		}
	}

	public static boolean contains(final String functionalType) {
		return functionalType != null
				? routingInstanceFunctionalTypesMap.get(functionalType) != null ? true : false : false;
	}
}
