package com.vz.uiam.inventory.equipment.jpa.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.javers.core.metamodel.annotation.TypeName;

import com.vz.uiam.inventory.equipment.model.validator.EntityValidator;

/**
 * The persistent class for the PORT database table.
 * 
 */
@Entity
@Table(name = "PORT")
@TypeName("Port")
@NamedQuery(name = "Port.findAll", query = "SELECT p FROM Port p")
public class Port implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PORT_REFERENCE_ID")
	private Long portReferenceId;

	@Column(name = "A_WIRED_PORT_REF_ID")
	private BigDecimal aWiredPortRefId;

	private String aid;

	@Column(name = "ALIAS_AID")
	private String aliasAid;

	@Column(name = "BANDWIDTH_NAME")
	private String bandwidthName;

	@Column(name = "BANDWIDTH_REFRENCE_ID")
	private Long bandwidthRefrenceId;

	@Column(name = "CABLE_NAME")
	private String cableName;

	@Column(name = "CABLE_REFERENCE_ID")
	private Long cableReferenceId;

	@Column(name = "CABLE_STRAND")
	private String cableStrand;

	@Column(name = "CKT_NAME")
	private String cktName;

	@Column(name = "CKT_PATH_REFERENCE_ID")
	private BigDecimal cktPathReferenceId;

	@Column(name = "CKT_REFRENCE_ID")
	private BigDecimal cktRefrenceId;

	@Column(name = "CONNECTOR_TYPE")
	private String connectorType;

	@Temporal(TemporalType.DATE)
	@Column(name = "DATE_PROVISIONED")
	private Date dateProvisioned;

	private String description;

	@Column(name = "DEVICE_IP")
	private String deviceIp;

	private String direction;

	@Column(name = "DISPATCH_PORT_NAME")
	private String dispatchPortName;

	@Column(name = "EQP_REFERENCE_ID")
	private long eqpReferenceId;

	@Column(name = "FR_REF_KEY_NAME")
	private String frRefKeyName;

	@Column(name = "FR_REF_KEY_VALUE")
	private String frRefKeyValue;

	@Column(name = "FUNCTIONAL_TYPE")
	private String functionalType;

	@Column(name = "LAST_MODIFIED_BY")
	private String lastModifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_MODIFIED_TIME_STAMP")
	private Date lastModifiedTimeStamp;

	@Column(name = "NEXT_CHANNEL_REFERENCE_ID")
	private BigDecimal nextChannelReferenceId;

	@Column(name = "NEXT_PATH_REFERENCE_ID")
	private BigDecimal nextPathReferenceId;

	@Column(name = "PARENT_PORT_CHANNEL")
	private BigDecimal parentPortChannel;

	@Column(name = "PARENT_PORT_CHANNEL_NAME")
	private String parentPortChannelName;

	@Column(name = "PARENT_PORT_REF_ID")
	private Long parentPortRefId;

	@Column(name = "PATH_CHANNEL_REF_ID")
	private BigDecimal pathChannelRefId;

	@Column(name = "PORT_NAME")
	private String portName;

	@Column(name = "PORT_NUMBER")
	private long portNumber;

	@Column(name = "PORT_RESVATION_REF_ID")
	private BigDecimal portResvationRefId;

	@Column(name = "PORT_ROLE")
	private String portRole;

	@Column(name = "PORT_SPEC_REFERENCE_ID")
	private long portSpecReferenceId;

	@Column(name = "PORT_STATUS")
	private String portStatus;

	@Column(name = "RELATED_PORT_REF_ID")
	private Long relatedPortRefId;

	@Column(name = "RELATED_SPEC_REF_ID")
	private BigDecimal relatedSpecRefId;

	private String relation;

	@Column(name = "SITE_REFERENCE_ID")
	private Long siteReferenceId;

	@Column(name = "SLOT_REFERENCE_ID")
	private Long slotReferenceId;

	@Column(name = "TID_LOGICAL")
	private String tidLogical;

	@Column(name = "TID_PHYSICAL")
	private String tidPhysical;

	@Column(name = "TP_TYPE")
	private String tpType;

	@Column(name = "VIRTUAL_PORT")
	private String virtualPort;

	private String wavelength;

	@Column(name = "Z_WIRED_PORT_REF_ID")
	private BigDecimal zWiredPortRefId;

	@Column(name = "CARD_REFERENCE_ID")
	private Long cardReferenceId;

	@Column(name = "PORT_TYPE")
	private String dirPortType;

	@Column(name = "Block_Reason_Code")
	private String blockReasonCode;
	
	@Column(name = "ADMIN_STATUS")
	private String adminStatus;

	public Port() {
	}

	public Long getPortReferenceId() {
		return this.portReferenceId;
	}

	public void setPortReferenceId(Long portReferenceId) {
		this.portReferenceId = portReferenceId;
	}

	public BigDecimal getAWiredPortRefId() {
		return this.aWiredPortRefId;
	}

	public void setAWiredPortRefId(BigDecimal aWiredPortRefId) {
		this.aWiredPortRefId = aWiredPortRefId;
	}

	public String getAid() {
		return this.aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public String getAliasAid() {
		return this.aliasAid;
	}

	public void setAliasAid(String aliasAid) {
		this.aliasAid = aliasAid;
	}

	public String getBandwidthName() {
		return this.bandwidthName;
	}

	public void setBandwidthName(String bandwidthName) {
		this.bandwidthName = bandwidthName;
	}

	public Long getBandwidthRefrenceId() {
		return this.bandwidthRefrenceId;
	}

	public void setBandwidthRefrenceId(Long bandwidthRefrenceId) {
		this.bandwidthRefrenceId = bandwidthRefrenceId;
	}

	public String getCableName() {
		return this.cableName;
	}

	public void setCableName(String cableName) {
		this.cableName = cableName;
	}

	public Long getCableReferenceId() {
		return this.cableReferenceId;
	}

	public void setCableReferenceId(Long cableReferenceId) {
		this.cableReferenceId = cableReferenceId;
	}

	public String getCableStrand() {
		return this.cableStrand;
	}

	public void setCableStrand(String cableStrand) {
		this.cableStrand = cableStrand;
	}

	public String getCktName() {
		return this.cktName;
	}

	public void setCktName(String cktName) {
		this.cktName = cktName;
	}

	public BigDecimal getCktPathReferenceId() {
		return this.cktPathReferenceId;
	}

	public void setCktPathReferenceId(BigDecimal cktPathReferenceId) {
		this.cktPathReferenceId = cktPathReferenceId;
	}

	public BigDecimal getCktRefrenceId() {
		return this.cktRefrenceId;
	}

	public void setCktRefrenceId(BigDecimal cktRefrenceId) {
		this.cktRefrenceId = cktRefrenceId;
	}

	public String getConnectorType() {
		return this.connectorType;
	}

	public void setConnectorType(String connectorType) {
		this.connectorType = connectorType;
	}

	public Date getDateProvisioned() {
		return this.dateProvisioned;
	}

	public void setDateProvisioned(Date dateProvisioned) {
		this.dateProvisioned = dateProvisioned;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDeviceIp() {
		return this.deviceIp;
	}

	public void setDeviceIp(String deviceIp) {
		this.deviceIp = deviceIp;
	}

	public String getDirection() {
		return this.direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getDispatchPortName() {
		return this.dispatchPortName;
	}

	public void setDispatchPortName(String dispatchPortName) {
		this.dispatchPortName = dispatchPortName;
	}

	public long getEqpReferenceId() {
		return this.eqpReferenceId;
	}

	public void setEqpReferenceId(long eqpReferenceId) {
		this.eqpReferenceId = eqpReferenceId;
	}

	public String getFrRefKeyName() {
		return this.frRefKeyName;
	}

	public void setFrRefKeyName(String frRefKeyName) {
		this.frRefKeyName = frRefKeyName;
	}

	public String getFrRefKeyValue() {
		return this.frRefKeyValue;
	}

	public void setFrRefKeyValue(String frRefKeyValue) {
		this.frRefKeyValue = frRefKeyValue;
	}

	public String getFunctionalType() {
		return this.functionalType;
	}

	public void setFunctionalType(String functionalType) {
		this.functionalType = functionalType;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifiedTimeStamp() {
		return this.lastModifiedTimeStamp;
	}

	public void setLastModifiedTimeStamp(Date lastModifiedTimeStamp) {
		this.lastModifiedTimeStamp = lastModifiedTimeStamp;
	}

	public BigDecimal getNextChannelReferenceId() {
		return this.nextChannelReferenceId;
	}

	public void setNextChannelReferenceId(BigDecimal nextChannelReferenceId) {
		this.nextChannelReferenceId = nextChannelReferenceId;
	}

	public BigDecimal getNextPathReferenceId() {
		return this.nextPathReferenceId;
	}

	public void setNextPathReferenceId(BigDecimal nextPathReferenceId) {
		this.nextPathReferenceId = nextPathReferenceId;
	}

	public BigDecimal getParentPortChannel() {
		return this.parentPortChannel;
	}

	public void setParentPortChannel(BigDecimal parentPortChannel) {
		this.parentPortChannel = parentPortChannel;
	}

	public String getParentPortChannelName() {
		return this.parentPortChannelName;
	}

	public void setParentPortChannelName(String parentPortChannelName) {
		this.parentPortChannelName = parentPortChannelName;
	}

	public Long getParentPortRefId() {
		return this.parentPortRefId;
	}

	public void setParentPortRefId(Long parentPortRefId) {
		this.parentPortRefId = parentPortRefId;
	}

	public BigDecimal getPathChannelRefId() {
		return this.pathChannelRefId;
	}

	public void setPathChannelRefId(BigDecimal pathChannelRefId) {
		this.pathChannelRefId = pathChannelRefId;
	}

	public String getPortName() {
		return this.portName;
	}

	public void setPortName(String portName) {
		this.portName = portName;
	}

	public long getPortNumber() {
		return this.portNumber;
	}

	public void setPortNumber(long portNumber) {
		this.portNumber = portNumber;
	}

	public BigDecimal getPortResvationRefId() {
		return this.portResvationRefId;
	}

	public void setPortResvationRefId(BigDecimal portResvationRefId) {
		this.portResvationRefId = portResvationRefId;
	}

	public String getPortRole() {
		return this.portRole;
	}

	public void setPortRole(String portRole) {
		this.portRole = portRole;
	}

	public long getPortSpecReferenceId() {
		return this.portSpecReferenceId;
	}

	public void setPortSpecReferenceId(long portSpecReferenceId) {
		this.portSpecReferenceId = portSpecReferenceId;
	}

	public String getPortStatus() {
		return EntityValidator.validateStatus(portStatus, this.getClass());
	}

	public void setPortStatus(String portStatus) {
		this.portStatus = portStatus;
	}

	public Long getRelatedPortRefId() {
		return this.relatedPortRefId;
	}

	public void setRelatedPortRefId(Long relatedPortRefId) {
		this.relatedPortRefId = relatedPortRefId;
	}

	public BigDecimal getRelatedSpecRefId() {
		return this.relatedSpecRefId;
	}

	public void setRelatedSpecRefId(BigDecimal relatedSpecRefId) {
		this.relatedSpecRefId = relatedSpecRefId;
	}

	public String getRelation() {
		return this.relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public Long getSiteReferenceId() {
		return this.siteReferenceId;
	}

	public void setSiteReferenceId(Long siteReferenceId) {
		this.siteReferenceId = siteReferenceId;
	}

	public Long getSlotReferenceId() {
		return this.slotReferenceId;
	}

	public void setSlotReferenceId(Long slotReferenceId) {
		this.slotReferenceId = slotReferenceId;
	}

	public String getTidLogical() {
		return this.tidLogical;
	}

	public void setTidLogical(String tidLogical) {
		this.tidLogical = tidLogical;
	}

	public String getTidPhysical() {
		return this.tidPhysical;
	}

	public void setTidPhysical(String tidPhysical) {
		this.tidPhysical = tidPhysical;
	}

	public String getTpType() {
		return this.tpType;
	}

	public void setTpType(String tpType) {
		this.tpType = tpType;
	}

	public String getVirtualPort() {
		return this.virtualPort;
	}

	public void setVirtualPort(String virtualPort) {
		this.virtualPort = virtualPort;
	}

	public String getWavelength() {
		return this.wavelength;
	}

	public void setWavelength(String wavelength) {
		this.wavelength = wavelength;
	}

	public BigDecimal getZWiredPortRefId() {
		return this.zWiredPortRefId;
	}

	public void setZWiredPortRefId(BigDecimal zWiredPortRefId) {
		this.zWiredPortRefId = zWiredPortRefId;
	}

	public Long getCardReferenceId() {
		return cardReferenceId;
	}

	public void setCardReferenceId(Long cardReferenceId) {
		this.cardReferenceId = cardReferenceId;
	}

	public String getDirPortType() {
		return EntityValidator.validateType(dirPortType, this.getClass());	
	}

	public void setDirPortType(String dirPortType) {
		this.dirPortType = dirPortType;
	}

	/**
	 * @return the blockReasonCode
	 */
	public String getBlockReasonCode() {
		return blockReasonCode;
	}

	/**
	 * @param blockReasonCode
	 *            the blockReasonCode to set
	 */
	public void setBlockReasonCode(String blockReasonCode) {
		this.blockReasonCode = blockReasonCode;
	}

	public String getAdminStatus() {
		return adminStatus;
	}

	public void setAdminStatus(String adminStatus) {
		this.adminStatus = adminStatus;
	}

	@Override
	public String toString() {
		return "Port [portReferenceId=" + portReferenceId + ", aWiredPortRefId="
				+ aWiredPortRefId + ", aid=" + aid + ", aliasAid=" + aliasAid + ", bandwidthName=" + bandwidthName
				+ ", bandwidthRefrenceId=" + bandwidthRefrenceId + ", cableName=" + cableName + ", cableReferenceId="
				+ cableReferenceId + ", cableStrand=" + cableStrand + ", cktName=" + cktName + ", cktPathReferenceId="
				+ cktPathReferenceId + ", cktRefrenceId=" + cktRefrenceId + ", connectorType=" + connectorType
				+ ", dateProvisioned=" + dateProvisioned + ", description=" + description + ", deviceIp=" + deviceIp
				+ ", direction=" + direction + ", dispatchPortName=" + dispatchPortName + ", eqpReferenceId="
				+ eqpReferenceId + ", frRefKeyName=" + frRefKeyName + ", frRefKeyValue=" + frRefKeyValue
				+ ", functionalType=" + functionalType + ", lastModifiedBy=" + lastModifiedBy
				+ ", lastModifiedTimeStamp=" + lastModifiedTimeStamp + ", nextChannelReferenceId="
				+ nextChannelReferenceId + ", nextPathReferenceId=" + nextPathReferenceId + ", parentPortChannel="
				+ parentPortChannel + ", parentPortChannelName=" + parentPortChannelName + ", parentPortRefId="
				+ parentPortRefId + ", pathChannelRefId=" + pathChannelRefId + ", portName=" + portName
				+ ", portNumber=" + portNumber + ", portResvationRefId=" + portResvationRefId + ", portRole=" + portRole
				+ ", portSpecReferenceId=" + portSpecReferenceId + ", portStatus=" + portStatus + ", relatedPortRefId="
				+ relatedPortRefId + ", relatedSpecRefId=" + relatedSpecRefId + ", relation=" + relation
				+ ", siteReferenceId=" + siteReferenceId + ", slotReferenceId=" + slotReferenceId + ", tidLogical="
				+ tidLogical + ", tidPhysical=" + tidPhysical + ", tpType=" + tpType + ", virtualPort=" + virtualPort
				+ ", wavelength=" + wavelength + ", zWiredPortRefId=" + zWiredPortRefId + ", cardReferenceId="
				+ cardReferenceId + ", dirPortType=" + dirPortType + ", blockReasonCode=" + blockReasonCode
				+ ", adminStatus=" + adminStatus + "]";
	}

}