delete from CARD_SPEC where NAME = 'EC_CS1';

delete from SITE where SITE_NAME = 'TEST_SITE1';