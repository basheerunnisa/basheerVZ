delete from EQUIPMENT where EQP_NAME = 'EQP_CREATE_E';

delete from EQUIPMENT_SPEC where NAME = 'EQP_CREATE_ES';

delete from SITE where SITE_NAME = 'TEST_SITE1';