delete from EQUIPMENT_DOMAIN_MAP where EQP_REFERENCE_ID in (select EQP_REFERENCE_ID from EQUIPMENT where EQP_NAME = 'EQP_MODIFY_E3');

delete from EQUIPMENT where EQP_NAME = 'EQP_MODIFY_E3';
delete from EQUIPMENT where EQP_NAME = 'EQP_MODIFY_R3';

delete from EQUIPMENT_SPEC where NAME = 'EQP_MODIFY_ES3';
delete from EQUIPMENT_SPEC where NAME = 'EQP_MODIFY_ES4';
delete from EQUIPMENT_SPEC where NAME = 'EQP_MODIFY_ES5';

delete from SITE where SITE_NAME='NB_SITE3';
delete from SITE where SITE_NAME='NB_SITE4';
delete from SITE where SITE_NAME='NB_SITE5';