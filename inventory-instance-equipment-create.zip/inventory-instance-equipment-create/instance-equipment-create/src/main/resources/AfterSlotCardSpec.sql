delete from SLOT_CARD_SPEC_MAP where SLOT_SPEC_REF_ID in (select SLOT_SPEC_REF_ID from SLOT_SPEC where SLOT_NAME = 'EC_SS');

delete from CARD_SPEC where NAME = 'EC_CS';

delete from SLOT_SPEC where SLOT_NAME = 'EC_SS';

delete from EQUIPMENT_SPEC where NAME = 'EQP_CREATE_ES';

delete from CARD_SPEC where NAME = 'EC_CS1';