delete p.* from PORT p join EQUIPMENT e on e.EQP_REFERENCE_ID = p.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_E1';
delete p.* from PORT p join EQUIPMENT e on e.EQP_REFERENCE_ID = p.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_E2';
delete p.* from PORT p join EQUIPMENT e on e.EQP_REFERENCE_ID = p.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_E3';
delete p.* from PORT p join EQUIPMENT e on e.EQP_REFERENCE_ID = p.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_E4';
delete p.* from PORT p join EQUIPMENT e on e.EQP_REFERENCE_ID = p.EQP_REFERENCE_ID where e.EQP_NAME = 'TEST_FRAME';
delete p.* from PORT p join EQUIPMENT e on e.EQP_REFERENCE_ID = p.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_ES';

delete from PORT_SPEC where PORT_NAME = 'EQP_CREATE_LS';
delete from PORT_SPEC where PORT_NAME = 'EQP_CREATE_PS';

delete c.* from CARD c join EQUIPMENT e on e.EQP_REFERENCE_ID = c.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_E1';
delete s.* from SLOT s join EQUIPMENT e on e.EQP_REFERENCE_ID = s.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_E1';

delete c.* from CARD c join EQUIPMENT e on e.EQP_REFERENCE_ID = c.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_E2';
delete s.* from SLOT s join EQUIPMENT e on e.EQP_REFERENCE_ID = s.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_E2';

delete c.* from CARD c join EQUIPMENT e on e.EQP_REFERENCE_ID = c.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_E3';
delete s.* from SLOT s join EQUIPMENT e on e.EQP_REFERENCE_ID = s.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_E3';

delete c.* from CARD c join EQUIPMENT e on e.EQP_REFERENCE_ID = c.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_E4';
delete s.* from SLOT s join EQUIPMENT e on e.EQP_REFERENCE_ID = s.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_E4';

delete c.* from CARD c join EQUIPMENT e on e.EQP_REFERENCE_ID = c.EQP_REFERENCE_ID where e.EQP_NAME = 'TEST_FRAME';
delete s.* from SLOT s join EQUIPMENT e on e.EQP_REFERENCE_ID = s.EQP_REFERENCE_ID where e.EQP_NAME = 'TEST_FRAME';

delete c.* from CARD c join EQUIPMENT e on e.EQP_REFERENCE_ID = c.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_ES';
delete s.* from SLOT s join EQUIPMENT e on e.EQP_REFERENCE_ID = s.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_ES';

delete edm.* from EQUIPMENT_DOMAIN_MAP edm join EQUIPMENT e on e.EQP_REFERENCE_ID = edm.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_E';
delete edm.* from EQUIPMENT_DOMAIN_MAP edm join EQUIPMENT e on e.EQP_REFERENCE_ID = edm.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_E1';
delete edm.* from EQUIPMENT_DOMAIN_MAP edm join EQUIPMENT e on e.EQP_REFERENCE_ID = edm.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_E2';
delete edm.* from EQUIPMENT_DOMAIN_MAP edm join EQUIPMENT e on e.EQP_REFERENCE_ID = edm.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_E3';
delete edm.* from EQUIPMENT_DOMAIN_MAP edm join EQUIPMENT e on e.EQP_REFERENCE_ID = edm.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_E4';
delete edm.* from EQUIPMENT_DOMAIN_MAP edm join EQUIPMENT e on e.EQP_REFERENCE_ID = edm.EQP_REFERENCE_ID where e.EQP_NAME = 'TEST_FRAME';
delete edm.* from EQUIPMENT_DOMAIN_MAP edm join EQUIPMENT e on e.EQP_REFERENCE_ID = edm.EQP_REFERENCE_ID where e.EQP_NAME = 'EQP_CREATE_ES';

delete from EQUIPMENT where EQP_NAME = 'EQP_CREATE_E';
delete from EQUIPMENT where EQP_NAME = 'EQP_CREATE_E1';
delete from EQUIPMENT where EQP_NAME = 'EQP_CREATE_E2';
delete from EQUIPMENT where EQP_NAME = 'EQP_CREATE_E3';
delete from EQUIPMENT where EQP_NAME = 'EQP_CREATE_E4';
delete from EQUIPMENT where EQP_NAME = 'TEST_FRAME';
delete from EQUIPMENT where EQP_NAME = 'EQP_CREATE_ES';

delete scsm.* from SLOT_CARD_SPEC_MAP scsm join SLOT_SPEC sc on sc.SLOT_SPEC_REF_ID = scsm.SLOT_SPEC_REF_ID where sc.SLOT_NAME = 'EC_SS';

delete from CARD_SPEC where NAME = 'EC_CS';

delete from SLOT_SPEC where SLOT_NAME = 'EC_SS';

delete from EQUIPMENT_SPEC where NAME = 'EQP_CREATE_ES';

delete from CARD_SPEC where NAME = 'EC_CS1';

delete from SITE where SITE_NAME like 'SITE_EQP_CREATE_E%' ;
delete from SITE where SITE_NAME = 'TEST_SITE1';
